import argparse
from cm_commons.colors import err_print
import json
from pprint import pprint
from skylla import etl_executor
import boto3
from urllib.parse import urlparse
import pyspark
from datetime import datetime

from kharybdis import mdm_executor

from cm_commons.util.boto_functions import get_s3_bucket

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--conf_files', nargs='+', help='Set conf files', required=False)
    parser.add_argument('-m', '--movefiles', nargs='+', help='Set move flag', required=False)
    parser.add_argument('-e', '--error', action='store_true', help='Stop on error')
    parser.add_argument('-s', '--s3folder', nargs='+', help='Pick S3 folder(s)', required=False)
    parser.add_argument('-p', '--prefix',  help='Set prefix (for non-conf jobs)', required=False)
    parser.add_argument('-o', '--outputType', nargs='+', help='Set output params (parquet, postgres, csv)', required=False)
    parser.add_argument('-x', '--matchCriteria', help='Set file source for MDM matching/scheduling purposes', required=False)

    args = parser.parse_args()
    a = args._get_kwargs()

    confs = []
    params = {var: val for var, val in a if val is not None and val}

    def row_to_dict(df):
        """  Usage:
                cdf = spark.read.json(<JSON LOCATION>, multiLine=True)
                tcdf = row_to_dict(cdf.collect()[0])
        """
        if isinstance(df, pyspark.sql.Row):
            i_d = df.asDict()
            o_d = {}
            for kk, vv in i_d.items():
                o_d[kk] = row_to_dict(vv)
            return o_d
        else:
            return df

    # Check if move files was set
    move_files = False
    if 'movefiles' in params:
        if params['movefiles'][0].lower() != 'false':
            move_files = True

    # Set default prefix
    # prefix = 'cm'
    prefix = ''
    if 'prefix' in params:
        prefix= params['prefix']

    # Set default output
    output = ['postgres']
    if 'outputType' in params:
        output = params['outputType']

    match_dict = {'SF': ['crm_id'],
                  'SV': ['salesvision_id', 'entity_type_prefix'],
                  'AMG': ['salesforce_id'], #06/27
                  'AU': ['salesforce_id'],
                  'RS': ['salesforce_id'],
                  'FT': ['salesforce_id'],
                  'sf': ['crm_id'],
                  'sv': ['salesvision_id', 'entity_type_prefix'],
                  'amg': ['salesforce_id'],
                  'ft': ['salesforce_id']
                  }
    match_criteria = ['crm_id']
    match_source = 'cm'
    if 'matchCriteria' in params:
        match_criteria = match_dict[params['matchCriteria']]
        match_source = params['matchCriteria']
        print(f"using match criteria: {match_criteria}")

    # if a conf is passed, send that
    if 'conffiles' in params:
        for tid in params['conffiles']:
            o = urlparse(tid)
            s3 = boto3.resource('s3')
            obj = s3.Object(o.netloc, o.path[1:])
            conf = json.loads(obj.get()['Body'].read().decode('utf-8'))
            pprint(conf)
            confs.extend([conf])

    # if no conf file is passed, but an s3 location is, send that in a default conf
    elif 's3folder' in params:
        print("adding s3 folder to conf for reading etl files")
        for ii in params['s3folder']:
            conf = {
                "mdm_name": "external_sources",
                "prefix": prefix,
                "file_date": datetime.today().strftime("%m-%d-%Y"),
                "input_location": {
                    "emr": ii,
                },
                "output_location": {
                    "emr": f"s3://{get_s3_bucket()}/mdm-output/"
                },
                "source_name": "MDM",
                "schema_name": "MDM_schema",
                "destinations": output,
                "conf_orig": 'no conf',
                "match_criteria": match_criteria,
                "match_source": match_source
            }
            confs.extend([conf])

    # if nothing is passed revert to the default conf settings
    else:
        move_files=False

        conf = {
            "mdm_name": "external_sources",
            "prefix": prefix,
            "file_date": datetime.today().strftime("%m-%d-%Y"),
            "input_location": {
                "emr": f"s3://{get_s3_bucket()}/MDM/conf/incoming/"
            },
            "output_location": {
                "emr": f"s3://{get_s3_bucket()}/mdm-output/"
            },
            "source_name": "MDM",
            "schema_name": "MDM_schema",
            "destinations": output,
            "conf_orig": 'no conf',
            "match_criteria": match_criteria,
            "match_source": match_source
        }
        confs.extend([conf])

    pprint(confs)
    for cid in confs:
        if args.error:
            mdm_executor(cid, cid['conf_orig'], move_files=move_files)
        else:
            try:
                mdm_executor(cid, cid['conf_orig'],  move_files=move_files)
            except:
                err_print("Error processing \033[1m{}\033[0m".format(cid['mdm_name']))
