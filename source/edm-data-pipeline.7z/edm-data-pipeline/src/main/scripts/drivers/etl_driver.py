import argparse
from cm_commons.colors import err_print
import json
from pprint import pprint
from skylla import etl_executor
import boto3
from urllib.parse import urlparse
from cm_commons.util.jobstatus import logCmJob, getTime

#some chagne

if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('-s', '--sources', nargs='+', help='<Required> Set flag', required=False)
    parser.add_argument('-d', '--s3folder', nargs='+', help='Pick S3 folder(s)', required=False)
    parser.add_argument('-c', '--conffiles', nargs='+', help='Set conf files', required=False)
    parser.add_argument('-m', '--movefiles', nargs='+', help='Set move flag', required=False)
    parser.add_argument('-e', '--error', action='store_true', help='Stop on error')
    parser.add_argument('-f', '--jsonconfig',  help='pass in config file', required=False)

    args = parser.parse_args()
    a = args._get_kwargs()

    jsonconfig_passed = False
    jobid = None
    confs = []
    params = {var: val for var, val in a if val is not None and val}

    if 'sources' in params:
        for sid in params['sources']:
            import cm_commons
            confs.extend(getattr(cm_commons.conf.etl, 'conf_dict')[sid])

    import pyspark

    def row_to_dict(df):
        """  Usage:
                cdf = spark.read.json(<JSON LOCATION>, multiLine=True)
                tcdf = row_to_dict(cdf.collect()[0])
        """
        if isinstance(df, pyspark.sql.Row):
            i_d = df.asDict()
            o_d = {}
            for kk, vv in i_d.items():
                o_d[kk] = row_to_dict(vv)
            return o_d
        else:
            return df

    if 'conffiles' in params:
        for tid in params['conffiles']:
                o = urlparse(tid)
                s3 = boto3.resource('s3')
                obj = s3.Object(o.netloc, o.path[1:])
                conf = json.loads(obj.get()['Body'].read().decode('utf-8'))
                pprint(conf)
                conf['conf_orig'] = tid
                if 'loaddestinations' in params:
                    confs['destinations'] = params['loaddestinations']
                confs.extend([conf])
    elif 's3folder' in params:
        print("adding s3 folder toK conf for reading etl files")
        for ii in params['s3folder']:
            o = urlparse(ii)
            s3 = boto3.resource('s3')
            objs = s3.Bucket(o.netloc).objects.filter(Prefix=o.path[1:])
            for oo in objs:
                if oo.key.endswith('.json') or oo.key.endswith('.conf') or oo.key[-1].isdigit():
                    obj = s3.Object(o.netloc, oo.key)
                    conf = json.loads(obj.get()['Body'].read().decode('utf-8'))
                    conf['conf_orig'] = ii+oo.key[oo.key.rfind("/") + 1:]
                    pprint(conf['conf_orig'])
                    pprint(conf)
                    confs.extend([conf])
    elif 'jsonconfig' in params:
        jsonconfig_passed = True
        jsonconfig = json.loads(params['jsonconfig'])
        confs.append(jsonconfig)
        pprint(jsonconfig)

    move_files = False
    if 'movefiles' in params:
        if params['movefiles'][0].lower() != 'false':
            move_files = True


    for cid in confs:
        if jsonconfig_passed:
            jobid = cid.get('job-id', None)
            if jobid:
                jobdata = {
                    'jobid': jobid,
                    'clmaster_etl_start': getTime(),
                }
                logCmJob(**jobdata)
            try:
                etl_executor(cid, location=None, move_files=False , jobid=jobid)
            except Exception as e:
                err_print("Error processing \033[1m{}\033[0m".format(cid['etl_name']))
                if jobid:
                    jobdata = {
                            'jobid': jobid,
                            'clmaster_etl_end': f"{getTime()}",
                            'etl_status': "FAILURE",
                            'clmaster_error': f"ETL Error: {e}"
                        }
                    logCmJob(**jobdata)
                raise e
            continue

        if args.error:
            location = cid['conf_orig']
            jobid = params.get('jobid', None)
            etl_executor(cid, location, move_files=move_files, jobid=jobid)
        else:
            try:
                etl_executor(cid, location, jobid=jobid)
            except:
                err_print("Error processing \033[1m{}\033[0m".format(cid['etl_name']))
                if jobid:
                    jobdata = {
                            'jobid': jobid,
                            'clmaster_etl_end': f"{getTime()}",
                            'etl_status': "FAILURE",
                            'clmaster_error': f"ETL Error: {e}"
                        }
                logCmJob(**jobdata)

    if jobid:
        jobdata = {
                'jobid': jobid,
                'etl_status': "SUCCESS",
                'clmaster_etl_end': f"{getTime()}"
                 }
        logCmJob(**jobdata)
