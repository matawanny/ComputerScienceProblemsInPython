from circe import process_ds, process_sv_merge, process_ds_resolution, process_sf_merge
import argparse
from cm_commons.util.boto_functions import get_s3_bucket
from cm_commons import conf

if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    parser.add_argument('-j', '--job_type', help='Specify DS or SV to run specific job; default is DS', required=True)

    parser.add_argument('-c', '--sv_sf_conf_location', help='Conf location for SV job', required=False, \
                        default=f's3://{get_s3_bucket()}/CIRCE/conf/SV/incoming/')
    parser.add_argument('-p', '--prefix', help='Set table prefix', required=False, default='None')

    parser.add_argument('-s', '--src_db_name', help='Set source database', required=False, default='edmcm')
    parser.add_argument('-t', '--target_db_name', help='Set targe database', required=False, default='edmcm')

    parser.add_argument('-m', '--dest_mastered_output_dir', help='Set S3 location for writing mastered parquet',\
                                        required=False,\
                                        default=f's3://{get_s3_bucket()}/etl-output/circe/')
    parser.add_argument('-d', '--dest_conf_output_dir', help='Set S3 location for writing conf for MDM to pick up', required=False,\
                                        default=f's3://{get_s3_bucket()}/MDM/conf/circe/')
    parser.add_argument('-b', '--sv_sf_conf_batch_size', help='Set batch size for SV merge', required=False, \
                        default='1')

    args = parser.parse_args()
    a = args._get_kwargs()
    params = {var: val for var, val in a if val is not None and val}

    if 'job_type' in params:
        job_type = params['job_type']

    if 'sv_sf_conf_location' in params:
        sv_sf_conf_location = params['sv_sf_conf_location']

    prefix = ''
    if 'prefix' in params:
        table_prefix = params['prefix']
        if table_prefix == 'None' or '':
            table_prefix = ''

    if 'src_db_name' in params:
        src_db_name = params['src_db_name']

    if 'target_db_name' in params:
        target_db_name = params['target_db_name']

    if 'dest_mastered_output_dir' in params:
        dest_mastered_output_dir = params['dest_mastered_output_dir']

    if 'dest_conf_output_dir' in params:
        dest_conf_output_dir = params['dest_conf_output_dir']

    if 'sv_sf_conf_batch_size' in params:
        sv_sf_conf_batch_size = params['sv_sf_conf_batch_size']

    try:
        print("Arguments for circe:")
        print(f"job_type={job_type} processing")
        print(f"table_prefix={table_prefix}")
        print(f"src_db_name={src_db_name}")
        print(f"target_db_name={target_db_name}")

        if job_type == 'DS':
            dest_conf_output_dir = dest_conf_output_dir + "talend_ds/"
            dest_mastered_output_dir = dest_mastered_output_dir + "talend_ds/"
            print(f"dest_conf_output_dir={dest_conf_output_dir}")
            print(f"dest_mastered_output_dir={dest_mastered_output_dir}")

            process_ds.start_process(conf.circe_conf, table_prefix, src_db_name, target_db_name,\
                                                    dest_mastered_output_dir, dest_conf_output_dir)
        elif job_type == 'SV':
            print(f"sv_sf_conf_location={sv_sf_conf_location}")

            dest_conf_output_dir = dest_conf_output_dir + "sv_merge/"
            dest_mastered_output_dir = dest_mastered_output_dir + "sv_merge/"
            print(f"dest_conf_output_dir={dest_conf_output_dir}")
            print(f"dest_mastered_output_dir={dest_mastered_output_dir}")
            print(f"sv_sf_conf_batch_size={sv_sf_conf_batch_size}")

            process_sv_merge.start_process(sv_sf_conf_location, table_prefix, src_db_name, target_db_name,\
                                           dest_mastered_output_dir, dest_conf_output_dir, sv_sf_conf_batch_size)
        elif job_type == 'SF':
            print(f"sv_sf_conf_location={sv_sf_conf_location}")

            dest_conf_output_dir = dest_conf_output_dir + "sf_merge/"
            dest_mastered_output_dir = dest_mastered_output_dir + "sf_merge/"
            print(f"dest_conf_output_dir={dest_conf_output_dir}")
            print(f"dest_mastered_output_dir={dest_mastered_output_dir}")
            print(f"sv_sf_conf_batch_size={sv_sf_conf_batch_size}")

            process_sf_merge.start_process(sv_sf_conf_location, table_prefix, src_db_name, target_db_name,\
                                           dest_mastered_output_dir, dest_conf_output_dir, sv_sf_conf_batch_size)
        else:
            dest_conf_output_dir = dest_conf_output_dir + "ds_resolution/"
            dest_mastered_output_dir = dest_mastered_output_dir + "ds_resolution/"
            print(f"dest_conf_output_dir={dest_conf_output_dir}")
            print(f"dest_mastered_output_dir={dest_mastered_output_dir}")
            process_ds_resolution.start_process({}, table_prefix, src_db_name, target_db_name,\
                            dest_mastered_output_dir, dest_conf_output_dir)
    except:
        print("Error processing \033[1m{}\033[0m".format(' from circe driver'))
