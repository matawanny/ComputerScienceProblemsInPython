# # # # # # # # # # # # # # # # # # # # #
#    .'.         _=,_                   #
#  ( ref )     o_/6 /#\                 #
#  ( ref )...  \_|  ##/                 #
#    '.'        ='|--\                  #
#                /    #'-.              #
#                \#|_    _'-. /         #
#                | /  \_(  #|"          #
#               C /, --___ /            #
# # # # # # # # # # # # # # # # # # # # #

# references of referential data

import spark_functions as sf
from cm_commons.colors import suc_print

import pandas as pd
import pyspark.sql.functions as f
from itertools import chain

from cm_commons.db.cm_rule_conn import create_cm_conn

cxn = create_cm_conn()
import spark_functions


class Rule:
    """Mapping Rule
    """

    def __init__(self, meta, col, out, default=None, cxn=None, filter_expr=None, refmap_expr=None):
        self.meta = meta
        self.in_col = col
        self.out_col = out
        self.def_col = default
        self.cxn = cxn
        self.filter_expr = filter_expr
        self.refmap_expr = refmap_expr

    def generate_filter(self, df):
        if self.filter_expr:
            return call_func(df=df[self.filter_expr['col']],
                             function=self.filter_expr['func'],
                             vargs=self.filter_expr['val'])

        else:
            print('No filter used in rule')
            return df.select(f.lit(True).alias('temp599')).temp599
            # If we don't have a filter. Need to pass a literal truth column

    def generate_refmap(self):

        self.refmap = pd.read_sql_query('select {source_col}, {target_col} FROM {table}'.format(**self.refmap_expr),
                                        con=cxn[0]).set_index(self.refmap_expr['source_col']).to_dict()

        # return chain(self.refmap[self.refmap_expr['target_col']].items())
        return f.create_map([f.lit(x) for x in chain(*self.refmap[self.refmap_expr['target_col']].items())]) \
            .getItem(f.col(self.in_col))

    def process(self, df):

        temp_df = df.withColumn("edm_orig", f.col(self.out_col))
        temp_df = temp_df.withColumn(self.out_col,
                                     f.when(self.generate_filter(df), self.generate_refmap()) \
                                     .otherwise(f.col(self.in_col)))

        # flag enrichment errors

        temp_df = temp_df.withColumn("enrichment_error", f.when(f.col(self.out_col).isNull(),
                                                                f.lit(
                                                                    "key not found in {ref_map['table']}{self.in_col}")
                                                                ).otherwise(f.lit("")))
        # replace non matches with the original value
        temp_df = temp_df.withColumn(self.out_col, f.when(f.col(self.out_col).isNull(),
                                                          f.col("edm_orig")
                                                          ).otherwise(f.col(self.out_col))
                                     )

        # if self.meta['name'] == 'cm_aggregator_id':
        #     temp_df.select('etl_source', 'aggregator_id').show(truncate=False)
        #     from pprint import pprint
        #     pprint(self.generate_refmap())
        self.__doc__ = self.__doc__ + '\n' + self.meta['name']
        return temp_df.na.fill('None')


class TransformRule(Rule):

    def __init__(self, meta, transform, params):
        self.meta = meta
        self.t_fun = getattr(spark_functions, transform)
        self.params = params

    def process(self, df):
        return self.t_fun(df=df, **self.params)


def call_func(df, function, vargs=None, kwargs=None):
    func = getattr(df, function)
    return func(*vargs)


amg_salesforce_id = Rule(meta={'tables': ['entity'],
                               'type': 'mapping',
                               'name': 'amg_salesforce_id'},
                         col='salesforce_id',
                         out='salesforce_id',
                         cxn=cxn,
                         filter_expr={'func': 'isin',
                                      'col': 'etl_source',
                                      'val': ['AMG'],
                                      'and': None},
                         refmap_expr={'database': 'cm_enrichment',
                                      'table': 'amg_salesforce_id',
                                      'source_col': 'prod_id',
                                      'target_col': 'full_id'}
                         )

amg_salesforce_id_reverse = Rule(meta={'tables': ['entity'],
                                       'type': 'mapping',
                                       'name': 'amg_salesforce_id_reverse'},
                                 col='salesforce_id',
                                 out='salesforce_id',
                                 cxn=cxn,
                                 filter_expr={'func': 'isin',
                                              'col': 'etl_source',
                                              'val': ['AMG', 'amg_match'],
                                              'and': None},
                                 refmap_expr={'database': 'cm_enrichment',
                                              'table': 'amg_salesforce_id',
                                              'source_col': 'full_id',
                                              'target_col': 'prod_id'}
                                 )

au_salesforce_id = Rule(meta={'tables': ['entity'],
                              'type': 'mapping',
                              'name': 'au_salesforce_id'},
                        col='salesforce_id',
                        out='salesforce_id',
                        cxn=cxn,
                        filter_expr={'func': 'isin',
                                     'col': 'etl_source',
                                     'val': ['au_platform_files', 'datacleaner_entity'],
                                     'and': None},
                        refmap_expr={'database': 'cm_enrichment',
                                     'table': 'au_salesforce_id',
                                     'source_col': 'prod_id',
                                     'target_col': 'full_id'}
                        )

au_raw_salesforce_id = Rule(meta={'tables': ['entity'],
                                  'type': 'mapping',
                                  'name': 'au_salesforce_id'},
                            col='sales_force_organisation_id',
                            out='sales_force_organisation_id',
                            cxn=cxn,
                            filter_expr={'func': 'isin',
                                         'col': 'etl_source',
                                         'val': ['datacleaner_entity'],
                                         'and': None},
                            refmap_expr={'database': 'cm_enrichment',
                                         'table': 'au_salesforce_id',
                                         'source_col': 'prod_id',
                                         'target_col': 'full_id'}
                            )

cm_currency_id = Rule(meta={'tables': ['trade', 'aum'],
                            'type': 'mapping',
                            'name': 'cm_currency_id'},
                      col='currency_id',
                      out='currency_id',
                      cxn=cxn,
                      filter_expr={'func': 'isin',
                                   'col': 'etl_source',
                                   'val': ['sv_firm', 'sv_office', 'sv_trade', 'sv_person',
                                           'fir', 'ofl', 'per',
                                           'sv_asset', 'sv_flow', 'sv_holding',
                                           'AI_flow', 'AI_aum',
                                           'CT', 'AMG', 'AMGWM', 'dmi', 'ft',
                                           'LDW_trade', 'LDW_aum', 'au_platform_files',
                                           'datacleaner_agreement', 'datacleaner_entity',
                                           'registreet_aum', 'registreet_trade'
                                           ],
                                   'and': None},
                      refmap_expr={'database': 'cm_enrichment',
                                   'table': 'cm_currency_id',
                                   'source_col': 'symbol',
                                   'target_col': 'currency_id'})

cm_preferred_currency_id = Rule(meta={'tables': ['agreement', 'sub_agreement'],
                                      'type': 'mapping',
                                      'name': 'cm_currency_id'},
                                col='preferred_currency_id',
                                out='preferred_currency_id',
                                cxn=cxn,
                                filter_expr={'func': 'isin',
                                             'col': 'etl_source',
                                             'val': ['sv_firm', 'sv_office', 'sv_trade', 'sv_person',
                                                     'fir', 'ofl', 'per',
                                                     'sv_asset', 'sv_flow', 'sv_holding',
                                                     'AI_flow', 'AI_aum',
                                                     'CT', 'AMG', 'AMGWM', 'dmi', 'ft',
                                                     'LDW_trade', 'LDW_aum', 'au_platform_files',
                                                     'datacleaner_agreement', 'datacleaner_entity',
                                                     'registreet_aum', 'registreet_trade'
                                                     ],
                                             'and': None},
                                refmap_expr={'database': 'cm_enrichment',
                                             'table': 'cm_currency_id',
                                             'source_col': 'symbol',
                                             'target_col': 'currency_id'})

ai_ipo_flag = Rule(meta={'tables': ['agreement'],
                         'type': 'mapping',
                         'name': 'ai_ipo_flag'},
                   col='ipo_flag',
                   out='ipo_flag',
                   cxn=cxn,
                   filter_expr={'func': 'isin',
                                'col': 'etl_source',
                                'val': ['AI_flow', 'AI_aum'],
                                'and': None},
                   refmap_expr={'database': 'cm_enrichment',
                                'table': 'ai_ipo_flag',
                                'source_col': 'entity_name',
                                'target_col': 'ipo_flag'})

### Client Type
sv_client_type_id = Rule(meta={'tables': ['entity'],
                               'type': 'mapping',
                               'name': 'sv_client_type_id'},
                         col='client_type_id',
                         out='client_type_id',
                         cxn=cxn,
                         filter_expr={'func': 'isin',
                                      'col': 'etl_source',
                                      'val': ['sv_firm', 'sv_person', 'sv_office',
                                              'fir', 'ofl', 'per',
                                              'sv_holding'],
                                      'and': None},
                         refmap_expr={'database': 'cm_enrichment',
                                      'table': 'sv_client_type_id_trv',
                                      'source_col': 'source_client_type',
                                      'target_col': 'target_client_sub_type_id'})

amg_client_type = Rule(meta={'tables': ['entity'],
                             'type': 'mapping',
                             'name': 'amg_client_type'},
                       col='client_type_id',
                       out='client_type_id',
                       cxn=cxn,
                       filter_expr={'func': 'isin',
                                    'col': 'etl_source',
                                    'val': ['AMG'],
                                    'and': None},
                       refmap_expr={'database': 'cm_enrichment',
                                    'table': 'amg_client_type_id',
                                    'source_col': 'symbol',
                                    'target_col': 'client_type'})

ai_client_type = Rule(meta={'tables': ['entity'],
                            'type': 'mapping',
                            'name': 'ai_client_type'},
                      col='client_type_id',
                      out='client_type_id',
                      cxn=cxn,
                      filter_expr={'func': 'isin',
                                   'col': 'etl_source',
                                   'val': ['AI', 'ai'],
                                   'and': None},
                      refmap_expr={'database': 'cm_enrichment',
                                   'table': 'ai_client_type_id_trv',
                                   'source_col': 'source_client_type',
                                   'target_col': 'target_client_sub_type_id'})

ct_client_type = Rule(meta={'tables': ['entity'],
                            'type': 'mapping',
                            'name': 'ct_client_type'},
                      col='client_type_id',
                      out='client_type_id',
                      cxn=cxn,
                      filter_expr={'func': 'isin',
                                   'col': 'etl_source',
                                   'val': ['CT', 'ct'],
                                   'and': None},
                      refmap_expr={'database': 'cm_enrichment',
                                   'table': 'ct_client_type_id_trv',
                                   'source_col': 'source_client_type',
                                   'target_col': 'target_client_sub_type_id'})

ct_entity_type = Rule(meta={'tables': ['entity'],
                            'type': 'mapping',
                            'name': 'ct_entity_type'},
                      col='entity_type_id',
                      out='entity_type_id',
                      cxn=cxn,
                      filter_expr={'func': 'isin',
                                   'col': 'etl_source',
                                   'val': ['CT', 'ct'],
                                   'and': None},
                      refmap_expr={'database': 'cm_enrichment',
                                   'table': 'ct_entity_type',
                                   'source_col': 'src_entity_type_id',
                                   'target_col': 'trg_entity_type_id'})

au_channel_id = Rule(meta={'tables': ['agreement', 'sub_agreement'],
                           'type': 'mapping',
                           'name': 'au_channel_id'},
                     col='channel_id',
                     out='channel_id',
                     cxn=cxn,
                     filter_expr={'func': 'isin',
                                  'col': 'etl_source',
                                  'val': ['au_platform_files',
                                          'datacleaner_agreement', 'datacleaner_entity',
                                          'registreet_aum', 'registreet_trade'],
                                  'and': None},
                     refmap_expr={'database': 'cm_enrichment',
                                  'table': 'au_channel_id',
                                  'source_col': 'source',
                                  'target_col': 'target'})

amg_channel_id = Rule(meta={'tables': ['agreement'],
                            'type': 'mapping',
                            'name': 'amg_channel_id'},
                      col='channel_id',
                      out='channel_id',
                      cxn=cxn,
                      filter_expr={'func': 'isin',
                                   'col': 'etl_source',
                                   'val': ['AMG', 'amg'],
                                   'and': None},
                      refmap_expr={'database': 'cm_enrichment',
                                   'table': 'amg_channel_id',
                                   'source_col': 'src_channel_id',
                                   'target_col': 'trg_channel_id'})

sv_channel_id = Rule(meta={'tables': ['agreement', 'sub_agreement'],
                           'type': 'mapping',
                           'name': 'sv_channel_id'},
                     col='channel_id',
                     out='channel_id',
                     cxn=cxn,
                     filter_expr={'func': 'isin',
                                  'col': 'etl_source',
                                  'val': ['sv_holding'],
                                  'and': None},
                     refmap_expr={'database': 'cm_enrichment',
                                  'table': 'sv_channel_id',
                                  'source_col': 'src_channel_id',
                                  'target_col': 'trg_channel_id'})
sv_shd_channel_id = Rule(meta={'tables': ['sv_sales_hierarchy'],
                               'type': 'mapping',
                               'name': 'sv_shd_channel_id'},
                         col='shd_channel',
                         out='shd_channel',
                         cxn=cxn,
                         filter_expr={'func': 'isin',
                                      'col': 'etl_source',
                                      'val': ['sv_sales_hier'],
                                      'and': None},
                         refmap_expr={'database': 'cm_enrichment',
                                      'table': 'sv_channel_id',
                                      'source_col': 'src_channel_id',
                                      'target_col': 'trg_channel_id'})
sv_origin_id = Rule(meta={'tables': ['agreement', 'sub_agreement'],
                          'type': 'mapping',
                          'name': 'sv_origin_id'},
                    col='origin_id',
                    out='origin_id',
                    cxn=cxn,
                    filter_expr={'func': 'isin',
                                 'col': 'etl_source',
                                 'val': ['sv_holding'],
                                 'and': None},
                    refmap_expr={'database': 'cm_enrichment',
                                 'table': 'cm_origin_id',
                                 'source_col': 'origin_name',
                                 'target_col': 'origin_id'})

sv_transaction_code = Rule(meta={'tables': ['flow'],
                                 'type': 'mapping',
                                 'name': 'sv_transaction_code'},
                           col='transaction_code',
                           out='flow_type',
                           cxn=cxn,
                           filter_expr={'func': 'isin',
                                        'col': 'etl_source',
                                        'val': ['sv_trade'],
                                        'and': None},
                           refmap_expr={'database': 'cm_enrichment',
                                        'table': 'v_sv_transaction_code',
                                        'source_col': 'transaction_code',
                                        'target_col': 'flow_type'})

cm_aggregator_id = Rule(meta={'tables': ['agreement', 'sub_agreement', 'aum', 'trade'],
                              'type': 'mapping',
                              'name': 'cm_aggregator_id'},
                        col='aggregator_id',
                        out='aggregator_id',
                        cxn=cxn,
                        filter_expr={'func': 'isin',
                                     'col': 'etl_source',
                                     'val': ['sv_firm', 'sv_office', 'sv_person',
                                             'sv_asset', 'sv_trade', 'sv_holding',
                                             'fir', 'ofl', 'per',
                                             'AI_flow', 'AI_aum',
                                             'CT', 'AMG', 'AMGWM', 'dmi', 'ft',
                                             'LDW_trade', 'LDW_aum',
                                             'au_platform_files', 'au_platform_file',
                                             'datacleaner_agreement', 'datacleaner_entity',
                                             'registreet_aum', 'registreet_trade'
                                             ],
                                     'and': None},
                        refmap_expr={'database': 'cm_enrichment',
                                     'table': 'cm_aggregator_id',
                                     'source_col': 'source_aggregator_id',
                                     'target_col': 'target_aggregator_id'})

cm_entity_type_id = Rule(meta={'tables': ['entity'],
                               'type': 'mapping',
                               'name': 'cm_entity_type_id'
                               },
                         col='entity_type_id',
                         out='entity_type_id',
                         cxn=cxn,
                         filter_expr={'func': 'isin',
                                      'col': 'etl_source',
                                      'val': ['sv_firm', 'sv_office', 'sv_person',
                                              'sv_holding',
                                              'fir', 'ofl', 'per',
                                              'AI_flow', 'AI_aum', 'AMGWM',
                                              'CT', 'AMG', 'dmi', 'ft',
                                              'LDW_trade', 'LDW_aum',
                                              'au_platform_files',
                                              'datacleaner_agreement', 'datacleaner_entity',
                                              'registreet_aum', 'registreet_trade'
                                              ],
                                      'and': None},
                         refmap_expr={'database': 'cm_enrichment',
                                      'table': 'cm_entity_type_id',
                                      'source_col': 'entity_type_desc',
                                      'target_col': 'entity_type_id'})

cm_relationship_type_id = Rule(meta={'tables': ['agreement_entity_xref'],
                                     'type': 'mapping',
                                     'name': 'cm_relationship_type_id'
                                     },
                               col='relationship_type_id',
                               out='relationship_type_id',
                               cxn=cxn,
                               filter_expr={'func': 'isin',
                                            'col': 'etl_source',
                                            'val': ['sv_holding',
                                                    'AI_flow', 'AI_aum',
                                                    'CT', 'AMG', 'AMGWM', 'dmi', 'ft',
                                                    'LDW_trade', 'LDW_aum',
                                                    'au_platform_files',
                                                    'datacleaner_agreement', 'datacleaner_entity',
                                                    'registreet_aum', 'registreet_trade'
                                                    ],
                                            'and': None},
                               refmap_expr={'database': 'cm_enrichment',
                                            'table': 'cm_relationship_type_id',
                                            'source_col': 'relationship_desc',
                                            'target_col': 'relationship_type_id'})

ft_platform_crm_id = Rule(meta={'tables': ['entity'],
                                'type': 'mapping',
                                'name': 'ft_platform_crm_id'},
                          col='crm_id',
                          out='crm_id',
                          cxn=cxn,
                          filter_expr={'func': 'isin',
                                       'col': 'etl_source',
                                       'val': ['ft'],
                                       'and': None},
                          refmap_expr={'database': 'cm_enrichment',
                                       'table': 'ft_platform_crm_id',
                                       'source_col': 'entity_name',
                                       'target_col': 'crm_id'})

ft_channel_id = Rule(meta={'tables': ['agreement', 'sub_agreement'],
                            'type': 'mapping',
                            'name': 'ft_channel_id'},
                      col='channel_id',
                      out='channel_id',
                      cxn=cxn,
                      filter_expr={'func': 'isin',
                                   'col': 'etl_source',
                                   'val': ['ft'],
                                   'and': None},
                      refmap_expr={'database': 'cm_enrichment',
                                   'table': 'ft_channel_id',
                                   'source_col': 'src_channel_id',
                                   'target_col': 'trg_channel_id'})

ft_employee = Rule(meta={'tables': ['sales_owner_agreement_xref'],
                            'type': 'mapping',
                            'name': 'ft_employee'},
                      col='sales_owner_id',
                      out='sales_owner_id',
                      cxn=cxn,
                      filter_expr={'func': 'isin',
                                   'col': 'etl_source',
                                   'val': ['ft'],
                                   'and': None},
                      refmap_expr={'database': 'cm_enrichment',
                                   'table': 'ft_employee',
                                   'source_col': 'employee_name',
                                   'target_col': 'employee_id'})

ft_salesforce_id = Rule(meta={'tables': ['entity'],
                               'type': 'mapping',
                               'name': 'ft_salesforce_id'},
                         col='salesforce_id',
                         out='salesforce_id',
                         cxn=cxn,
                         filter_expr={'func': 'isin',
                                      'col': 'etl_source',
                                      'val': ['ft'],
                                      'and': None},
                         refmap_expr={'database': 'cm_enrichment',
                                      'table': 'ft_salesforce_id',
                                      'source_col': 'prod_id',
                                      'target_col': 'full_id'}
                         )


cm_address_type_id = Rule(meta={'tables': ['entity_address_xref'],
                                'type': 'mapping',
                                'name': 'cm_email_type_id'},
                          col='address_type_id',
                          out='address_type_id',
                          cxn=cxn,
                          filter_expr={'func': 'isin',
                                       'col': 'etl_source',
                                       'val': ['sv_firm', 'sv_office', 'SF_Entity', 'sf_entity'],
                                       'and': None},
                          refmap_expr={'database': 'cm_enrichment',
                                       'table': 'cm_address_type_id',
                                       'source_col': 'source',
                                       'target_col': 'target'})

cm_email_type_id = Rule(meta={'tables': ['entity_email_xref'],
                              'type': 'mapping',
                              'name': 'cm_email_type_id'},
                        col='email_type_id',
                        out='email_type_id',
                        cxn=cxn,
                        filter_expr={'func': 'isin',
                                     'col': 'etl_source',
                                     'val': ['sv_person', 'SF_Entity', 'sf_entity'],
                                     'and': None},
                        refmap_expr={'database': 'cm_enrichment',
                                     'table': 'cm_email_type_id',
                                     'source_col': 'source',
                                     'target_col': 'target'})

cm_phone_type_id = Rule(meta={'tables': ['entity_phone_xref'],
                              'type': 'mapping',
                              'name': 'cm_phone_type_id'},
                        col='phone_type_id',
                        out='phone_type_id',
                        cxn=cxn,
                        filter_expr={'func': 'isin',
                                     'col': 'etl_source',
                                     'val': ['sv_person', 'SF_Entity', 'sf_entity'],
                                     'and': None},
                        refmap_expr={'database': 'cm_enrichment',
                                     'table': 'cm_phone_type_id',
                                     'source_col': 'source',
                                     'target_col': 'target'})

if __name__ == "__main__":
    from pprint import pprint

    pprint([x for x in ct_entity_type.generate_refmap()])
