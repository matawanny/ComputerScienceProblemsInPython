from cm_commons.db.cm_rule_conn import create_cm_conn
import pyspark.sql.functions as f
from itertools import chain

cxn = create_cm_conn()

import pandas as pd
df = pd.read_sql_query('select * FROM ct_entity_type', con=cxn[0])
print(df[['src_entity_type_id', 'trg_entity_type_id']])


map = {
        'database': 'cm_rule_reference',
        'table': 'ct_entity_type',
        'source_col': 'src_entity_type_id',
        'target_col': 'trg_entity_type_id',
       }



