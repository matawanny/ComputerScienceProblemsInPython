# Rule list
# Dictionary
from docutils.nodes import author

import spark_functions as sf
import pandas as pd
import pyspark.sql.functions as f

from cm_commons import colors
from cm_commons.db.cm_rule_conn import create_cm_conn
from skylla.enrich.ref_ref import cm_aggregator_id, cm_currency_id, cm_entity_type_id, cm_relationship_type_id, \
    ct_entity_type, ai_ipo_flag, amg_channel_id, sv_channel_id, sv_transaction_code, sv_origin_id, \
    sv_client_type_id, amg_client_type, ai_client_type, ct_client_type, ft_platform_crm_id, cm_email_type_id, \
    cm_phone_type_id, cm_address_type_id, cm_preferred_currency_id, amg_salesforce_id, au_channel_id, \
    sv_shd_channel_id, au_salesforce_id, ft_channel_id, ft_salesforce_id, ft_employee


cxn = create_cm_conn()


class Enricher:
    """
# #---------------------------------------------------------------# #
# #                            Enricher                           # #
# #---------------------------------------------------------------# #
    """

    def __init__(self, dfs, conf):
        self.dfs = dfs
        self.objs = dfs
        self.conf = conf

    def add_etl_source(self):
        for tt in self.objs:
            self.objs[tt] = self.objs[tt].withColumn('etl_source', f.lit(self.conf['source_name']))
        # print(self.conf['source_name'])
        return self

    def rule_interpreter(self, rule, df, table):
        if table in rule.meta['tables']:
            df = rule.process(df)
            self.__doc__ = self.__doc__ + '\n' + rule.__doc__
        return df

    def commit(self):
        self.dfs = self.objs
        return self

    def process(self):
        self.add_etl_source()
        for tt in self.objs:
            self.__doc__ = self.__doc__ + '\n' + colors.colors['green'] + str(tt) + "\n" + colors.colors['reset']
            obj = self.objs[tt]
            obj = self.rule_interpreter(cm_aggregator_id, obj, tt)
            obj = self.rule_interpreter(ct_entity_type, obj, tt)
            obj = self.rule_interpreter(sv_channel_id, obj, tt)
            obj = self.rule_interpreter(amg_channel_id, obj, tt)
            obj = self.rule_interpreter(sv_transaction_code, obj, tt)
            obj = self.rule_interpreter(sv_origin_id, obj, tt)
            obj = self.rule_interpreter(sv_client_type_id, obj, tt)
            obj = self.rule_interpreter(amg_client_type, obj, tt)
            obj = self.rule_interpreter(ai_client_type, obj, tt)
            obj = self.rule_interpreter(ct_client_type, obj, tt)
            obj = self.rule_interpreter(cm_currency_id, obj, tt)
            obj = self.rule_interpreter(cm_entity_type_id, obj, tt)
            obj = self.rule_interpreter(ai_ipo_flag, obj, tt)
            obj = self.rule_interpreter(cm_relationship_type_id, obj, tt)
            obj = self.rule_interpreter(ft_platform_crm_id, obj, tt)
            obj = self.rule_interpreter(cm_address_type_id, obj, tt)
            obj = self.rule_interpreter(cm_email_type_id, obj, tt)
            obj = self.rule_interpreter(cm_preferred_currency_id, obj, tt)
            obj = self.rule_interpreter(cm_phone_type_id, obj, tt)
            obj = self.rule_interpreter(au_channel_id, obj, tt)
            obj = self.rule_interpreter(sv_shd_channel_id, obj, tt)
            obj = self.rule_interpreter(ft_channel_id, obj, tt)
            obj = self.rule_interpreter(ft_employee, obj, tt)
            # obj = self.rule_interpreter(amg_salesforce_id, obj, tt)
            # obj = self.rule_interpreter(au_salesforce_id, obj, tt)
            # obj = self.rule_interpreter(ft_salesforce_id, obj, tt)
            self.objs[tt] = obj
        self.commit()
        return self


class Single_Enricher:
    """
# #---------------------------------------------------------------# #
# #                    Single Table Enricher                      # #
# #---------------------------------------------------------------# #
    """

    def __init__(self, df, table, rules):
        self.df = df
        self.rules = rules
        self.table = table

    def rule_interpreter(self, rule, df, table):
        if table in rule.meta['tables']:
            df = rule.process(df)
            self.__doc__ = self.__doc__ + '\n' + rule.__doc__
        return df

    def process(self):

        for ri in self.rules:
            self.rule_interpreter(ri, self.df, self.table)

        return self
