from extract.extract import Extractor

class AMGExtractor(Extractor):
    """
        Generic Extract protocol
        - Supports (.xlsx, .csv) inputs and Spark.SQL.DataFrame outputs
    """
    def __init__(self, sql_context, file_loc, file_ext, field_mappings):
        self.sql_context = sql_context
        self.file_loc = file_loc
        self.df = None
        self.field_mappings = field_mappings
        self.file_ext = file_ext
        self.obj = None

    def oracle_to_df(self):
        """test
        """
    def process(self):
        if self.file_ext.lower() == 'csv':
            return self.csv_to_df()
        if self.file_ext.lower() == 'xlsx':
            return self.xlsx_to_df()
        else:
            raise ValueError(".{} files not supported by extract".format(self.file_ext))
