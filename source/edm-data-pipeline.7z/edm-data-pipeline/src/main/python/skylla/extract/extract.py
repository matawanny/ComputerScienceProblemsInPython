__date__ = "10/23/2018"
__version__ = "Base"
__status__ = "Done"

from cm_commons.decorators import to_doc
from pyspark.sql.types import ArrayType, StructType, StructField, IntegerType, StringType
import pyspark.sql.functions as f
import re


class Extractor:
    """
# #---------------------------------------------------------------# #
# #                        General Extractor                      # #
# #---------------------------------------------------------------# #
    """

    def __init__(self, conf, spark, cxn, schema):
        self.spark = spark

        self.cxn = cxn

        self.conf = conf

        self.schema = schema

        self.file_loc = conf["input_location"][conf["environment"]]
        self.file_ext = conf['file_extension']

        self.df = None
        self.obj = None

        self.read_only = False

    @staticmethod
    def csv_to_df(file_loc, field_mappings, source='Not salesvision', spark=None):
        """ Convert csv to spark """
        df = spark.read.csv(file_loc,
                            header=True,
                            inferSchema=False,
                            multiLine=True,
                            quote='"',
                            escape='"',
                            ignoreTrailingWhiteSpace=True)


        # df = df.select(list(field_mappings.keys()))
        if source == 'salesvision':
            regex = re.compile(r".+?(?=\d+$)")
            for key in field_mappings:
                for k in df.columns:
                    m = regex.match(k)
                    if not m:
                        continue
                    else:
                        if key == m.group(0):
                            df = df.withColumnRenamed(k, field_mappings[key])
        elif field_mappings is {}:
            pass
        else:
            cols = df.columns
            for key in field_mappings:
                df = df.withColumnRenamed(key.strip(), field_mappings[key])
        return df

    @staticmethod
    def parquet_to_df(file_loc, spark):
        """ Convert csv to spark """
        df = spark.read.parquet(file_loc)
        return df

    @staticmethod
    def postgres_to_df(table, cxn, spark):
        """ Convert csv to spark """
        df = spark.read.jdbc(cxn, table)
        return df

    @staticmethod
    def xlsx_to_df(file_loc, field_mappings, spark):
        """" Convert """
        df = spark.read.format("com.crealytics.spark.excel") \
            .option("location", file_loc) \
            .option("useHeader", "true") \
            .option("treatEmptyValuesAsNulls", "true") \
            .option("inferSchema", "true") \
            .option("addColorColumns", "False") \
            .load(file_loc)
        df = df.select(field_mappings.keys())
        for key in field_mappings:
            df = df.withColumnRenamed(key, field_mappings[key])
            df = df.withColumn(field_mappings[key], f.expr("CAST({} AS {})".format(field_mappings[key], "STRING")))
        return df

    @staticmethod
    def oracle_to_df(cxn, query, field_mappings, spark):
        """" Convert """
        # TODO - implement later
        pass
        return None

    @staticmethod
    def sybase_to_df(cxn, query, field_mappings, spark):
        """ Convert """

    """ Reserve - """
    @to_doc(indent=0)
    def read_file(self, source_type, file_loc):
        """ Read file from raw source """

        if source_type == 'csv':
            return self.csv_to_df(file_loc, self.schema['mapping'], self.conf['etl_name'], self.spark)
        if source_type == 'xlsx':
            return self.csv_to_df(file_loc, self.schema['mapping'], self.spark)
        if source_type == 'oracle':
            return self.oracle_to_df(self.cxn, self.schema['query'], self.schema['mapping'], self.spark)
        else:
            raise ValueError("{} files not supported by extract".format(self.conf['source_type']))

    def process(self):
        self.df = self.read_file(source_type=self.conf['source_type'], file_loc=self.file_loc)

        print("\033[34mNum records in file: " + str(self.df.count())+'\033[0m')
        if "rowcount" in self.conf.keys():
            print("\033[34mNum records expected: " + str(self.conf['rowcount'])+'\033[0m')
        else:
            print("Num records expected")
        # self.df.cache()


        return self
