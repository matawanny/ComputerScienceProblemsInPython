from cm_commons.util.boto_functions import move_conf_along, s3_move_file, get_s3_bucket
from cm_commons import colors
import traceback


def etl_executor(conf, location, move_files=True, jobid=None):
    print('\033[32;4m' + '#########################################\033[0m')
    print('\033[32;4m' + '#########################################\033[0m')
    import skylla

    # import E,T,L objects
    ETL = getattr(skylla, 'ETL')

    from cm_commons.db.cm_conn import cm_cxn_jdbc
    etl_obj = ETL(conf=conf, src_cxn=None, trg_cxn=cm_cxn_jdbc)
    if move_files:
        colors.out_print("Moving files...", indent=0)
        current_conf = move_conf_along(location, currentstep="incoming", nextstep="active")
    # etl_obj.extract().transform().load()

        try:

            etl_obj.extract().transform().enrich().load()

            # For release
            # etl_obj.extract().registreet_enrich().transform().enrich().load()

            etl_obj.print_doc()
            source_mapping = {'amgwm': 'AMG',
                              'amg': 'AMG',
                              'ldw_aum': 'AMG',
                              'ldw_trade': 'AMG',
                              'sf_entity': 'SF',
                              'sf_agreement': 'SF',
                              'sv_holding': 'SV',
                              'sv_asset': 'SV',
                              'sv_trade': 'SV',
                              'sv_firm': 'SV',
                              'sv_office': 'SV',
                              'sv_person': 'SV',
                              'sv_sales_hier': 'SV',
                              'sv_sales_per': 'SV',
                              'au_platform_files': 'AU',
                              'datacleaner_agreement': 'AU',
                              "datacleaner_entity": 'AU',
                              'registreet_aum': 'AU',
                              'registreet_trade': 'AU',
                              'ft': 'FT'
                              }

            if conf['source_name'].lower() not in source_mapping.keys():
                colors.bug_print(f"{conf['source_name']} not found")
                mdm_prefix = None
            else:
                colors.bug_print(f"{conf['source_name']} maps to {source_mapping[conf['source_name'].lower()]} found")
                mdm_prefix = source_mapping[conf['source_name'].lower()]

            colors.bug_print(f"prefix: {mdm_prefix}")

            if move_files:
                # move conf to done
                current_conf = move_conf_along(current_conf, currentstep="active", nextstep="done")
                # move conf to MDM/.../incoming if applicable
                if mdm_prefix:
                    mdm_location = f"s3://{get_s3_bucket()}/MDM/conf/{mdm_prefix}/incoming/"
                    s3_move_file(current_conf, mdm_location, delete=False)
                    colors.suc_print(f"{current_conf}  moved to MDM/incoming")

                else:
                    colors.war_print(f"{current_conf} not moved to MDM/incoming")

        except Exception as e:
            colors.err_print("ETL JOB FAILED:", indent=0)


            if move_files:
                current_conf = move_conf_along(current_conf, currentstep="active", nextstep="error")



            print(traceback.format_exc())
            raise ValueError('ETL Failed')
    else:
        colors.out_print("Not moving files...", indent=0)

        etl_obj.extract().transform().enrich().load()
        # Release testing only
        #etl_obj.extract().().transform().enrich().load()
        etl_obj.print_doc()


