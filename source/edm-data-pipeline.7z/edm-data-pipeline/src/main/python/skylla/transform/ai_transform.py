from skylla.transform.general_transform import Transformer

import pyspark.sql.functions as f
from pyspark.sql.types import *

from cm_commons.decorators import to_doc


class AITransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                          AI Transformer                       # #
# #---------------------------------------------------------------# #
    """

    @to_doc(indent=0)
    def get_owner_pre_melt(self):
        """{h2} Entity ID, Entity Name, Entity Type Id, Investor ID, Sub Investor ID {/h2}
        """
        self.hash(cols=['investor_id'], out='investor_entity_id')
        self.rename(col='investor_name', out='investor_name')
        self.add_static_column(col='investor_type_id', val='500')
        self.rename(col='investor_id', out='investor_id')
        self.add_static_column(col='dummy', val='None')
        self.add_static_column(col='i_relationship_type_id', val='asset_owner')
        self.add_static_column(col='i_primary_relationship', val='Y')

        return self

    @to_doc(indent=0)
    def get_sub_investor_pre_melt(self):
        """ {h2}Entity ID, Entity Name, Entity Type Id, Investor ID, Sub Investor ID{/h2}
        """
        self.hash(cols=['sub_investor_id'], out='sub_investor_entity_id')
        self.rename(col='sub_investor_name', out='sub_investor_name')
        self.add_static_column(col='sub_investor_type_id', val='501')
        self.add_static_column(col='dummy', val='None')
        self.rename(col='sub_investor_id', out='sub_investor_id')
        self.determine_sub_investor_relationship_type()

        return self

    @to_doc(indent=0)
    def determine_sub_investor_relationship_type(self):
        """{h2}Determines sub_investor_relationship_type{/h2}
            |  - EDM-1055
        """
        self.add_static_column(col='si_relationship_type_id', val='EDM-1055')
        self.add_static_column(col='si_primary_relationship', val='N')
        return self

    @to_doc(indent=0)
    def melt_entities(self):
        """{h2}Melts entity into the following fields{\h2}
            |  - entity_id
            |  - entity_type_id
            |  - entity_name
        """
        # takes entity class columns and un-pivots data from AI structure
        pre_melt = {
            'investor': ['investor_entity_id', 'investor_name',
                         'investor_type_id', 'investor_id', 'dummy',
                         'si_relationship_type_id', 'si_primary_relationship',
                         'dummy'],
            'sub_investor': ['sub_investor_entity_id', 'sub_investor_name',
                             'sub_investor_type_id', 'dummy','sub_investor_id',
                             'si_relationship_type_id', 'si_primary_relationship',
                             'sub_investor_name']
        }

        # target data structure
        post_melt = {
            'entity': ['entity_id', 'entity_name',
                       'entity_type_id', 'ai_investor_id', 'ai_subinvestor_id',
                       'relationship_type_id','primary_relationship',
                       'employee_id']
        }

        self.melt(cols=pre_melt, out=post_melt)

    @to_doc(indent=0)
    def get_agreement(self):
        """ {h2} Builds an agreement for entry {/h2}
            |  - Hashes ENTITY_ID, SUB_STRATEGY_ID
        """
        self.rename(col='investor_entity_id', out='asset_owner_id')
        self.hash(cols=['asset_owner_id', 'share_class_id', 'sub_investor_entity_id'], out='agreement_id')
        self.rename(col='sub_investor_entity_id', out='consultant_id')

        # External Identifiers
        self.rename(col='share_class_id', out='external_identifier')
        self.rename(col='currency', out='preferred_currency_id')
        self.add_static_column(col='external_identifier_type', val='share_class_id')

        # Agreement Type
        self.add_static_column(col='agreement_type', val='holding')

        # Erisa Plan y/n
        statement = [('Erisa Investor', 'Y'), ('Non-Erisa', 'N')]
        # TODO-Handle defaults
        default = 'Maybe'

        self.switch_case(col='erisa_type', out='erisa_plan', statement=statement, default=default)

        return self

    @to_doc(indent=0)
    def link_agreement_and_entity(self):
        """{h2}Link entity and agreement via asset owner{/h2}"""
        self.hash(cols=['entity_id', 'agreement_id'], out='agreement_entity_xref_id')
        return self

    @to_doc(indent=0)
    def build_aum(self):
        """{h2}Build AUM, amt, id, and as_of date{/h2}"""
        self.rename(col='aum', out='amount')
        self.hash(cols=['agreement_id', 'as_of_date_raw', 'aum'], out='aum_id')
        self.rename(col='currency', out='currency_id')
        self.add_time_column(col='as_of_date', is_column=True,
                             date='as_of_date_raw', pattern_in='%m/%d/%Y %H:%M:%S %p')
        return self

    @to_doc(indent=0)
    def build_trade(self):
        """{h2}Build trade amt, id, code, and start/end date{/h2}"""
        self.hash(cols=['agreement_id', 'start_date', 'transaction_code'], out='trade_id')
        self.rename(col='currency', out='currency_id')
        self.rename(col='transaction_code', out='aggregator_trade_code')
        self.rename(col='amount', out='amount')
        self.rename(col='start_date', out='start_date')
        self.rename(col='start_date', out='end_date')

        return self

    @to_doc(indent=0)
    def add_financial_details(self):
        """{h2}Build following financial details{/h2}
            |  - currency id
            |  - aggregator id
            |  - updated at
            |  - created at
        """
        self.add_static_column(col='currency_id', val='USD')
        self.add_static_column(col='aggregator_id', val='AI')
        self.add_time_column(col='updated_at', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        self.add_time_column(col='created_at', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        return self

    @to_doc(indent=0)
    def populate_client_type_id(self):
        """{h2}Populate client_type_id{/h2}
            |   - send to data stewardhsip -
            |   - TODO - enrich EDM-602"""
        self.add_static_column(col='client_type_id', val='EDM-602')
        return self

    @to_doc(indent=0)
    def populate_channel(self):
        """{h2}Populate channel_id{/h2}
            |  - TODO - EDM-883
            |  - TODO - enrich EDM-873"""
        self.add_static_column(col='channel_id', val='EDM-883')
        return self

    @to_doc(indent=0)
    def populate_employee_id(self):
        """{h2} Populate employee_id for investor_id == '66'
            |  - employee_id was set as sub_investor_name for all sub_investors in melt
            |  - use employee_id if ai_subinvestor_id == '66' - EDM-1053
            |  - TODO - enrich EDM-1054"""
        statement = [('66', f.col('employee_id'))]
        # TODO - EDM-1056
        self.switch_case_2(col='investor_id', out='employee_id',
                         statement=statement, default='None')
        return self

    @to_doc(indent=0)
    def populate_inception_date(self):
        """{h2}TODO - Populate inception_date
           {/h2}"""
        self.add_static_column(col='inception_date', val='EDM-1050')
        return self

    @to_doc(indent=0)
    def populate_ipo_flag(self):
        """{h2}Populate IPO flag
            |  - Populate ipo flag with entity_name EDM-1057
            |  - TODO - enrich EDM-728
           {/h2}"""
        self.rename(col='entity_name', out='ipo_flag')
        return self

    def process(self):
        # define null fields for each step of the process
        null_entity = ['salesforce_id', 'crm_id', # SF only
                       'lei', # placeholder
                       'fca_id', # FT only
                       'licensee_id', 'ta_number', # DMI/CT only
                       'salesvision_id', 'group_id', 'iard', 'crd', # SV Only
                       'do_not_contact', # CT only
                       'parent_id', # not AI
                       'persistence_id',
                       'ect_entity_id', 'ect_channel_id', 'ect_team_id']
        null_agreement = ['unit_holder_code', # AUS fields
                          'ocio_flag', 'money_type_id', # SF only,
                          'account_number', 'origin_id', # SV only
                          'benchmark_id', 'agreement_name', 'ended_at']  # not

        # pre melt entity level information
        self.get_owner_pre_melt()
        self.get_sub_investor_pre_melt()

        # Build agreement
        self.get_agreement()

        # Build AUM if AUM ETL
        if self.conf['etl_runtime'] == 'aum':
            self.build_aum()

        # Build Flows if Flows ETL
        if self.conf['etl_runtime'] == 'flow':
            self.build_trade()
            self.add_time_column(col='start_date', source='conf', is_column=True,
                                 date='start_date', pattern_in='%m/%d/%Y %H:%M:%S %p')
            self.add_time_column(col='end_date', source='conf', is_column=True,
                                 date='end_date', pattern_in='%m/%d/%Y %H:%M:%S %p')



        # melt entites
        self.melt_entities()
        self.link_agreement_and_entity()

        # additional column data
        self.add_financial_details()

        # placeholders
        self.populate_client_type_id()
        self.populate_channel()
        self.populate_employee_id()
        self.populate_inception_date()
        self.populate_ipo_flag()
        # add null columns
        self.add_null_columns(cols=null_entity)
        self.add_null_columns(cols=null_agreement)

        # Map to tables
        self.commit().map()
        return self
