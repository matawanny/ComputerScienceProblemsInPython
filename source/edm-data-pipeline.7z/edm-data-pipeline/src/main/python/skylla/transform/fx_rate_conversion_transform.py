
from skylla.transform.general_transform import Transformer


class FXRateConversionTransformer(Transformer):
    """
    # #---------------------------------------------------------------# #
    # #                          FXRate Conversion Transformer                      # #
    # #---------------------------------------------------------------# #
    """

    def process(self):

        # print(self.conf['file_date'])
        # one way to add column
        # self.add_static_column('created_at', self.conf['file_date'])

        #the second way to add column
        # self.obj = self.obj.withColumn('updated_at', f.lit(self.conf['file_date']))

        #The correct way to add date column
        self.add_time_column(col='created_at', source='conf', is_column=False, date=self.conf['file_date'],
                             pattern_in='%m-%d-%Y')
        self.add_time_column(col='updated_at', source='conf', is_column=False, date=self.conf['file_date'],
                             pattern_in='%m-%d-%Y')

        self.add_null_columns(cols=['enrichment_error'])
        self.commit().map()
        # self.df.show()
        return self

