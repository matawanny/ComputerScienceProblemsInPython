from skylla.transform.general_transform import Transformer

import pyspark.sql.functions as f
from pyspark.sql.types import *

from cm_commons.decorators import to_doc

import datetime

class AuditTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                    Audit Table Transformer                    # #
# #---------------------------------------------------------------# #
    """
    @to_doc(indent=0)
    def build_audit_id(self):
        """Build {b}Audit{\b} table """
        column_name_list = self.obj.columns
        self.hash(cols=column_name_list, out='audit_id')

    @to_doc(indent=0)
    def filter_records(self):
        """"Filter for (b)CM(\b) records """
        self.simple_filter("source_name", ["CM"], True)

    def process(self):
        self.obj.fillna("None")
        self.build_audit_id()
        self.filter_records()

        # Map to tables
        self.commit().map()

        return self
