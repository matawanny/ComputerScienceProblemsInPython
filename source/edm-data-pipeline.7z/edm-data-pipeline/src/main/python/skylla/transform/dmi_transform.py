from skylla.transform.general_transform import Transformer
import pyspark.sql.functions as f
from pyspark.sql.types import *

from cm_commons.decorators import to_doc

class DMITransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                          DMI Transformer                      # #
# #---------------------------------------------------------------# #
    """

    # @to_doc(indent=0)
    # def build_entity(self):
    #     """{h2}Build entity{/h2}"""
    #     self.add_static_column(col='entity_id', val="")
    #     self.fill_nulls(col="first_name", val="")
    #     self.fill_nulls(col="Last Name", val="")
    #     self.concatenate_cols(cols=["First Name", "Last Name"], out="entity_name", delim=" ")
    #
    #     return self

    @to_doc(indent=0)
    def build_entity(self):
        """Build all {h1} entities {/h1}"""
        self.build_advisor()
        self.build_licensee()
        self.build_offices()

        self.melt(cols={'advisor': ['advisor_id', 'advisor_name', 'advisor_type_id'],
                        'licensee': ['licensee_id', 'licensee_name', 'licensee_type_id'],
                        'office': ['office_id', 'office_name', 'office_type_id']},
                  out={'entity': ['entity_id', 'entity_name', 'entity_type_id']})

        return self


    @to_doc(indent=0)
    def for_record_determine_entity_type(self):
        """{h2}Determine the type of entity (company/person){/h2}"""
        statement = [('Person', "person"), ("Company", "firm"), ("Other", "error")]
        default = "default"
        self.switch_case(col="record_type", out="entity_type_id", statement=statement, default=default) #this is Record Type column for the file.
        return self

    def build_advisor(self):

        if "entity_type_id" == "person":
            self.concatenate_cols(["first_name", "last_name"], out="advisor_name", delim=" ", drop_cols=True)
        else:
            self.add_static_column(col="advisor_name", val="")

        return self


    def process(self):
        #build entity details
        #self.build_entity()
        self.determine_entity_type()



        #commit changes to data frame and map the changes
        self.commit().map()
        return self



class old_DMITransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                          DMI Transformer                      # #
# #---------------------------------------------------------------# #
    """

#Kempe added a comment

    @to_doc(indent=0)
    def build_agreement(self):
        """Build an {h1}agreements{/h1}"""
        self.rename(col="person_psn", out="advisor_id")
        self.hash(cols=['advisor_id', 'product_code'], out='agreement_id')
        self.add_static_column(col='aggregator_id', val='DMI')
        self.rename(col='licensee_name',out='whatever schema says')
        self.rename(col='licensee_number', out='licensee_id')
        self.rename(col="product_code", out="external_identifier")
        self.add_static_column(col="external_identifier_type", val="product_code")
        self.add_static_column(col='agreement_type', val='portfolio')
        self.add_static_column(col='channel_id', val='FIG')

        return self


    @to_doc(indent=0)
    def build_aum(self):
        """Build {h1}aum{/h1}"""
        self.hash(cols=['agreement_id'], out='aum_id')
        self.add_time_column(col='as_of_date', source='conf', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        return self

    @to_doc(indent=0)
    def build_flow(self):
        """Build {h1}flow{/h1}"""
        self.hash(cols=['agreement_id'], out='flow_id')
        self.add_time_column(col='start_date', source='conf', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')

        self.add_time_column(col='end_date', source='conf', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')

        return self

    """
    def aggregrate(self):

        self.group_by(cols=[ci for ci in self.obj.columns if ci not in ['aum', 'inflow']]).agg({'inflow': "sum", 'aum': 'sum'})
        self.rename
    """

    def build_advisor(self):
        # advisor_id, advisor_name, advisor_type
        # self.rename(col=advisor_id, out=advisor_id)
        self.concatenate_cols(["first_name", "last_name"], out="advisor_name", delim=" ", drop_cols=True)

        statement = [('Person', 1), ("Company", 3), ("Other", 999)]
        default = -1
        self.switch_case(col='record_type', out='advisor_type_id', statement=statement, default=default)

        return self

    def build_licensee(self):
        # licensee_id, licensee_name, licensee_type_id
        # id mapped from source
        # name mapped from source
        self.hash(cols=['licensee_number'], out='licensee_id')
        self.add_static_column(col="licensee_type_id", val=7)
        return self

    def build_offices(self):
        # office_id, office_name, office_type_id
        self.rename(col="account_name", out="office_name")
        self.hash(cols=["office_name"], out="office_id")

        self.add_static_column(col="office_type_id", val=3)
        return self

    @to_doc(indent=0)
    def build_entity(self):
        """Build all {h1} entities {/h1}"""
        self.build_advisor()
        self.build_licensee()
        self.build_offices()

        self.melt(cols={'advisor': ['advisor_id', 'advisor_name', 'advisor_type_id'],
                        'licensee': ['licensee_id', 'licensee_name', 'licensee_type_id'],
                        'office': ['office_id', 'office_name', 'office_type_id']},
                  out={'entity': ['entity_id', 'entity_name', 'entity_type_id']})

        # need to fix this
        statement = [(1, f.col('office_id')), (3, f.lit('None')), (7, f.lit('None')), (999, f.lit('None'))]
        default = "TYPE ERROR"
        self.switch_case(col='entity_type_id', out='parent_id', statement=statement, default=default)

        #statement = [(7, f.col('licesnsee_number'))]
        #default = "None"
        #self.switch_case(col='entity_type_id', out='licensee_number', statement=statement, default=default)
        return self


    @to_doc(indent=0)
    def add_file_details(self):
        """{h2}Adds {b}SOURCE_FILE{/b}, {b}DATE_INFORMATION{/b} to dataframe{/h2}"""
        self.add_static_column(col='source_id', val='DMI')

        self.add_time_column(col='updated_at', source='conf', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        self.add_time_column(col='created_at', source='conf', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        return self

    @to_doc(indent=0)
    def aggregate_aums(self):
        """{h2} Aggregate flow and AUM table post mapping {/h2}"""
        #self.obj = self.out_df['flow']
        #self.group_by([ii for ii in self.obj.columns if ii not in ['inflow', 'outflow']]).agg({'inflow':'sum','outflow':'sum'})
        #self.out_df['flow'] = self.obj
        #self.obj = self.df

        # AUM
        self.obj = self.out_df['aum']
        self.group_by([ii for ii in self.obj.columns if ii not in ['aum']]).agg({'aum': 'sum'})
        self.out_df['aum'] = self.obj
        self.obj = self.df

    def process(self):
        null_entity = ['employee_id', 'fca_id', 'ai_subinvestor_id', 'ai_investor_id', 'salesforce_id',
                       'erisa_plan', 'updated_on', 'group_id',  'lei', 'crd',
                       'ipo_flag', 'created_on', 'salesvision_id', 'crm_id', 'client_type_id',
                       'persistence_id', 'do_not_contact']
        null_agreement = ['dealer_number', 'updated_on', 'money_type', 'benchmark_id', 'created_on',
                          'sub_strategy_id', 'custodian_id', 'ta_number', 'platform_id', 'asset_owner_id',
                          'account_number', 'consultant_id', 'agreement_name']
        null_aum = ['updated_on', 'aum_type', 'origin_id', 'end_of_period_aum', 'currency_id', 'transaction_code']

        self.build_agreement()
        self.build_aum()
        self.build_flow()
        self.build_entity()
        self.add_file_details()

        self.add_null_columns(cols=null_entity)
        self.add_null_columns(cols=null_agreement)
        self.add_null_columns(cols=null_aum)

        self.commit().map()
        self.aggregate_aums()
        return self
