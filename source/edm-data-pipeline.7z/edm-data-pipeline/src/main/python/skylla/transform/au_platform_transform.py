import pyspark.sql.functions as f
from pyspark.sql.types import *

from cm_commons.decorators import to_doc
import spark_functions as sf
from skylla.transform.general_transform import Transformer


class AUPlatformSubAgreementsTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                     AU platform Transformer                   # #
# #---------------------------------------------------------------# #
    """
    #transforms the au_platform files into tables: AuPlatformSubAgreement and AuPlatformSubAgreement_Agreement_XREF

    @to_doc(indent=0)
    def build_sub_agreement(self):
        """{h2}Build sub agreements table directly from file{/h2}"""
        # all fields taken from sql alchemy models

        # FIELDS IN USE
        # sub_agreement_id = Column(Integer, primary_key=True, nullable=False, info=IUO)
        # the sub_agreement_id column from the file contains the following string: <YYYYMM>_<filenameprefix>_<file subgroup (usually APIR)>_<int- starting at zero for the combination of the previous three parts>
        # the sub_agreement_id_column is build such that it is effectivly always unique... as for a given month there will only be one <filename> and <apir> combo - so an int for each line should be unique across all files, for all time.
        # this means that the id can be used for genuine replacement, with the latest record with the same ID being the most accurate and able to repalce all previous records with that same ID regardless of time of parsing
        # this is because the YYYYMM date is not about the time of parsing... as about the creation of the file (e.g. 201902_ANZWrap_LAZ0010AU_0 pertains to the 2019 Feb ANZ Wrap file for all investments into LAZ0010AU.
        # This particular ID designates the first row of data.

        # cast additional fields just in case
        self.cast(cols=['sub_strategy_id', 'share_class_id'], typecast='INTEGER')
        self.cast(cols=['sub_strategy_id', 'share_class_id'], typecast='STRING')

        # external identifier info
        self.obj = self.obj.withColumn('external_identifier',
                                       f.when(f.col('apir').like('PF%'), f.col('sub_strategy_id')).otherwise(
                                           f.col('apir')))
        self.obj = self.obj.withColumn('external_identifier_type',
                                       f.when(f.col('apir').like('PF%'), f.lit('product_id')).otherwise(
                                           f.lit('apir_code')))

        # self.rename(col="apir", out="external_identifier")
        # self.add_static_column(col="external_identifier_type", val="apir_code")

        # agreement ID creation
        self.rename(col='agreement_id', out='org_agreement_id')
        self.hash(cols=['org_agreement_id', 'apir', 'sf_org_id', 'sf_contact_id',
                        'platform_file_prefix'], out='agreement_id')
        self.rename(col='agreement_name', out='agreement_name')

        # sub agreement parent ID
        self.add_static_column(col="au_dc_a_file_id_prefix", val="au_dc_a")
        self.hash(cols=["au_dc_a_file_id_prefix", "agreement_id"], out="parent_agreement_id")

        # preferred_currency_id
        self.add_static_column(col='preferred_currency_id', val='AUD')
        self.add_static_column(col="currency_id", val="AUD")

        # channel info
        self.add_static_column(col='channel_id', val='FIG')

        # ended at
        # TODO: is this ended at?
        # self.add_time_column(col='ended_at', source=None, is_column=True, date='end_date_yyyymmdd',
        #                      pattern_in='%Y%m%d')

        # BLANK FIELDS
        self.add_null_columns(cols=(["origin_id", "inception_date", "ipo_flag", "ocio_flag",
                                     "unit_holder_code", "erisa_plan", "ta_number", "benchmark_id", "money_type_id",
                                     "account_number"]))

        self.add_time_column(col='updated_at', source='conf', is_column=False, date=self.conf['file_date'],
                             pattern_in='%m-%d-%Y')
        self.add_time_column(col='created_at', source='conf', is_column=False, date=self.conf['file_date'],
                             pattern_in='%m-%d-%Y')
        return self

    def build_sub_agreement_xref(self):
        """{h2}Build sub agreements xref table directly from file{/h2}"""
        #note that the addition of the static column creates new unique ids for this sub_agreement to agreement xref as the sub-agreement ID already contains the portfolio id.
        self.add_static_column(col="au_pf_saxr_file_id_prefix", val="au_pf_saxr")  # au = Australia, pf = platform_file, saxr = subagreement_xref
        self.hash(cols=["au_pf_saxr_file_id_prefix", "agreement_id", "platform_file_prefix", "apir", "sf_org_id",
                        "sf_org_id_for_contact", "sf_contact_id"], out="auplatformsubagreement_agreement_xref_id")

        # sub_agreement_id = Column(Integer, nullable=False, info=IUO)
        self.hash(cols=["platform_file_prefix", "apir", "sf_org_id", "sf_org_id_for_contact", "sf_contact_id"], out="sub_agreement_id")

        # parent_agreement_id = Column(Integer, ForeignKey(temp_prefix + 'agreement' + temp_postfix + '.agreement_id'),
        #                              nullable=False, info=RD)
        #note, this will create an agreement ID that is the same as the Registreet agreement ID.
        self.add_static_column(col="au_dc_a_file_id_prefix", val="au_dc_a_")
        self.hash(cols=["au_dc_a_file_id_prefix", "agreement_id"], out="parent_agreement_id")

        #RETURN
        return self

    def build_sub_agreement_trades(self):
        """{h2}Build trades table directly from file{/h2}"""
        # order as per sqlalchemy_models.py
        # trade_id - sub agreement id is unique per line and so should flow then be...
        self.add_static_column(col="au_platform_trades_file_id_prefix", val="aup_t_")
        self.hash(cols=["au_platform_trades_file_id_prefix", "agreement_id", 'end_date_yyyymmdd'], out="trade_id")

        # aggregator_trade_code - this is set in filemanager to make positive net flows as "applications" and negative net flows as "redemptions"
        self.rename(col="aggregator_trade_code", out="aggregator_trade_code")

        # sub_agreement_id - this column has already been created...
        self.rename(col="sub_agreement_id", out="agreement_id")

        # amount - applying absolute value here.
        self.rename(col="adviser_netflow", out="amount_raw")
        self.abs(col="amount_raw", out="amount_raw_abs")
        self.rename(col="amount_raw_abs", out="amount")

        # currency_id - not used as currency is always AUD. Assume that post ETL enhancement will transform into currency id
        self.add_static_column(col="currency_id", val="AUD")

        # start_date - start date and end date added in filemanager
        self.add_time_column(col='start_date', source=None, is_column=True, date='start_date_yyyymmdd', pattern_in='%Y%m%d')

        # end_date - end date
        self.add_time_column(col='end_date', source=None, is_column=True, date='end_date_yyyymmdd', pattern_in='%Y%m%d')

        # updated_at, sub_agreement_id, ended_at, created_at
        self.add_time_column(col='updated_at', source='conf', is_column=False, date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        self.add_time_column(col='created_at', source='conf', is_column=False, date=self.conf['file_date'], pattern_in='%m-%d-%Y')

        # BLANK FIELDS
        self.add_null_columns(cols=(["ended_at"]))

        # RETURN
        return self

    def build_sub_agreement_aum(self):
        """{h2}Build aum table directly from file{/h2}"""
        #used to add in the closing AUM for each sub agreement

        #aum_id
        self.add_static_column(col="au_platform_aum_file_id_prefix", val="aup_a_")
        self.hash(cols=["au_platform_aum_file_id_prefix", 'agreement_id', 'end_date_yyyymmdd'], out="aum_id")

        # # sub_agreement_id - this effectively contians the date as the sub_agreement_id field has YYYYMM in it.
        self.rename(col="agreement_id", out="agreement_id")

        # as_of_date - use fund_balance_effective_date
        self.add_time_column(col='as_of_date', source=None, is_column=True, date='end_date_yyyymmdd',
                             pattern_in='%Y%m%d')

        # amount - use adviser_closing_fum
        self.rename(col="adviser_closing_fum", out="amount")

        # currency_id - use a static column
        self.add_static_column(col="currency_id", val="AUD")

        # aggregator_id - static column for Australian Platform see enum
        self.add_static_column(col="aggregator_id", val="DMI")

        self.add_time_column(col='updated_at', source='conf', is_column=False, date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        self.add_time_column(col='created_at', source='conf', is_column=False, date=self.conf['file_date'], pattern_in='%m-%d-%Y')

        #agreement ID - column already exists, so won't make it null.
        self.rename(col="agreement_id", out="agreement_id")

        # add all null columns:
        # updated_at, sub_agreement_id, ended_at, created_at
        self.add_null_columns(cols=(["batch_id", "ended_at"]))

        return self

    def build_entity(self):
        """{h2}Build entity table directly from file{/h2}"""
        # salesforce id (for contact)
        contact_stmt = [(None, 'DropMe'), ('None', 'DropMe'), ('', 'DropMe')]
        contact_def = f.col("sf_contact_id")
        self.switch_case_2(col="sf_contact_id", out="contact_salesforce_id", statement=contact_stmt,
                           default=contact_def)

        # determine salesforce id (for orgs)
        org_stmt = [(None, f.col('sf_org_id_for_contact')), ('None', f.col('sf_org_id_for_contact')),
                    ('', f.col('sf_org_id_for_contact'))]
        org_def = f.col('sf_org_id')
        self.switch_case_2(col='sf_org_id', out='org_salesforce_id', statement=org_stmt, default=org_def)

        # add conversion for SF 15 -> 18 (preventative step)
        self.obj = self.obj.withColumn("contact_salesforce_id", sf.udf_15_to_18(f.col("contact_salesforce_id")))
        self.obj = self.obj.withColumn("org_salesforce_id", sf.udf_15_to_18(f.col("org_salesforce_id")))

        # aggregator ID
        self.add_static_column(col="aggregator_id", val="DMI")

        # generate pre-melt data for contact
        self.hash(cols=['contact_salesforce_id'], out='contact_entity_id')
        self.add_static_column(col='contact_entity_type_id', val='None')
        self.add_static_column(col='contact_parent_id', val='None')
        self.add_static_column(col='contact_relationship_type_id', val='advisor')
        self.add_static_column(col='contact_psn', val='None')
        # self.rename(col='adviser_name', out='contact_entity_name')

        # generate pre-melt data for org
        self.hash(cols=['org_salesforce_id'], out='org_entity_id')
        self.add_static_column(col='org_relationship_type_id', val='asset_owner')
        self.add_static_column(col='org_parent_id', val='None')
        self.add_static_column(col='org_entity_type_id', val='None')
        self.add_static_column(col='org_psn', val='None')
        # self.rename(col='adviser_name', out='org_entity_name')

        # TODO: populate entity_name pre-melt (see comments above)
        self.add_static_column(col='entity_name', val='None')

        pre_melt = {
            'contact': ['contact_entity_id', 'contact_entity_type_id', 'contact_parent_id', 'contact_salesforce_id',
                        'contact_relationship_type_id', 'contact_psn'],
            'org': ['org_entity_id', 'org_entity_type_id', 'org_parent_id', 'org_salesforce_id',
                    'org_relationship_type_id', 'org_psn']
        }
        post_melt = {
            'entity': ['entity_id', 'entity_type_id', 'parent_id', 'salesforce_id',
                       'relationship_type_id', 'psn']
        }
        self.melt(cols=pre_melt, out=post_melt)

        # persistence ID
        self.rename(col='entity_id', out='persistence_id')
        self.add_time_column(col='updated_at', source='conf', is_column=False, date=self.conf['file_date'],
                             pattern_in='%m-%d-%Y')
        self.add_time_column(col='created_at', source='conf', is_column=False, date=self.conf['file_date'],
                             pattern_in='%m-%d-%Y')

        # add all null columns:
        self.add_null_columns(cols=(["ended_at", "err_msg", "asic_license_number", "fishtank_id", "job_desc",
                                     "licensee_parent", "crm_id", "employee_id", 'entity_type_id',
                                     "group_id", "client_type_id", "ai_subinvestor_id", "ai_investor_id", "lei", "crd",
                                     "fca_id", "iard", "do_not_contact", "salesvision_id", 'ect_entity_id',
                                     'ect_channel_id', 'ect_team_id']))

        return self

    def build_sub_agreement_entity_xref(self):
        """{h2}Build entity sub agreement xref table directly from file{/h2}"""
        # agreement_entity_xref_id
        self.hash(cols=["relationship_type_id", "agreement_id"], out="agreement_entity_xref_id")

        # primary_relationship - do not need this column
        self.add_null_columns(cols=["primary_relationship"])

    def build_sales_owner_agreement_xref(self):
        """{h2}Builds Sales Owner Xref{/h2}"""
        self.rename(col='org_owner_id', out='sales_owner_id')
        self.cast(cols=['sales_owner_id'], typecast='INTEGER')
        self.cast(cols=['sales_owner_id'], typecast='STRING')
        self.add_static_column(col='sales_owner_id_type', val='au_platform_sales_rep_id')
        self.hash(cols=['agreement_id', 'sales_owner_id_type'], out='sales_owner_xref_id')

        # null columns
        self.add_null_columns(cols=['primary_owner_flag', 'percent_owned'])

    @to_doc(indent=0)
    def melt_entity_sub_agreement_table(self):
        """{h2}Melts entity into the following fields{/h2}
            - entity_id
            - entity_type_id
            - entity_name
            - entity_parent_id
            - crm_id
            - primary_relationship
            - relationship_type_id
        """
        pre_melt = {
            'asset_owner': ['investor_id', 'asset_owner_type_name'],
            'advisor': ['advisor_id', 'advisor_type_name']
        }
        post_melt = {'agreement_entity_xref':
                         ['entity_id', 'relationship_type_id']}
        self.melt(cols=pre_melt, out=post_melt)

        self.hash(cols=["relationship_type_id", "agreement_id"], out="agreement_entity_xref_id")

    def process(self):
        self.build_entity()
        self.build_sub_agreement()
        self.build_sub_agreement_xref()
        self.build_sub_agreement_trades()
        self.build_sub_agreement_aum()
        self.build_sub_agreement_entity_xref()
        # self.melt_entity_sub_agreement_table()
        self.build_sales_owner_agreement_xref()

        null_cols = ['etl_error', 'external_agreement_id', 'external_entity_id', 'sv_event_code', 'ingested_at',
                     'home_office_flag', 'broker_rep_code']
        self.add_null_columns(cols=[*null_cols])

        # Map to tables
        self.commit().map()

        return self
