from skylla.transform import Transformer
import pyspark.sql.functions as f
from pyspark.sql.types import *

from cm_commons.decorators import to_doc

class DMIContactsTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                          DMI Contacts Transformer                      # #
# #---------------------------------------------------------------# #
    """

    def build_advisor(self):
        # advisor_id, advisor_name, advisor_type
        # self.rename(col=advisor_id, out=advisor_id)
        self.concatenate_cols(["first_name", "last_name"], out="advisor_name", delim=" ", drop_cols=True)

        """
        statement = [('Person', 1), ("Company", 3)]
        default = -1
        self.switch_case(col='record_type', out='advisor_type_id', statement=statement, default=default)
        """

        self.add_static_column(col="advisor_type_id", val=1)

        return self


    def build_licensee(self):
        # licensee_id, licensee_name, licensee_type_id
        # id mapped from source
        # name mapped from source
        self.add_static_column(col="licensee_type_id", val=7)
        return self

    def build_offices(self):
        # office_id, office_name, office_type_id
        self.rename(col="account_name", out="office_name")
        self.hash(cols=["office_name"], out="office_id")

        self.add_static_column(col="office_type_id", val=3)
        return self

    @to_doc(indent=0)
    def build_entity(self):
        """Build all {h1} entities {/h1}"""
        self.build_advisor()
        self.build_licensee()
        self.build_offices()

        self.melt(cols={'advisor': ['advisor_id', 'advisor_name', 'advisor_type_id'],
                        'licensee': ['licensee_number', 'licensee_name', 'licensee_type_id'],
                        'office' : ['office_id', 'office_name', 'office_type_id']},
                  out={'entity': ['entity_id', 'entity_name', 'entity_type_id']})

        # need to fix this
        statement = [(1, f.col('office_id')), (3, f.lit('None')), (7, f.lit('None'))]
        default = "TYPE ERROR"
        self.switch_case(col='entity_type_id', out='parent_id', statement=statement, default=default)
        return self

    @to_doc(indent=0)
    def add_file_details(self):
        """{h2}Adds {b}SOURCE_FILE{/b}, {b}DATE_INFORMATION{/b} to dataframe{/h2}"""
        self.add_static_column(col='source_id', val='DMI_Contacts')
        self.add_time_column(col='updated_at', source='conf')
        self.add_time_column(col='created_at', source='conf')
        return self

    def process(self):


        self.rename(col="person_psn", out="advisor_id")
        self.add_static_column(col='aggregator_id', val='DMI_Contacts')


        null_entity = ['employee_id', 'fca_id', 'ai_subinvestor_id', 'ai_investor_id', 'salesforce_id',
                       'erisa_plan', 'updated_on', 'group_id', 'aggregator_id', 'lei', 'crd',
                       'ipo_flag', 'created_on', 'salesvision_id', 'crm_id', 'client_type_id']

        self.build_entity()
        self.add_file_details()
        self.add_null_columns(cols=null_entity)
        self.commit().map()

        return self
