# from pyspark.sql.functions import udf, explode, split, explode_outer
# from pyspark.sql.functions import expr, lit, concat, col
import pyspark.sql.functions as f
from pyspark.sql.types import ArrayType, StructType, StructField, IntegerType, StringType

from cm_commons.decorators import to_doc
from cm_commons.util import date_util
from skylla.transform.general_transform import Transformer


class FTTransformer(Transformer):
    """
    # #---------------------------------------------------------------# #
    # #                         New FT Transformer                    # #
    # #---------------------------------------------------------------# #
    """

    def map_old(self):
        # Preserve all records to be used for fishtank_enum, sales_owner_agreement_xref
        self.all_df = self.df

        for oo in self.schema:
            # Handling split records based on table data:
            if oo in ['entity', 'agreement_entity_xref', 'agreement', 'sub_agreement', 'aum', 'trade']:
                # self.df = self.df.filter(~f.col('platform').rlike("|".join(["SPLIT_LGAF", "SPLIT_LGIF", "SPLIT_RUFUS"])))
                self.df = self.df.filter(f.col('exclude_yn')=='N')

            print(f"Creating data for {oo} table...")
            if oo == 'entity':
                self.df.select([name for name in self.schema[oo]['fields'] if name in self.df.schema.names]) \
                    .registerTempTable(oo)
                self.out_df[oo] = self.spark.sql("select * from {}".format(oo))

            if oo == 'agreement_entity_xref':
                self.df.select([name for name in self.schema[oo]['fields'] if name in self.df.schema.names]) \
                    .filter(~(~f.col('platform').rlike("|".join(['LGAF', 'LGIF', 'RUFUS',
                                                                 'SPLIT_LGAF', 'SPLIT_LGIF', 'SPLIT_RUFUS']))
                              & (f.col('is_balance') == f.lit("true")))) \
                    .registerTempTable(oo)
                self.out_df[oo] = self.spark.sql("select * from {}".format(oo))

            if oo in ['fishtank_enum', 'sales_owner_agreement_xref']:
                if oo == 'fishtank_enum':
                    if 'aum_amount' in self.all_df.columns:
                        self.all_df = self.all_df.withColumnRenamed('aum_amount', 'aum')
                    self.all_df.select([name for name in self.schema[oo]['fields'] if name in self.all_df.schema.names]) \
                        .registerTempTable(oo)
                    self.out_df[oo] = self.spark.sql("select * from {}".format(oo))

                if oo == 'sales_owner_agreement_xref':
                    # print(f"self.df.schema.names for {oo}: {self.df.schema.names}")
                    # print(f"self.schema[oo]['fields'] for {oo}: {self.schema[oo]['fields']}")

                    # Exclude Sub_TA's balance accounts:
                    self.all_df.filter(~f.col('employee_crm_name').rlike('/'))\
                        .filter(f.col('exclude_yn') == 'N')\
                        .filter(~(~f.col('platform').rlike("|".join(['LGAF', 'LGIF', 'RUFUS',
                                                                     'SPLIT_LGAF', 'SPLIT_LGIF', 'SPLIT_RUFUS']))
                                  & (f.col('is_balance')==f.lit("true"))))\
                        .select([name for name in self.schema[oo]['fields']
                                 if name in self.all_df.schema.names])\
                        .registerTempTable(oo)
                    self.out_df[oo] = self.spark.sql("select * from {}".format(oo))

            else:
                # Data for aum, trade, agreement, sub_agreement
                if oo == 'aum':
                    if 'trade' not in self.out_df.keys():
                        # Preserves amount for inflow/outflow before amount field gets overwritten by aum value
                        self.df = self.df.withColumnRenamed('amount', 'trade_amount')
                    else:
                        self.df = self.df.drop('amount')

                    if 'fishtank_enum' not in self.out_df.keys():
                        # Preserves aum field before it gets renamed to amount field
                        self.df = self.df.withColumn('aum_amount', f.col('aum'))

                    self.df = self.df.withColumnRenamed('aum', 'amount')
                    self.df.filter(f.col('flow_type') == 'inflow')\
                        .filter( ((f.col('platform').rlike("|".join(['LGAF', 'LGIF', 'RUFUS',
                                                                    'SPLIT_LGAF', 'SPLIT_LGIF', 'SPLIT_RUFUS']))) &
                                  (f.col('exclude_yn')==f.lit("N"))) |
                                 ((~f.col('platform')
                                   .rlike("|".join(['LGAF', 'LGIF', 'RUFUS',
                                                    'SPLIT_LGAF', 'SPLIT_LGIF', 'SPLIT_RUFUS'])))
                                   & (f.col('is_balance')==f.lit("false")))
                                 )\
                        .select([name for name in self.schema[oo]['fields'] if name in self.df.schema.names])\
                        .registerTempTable(oo)
                    self.out_df[oo] = self.spark.sql("select * from {}".format(oo))

                if oo == 'agreement':
                    self.df.filter( (f.col('platform').rlike("|".join(['LGAF', 'LGIF', 'RUFUS',
                                                                     'SPLIT_LGAF', 'SPLIT_LGIF', 'SPLIT_RUFUS']))) &
                                    (f.col('exclude_yn') == f.lit("N"))
                                   )\
                        .select([name for name in self.schema[oo]['fields'] if name in self.df.schema.names])\
                        .registerTempTable(oo)
                    self.out_df[oo] = self.spark.sql("select * from {}".format(oo))

                if oo == 'sub_agreement':
                    self.df.filter((~f.col('platform')
                                    .rlike("|".join(['LGAF', 'LGIF', 'RUFUS',
                                                     'SPLIT_LGAF', 'SPLIT_LGIF', 'SPLIT_RUFUS'])))
                                   & (f.col('exclude_yn') == f.lit("N"))
                                   & (f.col('is_balance')==f.lit("false"))
                                   )\
                        .select([name for name in self.schema[oo]['fields'] if name in self.df.schema.names])\
                        .registerTempTable(oo)
                    self.out_df[oo] = self.spark.sql("select * from {}".format(oo))

                if oo == 'trade':
                    if 'trade_amount' in self.df.columns and 'amount' in self.df.columns:
                        self.df = self.df.drop('amount')
                        self.df = self.df.withColumnRenamed('trade_amount', 'amount')

                    self.df.filter(f.col('amount').cast("int") != 0) \
                        .withColumn('aggregator_trade_code',
                                    f.when(f.col('flow_type') == 'inflow', f.col('sign_sales'))\
                                        .otherwise(f.col('sign_redemptions')))\
                        .filter( ((f.col('platform').rlike("|".join(['LGAF', 'LGIF', 'RUFUS',
                                                                       'SPLIT_LGAF', 'SPLIT_LGIF', 'SPLIT_RUFUS'])))
                                     & (f.col('exclude_yn') == f.lit("N")) ) |
                                     ((~f.col('platform')
                                       .rlike("|".join(['LGAF', 'LGIF', 'RUFUS',
                                                        'SPLIT_LGAF', 'SPLIT_LGIF', 'SPLIT_RUFUS'])))
                                       & (f.col('exclude_yn') == f.lit("N"))
                                       & (f.col('is_balance')==f.lit("false")))
                                 )\
                        .select([name for name in self.schema[oo]['fields'] if name in self.df.schema.names]) \
                        .registerTempTable(oo)
                    self.out_df[oo] = self.spark.sql("select * from {}".format(oo))

        return self

    def map(self):
        # Preserve all records to be used for fishtank_enum, sales_owner_agreement_xref
        self.all_df = self.df

        for oo in self.schema:
            print(f"Creating data for {oo} table...")
            if oo == 'entity':
                self.df.select([name for name in self.schema[oo]['fields'] if name in self.df.schema.names]) \
                    .registerTempTable(oo)
                self.out_df[oo] = self.spark.sql("select * from {}".format(oo))

            if oo == 'agreement_entity_xref':
                self.df.select([name for name in self.schema[oo]['fields'] if name in self.df.schema.names]) \
                    .filter(~f.col('office_name').isin('Dublin Office – Balance Account Data Only')) \
                    .registerTempTable(oo)
                self.out_df[oo] = self.spark.sql("select * from {}".format(oo))

            if oo in ['fishtank_enum', 'sales_owner_agreement_xref']:
                if oo == 'fishtank_enum':
                    if 'aum_amount' in self.all_df.columns:
                        self.all_df = self.all_df.withColumnRenamed('aum_amount', 'aum')
                    self.all_df.select([name for name in self.schema[oo]['fields'] if name in self.all_df.schema.names]) \
                        .registerTempTable(oo)
                    self.out_df[oo] = self.spark.sql("select * from {}".format(oo))

                if oo == 'sales_owner_agreement_xref':
                    # print(f"self.df.schema.names for {oo}: {self.df.schema.names}")
                    # print(f"self.schema[oo]['fields'] for {oo}: {self.schema[oo]['fields']}")

                    # Exclude Sub_TA's balance accounts:
                    self.all_df.filter(~f.col('employee_crm_name').rlike('/'))\
                        .filter(f.col('exclude_yn') == 'N')\
                        .filter(~(~f.col('platform').rlike("|".join(['LGAF', 'LGIF', 'RUFUS',
                                                                     'SPLIT_LGAF', 'SPLIT_LGIF', 'SPLIT_RUFUS']))
                                  & (f.col('is_balance')==f.lit("true"))))\
                        .select([name for name in self.schema[oo]['fields']
                                 if name in self.all_df.schema.names])\
                        .registerTempTable(oo)
                    self.out_df[oo] = self.spark.sql("select * from {}".format(oo))

            else:
                # Data for aum, trade, agreement, sub_agreement
                if oo == 'aum':
                    if 'trade' not in self.out_df.keys():
                        # Preserves amount for inflow/outflow before amount field gets overwritten by aum value
                        self.df = self.df.withColumnRenamed('amount', 'trade_amount')
                    else:
                        self.df = self.df.drop('amount')

                    if 'fishtank_enum' not in self.out_df.keys():
                        # Preserves aum field before it gets renamed to amount field
                        self.df = self.df.withColumn('aum_amount', f.col('aum'))

                    self.df = self.df.withColumnRenamed('aum', 'amount')
                    self.df.filter(f.col('flow_type') == 'inflow')\
                        .filter(~f.col('office_name').isin('Dublin Office – Balance Account Data Only'))\
                        .select([name for name in self.schema[oo]['fields'] if name in self.df.schema.names])\
                        .registerTempTable(oo)
                    self.out_df[oo] = self.spark.sql("select * from {}".format(oo))

                if oo == 'agreement':
                    self.df.filter( (f.col('platform').rlike("|".join(['LGAF', 'LGIF', 'RUFUS',
                                                                     'SPLIT_LGAF', 'SPLIT_LGIF', 'SPLIT_RUFUS']))) &
                                    (~f.col('office_name').isin('Dublin Office – Balance Account Data Only'))
                                   )\
                        .select([name for name in self.schema[oo]['fields'] if name in self.df.schema.names])\
                        .registerTempTable(oo)
                    self.out_df[oo] = self.spark.sql("select * from {}".format(oo))

                if oo == 'sub_agreement':
                    self.df.filter((~f.col('platform')
                                    .rlike("|".join(['LGAF', 'LGIF', 'RUFUS',
                                                     'SPLIT_LGAF', 'SPLIT_LGIF', 'SPLIT_RUFUS'])))
                                   & (~f.col('office_name').isin('Dublin Office – Balance Account Data Only'))
                                   )\
                        .select([name for name in self.schema[oo]['fields'] if name in self.df.schema.names])\
                        .registerTempTable(oo)
                    self.out_df[oo] = self.spark.sql("select * from {}".format(oo))

                if oo == 'trade':
                    if 'trade_amount' in self.df.columns and 'amount' in self.df.columns:
                        self.df = self.df.drop('amount')
                        self.df = self.df.withColumnRenamed('trade_amount', 'amount')

                    self.df.filter(f.col('amount').cast("float") != 0.0) \
                        .withColumn('aggregator_trade_code',
                                    f.when(f.col('flow_type') == 'inflow', f.col('sign_sales'))\
                                        .otherwise(f.col('sign_redemptions')))\
                        .filter(~f.col('office_name').isin('Dublin Office – Balance Account Data Only'))\
                        .select([name for name in self.schema[oo]['fields'] if name in self.df.schema.names]) \
                        .registerTempTable(oo)
                    self.out_df[oo] = self.spark.sql("select * from {}".format(oo))

        return self


    @to_doc(indent=0)
    def create_entity(self):
        """Create advisor from CRM_ID of FT_ID
           |  - for now - get ft_id
           |  - TODO - get CRM_ID to populate
        """

        self.add_static_column(col='aggregator_id', val='ft')
        self.create_advisor()

        # Turn-off platform-based agreements for now:
        # self.create_platform()

        self.melt_entities()
        return

    @to_doc(indent=0)
    def identify_balance_accounts(self):
        """Find all balance accounts"""
        # identify balance acccounts
        self.obj = self.obj.withColumn('is_balance',
                                       f.when(f.lower(f.col('organization_name')).rlike('balance account'),
                                              f.lit("true")).otherwise(f.lit("false")))

        return self

    @to_doc(indent=0)
    # TODO: Handled in map(). Remove this method later.
    def remove_split_records(self):
        """Find all split accounts for credit assignment
            |  - EDM-1481
        """
        self.obj = self.obj.filter(~f.col('platform').rlike("|".join(["SPLIT_LGAF", "SPLIT_LGIF", "SPLIT_RUFUS"])))
        return self

    # This method is not used currently:
    @to_doc(indent=1)
    def create_platform(self):
        """Create advisor from CRM_ID of FT_ID
           |  - for now - get ft_id
           |  - TODO - get CRM_ID to populate
        """

        self.hash(cols=['platform'], out='platform_id')
        self.rename(col='platform', out='platform_name')

        self.add_static_column(col='platform_entity_type_id', val='platform')

        self.add_null_columns(cols=['platform_ft_id', 'platform_parent_id', 'platform_client_type_id'])
        # TODO - make a ticket for enrich
        self.add_static_column(col='platform_primary_relationship', val='False')
        self.add_static_column(col='platform_relationship_type_id', val='platform')
        self.rename(col='platform_crm_id', out='platform_crm')

        return self

    @to_doc(indent=1)
    def create_advisor(self):
        """Create advisor from CRM_ID of FT_ID
           |  - for now - get ft_id
           |  - TODO - get CRM_ID to populate
        """
        self.rename(col='crm_id', out='salesforce_id')
        self.hash(cols=['salesforce_id', 'ft_id'], out='advisor_id')
        self.hash(cols=['salesforce_id', 'ft_id'], out='persistence_id')

        self.rename(col='organization_name', out='advisor_name')
        self.rename(col='ft_id', out='advisor_ft_id')

        self.add_static_column(col='advisor_parent_id', val='None')

        # Let's just always use the salesforce entity_type_id for advisor
        self.add_static_column(col='advisor_type_id', val='None')

        self.rename(col='client_type', out='advisor_client_type_id')

        # TODO - make a ticket for enrich
        self.rename(col='client_type', out='advisor_entity_type_id')
        self.add_static_column(col='advisor_entity_type_id', val='None')

        self.add_static_column(col='advisor_primary_relationship', val='yes')
        self.add_static_column(col='advisor_relationship_type_id', val='asset_owner')
        self.rename(col='salesforce_id', out='advisor_crm')
        self.add_static_column(col='crm_id', val='None')

        return self

    @to_doc(indent=1)
    def melt_entities(self):
        """ Melt advisor and platform"""

        '''
        pre_melt = {
            "advisor":["advisor_id", "advisor_crm", "advisor_ft_id",
                       "advisor_name", "advisor_parent_id",
                       "advisor_client_type_id", "advisor_entity_type_id",
                       "advisor_primary_relationship", "advisor_relationship_type_id"] ,
            "platform": ["platform_id", "platform_name", "platform_ft_id",
                         "platform_name", "platform_parent_id",
                         "platform_client_type_id", "platform_entity_type_id",
                         "platform_primary_relationship", "platform_relationship_type_id"]
        }
        '''

        pre_melt = {
            "advisor": ["advisor_id", "advisor_crm", "advisor_ft_id",
                        "advisor_name", "advisor_parent_id",
                        "advisor_client_type_id", "advisor_entity_type_id",
                        "advisor_primary_relationship", "advisor_relationship_type_id"]
        }

        post_melt = {"entity": ["entity_id", "salesforce_id", "fishtank_id",
                                "entity_name", "parent_id",
                                "client_type_id", "entity_type_id",
                                "primary_relationship", "relationship_type_id"]}

        self.melt(cols=pre_melt, out=post_melt)

    @to_doc(indent=0)
    def create_agreement(self):
        """Create agreement from entity_id and ISIN
            | -
        """
        self.hash(cols=['salesforce_id', 'platform', 'isin', 'advisor_ft_id'], out='agreement_id')
        self.rename(col='isin', out='external_identifier')
        self.add_static_column(col='external_identifier_type', val='isin')
        self.rename(col='channel_mapping', out='channel_id')
        self.rename(col='employee_crm_name', out='sales_owner_id')
        self.rename(col='currency', out='preferred_currency_id')
        self.rename(col='salesforce_id', out='external_entity_id')

        self.hash(cols=['entity_id', 'agreement_id'], out='agreement_entity_xref_id')
        return self

    # Currently this method is not used
    @to_doc(indent=0)
    def determine_agreement_parent_id(self):
        """ RUFUS, LGIF, LFGAF: no parent, these are ta-level
            Else: set parent as hash(platform, isin)
        """
        self.hash(cols=['platform_crm_id', 'isin'], out='platform_agreement_id')
        self.assign_parent_based_platform()
        self.correct_balance_accounts()
        return self

    @to_doc(indent=1)
    def assign_parent_based_platform(self):
        """ Assign
        |  - agreement: None if platform in ('LGIF', 'LGAF', 'RUFUS')
        |  - sub-agreement: hash(
        """

        statement = [('LGIF', 'ERROR - NO PARENT'), ('LGAF', 'ERROR - NO PARENT'), ('RUFUS', 'ERROR - NO PARENT')]
        default = f.col('platform_agreement_id')

        self.switch_case_2(col='platform', out='parent_agreement_id', statement=statement, default=default)
        self.rename(col='parent_agreement_id', out='etl_error')

        return self

    @to_doc(indent=1)
    def correct_balance_accounts(self):
        """ If a balance_account
            |  - remove negative balances from TA level
        """

        # pull out a copy of balance accounts to copy to sub_agreement with the correct parent_agreement_id
        # bal_subta_df = self.obj.filter(f.col('is_balance')).withColumn('parent_agreement_id',
        #                                                                   f.col('platform_agreement_id'))

        # remove balance accounts from ta level records with negative AUM balance
        self.is_negative(col='aum', out='aum_is_neg', cast=True, bool=True)
        self.obj = self.obj.filter(~(f.col('parent_agreement_id').isin(['ERROR - NO PARENT']) & f.col('aum_is_neg')))

        # statement = [('yes', f.col('platform_agreement_id')), ('no', f.lit('None'))]
        # default = 'error'
        # self.switch_case_2(col='is_balance', out='sub_ta_parent_agreement_id', statement=statement, default=default

        return self

    @to_doc(indent=0)
    def pre_melt_flows(self):
        """Create agreement from entity_id and ISIN
            | - melt flows into 'in' and 'out' trades
        """
        # sales --> inflow

        self.cast(cols=['gross_sales', 'gross_redemptions'], typecast='FLOAT')
        self.is_negative(col='gross_sales', out='gross_sales_neg')
        self.is_negative(col='gross_redemptions', out='gross_redemptions_neg')
        self.abs(col='gross_sales', out='abs_sales')
        self.abs(col='gross_redemptions', out='abs_redemptions')

        self.switch_case_2(col='gross_sales_neg', out='sign_sales',
                           statement=[('true', '1'),
                                      ('false', '1')],
                           default='error_sales')
        self.switch_case_2(col='gross_redemptions_neg', out='sign_redemptions',
                           statement=[('true', '2'),
                                      ('false', '2')],
                           default='error_redepemption')
        self.add_static_column(col='in_code', val='inflow')
        self.add_static_column(col='out_code', val='outflow')

        self.cast(cols=['abs_sales', 'abs_redemptions'], typecast='STRING')
        return self

    @to_doc(indent=0)
    def simple_transform_flows(self):
        """ Simple trades
            |  1) sales
            |  2) redemptions
        """
        self.pre_melt_flows()

        pre_melt = {
            "in": ["abs_sales", "in_code", "in_code"],
            "out": ["abs_redemptions", "out_code", "out_code"]
        }

        post_melt = {
            "trade": ["amount", "aggregator_trade_code", "flow_type"]
        }
        self.melt(cols=pre_melt, out=post_melt)
        self.hash(cols=['agreement_id', 'aggregator_trade_code'], out='trade_id')

    @to_doc(indent=0)
    def transform_flows(self):
        """Create trade - preserving four types
            |  1) positive sales
            |  2) negative sales
            |  3) positive redemptions
            |  4) negative redemptions
        """

        self.pre_melt_flows()

        pre_melt = {
            "in": ["abs_sales", "sign_sales", "in_code"],
            "out": ["abs_redemptions", "sign_redemptions", "out_code"]
        }

        post_melt = {
            "trade": ["amount", "aggregator_trade_code", "flow_type"]
        }

        self.melt(cols=pre_melt, out=post_melt)
        self.hash(cols=['agreement_id', 'aggregator_trade_code'], out='trade_id')

        return self

    @to_doc(indent=0)
    def deal_with_dates(self):
        """ Ignore until we get actual dates"""

        last_bus_day_udf = f.udf(lambda z: date_util.last_business_day_in_month(z, num_months_back=1))
        self.obj = self.obj.withColumn('prev_month_last_bus_date',
                                       last_bus_day_udf(f.substring_index(f.col('period'), '.', 1)))

        self.add_time_column(col='start_date', source=None, is_column=True, date='prev_month_last_bus_date',
                             pattern_in='%Y-%m-%d %H:%M:%S.%f')
        self.add_time_column(col='end_date', source=None, is_column=True, date='period',
                             pattern_in='%Y-%m-%d %H:%M:%S.%f')
        return self

    @to_doc(indent=0)
    def build_aum(self):
        """ Build aum from amount
        """
        # self.rename(col='aum', out='amount')
        self.rename(col='currency', out='currency_id')
        self.add_time_column(col='as_of_date', source=None, is_column=True, date='period',
                             pattern_in='%Y-%m-%d %H:%M:%S.%f')
        self.hash(cols=['agreement_id', 'as_of_date'], out='aum_id')

        return self

    @to_doc(indent=0)
    def populate_fca_id(self):
        """{h2}Populate fca_id on the entity_table{/h2}
            |  - TODO - comment left on the fields list
        """
        self.rename(col='fca_number', out='fca_id')

        return self

    @to_doc(indent=0)
    def add_ft_time_columns(self):
        """{h2}Adds time_columns to file from Fishtank file{/h2}"""
        self.add_time_column(col='updated_at', source='conf', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        self.add_time_column(col='created_at', source='conf', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')

        return self

    @to_doc(indent=0)
    # TODO: Not used, can be removed later
    def split_agreement_type(self):
        """ agreement: no-parent OR is_balance_acc and
        """
        '''
        self.out_df['agreement'] = self.out_df['agreement'].filter(
            (self.out_df['agreement']['etl_error'].isin(['ERROR - NO PARENT'])))
        '''
        self.out_df['sub_agreement'] = self.out_df['sub_agreement'].filter(
            ~(self.out_df['sub_agreement']['etl_error'].isin(['ERROR - NO PARENT'])))

        return self

    @to_doc(indent=0)
    def sum_aum(self):
        """sum aum"""
        self.out_df['aum'] = self.out_df['aum'] \
            .groupBy([ii for ii in self.out_df['aum'].schema.names if ii not in ['amount']]) \
            .agg(f.sum('amount').alias('amount'))
        return self

    @to_doc(indent=0)
    def sum_flows(self):
        """sum aum"""
        self.out_df['trade'] = self.out_df['trade']\
            .groupBy([ii for ii in self.out_df['trade'].schema.names if ii not in ['amount']])\
            .agg(f.sum('amount').alias('amount'))
        return self

    def create_sales_owner_agreement(self):

        def create_sales_owner_cols_udf(platform, employee_crm_name, ft_id):
            if platform.find('SPLIT') >= 0:
                if employee_crm_name.find('/') >= 0:
                    return (str('Y'), str('1'))
                if ft_id.find('_1') >= 0:
                    return (str('Y'), str('0.5'))
                elif ft_id.find('_') >= 0:
                    # Stamp anything other than _1 as Secondary
                    return (str('N'), str('0.5'))
                else:
                    # employee_crm_name without a slash:
                    return (str('Y'), str('1'))
            else:
                return (str('Y'), str('1'))

        schema = StructType([
            StructField("primary_owner_flag", StringType(), False),
            StructField("percent_owned", StringType(), False)
        ])

        sales_owner_udf = f.udf(create_sales_owner_cols_udf, schema)

        # df = df.select(sales_owner_udf(col('platform'), col('employee_crm_name'), col('ft_id')).alias('so_cols'))
        obj_cols = self.obj.columns
        self.obj = self.obj.withColumn('salesowner_arr',
                                       sales_owner_udf(f.col('platform'),
                                                       f.col('employee_crm_name'), f.col('ft_id')))
        self.obj = self.obj.select([c for c in obj_cols] +
                                   ['salesowner_arr.primary_owner_flag', 'salesowner_arr.percent_owned'])

        self.rename(col='employee_crm_name', out='sales_owner_id')
        self.hash(cols=['agreement_id','sales_owner_id'], out='sales_owner_xref_id')
        self.add_static_column(col='sales_owner_id_type', val='fishtank')

        return self

    def mark_exclusions(self):
        """
        New column 'exclude_yn' to enable filtering off certain accounts from reporting AuM.
        Logic for exclude_yn column:
        set Y for negative AuMs
        set Y for non-SPLITs associated with SPLIT accounts
        set N for SPLITS
        set N for standalone non-SPLITS
        """

        df1 = self.obj.withColumn("exclude_yn", f.lit("n"))
        # df1 = df.filter(df.aum.cast('float')>0)

        gdf = df1.groupBy(df1.ft_id.substr(1, 7))
        gdf1 = gdf.agg(f.collect_set('ft_id'))\
            .withColumnRenamed('collect_set(ft_id)', 'ft_id_set')\
            .withColumnRenamed('substring(ft_id, 1, 7)', 'ft_group_id')
        gdf2 = gdf1.withColumn('ft_id_length', f.size(gdf1['ft_id_set']))\
                    .filter(f.col('ft_id_length') > 1)
        ft_to_exclude = gdf2.drop('ft_id_set', 'ft_id_length')

        df2 = df1.join(ft_to_exclude, df1.ft_id == ft_to_exclude.ft_group_id, how='left') \
            .withColumn('exclude_yn',
                        f.when((f.col('ft_group_id').isNotNull())
                               | ((f.col('aum').cast('float') < 0.0)
                                  & (f.col('platform').substr(1, 5) == 'SPLIT')),
                               f.lit('Y'))
                        .otherwise(f.lit('N')))

        self.obj = df2
        return self

    def process(self):
        """Order of execution for transforming a Transformer object"""
        self.trim_columns()

        null_entity_sv = ['group_id', 'crd', 'iard', 'salesvision_id', 'ended_at', 'err_msg', 'psn',
                          'asic_license_number', 'job_desc', 'sv_event_code', 'ingested_at', 'home_office_flag',
                          'broker_rep_code']
        null_entity_sf = ['salesforce_id']
        null_entity_ai = ['ai_investor_id', 'ai_subinvestor_id']
        null_entity_ct = ['do_not_contact']
        null_entity_hr = ['employee_id']
        null_entity_amg = ['lei', 'account_number']
        null_entity_todo = ['persistence_id', 'ect_entity_id', 'ect_channel_id', 'ect_team_id']
        self.add_null_columns(cols=[*null_entity_sv, *null_entity_sf, *null_entity_ai,
                                    *null_entity_ct, *null_entity_hr, *null_entity_amg,
                                    *null_entity_todo])

        null_agreement_sf = ['account_sf_id', 'ocio_flag', 'inception_date', 'ended_at', 'firm_type_id',
                             'money_type_id']
        null_agreement_aict = ['ipo_flag', 'erisa_plan']
        null_agreement_aus = ['unit_holder_code']
        null_agreement_dmi = ['ta_number']
        null_agreement_sv = ['origin_id']
        null_agreement_todo = ['benchmark_id', 'sub_agreement_id', 'agreement_type']
        null_agreement_cols = ['agreement_name', 'parent_agreement_id', 'external_agreement_id', 'external_entity_id']
        self.add_null_columns(cols=[*null_agreement_sf, *null_agreement_aict, *null_agreement_aus,
                                    *null_agreement_dmi, *null_agreement_sv, *null_agreement_todo,
                                    *null_agreement_cols])
        # self.obj = self.obj.withColumn('ta_number', f.lit("Not Applicable"))
        # self.remove_split_records()

        self.identify_balance_accounts()
        self.mark_exclusions()
        self.create_entity()
        self.create_agreement()
        # self.determine_agreement_parent_id()
        self.create_sales_owner_agreement()
        self.simple_transform_flows()
        self.build_aum()
        self.add_ft_time_columns()
        self.deal_with_dates()
        self.populate_fca_id()
        self.commit()
        self.map()

        # self.split_agreement_type()
        self.sum_aum()
        self.sum_flows()

        return self
