from skylla.transform.general_transform import Transformer

import pyspark.sql.functions as f
from pyspark.sql.types import *

from cm_commons.decorators import to_doc


class CTTransformer(Transformer):
    """
    # #---------------------------------------------------------------# #
    # #                          CT Transformer                       # #
    # #---------------------------------------------------------------# #
    """

    @to_doc(indent=0)
    def build_entity(self):
        """{h2}Hash Entity_ID using ta_number & client_portfolio_id (portia ID), use investor type for entity type{/h2}"""
        self.hash(cols=['ta_number', 'client_portfolio_id', 'cusip'], out='entity_id')
        self.rename(col='investor_type', out='entity_type_id')
        self.add_static_column(col='parent_id', val='None')
        return self

    @to_doc(indent=0)
    def build_agreement(self):
        """{h2}Build agreement ID from hashed owner ID, add agreement type{/h2}"""
        self.rename(col='entity_id', out='asset_owner_id')
        self.hash(cols=['asset_owner_id', 'cusip'], out='agreement_id')
        self.add_static_column(col='agreement_type', val='holding')
        self.rename(col='cusip', out='external_identifier')
        self.add_static_column(col='external_identifier_type', val='cusip')

        return self

    @to_doc(indent=0)
    def build_agreement_entity_xref(self):
        """{h2}builds agreement_entity_xref using asset_owner{/h2}"""
        self.hash(cols=['asset_owner_id', 'agreement_id'], out='agreement_entity_xref_id')
        self.add_static_column(col='primary_relationship', val='Y')
        self.add_static_column(col='relationship_type_id', val='asset_owner')
        return self

    @to_doc(indent=0)
    def build_aum(self):
        """{h2}Hashes AGREEMENT_ID to make AUM ID, add PMF ID{/h2}"""
        self.hash(cols=['agreement_id'], out='aum_id')
        self.rename(col='aum', out='amount')
        self.add_static_column(col='currency_id', val='USD')
        return self

    @to_doc(indent=0)
    def add_file_details(self):
        """
        Adds SOURCE_FILE, DATE_INFORMATION to dataframe
        """
        self.add_static_column(col='aggregator_id', val='CT')

        self.add_time_column(col='updated_at', source='conf', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        self.add_time_column(col='created_at', source='conf', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        self.add_time_column(col='as_of_date', source='conf', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')

        return self



    @to_doc(indent=0)
    def populate_account_number(self):
        """{h2}TODO - Populate account number
           {/h2}"""
        self.rename(col='ta_number', out='account_number')
        self.rename(col='ta_number', out='ta_number')
        return self

    @to_doc(indent=0)
    def populate_erisa_plan(self):
        """{h2}Pulling erisa plan directly from the file{/h2}"""
        self.rename(col='erisa_plan_number', out='erisa_plan')
        return self

    @to_doc(indent=0)
    def populate_client_type_id(self):
        """{h2}Populate client_type_id{/h2}
            |   - fill in client_type_id with investor_type EDM-1047
            |   - TODO - enrich EDM-602"""
        self.rename(col='investor_type', out='client_type_id')
        return self

    @to_doc(indent=0)
    def populate_channel(self):
        """{h2}Populate channel_id{/h2}
            |  - fill in channel_id with investor_id EDM-1044
            |  - TODO - enrich EDM-873"""
        self.rename(col='investor_type', out='channel_id')
        return self

    @to_doc(indent=0)
    def populate_do_not_contact(self):
        """{h2}TODO - Populate do_not_contact with regex entity logic
            |  - EDM-551
           {/h2}"""
        self.add_static_column(col='do_not_contact', val='EDM-551')
        return self

    # @to_doc(indent=0)
    # def populate_employee_id(self):
    #     """{h2}
    #         |  - HR will populate
    #        {/h2}"""
    #     self.add_static_column(col='employee_id', val='EDM-1049')
    #     return self

    @to_doc(indent=0)
    def populate_inception_date(self):
        """{h2}TODO - Populate inception_date
           {/h2}"""
        self.add_static_column(col='inception_date', val='EDM-1050')
        return self

    @to_doc(indent=0)
    def process(self):
        null_entity = ['salesforce_id', 'crm_id', #SF
                       'fca_id',  # fishtank
                       'iard', 'salesvision_id', 'group_id', 'crd', # SV
                       'ai_investor_id','ai_subinvestor_id', # AI
                       'persistence_id', # null for now
                       'licensee_id', # AUS
                       'lei', #placeholder,
                       'employee_id' # HR load
                       ]
        null_agreement = ['ocio_flag', 'money_type', # SF
                          'unit_holder_code', # AUS
                          'benchmark_id'] # placeholder
        null_aum = ['aum_type', 'origin_id', 'end_of_period_aum']

        self.build_entity()
        self.build_agreement()
        self.build_agreement_entity_xref()
        self.build_aum()

        # additional column data
        self.add_file_details()

        # add null columns
        self.add_null_columns(cols=null_entity)
        self.add_null_columns(cols=null_agreement)
        self.add_null_columns(cols=null_aum)

        # TODO - all of these
        self.populate_channel()
        self.populate_account_number()
        self.populate_erisa_plan()
        self.populate_client_type_id()
        self.populate_do_not_contact()
        #self.populate_employee_id()
        self.populate_inception_date()
        # Map to tables
        self.commit().map()

        return self
