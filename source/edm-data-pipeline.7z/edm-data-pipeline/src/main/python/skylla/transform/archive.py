### WILL DELETE THESE IN THE FUTURE

class LQETransformer(Transformer):
    """

    Transformer protocol for LQE TA data
    - Take (Dealer x Rep x Fund) -> Agreement slices and aggregate over AUM/flow df data

    +--------------------+----------------+--------------------+----------------+--------------------+
    |            DealerID|           RepID|              FundID|             AUM|                Flow|
    +--------------------+----------------+--------------------+----------------+--------------------+
    |                ....|            ....|                ....|            ....|                ....|

    - Load into a postgres database in load

    """

    fields = {'DEA_NUM1': 'DealerNumber', 'PER_ID32': 'AdvisorID', 'PRO_CUSIP9': 'FundID',
              'PURCHASES_AMOUNT15_20180808': 'flow_out', 'REDEMPTIONS_AMOUNT16_20180808':'flow_in','ACCOUNT_BALANCE26_20180629': 'aum',
              'PRO_TYPE14': 'ProductType'}
    grp_expr = {'DealerNumber': True, 'AdvisorID': True, 'FundID': True,
                }
    agg_expr = {'flow_in': "sum", 'flow_out': 'sum', 'aum': "sum"}
    null_expr = {'flow_in': True, 'flow_out': True, 'aum': True}

    def __init__(self, df):
        """Initialize using LQE defaults"""
        self.fields = LQETransformer.fields
        self.grp_expr = LQETransformer.grp_expr
        self.agg_expr = LQETransformer.agg_expr
        self.null_expr = list(filter(LQETransformer.null_expr.get, LQETransformer.null_expr))
        self.obj = df  # dynamic instance of Spark objects
        self.df = df

    def process(self):
        """Order of execution for LQE"""
        return self.fix_names().fill_nulls().group_by().agg().sub_cols('sum(flow_in)', 'sum(flow_out)', 'net_flow').commit()


class LQEClientReferenceSplit(Transformer):
    """
    Transformer protocol for LQE_client_meta_data
    - Take entity-centric slices from LQE and store as raw rows in parquet output

                           Teams
                             |
    - ex I/O: Territory -- Entity -- Address
                             |
                     Name/LEI/CRD/TaxID

    """
    fields = {'PER_ID32': 'AdvisorID', 'PER_FIRST_NAME28': 'EntityName1','PER_LAST_NAME29': 'EntityName2', 'PER_CRD_NUMBER30': 'CRD',
              'SHD_TERRITORY52': 'TerritoryID', # Need to parse this into name and number
              'OFL_ADDR_LINE139': 'Address', 'OFL_CITY40': 'City', 'OFL_REGION_REF_CODE41': 'State',
              'PGP_GROUP_NAME36': 'TeamID'}
    select1 = fields.values()
    distinct_expr = {val: True for val in fields.values()}

    def __init__(self, df):
        self.df = df
        self.obj = df
        self.fields = LQEClientReferenceSplit.fields
        self.distinct_expr = LQEClientReferenceSplit.distinct_expr

    def process(self):
        """Order of operation"""
        return self.fix_names().select(LQEClientReferenceSplit.select1).distinct().commit()


def find_parent(df, rules):
    """"-> udf for finding parent level in SV_LQE row"""
    for rid in rules.keys():
        if rules[rid](df):
            return df[rid]
    return lit(None)


class LQEEntities(Transformer):
    """
    +--------------------+----------------+--------------------+----------------+
    |           EntityID |     EntityType |         EntityName |       ParentID |
    +--------------------+----------------+--------------------+----------------+
    |                ....|            ....|                ....|            ....|

    """
    fields = {'PER_CRD_NUMBER30': 'PerCRD', 'PER_FIRST_NAME28': 'FirstName', "PER_LAST_NAME29": 'LastName',
              'PER_ID32': 'TeamID', 'PER_BROKER_TEAM_FLG33': 'TeamFlag',      ## Team
              'PGP_ID37': 'GroupID',
              'DEB_BRANCH_CODE38': 'BranchCode',
              'OFL_ID42': 'OfficeID', 'OFL_REGION_REF_CODE41': 'OfficeName',
              'FIR_CRD3': 'FirmCRD', 'FIR_NAME6': 'FirmName'}
    grp_expr = {'EntityID': True}
    agg_expr = {'flow_in': "sum", 'flow_out': 'sum', 'aum': "sum"}
    sel_expr = ['PersonName', 'person']
    null_expr = {'flow_in': True, 'flow_out': True, 'aum': True}

    ent_fields = [StructField("EntityID", StringType(), True),
                  StructField("EntityType", StringType(), True),
                  StructField("EntityName", StringType(), True),
                  StructField("ParentID", StringType(), True)]

    def __init__(self, df, sc, sqlContext):
        """Initialize using LQE defaults"""
        self.fields = LQEEntities.fields
        self.grp_expr = LQEEntities.grp_expr
        self.agg_expr = LQEEntities.agg_expr
        self.null_expr = list(filter(LQEEntities.null_expr.get, LQEEntities.null_expr))
        self.obj = df  # dynamic instance of Spark objects
        self.df = df
        self.ent = sqlContext.createDataFrame(sc.emptyRDD(), StructType(LQEEntities.ent_fields))
        self.sc = sc
        self.sqlContext = sqlContext


    def get_temp(self):
        temp = self.sqlContext.createDataFrame(self.sc.emptyRDD(), StructType(LQEEntities.ent_fields))
        return temp

    def get_person(self):
        """Tabulates all people in self.ent"""

        # find_person_parent(df, rules)
        person_udf = udf(find_parent)
        rules = {'TeamID': lambda x: x['TeamFlag'] == 'Y',
                 'BranchCode': lambda x: x,
                 'OfficeID': lambda x: x,
                 'FirmCRD': lambda x: x}

#        temp = temp.withColumn("EntityType", lit("person"))
#        temp = temp.withColumn("ParentID", person_udf(self.obj, rules))
        # .where("PerCRD").isNotNull

        self.ent = self.obj.select('person', 'PersonName')

        return self

    def get_team(self, out='team'):
        """"Tabulates all teams in self.ent"""

        team_udf = udf(find_parent)
        rules = {'BranchCode': lambda x: x,
                 'OfficeID': lambda x: x,
                 'FirmCRD': lambda x: x}

        self.ent = self.ent.union(self.ent.withColumn('EntityID', self.obj['TeamID'])
                                          .withColumn("EntityType", lit("team"))
                                          .withColumn('EntityName', lit(None))
                                          .withColumn("ParentID", team_udf(self.obj, rules))
                                          .where(col("EntityID").isNotNull))
        return self

    def get_group(self, out='group'):
        """Figure out how we want to handle group"""
        pass

    def get_branch(self):
        """"Tabulates all branches in self.ent"""
        branch_udf = udf(find_parent)
        rules = {'OfficeID': lambda x: x,
                 'FirmCRD': lambda x: x}

        self.ent = self.ent.union(self.ent.withColumn('EntityID', self.obj['BranchCode'])
                                  .withColumn("EntityType", lit("branch"))
                                  .withColumn('EntityName', lit(None))
                                  .withColumn("ParentID", branch_udf(self.obj, rules))
                                  .where(col("EntityID").isNotNull))
        return self

    def get_office(self):
        """"Tabulates all offices in self.ent"""
        office_udf = udf(find_parent)
        rules = {'FirmCRD': lambda x: x}

        self.ent = self.ent.union(self.ent.withColumn('EntityID', self.obj['OfficeID'])
                                  .withColumn("EntityType", lit("office"))
                                  .withColumn('EntityName', self.obj['OfficeName'])
                                  .withColumn("ParentID", office_udf(self.obj, rules))
                                  .where(col("EntityID").isNotNull))
        return self

    def get_firm(self):
        """Tabulates all firms in self.ent"""

        self.ent = self.ent.union(self.ent.withColumn('EntityID', self.obj['FirmCRD'])
                                  .withColumn("EntityType", lit("firm"))
                                  .withColumn('EntityName', self.obj['FirmName'])
                                  .withColumn("ParentID", lit(None))
                                  .where(col("EntityID").isNotNull))
        return self

    def process(self):
        """Order of execution for LQE"""
    #
        return self.fix_names().fill_nulls() \
            .concatenate_cols("FirstName", "LastName", "PersonName", delim=" ") \
            .explode_split(col=['PerCRD','PersonName'], out=['person', 'PersonName'])\
            .get_person()\
            .swap_obj(self.ent)\
            .select(LQEEntities.sel_expr).distinct().commit()
        # .get_team().get_branch().get_office().get_firm()\

class LQEStats(Transformer):
    """

    Transformer protocol for stats and analysis

    """

    fields = {'DEA_NUM1': 'DealerNumber', 'PER_ID32': 'AdvisorID', 'PRO_CUSIP9': 'FundID',
              'PURCHASES_AMOUNT15_20180808': 'flow_out','REDEMPTIONS_AMOUNT16_20180808':'flow_in','ACCOUNT_BALANCE26_20180629': 'aum',
              'PRO_MORNINGSTAR_CLASS11': 'ProdClass','SHD_TERRITORY52': 'Territory'}
    grp_expr = {'DealerNumber': True, 'AdvisorID': True, 'FundID': True, 'ProdClass': True, 'Territory': True}
    agg_expr = {'flow_in': "sum",'flow_out':'sum', 'aum': "sum"}
    null_expr = {'flow_in': True,'flow_out': True, 'aum': True}

    def __init__(self, df):
        """Initialize using LQE defaults"""
        self.fields = LQEStats.fields
        self.grp_expr = LQEStats.grp_expr
        self.agg_expr = LQEStats.agg_expr
        self.null_expr = list(filter(LQEStats.null_expr.get, LQEStats.null_expr))
        self.obj = df  # dynamic instance of Spark objects
        self.df = df

    def process(self):
        """Order of execution for LQE"""
        return self.fix_names().fill_nulls().group_by().agg().commit()

