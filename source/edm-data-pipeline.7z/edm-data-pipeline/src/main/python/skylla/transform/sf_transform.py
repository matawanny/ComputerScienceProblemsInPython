from skylla.transform.general_transform import Transformer

import pyspark.sql.functions as f
from pyspark.sql.types import *

from cm_commons.decorators import to_doc


class SFEntityTransformer(Transformer):
    """{h1}
# #---------------------------------------------------------------# #
# #                 Salesforce Entity Transformer                 # #
# #---------------------------------------------------------------# #
    {/h1}"""

    @to_doc(indent=0)
    def build_entity(self):
        """{h2}Build Entity object from Salesforce supplied data{/h2}"""

        # create a column that's the hash of the sf id (in case persistence_id is null)
        self.rename(col='salesforce_id', out='salesforce_id')
        self.hash(cols=['salesforce_id'], out='hash_sf_id')
        self.hash(cols=['salesforce_id', 'parent_salesforce_id'], out='hash_sf_id_with_parent')

        # hash parent SF ID from SF
        self.hash(cols=['parent_salesforce_id'], out='hash_parent_sf_id')
        self.switch_case_2(col="parent_salesforce_id",
                           out="hash_parent_sf_id",
                           statement=[("None", f.lit('None')),
                                      (None, f.lit('None')),
                                      ("", f.lit('None')),
                                      ('null', f.lit('None'))],
                           default=f.col('hash_parent_sf_id'))

        # capture CM IDs if sent from SF (if not sent, create from SF IDs)
        self.obj = self.obj.withColumn('entity_id', f.when(self.obj.entity_id.isNull(), 'None')
                                       .otherwise(self.obj.entity_id))
        self.obj = self.obj.withColumn('persistence_id', f.when(self.obj.persistence_id.isNull(), 'None')
                                       .otherwise(self.obj.persistence_id))

        # switch cases to properly manage current CM ID set (if switch fails, use hash of SF ID)
        self.switch_case_2(col="persistence_id",
                           out="persistence_id",
                           statement=[("None", f.col("hash_sf_id")),
                                      (None, f.col("hash_sf_id")),
                                      ("", f.col("hash_sf_id")),
                                      ('null', f.col("hash_sf_id"))],
                           default=f.col("persistence_id"))

        self.switch_case_2(col="entity_id",
                           out="contact_entity_id",
                           statement=[("None", f.col("hash_sf_id_with_parent")),
                                      (None, f.col("hash_sf_id_with_parent")),
                                      ("", f.col("hash_sf_id_with_parent")),
                                      ('null', f.col("hash_sf_id_with_parent"))],
                           default=f.col("entity_id"))

        self.switch_case_2(col="entity_id",
                           out="org_entity_id",
                           statement=[("None", f.col("hash_sf_id")),
                                      (None, f.col("hash_sf_id")),
                                      ("", f.col("hash_sf_id")),
                                      ('null', f.col("hash_sf_id"))],
                           default=f.col("entity_id"))

        self.rename(col='entity_type_id', out='entity_type_id')

        self.add_null_columns(cols=['entity_prefix'])
        self.obj = self.obj.withColumn('entity_prefix', f.substring('entity_type_id', 0, 1))

        self.switch_case_2(col='entity_prefix',
                           out='entity_id',
                           statement=[('1', f.col('contact_entity_id'))],
                           default=f.col('org_entity_id'))

        self.obj = self.obj.withColumn('parent_entity_id', f.when(self.obj.parent_entity_id.isNull(), 'None')
                                       .otherwise(self.obj.parent_entity_id))
        self.obj = self.obj.withColumn('parent_persistence_id', f.when(self.obj.parent_persistence_id.isNull(), 'None')
                                       .otherwise(self.obj.parent_persistence_id))
        self.obj = self.obj.withColumn('parent_salesforce_id', f.when(self.obj.parent_salesforce_id.isNull(), 'None')
                                       .otherwise(self.obj.parent_salesforce_id))

        self.switch_case_2(col="parent_entity_id",
                           out="parent_id",
                           statement=[("None", f.col("hash_parent_sf_id")),
                                      (None, f.col("hash_parent_sf_id")),
                                      ("", f.col("hash_parent_sf_id")),
                                      ('null', f.col("hash_parent_sf_id"))],
                           default=f.col("parent_entity_id"))

        # additional entity fields from SF
        self.rename(col='entity_name', out='entity_name')
        self.rename(col='entity_type_name', out='entity_type_name')
        self.rename(col='client_type_id', out='client_type_id')
        self.rename(col='client_type_name', out='client_type_name')
        self.rename(col='entity_name', out='entity_name')
        self.rename(col='salesvision_id', out='salesvision_id')
        self.rename(col='err_msg', out='api_error')
        self.rename(col='employee_id', out='employee_id')
        self.rename(col='ect_channel_id', out='ect_channel_id')
        self.rename(col='ect_entity_id', out='ect_entity_id')
        self.rename(col='ect_team_id', out='ect_team_id')

        # handle all casting
        self.cast(['entity_type_id', 'client_type_id', 'crd', 'salesvision_id'], 'INTEGER')
        self.cast(['entity_type_id', 'client_type_id', 'crd', 'salesvision_id'], 'STRING')

        # update ended at with time column (if record is deleted); fill nulls if not present
        self.add_time_column(col='ended_at', is_column=True, date='ended_at', pattern_in='%Y-%m-%d %H:%M:%S', null=True)
        self.obj = self.obj.fillna('None')

        # add ingested date
        self.add_time_column(col='ingested_at', source='conf', is_column=False, date=self.conf['file_date'],
                             pattern_in='%m-%d-%Y')
        # last modified date
        self.add_time_column(col='updated_at', is_column=True, date='Last_Modified_Date',
                             pattern_in='%Y-%m-%dT%H:%M:%S.000Z')
        # end date
        statement = [('true', f.lit(self.conf['file_date']))]
        self.switch_case_2(col='inactive', out='ended_at',
                           statement=statement, default=f.col('ended_at'))
        return self

    @to_doc(indent=1)
    def manage_event_codes(self):
        """populate event code (I/U/D) col when event is triggered"""
        # determine insert or update for a record
        self.obj = self.obj.withColumn('sv_event_code',
                                       f.when(self.obj.persistence_id.isNull(), 'I')
                                       .otherwise(
                                           f.when(f.col('inactive').isin(['true']), 'D').otherwise('U')
                                       ))
        return self

    @to_doc(indent=1)
    def check_address_fields(self):
        """Check if address fields unrolled properly """
        addr_fields = ["entity_mailing_address_address_type",
                       "entity_mailing_address_street_1",
                       "entity_mailing_address_street_2",
                       "entity_mailing_address_city",
                       "entity_mailing_address_state",
                       "entity_mailing_address_country",
                       "entity_mailing_address_postal_code",
                       "entity_billing_address_address_type",
                       "entity_billing_address_street_1",
                       "entity_billing_address_street_2",
                       "entity_billing_address_city",
                       "entity_billing_address_state",
                       "entity_billing_address_country",
                       "entity_billing_address_postal_code"]

        for fn in addr_fields:
            if fn not in self.obj.schema.names:
                self.add_static_column(col=fn, val='RemoveMe')
            else:
                self.obj = self.obj.withColumn(fn, f.regexp_replace(fn, '\\t|\\n|\\r', ' '))
        return self

    @to_doc(indent=0)
    def build_address(self):
        """{h2}Melt Billing & Mailing addresses to create objects from the Salesforce request{/h2}"""
        self.check_address_fields()
        self.add_static_column(col='entity_billing_address_address_type', val='billing')
        self.add_static_column(col='entity_mailing_address_address_type', val='mailing')
        pre_melt = {
            'billing_address': ['entity_billing_address_address_type',
                                'entity_billing_address_street_1', 'entity_billing_address_street_2',
                                'entity_billing_address_city', 'entity_billing_address_state',
                                'entity_billing_address_postal_code', 'entity_billing_address_country'],
            'mailing_address': ['entity_mailing_address_address_type',
                                'entity_mailing_address_street_1', 'entity_mailing_address_street_2',
                                'entity_mailing_address_city', 'entity_mailing_address_state',
                                'entity_mailing_address_postal_code', 'entity_mailing_address_country']
        }

        post_melt = {
            'address': ['address_type_id', 'street_address_1', 'street_address_2', 'city', 'state_val',
                        'postal_code', 'country']
        }
        self.melt(cols=pre_melt, out=post_melt)
        self.hash(cols=['entity_id', 'address_type_id'], out='entity_address_id')
        self.add_exempt_state()

    @to_doc(indent=1)
    def add_exempt_state(self):
        """If country is not US, fill state with exempt"""
        # 1) US addresses must have a state
        # 2) Foreign address can have a state but don't need one

        self.add_exempt_null_columns(cols=["state_exempt"])
        self.obj = self.obj.withColumn("state",
                                       f.when(
                                           f.col("state_val").isNull() |
                                           f.col("state_val").isin(["None", "none", ""]),
                                           f.col("state_exempt")  # if non-US and null exempt
                                       ).otherwise(f.col("state_val")) # if non-US and non-null, use state value
                                    )
        return self

    @to_doc(indent=0)
    def build_entity_phone(self):
        """{h2}Create Entity Phone records from provided data{/h2}"""

        # check if phone fields are present
        if 'entity_primary_phone' not in self.obj.schema.names:
            self.add_static_column(col='entity_primary_phone', val='None')
        if 'entity_secondary_phone' not in self.obj.schema.names:
            self.add_static_column(col='entity_secondary_phone', val='None')

        # add phone types for melting
        self.add_static_column(col='primary_phone_type', val='primary')
        self.add_static_column(col='secondary_phone_type', val='secondary')

        pre_melt = {
            'primary_phone': ['entity_primary_phone', 'primary_phone_type'],
            'secondary_phone': ['entity_secondary_phone', 'secondary_phone_type']
        }

        post_melt = {
            'entity_phone': ['phone_number', 'phone_type_id']
        }

        self.melt(cols=pre_melt, out=post_melt)
        self.hash(cols=['entity_id', 'phone_type_id'], out='entity_phone_id')

        # convert null phone numbers to edm exempt to pass through MDM
        self.obj = self.obj.withColumn('phone_number',
                                       f.when(f.col('entity_type_id').isin(['101']) & f.col('phone_number').isin(
                                           ['None', 'none']), f.lit('edm_exempt')) \
                                       .otherwise(f.col('phone_number')))

        # debugging fill na for phones
        # self.obj = self.obj.fillna('None', subset=['phone_number'])
        return self

    @to_doc(indent=0)
    def build_entity_email(self):
        """{h2}Create Entity email records from provided data{/h2}"""

        # check if email fields are present
        if 'entity_primary_email' not in self.obj.schema.names:
            self.add_static_column(col='entity_primary_email', val='None')
        if 'entity_secondary_email' not in self.obj.schema.names:
            self.add_static_column(col='entity_secondary_email', val='None')

        # add email types for melting
        self.add_static_column(col='primary_email_type', val='primary')
        self.add_static_column(col='secondary_email_type', val='secondary')

        pre_melt = {
            'primary_email': ['entity_primary_email', 'primary_email_type'],
            'secondary_email': ['entity_secondary_email', 'secondary_email_type']
        }

        post_melt = {
            'entity_email': ['email_address', 'email_type_id']
        }

        self.melt(cols=pre_melt, out=post_melt)
        self.hash(cols=['entity_id', 'email_type_id'], out='entity_email_id')

        # convert null emails to edm exempt to pass through MDM
        self.obj = self.obj.withColumn('email_address',
                                       f.when(f.col('entity_type_id').isin(['101']) & f.col('email_address').isin(['None', 'none']), f.lit('edm_exempt')) \
                                       .otherwise(f.col('email_address')))
        return self

    def build_team_xref(self):
        # TODO: this
        pass

    def add_job_desc(self):
        self.rename(col='job_desc', out='job_desc_real')
        self.obj = self.obj.drop('job_desc')

        self.add_exempt_null_columns(cols=["job_desc_exempt"])
        self.obj = self.obj.withColumn("job_desc", f.when(
            (
                self.obj.entity_type_id.like("3%") |
                self.obj.entity_type_id.like("2%")
            )
                &
            (
                self.obj.job_desc_real.isNull() |
                self.obj.job_desc_real.isin(['', 'None', 'none'])
            ),
            self.obj.job_desc_exempt).otherwise(self.obj.job_desc_real))
        return self

    def remove_bad_records(self):
        """
        Remove bad records without harming other records
        :return :
        """
        if 'entity_address_xref' in self.out_df:
            self.out_df['entity_address_xref'] = self.out_df['entity_address_xref']\
                .filter(
                    (~f.col('city').isin(['RemoveMe'])) |
                    (f.col('city').isNull())
            )
        if 'entity_phone_xref' in self.out_df:
            self.out_df['entity_phone_xref'] = self.out_df['entity_phone_xref'] \
                .filter(
                    ~(f.col('phone_number').isin(['RemoveMe', '', 'none', 'None'])) |
                    (f.col('phone_number').isNull())
            )
        if 'entity_email_xref' in self.out_df:
            self.out_df['entity_email_xref'] = self.out_df['entity_email_xref'] \
                .filter(
                    ~(f.col('email_address').isin(['RemoveMe', '', 'none', 'None'])) |
                    (f.col('email_address').isNull())
            )
        return self

    @to_doc(indent=0)
    def add_file_details(self):
        """{h2}Adds {b}created_at{/b} to dataframe{/h2}"""
        self.add_time_column(col='created_at', is_column=True, date='created_at',
                             pattern_in='%Y-%m-%dT%H:%M:%S.000Z')
        return self

    def process(self):
        self.manage_event_codes()
        self.build_entity()
        self.build_address()
        self.build_entity_phone()
        self.build_entity_email()
        self.add_job_desc()

        # populate null columns
        null_entity = ['group_id', 'ai_subinvestor_id', 'ai_investor_id', 'fca_id', 'fishtank_id', 'psn',
                       'asic_license_number', 'lei', 'fca', 'iard', 'salesvision_group_id', 'do_not_contact',
                       'home_office_flag', 'broker_rep_code']

        self.add_file_details()

        null_phone = ['country_code', 'extension']
        self.add_null_columns(cols=null_entity)
        self.add_null_columns(cols=null_phone)

        # Map to tables
        self.commit().map()
        self.remove_bad_records()

        return self
