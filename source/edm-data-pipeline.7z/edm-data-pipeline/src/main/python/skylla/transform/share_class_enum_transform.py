import pyspark.sql.functions as f
from skylla.transform.general_transform import Transformer


class ShareClassEnumTransformer(Transformer):
    """
    # #---------------------------------------------------------------# #
    # #                          ShareClassEnum Transformer                      # #
    # #---------------------------------------------------------------# #
    """

    def process(self):
        # statement = [('larzard',  self.substring_column('product_name', 0, 7))]
        # out = self.remove_prefix_column('product_name', 'larzard ')
        # self.switch_case(col='product_name', out=out, statement=statement, default=f.col('product_name'))
        self.obj = self.obj.withColumn('product_name_new', f.regexp_replace('product_name', r'^Lazard ', '')) \
            .drop('product_name').withColumnRenamed('product_name_new', 'product_name')

        # print(self.conf['file_date'])
        # one way to add column
        # self.add_static_column('created_at', self.conf['file_date'])

        #the second way to add column
        # self.obj = self.obj.withColumn('updated_at', f.lit(self.conf['file_date']))

        #The correct way to add date column
        self.add_time_column(col='created_at', source='conf', is_column=False, date=self.conf['file_date'],
                             pattern_in='%m-%d-%Y')
        self.add_time_column(col='updated_at', source='conf', is_column=False, date=self.conf['file_date'],
                             pattern_in='%m-%d-%Y')

        self.add_null_columns(cols=['enrichment_error'])
        self.commit().map()
        # self.df.show()
        return self

