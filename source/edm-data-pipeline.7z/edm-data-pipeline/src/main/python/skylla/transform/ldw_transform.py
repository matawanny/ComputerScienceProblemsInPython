from skylla.transform.general_transform import Transformer

import pyspark.sql.functions as f
from pyspark.sql.types import *

from cm_commons.decorators import to_doc

class LDWEntityTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                          LDW Transformer                      # #
# #---------------------------------------------------------------# #
    """

    @to_doc(indent=0)
    def build_entity(self):
        """{h2}Builds empty entity with client_type_id {/h2}
             - EDM-1099
        """

        self.add_static_column(col='relationship_type_id', val="asset_owner")
        self.hash(cols=["symbol"], out="entity_id")
        self.rename(col="client_type", out="client_type_id")
        return self

    @to_doc(indent=0)
    def add_file_details(self):
        """
        Adds SOURCE_FILE, DATE_INFORMATION to dataframe
        """
        self.add_static_column(col='aggregator_id', val='LDW')
        self.add_time_column(col='updated_at', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        self.add_time_column(col='created_at', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')

        return self

    def process(self):
        # additional column data
        self.add_file_details()
        self.build_entity()

        self.add_null_columns(cols=['ended_at'])
        self.commit().map()
        return self


class LDWTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                          LDW Transformer                      # #
# #---------------------------------------------------------------# #
    """
    @to_doc(indent=0)
    def get_agreement(self):
        """{h2}Determine agreement_id {/h2}"""
        self.add_static_column(col='agreement_id_prefix', val='amg_portfolio')
        self.hash(cols=['agreement_id_prefix', 'portfolio_symbol'], out='agreement_id')
        return self

    @to_doc(indent=0)
    def add_file_details(self):
        """
        Adds SOURCE_FILE, DATE_INFORMATION to dataframe
        """
        self.add_static_column(col='aggregator_id', val='LDW')
        self.add_time_column(col='updated_at', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        self.add_time_column(col='created_at', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')

        return self

    @to_doc(indent=0)
    def get_trade(self):
        """ {h2}Build trade details{/h2}"""
        self.rename(col='amount', out='amount')
        self.rename(col='tran_type_remark', out='aggregator_trade_code')
        self.add_time_column(col='start_date', is_column=True, date='tran_trade_date',
                             pattern_in='%Y-%m-%d %H:%M:%S.%f')

        self.add_time_column(col='end_date', is_column=True, date='tran_trade_date',
                             pattern_in='%Y-%m-%d %H:%M:%S.%f')
        self.hash(cols=['agreement_id', 'start_date', 'aggregator_id', 'aggregator_trade_code'],
                  out='trade_id')
        self.rename(col='currency', out='currency_id')

        return self

    @to_doc(indent=0)
    def get_aum(self):
        """ {h2}Build aum details{/h2}"""
        self.rename(col='amount', out='amount')
        self.add_time_column(col='as_of_date', source=None, is_column=True,
                             date='as_of_date', pattern_in="%Y-%m-%d %H:%M:%S.%f")
        self.hash(cols=['agreement_id', 'as_of_date', 'aggregator_id'], out='aum_id')
        self.rename(col='currency', out='currency_id')

        return self

    def process(self):
        # additional column data
        self.add_file_details()
        self.get_agreement()

        if self.conf['etl_runtime'] == 'aum':
            self.get_aum()
        if self.conf['etl_runtime'] == 'trade':
            self.get_trade()

        self.add_null_columns(cols=['ended_at'])
        self.commit().map()
        return self
