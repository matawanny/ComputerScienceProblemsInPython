from skylla.transform.general_transform import Transformer
import pyspark.sql.functions as f
from pyspark.sql.types import *

from cm_commons.decorators import to_doc


class RegistreetTradeTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                          Registreet Transactions              # #
# #---------------------------------------------------------------# #
    """
    # parses the registreet trades to extract flow data:
    # ---  sample conf file
    # {
    #     "etl_name": "Registreet TRADE ETL",
    #     "prefix": "registreet_trade",
    #     "file_date": "04-03-2019",
    #     "source_type": "csv",
    #     "file_extension": "csv",
    #     "input_location": {
    #         "emr": "s3://lazard-emr-test-data/ETL/data/registreet/registreet_trade_data_04-03-2019.csv.gz"
    #     },
    #     "output_location": {
    #         "emr": "s3://lazard-emr-test-data/etl-output/registreet_trade/"
    #     },
    #     "source_name": "registreet_trade",
    #     "schema_name": "TRADE_only",
    #     "etl_runtime": "trade",
    #     "destinations": ["postgres", "parquet"],
    #     "source_schema_name": "null_schema",
    #     "target_schema_name": "TRADE_only",
    #     "transformer": "RegistreetTradeTransformer"
    # }
    # --- end conf file

    #file header row:
    #['account', 'sub_account', 'fund_code', 'trade_date', 'type', 'price', 'shares', 'amount', 'currency', 'exchange_rate', 'status', 'payment_code',
    # 'dealer_number', 'dealer_office', 'dealer_adviser', 'reference_no', 'added_date', 'BATCH_ID', 'FILE_ROW_NUM']
    #Header Notes:
    #account: is state street unit holder account number. Unique within a fund. So unique at State street when combined with fund id.
    #sub account: is always: DD
    #fund_code: is the state street code for the fund, alwasy DD and then 3 numbers
    #trade_date: is the date of the transaction
    ##type: is a code code that references the kind of transaction this is. There is an enum the expands on these transaction types in the enum master:
        # type, Share Transaction?, State Street Transaction Type, Inflow/Outflow, Flow Type
        # 100, TRUE, Application, Inflow, Active
        # 280, TRUE, Total Distribution, Inflow, Passive
        # 210, TRUE, Money Market Dividend Reinvestment, Inflow, Passive
        # 690, TRUE, Withdrawal, Outflow, Active
        # 310, TRUE, Transfer In, Inflow, Active
        # 410, TRUE, Transfer Out, Outflow, Active
        # 300, TRUE, Switch In, Inflow, Active
        # 400, TRUE, Switch Out, Outflow, Active
        # 691, TRUE, Redemption, Outflow, Active
        # 311, TRUE, Transfer In, Inflow, Active
        # 411, TRUE, Transfer Out, Outflow, Active
        # 103, TRUE, Fee Rebate (Reinvest), Inflow, Passive
        # 500, TRUE, Adjustment, Depends on Sign. Positive is inflow. Negate is outflow, Passive
        # 694, TRUE, Equalisation Redemption, Outflow, Passive
        # 108, TRUE, Equalisation Purchase, Inflow, Passive
        # 101, TRUE, Direct Purchase, Inflow, Active
        # 112, TRUE, Switch In, Inflow, Active
        # 696, TRUE, Switch Out, Outflow, Active
        # 283, TRUE, Total Distribution, Inflow, Passive
        #NB all other transaction types should be "reporting only" and can be ignored.
    #price: the unit price at which the transaction for the shares occur. Could match the "application", "redemption" or "NAV" type of unit price for that date.
    #shares: the number of shares that were applied or redeemed
    #amount: the currency value of the transaction (should be price * shares)
    #currency: the currency of hte transaction row
    #exchange rate: this is always zero as far as I can tell.
    #status: Always S - I think this denotes status of the transaction and S is for settled. This report only includes settled transactions hence always S.
    #payment code - denotes the kind of payment to be made - not relevant unless tracking cash.
    #dealer_number: if a financial adviser is attached to the transaction, this is the number state street associates with the adviser business
    #dealer_office: if a financial adviser is attached to the transaction, this is the number state street associates with the office which is part of the adviser business
    #dealer_adviser: if a financial adviser is attached to the transaction, this is the adviser code for the individual who is the adviser
    #reference number: IMPORTANT : unique to each transaction and can be used to detect changes and or dupes. As all transactions have settled they won't change! so can be used to ignore all previous rows.
    #added date: Date added to the transction store - can be used as a proxy for settlement date. though trade date should be used as actual date of transaction. Only use if tracking cash.
    #BATCH ID: this is a Lazard added number for the batch download that was done from State Street. Instead of only downloading batch transactions, we always download all transactions from State Street, then compare the batches.
    #File_row_num: this is a Lazard added number for the file row: unique to each batch ID. Ie. 1 for row 1 of the batch ID (which is the header) so data always starts on row 2.

    #sql alchemy model:
    #trade_id - use the reference number, hashed with a registreet designator as this will be unique for each transaction
    #aggregator_trade_code - this is from the type column which denotes the kind of trade this is (see enum for reference)
    #agreement_id - this is the "portfolio code" from the agreements table of the the au_data cleaner. It is a combination of the fields <account>_<fund_code>.
    #amount - this needs to be an absolute value... of the amount column and should be zero for all transactions that do not have shares. As a result, the amount column is times by the shares column to zero out those transactions that do not have shares.
    #currency_id - use the currency column
    #start_date - use the trade date
    #end_date - use the trade date
    #aggregator_id - use the enumerator to denote registreet.

    #build the trade using the info above:
    @to_doc(indent=0)
    def build_trades(self):
        """{h2}Build trade table directly from file{/h2}"""
        # order as per sqlalchemy_models.py
        # trade_id - use the reference number, hashed with a registreet designator as this will be unique for each transaction
        self.add_static_column(col="registreet_trade_file_id_prefix", val="registreet_t_")
        self.hash(cols=["registreet_trade_file_id_prefix", "reference_no"], out="trade_id")

        # aggregator_trade_code - this is from the type column which denotes the kind of trade this is (see enum for reference)
        self.rename(col="type_cm_code", out="aggregator_trade_code")
        self.cast(['aggregator_trade_code'], 'INTEGER')
        self.cast(['aggregator_trade_code'], 'STRING')

        # agreement_id - this is the "portfolio code" from the agreements table of the the au_data cleaner. It is a combination of the fields <account>_<fund_code>.
        self.concatenate_cols(["account", "fund_code"], out="portfolio_id", delim="_", drop_cols=False)
        self.add_static_column(col="au_dc_a_file_id_prefix", val="au_dc_a")
        self.hash(cols=["au_dc_a_file_id_prefix", "portfolio_id"], out="agreement_id")

        # amount - this needs to be an absolute value...
        self.rename(col="amount", out="amount_raw")
        self.abs(col="amount_raw", out="amount_raw_abs")
        #self.rename(col="amount_raw_abs", out="amount")

        #attempted to add a math column here to multiply by zero (so to zero out if the shares column is zero... but didn't work...
        #self.add_static_column(col="amount_raw_abs_shares_only", val="0") #add this column with zero for all values first, then attempt to fill it.
        self.multiply_cols(a="amount_raw_abs", b="shares", out="amount_raw_abs_shares_only") #this is a new function added by akempe to math_operations.py and general_transform.py
        self.divide_cols(a="amount_raw_abs_shares_only", b="shares", out="amount_zero_shares_removed")
        self.rename(col="amount_zero_shares_removed", out="amount")

        # currency_id - use the currency column
        self.rename(col="currency", out="currency_id")

        # start_date - use the trade date
        # self.rename(col="trade_date", out="start_date")
        self.add_time_column(col='start_date', source=None, is_column=True, date='trade_date', pattern_in='%Y-%m-%d')

        # end_date - use the trade date
        # self.rename(col="trade_date", out="end_date")
        self.add_time_column(col='end_date', source=None, is_column=True, date='trade_date', pattern_in='%Y-%m-%d')

        # aggregator_id - use the enumerator to denote registreet.
        self.add_static_column(col="aggregator_id", val="RS")

        # add all null columns:
        # updated_at, sub_agreement_id, ended_at, created_at
        self.add_static_column(col="sub_agreement_id", val="")
        self.add_static_column(col="ended_at", val="")
        self.add_time_column(col='updated_at', source='conf', is_column=False, date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        self.add_time_column(col='created_at', source='conf', is_column=False, date=self.conf['file_date'], pattern_in='%m-%d-%Y')

        return self

    # now put the process together
    def process(self):
        self.build_trades()

        #NOTE: IT IS POSSIBLE TO ADD A DMI PROCESS IS A MELT THAT EXTRACTS THE ADVISER TRADES/FLOWS FROM THIS TRANSACTION... HOWEVER I THINK THIS MAY BE BETTER TO DO AS A COMPLETELY SEPERATE PROCESS WITH ITS OWN DATABASE QUERY
        self.commit().map()

        return self


class RegistreetAUMTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                          Registreet Holdings                  # #
# #---------------------------------------------------------------# #
    """

    # #parses the registreet AUM data to extract AUM position for a given day. This file is typically called the Unitholder Register Report
    #conf file:
    # {
    #     "etl_name": "Registreet AUM ETL",
    #     "prefix": "registreet_aum",
    #     "file_date": "04-08-2019",
    #     "source_type": "csv",
    #     "file_extension": "csv",
    #     "input_location": {
    #         "emr": "s3://lazard-emr-test-data/ETL/data/registreet/registreet_aum_data_04-08-2019.csv.gz"
    #     },
    #     "output_location": {
    #         "emr": "s3://lazard-emr-test-data/etl-output/registreet_aum/"
    #     },
    #     "source_name": "registreet_aum",
    #     "schema_name": "AUM_only",
    #     "etl_runtime": "trade",
    #     "destinations": ["postgres", "parquet"],
    #     "source_schema_name": "null_schema",
    #     "target_schema_name": "AUM_only",
    #     "transformer": "RegistreetAUMTransformer"
    # }

    #File header Row
    #['fund_number', 'unit_holder_account', 'unit_holder_sub_account', 'fund_balance_brought_forward', 'fund_balance_shares', 'fund_balance_book_shares', 'fund_balance_amount', 'fund_balance_currency',
    # 'fund_balance_effective_date', 'fund_balance_price', 'fund_balance_pending_shares', 'distribution_option', 'distribute_to_fund', 'distribute_to_account', 'distribute_to_sub_account',
    # 'unit_holder_mer', 'default_payment_method', 'statement_frequency', 'application_top_up', 'redemption_option', 'account_open_date', 'annual_report_frequency', 'BATCH_ID', 'FILE_ROW_NUM']

    #File Header Notes:
    # fund_number : same as fund code for transaction file. Starts in DD.
    # unit_holder_account : State street account number. creates portfolio id when combined with fund number: <account>_<fund_number>
    # unit_holder_sub_account : Always DD
    # fund_balance_brought_forward : Always zero so ignore
    # fund_balance_shares : current balance of shares
    # fund_balance_book_shares : not sure what this is
    # fund_balance_amount : Value of the current fund share balance.
    # fund_balance_currency :currency of the fund balance.
    # fund_balance_effective_date : date of fund balance
    # fund_balance_price : fund balance shares * fund balance price should result in fund balance amount.
    # fund_balance_pending_shares : always blank. Not sure when this might be used
    # distribution_option : NA
    # distribute_to_fund : NA
    # distribute_to_account : NA
    # distribute_to_sub_account : NA
    # unit_holder_mer : Y or N but not sure what it denotes. MER's are a management fee designation.
    # default_payment_method : NA
    # statement_frequency : NA
    # application_top_up : NA
    # redemption_option : NA
    # account_open_date : Start date of the account
    # annual_report_frequency : N or Y. Unsure what this is for.
    # BATCH_ID : Lazard added to track the relevant batch number
    # FILE_ROW_NUM : Per batch ID, the row of the file.

    #SQL Alchemy model:
    # aum_id - hash the agreement id and the as of date.
    # agreement_id - use portfolio_id: <account_number>_<fund_number>
    # amount - use fund_balance_amount
    # currency_id - use fund_balance_currency
    # as_of_date - use fund_balance_effective_date
    # aggregator_id - static column RS
    # created_at - leave blank for Talend
    # updated_at - leave blank for Talend

    # build the trade using the info above:
    @to_doc(indent=0)
    def build_aum(self):
        """{h2}Build aum table directly from file{/h2}"""

        # agreement_id - this is the "portfolio code" from the agreements table of the the au_data cleaner. It is a combination of the fields <account>_<fund_code>.
        self.concatenate_cols(["unit_holder_account", "fund_number"], out="portfolio_id", delim="_", drop_cols=False)
        self.add_static_column(col="au_dc_a_file_id_prefix", val="au_dc_a")
        self.hash(cols=["au_dc_a_file_id_prefix", "portfolio_id"], out="agreement_id")

        self.add_static_column(col="registreet_aum_file_id_prefix", val="registreet_a_")
        # aum_id - hash the agreement id and the as of date.

        # as_of_date - use fund_balance_effective_date
        self.add_time_column(col='as_of_date', source=None, is_column=True, date='fund_balance_effective_date',
                             pattern_in='%Y-%m-%d')

        self.concatenate_cols(["registreet_aum_file_id_prefix", "as_of_date"], out="aum_id_prefix", delim="_", drop_cols=False)
        self.hash(cols=["aum_id_prefix", "agreement_id"], out="aum_id")

        # amount - use fund_balance_amount
        self.rename(col="fund_balance_amount", out="amount")

        # currency_id - use fund_balance_currency
        self.rename(col="fund_balance_currency", out="currency_id")

        # as_of_date - use fund_balance_effective_date
        #self.rename(col="fund_balance_effective_date", out="as_of_date")

        # aggregator_id - static column RS
        self.add_static_column(col="aggregator_id", val="RS")
        self.rename(col="BATCH_ID", out="batch_id")

        # add all null columns:
        # updated_at, sub_agreement_id, ended_at, created_at
        self.add_static_column(col="sub_agreement_id", val="")
        self.add_static_column(col="ended_at", val="")
        self.add_time_column(col='updated_at', source='conf', is_column=False, date=self.conf['file_date'],
                             pattern_in='%m-%d-%Y')
        self.add_time_column(col='created_at', source='conf', is_column=False, date=self.conf['file_date'],
                             pattern_in='%m-%d-%Y')

        return self

    # now put the process together
    def process(self):
        self.build_aum()

        self.commit().map()

        return self