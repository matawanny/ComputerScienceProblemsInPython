import pyspark.sql.functions as f
from pyspark.sql.types import *

from cm_commons.decorators import to_doc
import spark_functions as sf
from skylla.transform.general_transform import Transformer


class AMGTransformer(Transformer):
    """
    # #---------------------------------------------------------------# #
    # #                          AMG Transformer                      # #
    # #---------------------------------------------------------------# #
    """
    @to_doc(indent=0)
    def build_entity(self):
        """Build an entity"""
        self.add_static_column(col='parent_id', val='None')
        self.add_null_columns(cols=['entity_name'])
        self.rename(col='crm_relationship_id', out='salesforce_id')

        # add conversion for SF 15 -> 18 (preventative step)
        self.obj = self.obj.withColumn("salesforce_id", sf.udf_15_to_18(f.col("salesforce_id")))

        # create entity PKeys
        self.hash(cols=['salesforce_id'], out='entity_id')
        self.rename(col='entity_id', out='persistence_id')

        self.add_static_column(col='entity_type_id', val='TBD')
        self.add_static_column(col='primary_relationship', val='Y')
        self.add_static_column(col='relationship_type_id', val='asset_owner')

        return self

    @to_doc(indent=0)
    def old_build_entity(self):
        """{h2} Populates all entity fields{/h2}
            |  - entity_id
            |  - entity_type_id
            |  - entity_name
            |  - entity_parent_id
            |  - crm_id
            |  - relationship_type_id
        """
        # entity_type_id = 604
        self.add_static_column(col='entity_type_id', val='604')

        # entity_parent_id
        self.add_static_column(col='parent_id', val='None')

        # crm_id
        self.add_static_column(col='crm_id', val='None')

        self.fill_nulls(col='contact_company_line1', val='')
        self.fill_nulls(col='contact_company_line2', val='')
        self.fill_nulls(col='contact_company_line3', val='')
        self.concatenate_cols(cols=['contact_company_line1', 'contact_company_line2', 'contact_company_line3'],
                              out='entity_name', delim='\r')

        # entity_id
        self.get_relationship_type()
        self.get_entity_id()

        return self

    @to_doc(indent=0)
    def drop_dummy(self):
        """Drop dummy records = 'Y'"""
        self.obj = self.obj.filter(~f.col('dummy_yn').isin(['Y']))
        return self

    @to_doc(indent=0)
    def get_relationship_type(self):
        """{h2}Hardcoded switch-case to determine owner/advisor/consultant/custodian{/h2}"""

        statement = [('BROKER', 'advisor'), ('CLICON', 'asset_owner'), ('CONSUL', 'consultant'),
                     ('CUADMN', 'custodian'), ('CUASST', 'custodian'), ('CUCORP', 'custodian'),
                     ('CUSCON', 'custodian'), ('CUSDOM', 'custodian'), ('CUSFX1', 'custodian'),
                     ('CUSFX2', 'custodian'), ('CUSGLB', 'custodian'), ('CUSMST', 'custodian'),
                     ('CUSSEN', 'custodian'), ('CUSSUB', 'custodian'), ('CUSTLE', 'custodian'),
                     ('CUSTOD', 'custodian'), ('CUSTRD', 'custodian'), ('CUSTTE', 'custodian'),
                     ('MAILCL', 'asset_owner'), ('PRICLI', 'asset_owner')]

        default = 'None'
        self.switch_case(col='contact_type_code', out='relationship_type_id',
                         statement=statement, default=default)

        return self

    @to_doc(indent=0)
    def get_entity_id(self):
        """{h2}Determine entity_id{/h2}
            |  - asset_owner - hash of pmf symbol
            |  - all others - hash of entity_name
        """

        self.hash(cols=['entity_name'], out='hash_name')
        self.hash(cols=['portfolio_no_char'], out='hash_pmf')
        self.switch_case(col='relationship_type_id', out="entity_id",
                         statement=[('asset_owner', f.col('hash_name'))], default=f.col("hash_name"))

    @to_doc(indent=0)
    def get_agreement(self):
        """{h2}Builds an agreement for entry{/h2}"""
        self.add_static_column(col='agreement_id_prefix', val='amg_portfolio')
        self.hash(cols=['agreement_id_prefix', 'portfolio_no_char'], out='agreement_id')
        self.rename(col='product_id', out='share_class_id')
        # TODO - remove in merge
        # self.rename(col='product_strategy_id', out='sub_strategy_id')

        # set account number to none as per Brendan Frick
        self.rename(col="portfolio_no_char", out="account_number")

        # generate account name for agreement
        self.concatenate_cols(cols=['account_legal_name1', 'account_legal_name2', 'account_legal_name3'],
                              out='agreement_name', delim=' ')

        self.rename(col='product_id', out='external_identifier')
        self.add_static_column(col='external_identifier_type', val='product_id')
        self.add_static_column(col='agreement_type', val='both')

        self.concatenate_cols(cols=['client_business_code', 'servicing_type'],
                              out='channel_id', delim='-')
        self.add_time_column(col='ended_at', is_column=True, date='account_lost_date',
                             pattern_in='%Y-%m-%d %H:%M:%S')
        return self

    @to_doc(indent=0)
    def build_agreement_entity_xref_id(self):
        """{h2}Hashes agreement and entity {/h2}"""
        self.hash(cols=['agreement_id', 'relationship_type_id'], out='agreement_entity_xref_id')
        self.rename(col="crm_relationship_id", out="external_entity_id")
        return self

    @to_doc(indent=1)
    def determine_credit_assignment(self):
        """{h2}Determine credit assignment fields{h2}"""
        self.hash(cols=['entity_id', 'agreement_id'], out='sales_owner_xref_id')
        self.rename(col='employee_id', out='sales_owner_id')
        self.add_static_column(col='sales_owner_id_type', val='clnt_svc_rep_employee_id')

    @to_doc(indent=0)
    def determine_primary_relationship(self):
        """{h2}Populate primary relationship Y/N{/h2}
            |  - EDM-881
        """
        self.add_static_column(col='primary_relationship', val='EDM-881')
        return self

    @to_doc(indent=0)
    def populate_inception_date(self):
        """{h2}Populate inception_date{/h2}"""
        self.add_time_column(col='inception_date', is_column=True, date='incept_date',
                             pattern_in='%-m/%d/%Y %H:%M:%S %p')
        return self

    @to_doc(indent=0)
    def populate_client_type_id(self):
        """{h2}Populate client_type_id{/h2}
            |   - Use own.client_business_code EDM-1061
            |   - TODO - enrich EDM-602"""
        self.rename(col='portfolio_no_char', out='client_type_id')
        return self

    @to_doc(indent=0)
    def add_file_details(self):
        """{h2}Adds {b}SOURCE_FILE{/b}, {b}DATE_INFORMATION{/b} to dataframe{/h2}"""
        self.add_static_column(col='aggregator_id', val='AMG')
        self.add_time_column(col='updated_at', source='conf', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        self.add_time_column(col='created_at', source='conf', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        return self

    @to_doc(indent=0)
    def undo_bad_entities(self):
        """{h2}remove non ended entites"""
        self.out_df['entity'] = self.out_df['entity'].withColumn('ended_at', f.lit('None'))
        self.out_df['entity'] = self.out_df['entity'].withColumn('employee_id', f.lit('None'))
        return self

    def process(self):
        null_entity_sv = ['group_id', 'crd', 'iard', 'salesvision_id', 'parent_id']
        null_entity_sf = ['salesforce_id', 'crm_id', 'job_desc']
        null_entity_ai = ['ai_investor_id', 'ai_subinvestor_id']
        null_entity_ft = ['fca_id', 'fishtank_id']
        null_entity_ct = ['do_not_contact']
        null_entity_dmi = ['psn', 'asic_license_number']
        null_entity_todo = ['err_msg', 'ended_at', 'ect_entity_id', 'ect_channel_id', 'ect_team_id', 'sv_event_code',
                            'ingested_at', 'home_office_flag', 'broker_rep_code']
        self.add_null_columns(cols=[*null_entity_sv, *null_entity_sf, *null_entity_ai,
                                    *null_entity_ft, *null_entity_ct, *null_entity_todo, *null_entity_dmi])

        null_agreement_sf = ['account_sf_id', 'salesforce_id', 'money_type', 'ocio_flag', 'money_type_id']
        null_agreement_aict = ['ipo_flag', 'erisa_plan']
        null_agreement_aus = ['unit_holder_code']
        null_agreement_dmi = ['ta_number']
        null_agreement_sv = ['origin_id']
        null_agreement_todo = ['benchmark_id', 'preferred_currency_id', 'firm_type_id', 'etl_error',
                               'external_agreement_id', 'lei']
        null_agreement_credit_assignment = ['primary_owner_flag', 'percent_owned']
        self.add_null_columns(cols=[*null_agreement_sf, *null_agreement_aict, *null_agreement_aus,
                                    *null_agreement_dmi, *null_agreement_sv, *null_agreement_todo,
                                    *null_agreement_credit_assignment])
        self.drop_dummy()
        self.build_entity()
        self.get_agreement()
        self.build_agreement_entity_xref_id()
        self.determine_credit_assignment()
        self.determine_primary_relationship()
        self.populate_inception_date()
        self.add_file_details()
        self.populate_client_type_id()
        self.commit().map()

        self.undo_bad_entities()
        return self


class AMGWMTransformer(Transformer):
    """
    # #---------------------------------------------------------------# #
    # #                   AMG Wrap Model Transformer                  # #
    # #---------------------------------------------------------------# #
    """
    @to_doc(indent=0)
    def build_entity(self):
        """build entity"""
        self.hash(cols=['program_name'], out='entity_id')
        self.rename(col='program_name', out='entity_name')
        self.add_static_column(col='entity_type_id', val='amg_sponsor')
        return self

    @to_doc(indent=0)
    def build_agreement(self):
        """build agreement and link to entity"""
        self.hash(cols=['wf_account_no'], out='agreement_id')
        self.rename(col='wf_account_no', out='account_number')
        self.add_static_column(col='preferred_currency_id', val='USD')
        self.add_static_column(col='currency_id', val='USD')
        self.add_time_column(col='ended_at', is_column=True, date='account_lost_date',
                             pattern_in='%Y-%m-%d %H:%M:%S')
        self.determine_product()
        self.determine_credit_assignment()
        self.link_agrent()
        return self

    @to_doc(indent=1)
    def determine_product(self):
        """Build the fields for product identification"""
        self.rename(col='product_id', out='external_identifier')
        self.add_static_column(col='external_identifier_type', val='product_id')
        return self

    @to_doc(indent=1)
    def link_agrent(self):
        """Link agreement and entity"""
        self.add_static_column(col='relationship_type_id', val='owner')
        self.add_static_column(col='primary_relationship', val='Y')
        self.hash(cols=['entity_id', 'agreement_id'], out='agreement_entity_xref_id')
        return self

    @to_doc(indent=1)
    def determine_credit_assignment(self):
        """Determine credit assignment fields"""
        self.rename(col='distrib_channel_code', out='channel_id')
        self.rename(col='distrib_channel_code', out='client_type_id')
        self.hash(cols=['entity_id', 'agreement_id'], out='sales_owner_xref_id')
        self.rename(col='clnt_svc_rep_employee_id', out='sales_owner_id')
        self.add_static_column(col='sales_owner_id_type', val='clnt_svc_rep_employee_id')
        self.rename(col='region_name', out='territory_id')

    @to_doc(indent=0)
    def build_aum(self):
        """build aum and link to agreement"""
        self.rename(col='end_date', out='as_of_date')
        self.hash(cols=['agreement_id', 'as_of_date'], out='aum_id')
        self.rename(col='market_value', out='amount')
        self.rename(col='end_date', out='as_of_date')
        return self

    @to_doc(indent=0)
    def populate_lei(self):
        """{h2}Populate lei{/h2}
            |   - post UAT - EDM-898"""
        self.add_static_column(col='lei', val='EDM-898')
        return self

    @to_doc(indent=0)
    def add_file_details(self):
        """{h2}Adds {b}SOURCE_FILE{/b}, {b}DATE_INFORMATION{/b} to dataframe{/h2}"""
        self.add_static_column(col='aggregator_id', val='AMG')
        self.add_time_column(col='updated_at', source='conf', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        self.add_time_column(col='created_at', source='conf', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')

        return self

    def process(self):
        null_entity_sv = ['group_id', 'crd', 'iard', 'salesvision_id', 'parent_id']
        null_entity_sf = ['salesforce_id', 'crm_id']
        null_entity_ai = ['ai_investor_id', 'ai_subinvestor_id']
        null_entity_ft = ['fca_id']
        null_entity_ct = ['do_not_contact']
        null_entity_hr = ['employee_id']
        null_entity_todo = ['persistence_id', 'external_entity_id']
        self.add_null_columns(cols=[*null_entity_sv, *null_entity_sf, *null_entity_ai,
                                    *null_entity_ft, *null_entity_ct, *null_entity_hr,
                                    *null_entity_todo])

        null_agreement_sf = ['salesforce_id', 'money_type', 'ocio_flag', 'money_type_id']
        null_agreement_aict = ['ipo_flag', 'erisa_plan']
        null_agreement_aus = ['unit_holder_code']
        null_agreement_dmi = ['ta_number']
        null_agreement_sv = ['origin_id']
        null_agreement_todo = ['benchmark_id']
        null_agreement_credit_assignment = ['primary_owner_flag', 'percent_owned']
        self.add_null_columns(cols=[*null_agreement_sf, *null_agreement_aict, *null_agreement_aus,
                                    *null_agreement_dmi, *null_agreement_sv, *null_agreement_todo,
                                    *null_agreement_credit_assignment])

        self.build_entity()
        self.build_agreement()
        self.build_aum()
        self.add_file_details()
        self.populate_lei()
        self.commit().map()
        return self
