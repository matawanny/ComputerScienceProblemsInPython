import pyspark.sql.functions as f
from pyspark.sql.types import *

from cm_commons.decorators import to_doc
import spark_functions as sf
from skylla.transform.general_transform import Transformer


class DataCleanerEntityTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                          Entity  Transformer                  # #
# #---------------------------------------------------------------# #
    """

    # transforms the entities file into the entities table.

    @to_doc(indent=0)
    def build_entity(self):
        """{h2}Build entity table directly from file{/h2}"""

        # rename SF ID and use this to hash CM keys
        self.rename(col="salesforce_organisation_id", out="salesforce_id")
        self.obj = self.obj.withColumn("salesforce_id", sf.udf_15_to_18(f.col("salesforce_id")))

        # entity ID
        self.hash(cols=["salesforce_id"], out="entity_id")
        self.rename(col='entity_id', out='persistence_id')

        # entity type Id
        # entity_type_id, entity_type_desc, code_reference
        # 101, Person, person
        # 102, Team, team
        # 103, House Account (_TBD_) not a requirement, house
        # 201, Office, office
        # 202, Regional Office, regional_office
        # 203, Head Office, head_office
        # 301, Firm , firm
        # 302, Ultimate Parent , ultimate_parent
        # 303, Licensee, licensee
        # 304, Platform , platform

        # statement = [('Company', 'firm'), ('Group', 'house'), ('Individual', 'person'), ('Platform', 'platform')]
        # default = 'firm'
        # self.switch_case(col='Type', out='entity_type_id', statement=statement, default=default)

        self.add_static_column(col='entity_type_id', val="None")
        self.add_static_column(col="au_dc_e_file_id_prefix",
                               val="au_dc_e")  # this stands for au = Australia, dc = data cleaner, e = entities table
        # self.concatenate_cols(["au_dc_e_file_id_prefix", "entity_id"], out="entity_id", delim="_", drop_cols=False)

        # entity Name
        # self.rename(col='Name', out='entity_name') #where this is different Sales Force should be retained. So making this a null column 20190711

        # 20190711 - removed this ID; at present, we don't want data cleaner to be a source for adviser heirachies (should be coming into Sales Force via CRM from Rainmaker. Not via datacleaner.
        # 20190711 - in addition, there is a whole lot of work that needs to be done to fix heirachies in Sales Force... and so maybe this will be added back into data cleaner later.
        # parent_id - this is currently spread across 3 columns to designate the type of parent. However... which is importnant as "licencee" is not the same kind of "parent" as the others. However, for now, treat as the same.
        # self.concatenate_cols(["AdviserAdviceBusinessParent", "Platform Parent Id"], out="parent_id_stub", delim="", drop_cols=False)
        # self.hash(cols=["au_dc_e_file_id_prefix", "parent_id_stub"], out="parent_id")
        # self.rename(col="AdviceBusinessLicenseeParent", out="licensee_parent_stub")
        # self.hash(cols=["au_dc_e_file_id_prefix", "licensee_parent_stub"], out="licensee_parent")

        # aggregator_id -
        self.add_static_column(col="aggregator_id", val="dc")

        # #employee_id - this is valid for datacleaner to update - denotes where an individual is accutally a staff member at Lazard and what their staff member number is.
        # self.rename(col="lazard_staff_employee_id", out="employee_id")

        # psn_id - valid and should be included, allows for data cleaner to assign and update PSN's for organsisations; so that Rainmaker data can be linked.
        # self.rename(col="PSN", out="psn")

        # must add these columns:
        self.add_time_column(col='updated_at', source='conf', is_column=False, date=self.conf['file_date'],
                             pattern_in='%m-%d-%Y')
        self.add_time_column(col='created_at', source='conf', is_column=False, date=self.conf['file_date'],
                             pattern_in='%m-%d-%Y')

        # columns that need to be added:
        # created_at, updated_at,
        # do not add channel as that only applies to agreements.

        # add all null columns:

        # 20190711 - this should be made NULL as can be edited in Sales Force.
        # entity type Id
        # entity_type_id, entity_type_desc, code_reference
        # 101, Person, person
        # 102, Team, team
        # 103, House Account (_TBD_) not a requirement, house
        # 201, Office, office
        # 202, Regional Office, regional_office
        # 203, Head Office, head_office
        # 301, Firm , firm
        # 302, Ultimate Parent , ultimate_parent
        # 303, Licensee, licensee
        # 304, Platform , platform
        # statement = [('Company', 'firm'), ('Group', 'house'), ('Individual', 'person'), ('Platform', 'platform')]
        # default = 'firm'
        # self.switch_case(col='Type', out='entity_type_id', statement=statement, default=default)

        # all else as null
        self.add_null_columns(cols=(['entity_type_id', 'err_msg', 'asic_license_number', 'fishtank_id',
                                     'job_desc', 'ended_at', 'group_id',
                                     'client_type_id', 'ai_subinvestor_id',
                                     'ai_investor_id', 'lei', 'crd', 'fca_id', 'iard', 'do_not_contact',
                                     'salesvision_id', 'firm_type_id', 'crm_id', 'psn', 'ect_team_id', 'ect_entity_id',
                                     'parent_id', 'employee_id', 'entity_name', 'ect_channel_id', 'sv_event_code',
                                     'ingested_at', 'home_office_flag', 'broker_rep_code']))

        return self

    def process(self):
        self.build_entity()

        # Map to tables
        self.commit().map()

        return self


class DataCleanerAgreementsTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                          Agreements  Transformer              # #
# #---------------------------------------------------------------# #
    """

    # transforms the agreements file into the agreements table.
    # Here is the conf file:
    # {
    #     "etl_name": "AUS ETL",
    #     "packages": [],
    #     "prefix": "aus",
    #     "file_extension": "csv",
    #     "source_type": "csv",
    #     "file_date": "3-28-2019",
    #     "input_location": {
    #         "emr": "s3://lazard-emr-test-data/ETL/data/load/agreements.csv.gz"
    #     },
    #     "output_location": {
    #         "emr": "s3://lazard-emr-test-data/etl-output/aus/dc/"
    #     },
    #     "source_name": "ausdc",
    #     "schema_name": "AUS_agr",
    #     "destinations": ["postgres", "parquet"],
    #     "source_schema_name": "null_schema",
    #     "target_schema_name": "AUS_agr",
    #     "transformer": "AUAgreementsTransformer"
    # }

    @to_doc(indent=0)
    def build_agreement(self):
        """{h2}Build agreement table directly from file{/h2}"""
        # order as per sqlalchemy_models.py
        # agreement_id
        self.add_static_column(col="au_dc_a_file_id_prefix",
                               val="au_dc_a")  # this stands for au = Australia, dc = data cleaner, e = entities table
        # self.concatenate_cols(["au_dc_a_file_id_prefix", 0], out="agreement_id", delim="_", drop_cols=False)

        self.rename(col="portfolio_id", out='agreement_name')

        # Leaving this in for now, would like to replace that with aggregator_id
        self.hash(cols=["au_dc_a_file_id_prefix", "portfolio_id"], out="agreement_id")

        # channel_id - use sales classification, where "retail" or platform" make "FIG", where "Insto" make "Institutional", where "Staff" or "Group" make "House"
        statement = [('Retail', 'FIG'), ('Platform', 'FIG'), ('Insto', 'Institutional'), ('Staff', 'House'),
                     ('Group', 'House')]
        default = 'FIG'
        self.switch_case(col='Sales Classification', out='channel_id', statement=statement, default=default)

        # external_identifier - #IMA = <argos_id>; registreet = <apir code>
        # this column already has the correct name. Nothing needs to be done
        self.rename(col="external_identifier", out="external_identifier")

        # external_identifier_type - #IMA = argos_id; registreet = apir_code
        # this column already has the correct name, so nothing needs to be done.
        self.rename(col="external_identifier_type", out="external_identifier_type")

        # unit_holder_code - #IMA = ""; registreet = <account number>
        self.rename(col="State Street ID", out="unit_holder_code")

        # inception_date
        self.add_time_column(col='inception_date', source=None, is_column=True, date='Portfolio Start Date',
                             pattern_in='%Y-%m-%d')

        # aggregator_id - #NA
        self.add_static_column(col="aggregator_id", val="dc")

        # preferred_currency_id
        self.add_static_column(col='preferred_currency_id', val='AUD')

        # 1.
        # cs_rep_id - these are the column names in the file... so don't need to be renamed. but how are they being recognised.

        # sales_rep_id
        # this is now the employee ID of the sales (not client services rep) who currently owns the organisation that this money belongs to.
        self.add_static_column(col="sales_owner_id", val='au_dummy')
        self.add_static_column(col='sales_owner_id_type', val='au_sales_rep_id')
        self.hash(cols=['agreement_id', 'sales_owner_id_type'], out='sales_owner_xref_id')

        # fix "created_at" and "updated_at"
        # ended_at
        self.add_time_column(col='ended_at', source=None, is_column=True, date='Portfolio End Date',
                             pattern_in='%Y-%m-%d')
        self.add_time_column(col='updated_at', source='conf', is_column=False, date=self.conf['file_date'],
                             pattern_in='%m-%d-%Y')
        self.add_time_column(col='created_at', source='conf', is_column=False, date=self.conf['file_date'],
                             pattern_in='%m-%d-%Y')

        # add all null columns
        self.add_null_columns(cols=(['firm_type_id', 'ocio_flag', 'account_number', 'origin_id', 'icio_flag', 'ipo_flag',
                                     'erisa_plan', 'ta_number', 'benchmark_id', 'money_type_id', 'account_sf_id',
                                     'salesforce_id', 'ect_entity_id', 'ect_channel_id', 'ect_team_id',
                                     'agreement_type', 'external_agreement_id', 'primary_owner_flag', 'percent_owned']))

    @to_doc(indent=0)
    def build_agreement_entity_table(self):
        """{h2}Build agreement table directly from file{/h2}"""
        # 20190711 - need to check which relationships are required to be updated by Data Cleaner!

        # agreement_entity_xref_id - #NA presumed it will auto populate?

        # first prep for the melt...
        # agreement_id - prep - copy from build_agreement to ensure prefix is the same.

        # REMOVED
        #   self.add_static_column(col="au_dc_a_file_id_prefix", val="au_dc_a")  # this stands for au = Australia, dc = data cleaner, a = agreements table
        # REMOVED
        #   self.concatenate_cols(["au_dc_a_file_id_prefix", "portfolio_id"], out="agreement_id", delim="_", drop_cols=False)

        # entity_id - prep - investor
        # REMOVED
        #   self.add_static_column(col="au_dc_e_file_id_prefix", val="au_dc_e")  # this stands for au = Australia, dc = data cleaner, e = entities table

        # relationship_type_id - prep - this has to be preped for all the entity ids present in the file
        # relationship_type_id, relationship_desc, hierarchy
        # 100, Asset Owner, 1
        # 200, Adviser, 2
        # 300, Consultant , 3
        # 400, Master Custodian, 5
        # 401, Custodian Trustee, 6
        # 402, Custodian Administrator, 7
        # 403, Custodian Settlement, 8
        # 404, Custodian Daily, 9
        # 405, Sub Custodian, 10
        # 406, FX Custodian, 11
        # 407, Custodian Corporate Action, 12
        # 500, Platform, 4
        # 600, Licensee, 13

        # convert SF ID to 18-char, remove old entity ID
        self.obj = self.obj.withColumn("salesforce_id", sf.udf_15_to_18(f.col("salesforce_organisation_id")))
        self.obj = self.obj.drop("entity_id")

        # manage relationships using SF ID as hash criteria
        self.hash(cols=["salesforce_id"], out="investor_id")
        self.add_static_column(col="asset_owner_type_name", val="asset_owner")

        self.hash(["salesforce_id"], out="advisor_id")
        self.add_static_column(col="advisor_type_name", val="advisor")

        self.hash(["salesforce_id"], out="custodian_id")
        self.add_static_column(col="custodian_type_name", val="custodian")

        self.hash(["salesforce_id"], out="consultant_id")
        self.add_static_column(col="consultant_type_name", val="consultant")

        # primary_relationship - do not need this column
        self.add_null_columns(cols=["primary_relationship"])
        # now carry out the melt...

        # column with no value required:
        self.add_static_column(col="sub_agreement_id", val="")

    @to_doc(indent=0)
    def melt_entity_agreement_table(self):
        """{h2}Melts entity into the following fields{/h2}
            - entity_id
            - entity_type_id
            - entity_name
            - entity_parent_id
            - crm_id
            - primary_relationship
            - relationship_type_id
        """
        pre_melt = {
            'asset_owner': ['investor_id', 'asset_owner_type_name'],
            'advisor': ['advisor_id', 'advisor_type_name'],
            'consultant': ['consultant_id', 'consultant_type_name'],
            'custodian': ['custodian_id', 'custodian_type_name']
        }
        post_melt = {'agreement_entity_xref':
                         ['entity_id', 'relationship_type_id']}
        self.melt(cols=pre_melt, out=post_melt)

        self.hash(cols=["relationship_type_id", "agreement_id"], out="agreement_entity_xref_id")
        self.obj = self.obj.withColumn('external_entity_id', f.col('salesforce_id'))

    def drop_blank_entities(self):
        pass
        return self

    # now put the process together
    def process(self):
        self.build_agreement()
        self.build_agreement_entity_table()
        self.melt_entity_agreement_table()
        self.commit().map()

        self.drop_blank_entities()
        return self
