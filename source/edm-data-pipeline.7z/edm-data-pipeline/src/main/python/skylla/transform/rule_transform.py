from skylla.transform.general_transform import Transformer

import pyspark.sql.functions as f
from pyspark.sql.types import *

from cm_commons.decorators import to_doc

import datetime

class RuleTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                    Rule Table Transformer                    # #
# #---------------------------------------------------------------# #
    """
    @to_doc(indent=0)
    def build_rule_id(self):
        """Build {b}Rule{\b} table """
        column_name_list = self.obj.columns
        for value in column_name_list:
            if value[-3:] == '_id':
                pkey_id = value
        # TODO - do we remove source_name
        column_name_list = ["source_name", pkey_id, "invalid_value", "column_name"]
        self.hash(cols=column_name_list, out='rule_id')

    @to_doc(indent=0)
    def filter_records(self):
        """"Filter for (b)rule(\b) records """
        self.simple_filter("create_rule", [True], True)

    def process(self):
        self.obj.fillna("None")
        self.build_rule_id()
        self.filter_records()

        # Map to tables
        self.commit().map()

        return self
