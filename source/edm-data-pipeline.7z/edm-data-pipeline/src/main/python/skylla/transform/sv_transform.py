from skylla.transform.general_transform import Transformer
import pyspark.sql.functions as f
from pyspark.sql.types import *
from cm_commons.decorators import to_doc
import spark_functions as sf


class SVAssetTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                      SV Asset Transformer                     # #
# #---------------------------------------------------------------# #
    """

    @to_doc(indent=0)
    def build_aum(self):
        """{h2}Reads in AUM values diretly from file{/h2}"""
        self.hash(cols=['asp_acp_id'], out='agreement_id')
        self.hash(cols=['asp_acp_id', 'asp_asset_date'], out='aum_id')
        # EDM-2154: use asset_balance and USD
        self.rename(col='asp_asset_balance', out='amount')
        self.add_static_column(col='aggregator_id', val='sv')
        self.add_static_column(col='currency_id', val='USD')

        return self

    @to_doc(indent=0)
    def add_sv_time_columns(self):
        """{h2}Adds time_columns {i}col{/i}{h2} from SalesVision field {i}date{/i}{/h2}"""

        self.add_time_column(col='created_at', source=None, is_column=True,
                             date='asp_create_date', pattern_in='%Y%m%d')
        self.add_time_column(col='updated_at', source='conf', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')

    @to_doc(indent=0)
    def add_sv_time_columns(self):
        """{h2}Adds time_columns to file from SalesVision file{/h2}"""
        # as_of_date
        self.add_time_column(col='as_of_date', source=None, is_column=True,
                             date='asp_asset_date', pattern_in='%Y%m%d')

        # created date
        self.add_time_column(col='created_at', source=None, is_column=True,
                             date='asp_create_date', pattern_in='%Y%m%d')

        # maintenancedate
        self.add_time_column(col='file_updated_at', source=None, is_column=True,
                             date='asp_maint_date', pattern_in='%Y%m%d', null=True)

        self.add_time_column(col='conf_job_date', source='conf$', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y', null=True)
        # updated hierachy
        # asp_maint_date
        # asp_create_date
        # conf_job date
        self.obj = self.obj.withColumn("updated_at", f.when(f.col("file_updated_at").isNotNull(),
                                                            f.col("file_updated_at")
                                                            ).otherwise(f.when(f.col("created_at").isNotNull(),
                                                                               f.col("created_at")
                                                                               ).otherwise(f.col("conf_job_date")
                                                                                           )
                                                                        )
                                       )
        self.obj = self.obj.fillna('None', subset=['created_at', 'updated_at'])
        return self

    def process(self):
        # Pre-melt entities
        self.build_aum()
        self.add_sv_time_columns()
        # Map to tables
        self.commit().map()

        return self


class SVHoldingTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                     SV Holding Transformer                    # #
# #---------------------------------------------------------------# #
    """

    @to_doc(indent=0)
    def build_agreement_key(self):
        """{h2}Populates the foreign keys for agreement table{/h2}"""

        self.hash(cols=['acp_id'], out='agreement_id')
        self.add_static_column(col='parent_agreement_id', val='None')

        return self

    @to_doc(indent=0)
    def build_platform_agreement_entity_xref(self):
        """{h2}Placeholder for populating platform as entity{/h2}"""
        self.rename(col='acp_platform', out='platform_name')
        self.hash(cols=['acp_platform'], out='platform_id')
        self.add_static_column(col='platform_type_id', val='platform')
        self.add_static_column(col='platform_parent_id', val='None')
        self.add_static_column(col='platform_relationship_type_id', val='platform')
        self.add_static_column(col='platform_primary_relationship', val='N')
        null_holdings_entity = ['group_id', 'iard', 'crd', 'salesvision_id']
        null_entity = ['salesforce_id', 'crm_id',  # salesforce populates
                       'lei', 'persistence_id',  # placeholder?
                       # 'employee_id',  # HR
                       'do_not_contact',  # CT only
                       'fca_id',  # fishtank
                       'ai_subinvestor_id', 'ai_investor_id'  # AI
                       ]
        self.add_null_columns(cols=[*null_entity, *null_holdings_entity])

        return self

    @to_doc(indent=0)
    def build_agreement_pmf_keys(self):
        """{h2}Placeholder for determining external_identifier_type{/h2}"""
        self.rename(col='pro_cusip', out='external_identifier')
        #self.add_static_column(col='external_identifier_type', val='cusip')
        self.obj = self.obj.withColumn('ext_id_length', f.length('external_identifier'))
        statement = [(9, f.lit('cusip'))]
        default = 'product_id'
        self.switch_case_2(col='ext_id_length', out='external_identifier_type', statement=statement,default=default)
        return self

    @to_doc(indent=0)
    def build_agreement_details(self):
        """{h2}Add following details to agreement
            |  account number
            |  ta_number
            |  dealer_number (null)
            |  aggregator_id
            |  channel_id
            |  origin_id
            |  money_type{/h2}"""
        self.rename(col='acp_external_account_number', out='account_number')
        self.rename(col='acc_ta_num', out='ta_number')
        self.add_null_columns(cols=['agreement_name'])
        self.add_null_columns(cols=['dealer_id'])
        self.add_static_column(col='aggregator_id', val='sv')
        self.add_static_column(col='preferred_currency_id', val='USD')
        self.rename(col='shd_channel', out='channel_id')
        self.rename(col='acp_ta', out='origin_id')
        self.add_static_column(col='money_type_id', val='None')
        self.add_static_column(col='currency_id',val='USD')
        self.rename(col='acp_id', out='external_agreement_id')
        return self

    @to_doc(indent=0)
    def build_credit_assignment(self):
        """
        {h2}Create Credit Assignment fields from SV Holdings file
        :return:
        """
        self.rename(col='aaa_sah_id', out='sales_owner_id')
        self.hash(cols=['sales_owner_id', 'agreement_id'], out='sales_owner_xref_id')
        self.add_static_column(col='sales_owner_id_type', val='aaa_sah_id')
        return self

    @to_doc(indent=0)
    def build_entity_with_client_type(self):
        """{h2} builds blank entities with id and client type {/h2}
            |  - client_type <- firm_type for all entities
            |  - EDM-1091
            """
        self.rename(col='fir_type', out='client_type_id')

        self.add_static_column(col='advisor_type_id', val='person')
        self.add_static_column(col='office_type_id', val='office')
        self.add_static_column(col='firm_type_id', val='firm')
        # hashmatch - person file entity_id
        ##  self.hash(cols=["sv_person_id", 'sv_office_id', "entity_type_id"], out="entity_id")
        self.hash(cols=['acp_per_id', 'acp_ofl_id', 'advisor_type_id'], out='advisor_id')
        self.hash(cols=['acp_ofl_id', 'office_type_id'], out='office_id')
        self.hash(cols=['acp_fir_id', 'firm_type_id'], out='firm_id')

        self.rename(col='office_id', out='advisor_parent_id')
        self.rename(col='firm_id', out='office_parent_id')
        self.add_static_column(col='firm_parent_id', val='None')

        self.add_static_column(col='advisor_primary_relationship', val='Y')
        self.add_static_column(col='advisor_relationship_type_id', val='advisor')

        self.add_static_column(col='office_primary_relationship', val='N')
        self.add_static_column(col='office_relationship_type_id', val='asset_owner')

        self.add_static_column(col='dummy', val='None')

        pre_melt_platform = {
            'advisor': ['advisor_id', 'advisor_type_id', 'advisor_parent_id',
                        'advisor_relationship_type_id', 'advisor_primary_relationship',
                        'acp_per_id'],
            'asset_owner': ['office_id', 'office_type_id', 'office_parent_id',
                            'office_relationship_type_id', 'office_primary_relationship',
                            'acp_ofl_id'],
            'platform': ['platform_id', 'platform_type_id', 'platform_parent_id',
                       'platform_relationship_type_id', 'platform_primary_relationship',
                       'dummy'],
        }

        pre_melt = {
            'advisor': ['advisor_id', 'advisor_type_id', 'advisor_parent_id',
                        'advisor_relationship_type_id', 'advisor_primary_relationship',
                        'acp_per_id'],
            'asset_owner': ['office_id', 'office_type_id', 'office_parent_id',
                            'office_relationship_type_id', 'office_primary_relationship',
                            'acp_ofl_id']
        }

        post_melt = {'entity': ['entity_id', 'entity_type_id', 'parent_id',
                                'relationship_type_id', 'primary_relationship',
                                'salesvision_id']
                     }

        self.melt(cols=pre_melt, out=post_melt)
        self.hash(cols=['agreement_id', 'relationship_type_id'], out='agreement_entity_xref_id')
        self.rename(col='salesvision_id', out='external_entity_id')

        null_holdings_entity = ['entity_name', 'group_id', 'iard', 'crd', 'salesvision_id']
        null_entity = ['salesforce_id', 'crm_id',  # salesforce populates
                       'lei', 'persistence_id',  # placeholder?
                       'do_not_contact',  # CT only
                       'fca_id',  # fishtank
                       'ai_subinvestor_id', 'ai_investor_id'  # AI
                       ]
        self.add_null_columns(cols=[*null_entity, *null_holdings_entity])
        return self

    @to_doc(indent=0)
    def add_sv_time_columns(self):
        """{h2}Adds time_columns to file from SalesVision file{/h2}"""

        self.add_time_column(col='created_at', source=None, is_column=True,
                             date='acp_create_date', pattern_in='%Y%m%d')
        self.add_time_column(col='updated_at', source='conf', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y')
        return self

    @to_doc(indent=0)
    def add_sv_time_columns(self):
        """{h2}Adds time_columns to file from SalesVision file{/h2}"""
        # as_of_date
        # created date
        self.add_time_column(col='created_at', source=None, is_column=True,
                             date='acp_create_date', pattern_in='%Y%m%d')

        # maintenancedate
        self.add_time_column(col='file_updated_at', source=None, is_column=True,
                             date='acp_maint_date', pattern_in='%Y%m%d', null=True)

        self.add_time_column(col='conf_job_date', source='conf$', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y', null=True)
        # updated hierachy
        # asp_maint_date
        # asp_create_date
        # conf_job date
        self.obj = self.obj.withColumn("updated_at", f.when(f.col("file_updated_at").isNotNull(),
                                                            f.col("file_updated_at")
                                                            ).otherwise(f.when(f.col("created_at").isNotNull(),
                                                                               f.col("created_at")
                                                                               ).otherwise(f.col("conf_job_date")
                                                                                           )
                                                                        )
                                       )
        self.obj = self.obj.fillna('None', subset=['created_at', 'updated_at'])
        return self

    def build_agreement(self):
        self.build_agreement_key()
        self.build_agreement_pmf_keys()
        #self.build_platform_agreement_entity_xref()
        self.build_entity_with_client_type()
        self.build_agreement_details()
        self.build_credit_assignment()
        return self

    @to_doc(indent=0)
    def split_omnibus_agreements(self):
        """{h2} Drop omnibus records from sub-agreement,
                drop non-omnibus records from agreement {/h2}
            |  - EDM-870: omnibus - origin_id = DST"""

        self.out_df['agreement'] = self.out_df['agreement'].filter((self.out_df['agreement']['origin_id'].isin(['DST'])))
        self.out_df['sub_agreement'] = self.out_df['sub_agreement'].filter(~(self.out_df['sub_agreement']['origin_id'].isin(['DST'])))
        return self

    def process(self):
        null_agreement = ['licensee_id', 'unit_holder_code', 'erisa_plan', # AUS fields
                          'ipo_flag',  # AI/CT fields
                          'ocio_flag', 'money_type',  # SF only
                          'inception_date', # AMG/AI/CT
                          'benchmark_id',
                          'ended_at',
                          'account_sf_id']  # not

        null_todo = ['salesforce_id']
        null_sales_owner_xref = ['primary_owner_flag', 'percent_owned']
        # Pre-melt entities
        self.build_agreement()
        self.add_sv_time_columns()
        self.add_null_columns(cols=null_agreement)
        self.add_null_columns(cols=null_todo)
        self.add_null_columns(cols=null_sales_owner_xref)
        # Map to tables
        self.commit().map()

        self.split_omnibus_agreements()

        return self


class SVTradeTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                     SV Trade Transformer                      # #
# #---------------------------------------------------------------# #
    """

    @to_doc(indent=0)
    def build_trade(self):
        """{h2}Build trade table directly from file{/h2}"""
        self.hash(cols=['tca_acp_id'], out='agreement_id')
        self.hash(cols=['tca_id'], out='trade_id')
        self.rename(col='tca_trc_id', out='aggregator_trade_code')
        self.add_static_column(col='currency_id',val='USD')
        self.rename(col='tca_amount', out='amount')
        self.add_static_column(col='aggregator_id', val='sv')

        return self

    @to_doc(indent=0)
    def add_sv_time_columns(self):
        """{h2}Adds time_columns to file from SalesVision file{/h2}"""

        self.add_time_column(col='start_date', source='conf', is_column=True,
                             date='tca_trade_date', pattern_in='%Y%m%d')
        self.add_time_column(col='end_date', source='conf', is_column=True,
                             date='tca_trade_date', pattern_in='%Y%m%d')

        # as_of_date
        # created date
        self.add_time_column(col='created_at', source=None, is_column=True,
                             date='tca_create_date', pattern_in='%Y%m%d')

        # maintenancedate
        self.add_time_column(col='file_updated_at', source=None, is_column=True,
                             date='tca_maint_date', pattern_in='%Y%m%d', null=True)

        self.add_time_column(col='conf_job_date', source='conf$', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y', null=True)
        # updated hierachy
        # asp_maint_date
        # asp_create_date
        # conf_job date
        self.obj = self.obj.withColumn("updated_at", f.when(f.col("file_updated_at").isNotNull(),
                                                            f.col("file_updated_at")
                                                            ).otherwise(f.when(f.col("created_at").isNotNull(),
                                                                               f.col("created_at")
                                                                               ).otherwise(f.col("conf_job_date")
                                                                                           )
                                                                        )
                                       )
        self.obj = self.obj.fillna('None', subset=['created_at', 'updated_at'])
        return self

    def process(self):
        self.build_trade()
        self.add_sv_time_columns()
        # Map to tables
        self.commit().map()

        return self


class SVEntityTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                     SV Entity Transformer                    # #
# #---------------------------------------------------------------# #
    """
    @to_doc(indent=0)
    def build_firm(self):
        """{h2}Builds firm from sv_firm file{/h2}"""
        self.rename(col="firm_name", out="entity_name")
        self.add_static_column(col="entity_type_id", val="firm")

        # self.hash(cols=["sv_firm_id", "entity_type_id"], out="entity_id")
        self.obj = self.obj.withColumn("entity_id",
                                       f.when(f.col("crm_firm_id").isNotNull(),
                                              f.col("crm_firm_id"))
                                       .otherwise(f.md5(
                                           f.concat_ws("_",f.array(f.col('sv_firm_id'), f.col('entity_type_id'))))
                                       ))

        # self.hash(cols=["sv_firm_id", "entity_type_id"], out="persistence_id")
        self.obj = self.obj.withColumn("persistence_id",
                                       f.when(f.col("crm_firm_id").isNotNull(),
                                              f.col("crm_firm_id"))
                                       .otherwise(f.md5(
                                           f.concat_ws("_",f.array(f.col('sv_firm_id'), f.col('entity_type_id'))))
                                       ))

        self.add_static_column(col="parent_id", val="None")
        self.rename(col="sv_firm_id", out="salesvision_id")
        self.add_exempt_null_columns(cols=["crd"])

        self.populate_address()

        self.add_static_column(col='aggregator_id', val='sv')
        self.add_exempt_null_columns(cols=['job_desc'])
        return self

    @to_doc(indent=0)
    def build_office(self):
        """{h2}Builds office from sv_firm file{/h2}"""

        self.add_exempt_null_columns(cols=["entity_name"])
        self.add_static_column(col="entity_type_id", val="office")
        self.add_static_column(col="firm_entity_type", val="firm")

        # self.hash(cols=["sv_office_id", "entity_type_id"], out="persistence_id")
        self.obj = self.obj.withColumn("persistence_id",
                                       f.when(f.col("crm_office_id").isNotNull(),
                                              f.col("crm_office_id"))
                                       .otherwise(f.md5(
                                           f.concat_ws("_",f.array(f.col('sv_office_id'), f.col('entity_type_id'))))
                                       ))

        # self.hash(cols=["sv_office_id", "entity_type_id"], out="entity_id")
        self.obj = self.obj.withColumn("entity_id",
                                       f.when(f.col("crm_office_id").isNotNull(),
                                              f.col("crm_office_id"))
                                       .otherwise(f.md5(
                                           f.concat_ws("_",f.array(f.col('sv_office_id'), f.col('entity_type_id'))))
                                       ))

        # self.hash(cols=["sv_firm_id", "firm_entity_type"], out="parent_id")
        self.obj = self.obj.withColumn("parent_id",
                                       f.when(f.col("crm_firm_id").isNotNull(),
                                              f.col("crm_firm_id"))
                                       .otherwise(f.md5(
                                           f.concat_ws("_",f.array(f.col('sv_firm_id'), f.col('firm_entity_type'))))
                                       ))

        self.rename(col="sv_office_id", out="salesvision_id")
        self.add_exempt_null_columns(cols=["crd"])
        self.populate_address()

        self.add_static_column(col='aggregator_id', val='sv')

        self.add_exempt_null_columns(cols=['job_desc'])
        return self

    @to_doc(indent=0)
    def build_person(self):
        """{h2}Builds person from sv_firm file{/h2}"""

        # Switch for per/team entity_type

        # Teams aren't recognized in the holdings file so we're going to use person to hash all teams
        self.add_static_column(col='fop_entity_type_id', val='person')

        # hashmatch - holdings entity_id
        self.hash(cols=["sv_person_id", 'sv_office_id', "fop_entity_type_id"], out="entity_id")

        # self.hash(cols=["sv_person_id", "fop_entity_type_id"], out="persistence_id")
        self.obj = self.obj.withColumn("persistence_id",
                                       f.when(f.col("crm_person_id").isNotNull(),
                                              f.col("crm_person_id"))
                                       .otherwise(f.md5(
                                           f.concat_ws("_",f.array(f.col('sv_person_id'), f.col('fop_entity_type_id'))))
                                       ))

        statement = [('Y', 'team'), ('N', 'person')]
        default = '-1'
        self.switch_case(col='broker_team', out='entity_type_id',
                         statement=statement, default=default)

        self.obj = self.obj.fillna("null", ["last_name", "first_name", "middle_name"])

        self.concatenate_cols(cols=['last_name', 'first_name', 'middle_name'], out='person_name', delim='|')
        self.concatenate_cols(cols=['last_name', 'first_name', 'middle_name'], out='team_name', delim='|')

        # self.add_exempt_null_columns(cols=["team_name_exempt"])
        #
        # self.obj = self.obj.withColumn("team_name",
        #                                f.when((~f.col("last_name").isNull()) &
        #                                       (~f.col("last_name").isin(["None", ""])),
        #                                       f.col("last_name")
        #                                       ).otherwise(
        #                                             f.when((~f.col("first_name").isNull()) &
        #                                                    (~f.col("first_name").isin(["None", ""])),
        #                                                    f.col("first_name")
        #                                                    ).otherwise(
        #                                                         f.col("team_name_exempt")
        #                                             )))

        # Switch for per/team entity_name
        statement = [('Y', f.col('team_name')), ('N', f.col('person_name'))]
        default = '-1'
        self.switch_case(col='broker_team', out='entity_name',
                         statement=statement, default=default)

        self.add_static_column(col="office_entity_type", val="office")
        # self.hash(cols=["sv_office_id", "office_entity_type"], out="parent_id")
        self.obj = self.obj.withColumn("parent_id",
                                       f.when(f.col("crm_office_id").isNotNull(),
                                              f.col("crm_office_id"))
                                       .otherwise(f.md5(
                                           f.concat_ws("_", f.array(f.col('sv_office_id'), f.col('office_entity_type'))))
                                       ))
        self.rename(col="sv_person_id", out="salesvision_id")
        self.rename(col="crd_number", out="crd")

        # # null out CRD if entity type is a team (EDM-2046)
        # self.obj = self.obj.withColumn('crd', f.when(f.col('broker_team').isin(['Y']), None).otherwise(f.col('crd')))

        self.obj = self.obj.withColumn('home_office_flag', f.col('home_office_flag'))
        self.obj = self.obj.withColumn('broker_rep_code', f.col('broker_rep_code'))
        self.populate_email()
        self.populate_phone()
        self.add_static_column(col='aggregator_id', val='sv')
        return self

    @to_doc(indent=0)
    def explode_team(self):
        """{h2} Split explodes the crds from team intos rows"""
        pdf = self.obj.filter(f.col('entity_type_id') == 'person')
        pdf = pdf.withColumn("entity_crd",
                             f.lit("REMOVE ME"))

        tdf = self.obj.filter(f.col('entity_type_id') == 'team')
        def trim(string):
            if string:
                return string.strip()
            else:
                return "None"

        utrim = f.udf(trim)

        tdf = tdf.withColumn("entity_crd",
                             f.explode_outer(
                                 f.split(f.col("crd"), "/")
                             ).alias("entity_crd"))
        tdf = tdf.withColumn("entity_crd", utrim(f.col('entity_crd')))
        tdf = tdf.withColumn("entity_crd", utrim(f.col('entity_crd')))
        tdf.select("entity_crd", "crd", "entity_type_id").show()

        self.obj = tdf.union(pdf)
        self.rename(col="entity_id", out="team_entity_id")
        self.hash(cols=["team_entity_id", "entity_crd"], out="entity_team_id")

        return self

    @to_doc(indent=0)
    def add_sv_time_columns(self):
        """{h2}Adds time_columns to file from SalesVision file{/h2}"""
        self.add_time_column(col='created_at', is_column=True,
                             date='sv_created_at', pattern_in='%Y-%m-%d %H:%M:%S')

        # Create candidate updated at columns
        self.add_time_column(col='updated_at', source=None, is_column=True,
                             date='sv_updated_at', pattern_in='%Y-%m-%d %H:%M:%S', null=True)

        self.add_time_column(col='conf_job_date', source='conf$', is_column=False,
                             date=self.conf['file_date'], pattern_in='%m-%d-%Y', null=True)

        # add ingested date
        self.add_time_column(col='ingested_at', source='conf', is_column=False, date=self.conf['file_date'],
                             pattern_in='%m-%d-%Y')

        self.obj = self.obj.fillna('None', subset=['created_at', 'updated_at'])
        self.add_static_column(col='money_type_id', val='None')

        return self

    @to_doc(indent=0)
    def populate_group_id(self):
        """{h2}Populate group_id{/h2}
            |  - TODO - populate group from file EDM-494"""
        self.add_static_column(col='group_id', val='EDM-494')
        return self

    @to_doc(indent=0)
    def populate_client_type_id(self):
        """{h2}Populate group{/h2}
            |  - This file will populate a place-holder client type until holding files enriches client_type ...
            |  - TODO - populate client_type_id using holding FOPs... EDM-1030
            """
        self.add_static_column(col='client_type_id', val='EDM-1030')
        return self

    @to_doc(indent=0)
    def populate_iard(self):
        """{h2}Populate group{/h2}
            |  - This file will populate a place-holder iard until holding files enriches client_type ...
            |  - TODO - populate iard using holding FOPs... EDM-646
            """
        self.add_static_column(col='iard', val='EDM-1030')
        return self

    @to_doc(indent=0)
    def populate_address(self):
        """{h2}Populate entity_address{/h2}"""
        self.rename(col='entity_id', out='entity_id')
        self.add_static_column(col='address_type_id', val='salesvision')
        self.hash(cols=['entity_id', 'address_type_id'], out='entity_address_id')
        if self.conf["source_name"] in ["fir","sv_firm"]:
            self.rename(col='address_line_1', out='street_address_1')
            self.rename(col='address_line_2', out='street_address_2')
        if self.conf["source_name"] in ["ofl", "sv_office"]:
            self.rename(col='address_line_1', out='street_address_1')
            self.concatenate_cols(cols=['address_line_2',
                                        'address_line_3'],
                                  out='street_address_2',
                                  delim = ' ')
        self.rename(col='city', out='city')
        self.rename(col='state', out='state')
        self.obj = self.obj.withColumn('state', f.regexp_replace('state', '.+?[?=-]', ''))

        self.switch_case_2(col='state', out='state', statement=[('UNKNOWN', 'None')], default=f.col('state'))
        self.switch_case_2(col='country', out='country', statement=[('UNKNOWN', 'None')], default=f.col('country'))

        #self.obj = self.obj.withColumn('state', f.regexp_replace('state','UNKNOWN','None'))
        #self.obj = self.obj.withColumn('country', f.regexp_replace('country','UNKNOWN','None'))

        self.rename(col='zip', out='postal_code')

        return self

    @to_doc(indent=0)
    def populate_email(self):
        """{h2}Populate entity_email{/h2}"""
        self.rename(col='entity_id', out='entity_id')
        self.add_static_column(col='email_type_id', val='salesvision_email')
        self.hash(cols=['entity_id', 'email_type_id'], out='entity_email_id')

        # self.rename(col='email_address', out='entity_email_address')
        self.obj = self.obj.withColumn('email_address',
                                       f.when(f.col('email_address').isNull(), 'edm_exempt')
                                       .otherwise(f.col('email_address')))
        return self

    @to_doc(indent=0)
    def populate_phone(self):
        """{h2}Populate entity_phone{/h2}"""
        self.rename(col='entity_id', out='entity_id')
        self.add_static_column(col='phone_type_id', val='salesvision_phone')
        self.hash(cols=['entity_id', 'phone_type_id'], out='entity_phone_id')
        # self.rename(col='phone_number', out='entity_phone_number')
        self.obj = self.obj.withColumn('phone_number',
                                       f.when(f.col('phone_number').isNull(), 'edm_exempt')
                                       .otherwise(f.col('phone_number')))

        self.add_static_column(col='country_code', val='EDM-1090')
        self.add_static_column(col='extension', val='EDM-1090')
        return self

    @to_doc(indent=0)
    def handle_iud(self):
        """{h2}Populate fields corresponding to I/U/D event_code{/h2}
        | - EDM-1941
        | -- ended_at as file_date if event_code is 'D'
        | - EDM-2167
        | -- populate event code as `sv_event_code`
        """
        statement = [('D', f.lit(self.conf['file_date']))]
        self.switch_case_2(col='event_code', out='ended_at',
                           statement=statement, default=f.col('ended_at'))

        self.rename(col='event_code', out='sv_event_code')

        return self

    # @to_doc(indent=0)
    # def populate_employee_id(self):
    #     """{h2}Populate group{/h2}
    #                 |  - populate as "FN | LN" if entity is person
    #                 |  - TODO - enrich in mapping EDM-838
    #                 """
    #
    #     if self.conf["source_name"] == 'sv_person':
    #         self.concatenate_cols(cols=['name2', 'name1'], delim='|', out='temp_employee_id')
    #         self.switch_case(col='entity_type_id', out='employee_id',
    #                          statement=[('1', f.col('temp_employee_id'))], default='None')
    #     else:
    #         self.add_static_column(col='employee_id', val='None')
    #
    #     return self

    def process(self):
        null_entity = ['salesforce_id', 'crm_id', # salesforce populates
                       'lei', # placeholder?
                       'employee_id', # HR
                       'do_not_contact', # CT only
                       'fca_id', # fishtank
                       'ai_subinvestor_id', 'ai_investor_id', #AI,
                       'ended_at', 'err_msg', 'psn', 'asic_license_number', 'fishtank_id',
                       'ect_entity_id', 'ect_channel_id', 'ect_team_id', 'job_desc']

        self.add_null_columns(cols=[*null_entity])
        self.add_sv_time_columns()
        self.populate_group_id()
        self.populate_client_type_id()
        self.populate_iard()
        # self.populate_employee_id()
        # Map to tables

        if self.conf["source_name"] == "sv_firm":
            self.build_firm()
        if self.conf["source_name"] == "sv_office":
            self.build_office()
        if self.conf["source_name"] == "sv_person":
            self.build_person()
            self.explode_team()
        self.handle_iud()

        self.commit().map()

        if self.conf["source_name"] == "sv_person":
            self.out_df['entity_team_xref'] = self.out_df['entity_team_xref'].filter(~
                self.out_df['entity_team_xref']['entity_crd'].isin(['REMOVE ME'])
            )

        return self


class SVEntityLQETransformer(SVEntityTransformer):
    """
# #---------------------------------------------------------------# #
# #                  SV LQE Entity Transformer                    # #
# #---------------------------------------------------------------# #
    """
    def __init__(self, *args, **kwargs):
        """
            df/obj - the static/dynamic instance of a Spark object
            fields/out - input/output schema information
        """
        super().__init__(*args, **kwargs)

    def process(self):
        null_entity = ['salesforce_id', 'crm_id', # salesforce populates
                       'lei', 'persistence_id', # placeholder?
                       'employee_id', # HR
                       'do_not_contact', # CT only
                       'fca_id', # fishtank
                       'ai_subinvestor_id', 'ai_investor_id' #AI
                       ]

        self.add_null_columns(cols=[*null_entity])
        self.add_sv_time_columns()
        self.populate_group_id()
        self.populate_client_type_id()
        self.populate_iard()
        # self.populate_employee_id()
        # Map to tables

        if self.conf["source_name"] == "fir":
            self.build_firm()
        if self.conf["source_name"] == "ofl":
            self.build_office()
        if self.conf["source_name"] == "per":
            self.build_person()
        self.commit().map()
        return self


class SVTradeCodeTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                    SV TradeCode Transformer                   # #
# #---------------------------------------------------------------# #
    """

    def process(self):
        self.commit().map()

        return self


class SVSalesPerTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                 SV Sales Person Transformer                   # #
# #---------------------------------------------------------------# #
    """

    def process(self):
        self.commit().map()

        return self


class SVSalesHierTransformer(Transformer):
    """
# #---------------------------------------------------------------# #
# #                 SV Sales Person Transformer                   # #
# #---------------------------------------------------------------# #
    """

    def process(self):
        self.commit().map()

        return self
