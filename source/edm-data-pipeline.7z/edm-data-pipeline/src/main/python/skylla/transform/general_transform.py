__date__ = "10/23/2018"
__version__ = "Base"
__status__ = "Done"

from pyspark.sql.types import ArrayType, StructType, StructField, IntegerType, StringType
import pyspark.sql.functions as f
import functools as ft
from datetime import datetime
from cm_commons.decorators import to_doc
from functools import partial
import re, time
import spark_functions as sf


class Transformer:
    """
# #---------------------------------------------------------------# #
# #                      General Transformer                      # #
# #---------------------------------------------------------------# #
    """

    def __init__(self, df, schema, spark, conf):
        """
            df/obj - the static/dynamic instance of a Spark object
            fields/out - input/output schema information
        """
        self.schema = schema
        self.spark = spark
        self.conf = conf
        self.df_orig = df
        self.obj = df  # dynamic instance of Spark objects
        self.df = df  # static instance of Spark objects
        self.out_df = {}
        self.read_only = False

    # #---------------------------------------------------------------# #
    # #                      maintenance operations                   # #
    # #---------------------------------------------------------------# #

    @to_doc(indent=2)
    def rename(self, col, out):
        """Creates column named {i}out{/i} with values from {i}col{/i} """
        self.obj = sf.rename(self.obj, col, out)
        return self

    @to_doc(indent=2)
    def fill_nulls(self, col, val='None'):
        """Replace {b}val{/b} with {i}val{/i}"""
        self.obj = sf.fill_nulls(self.obj, col, item=val)
        return self

    @to_doc(indent=2)
    def add_static_column(self, col, val):
        """Add a column named {i}col{/i} where every value is {i}val{/i}"""
        self.obj = sf.add_static_column(self.obj, col=col, val=val)
        return self

    @to_doc(indent=2)
    def add_time_column(self, col='updated_on', source=None, is_column=False, date=None, pattern_in=None, null=False):
        """Adds a time column named {i}col{/i} with standard formatting from either source or conf"""


        if not date:
            date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            pattern_in = '%Y-%m-%d %H:%M:%S'

        def date_formatter(date, pattern_in, pattern_out, null=False):
            """ Take given string date and pattern, convert to YYYY-mm-dd HH:MM:SS """
            try:
                return datetime.strptime(str(date), pattern_in).strftime(pattern_out)
            except:
                if null:
                    return None
                else:
                    return str(date)

        def epoch_formatter(date, pattern_out, null=False):
            """ Given epoch date and pattern, convert to YYYY-mm-dd HH:MM:SS """
            try:
                return time.strftime(pattern_out, time.localtime(date))
            except:
                if null:
                    return None
                else:
                    return str(date)

        udf_date_formatter = f.udf(date_formatter)
        udf_epoch_formatter = f.udf(epoch_formatter)

        if date.isdigit():
            # print("Instance is integer...")
            self.obj = self.obj.withColumn(col, udf_epoch_formatter(f.lit(int(date)), f.lit('%Y-%m-%d %H:%M:%S'), f.lit(null)))
        else:
            if is_column:
                self.obj = self.obj.withColumn(col, udf_date_formatter(f.col(date), f.lit(pattern_in),
                                                                       f.lit('%Y-%m-%d %H:%M:%S'), f.lit(null)))
            else:
                self.obj = self.obj.withColumn(col, udf_date_formatter(f.lit(str(date)), f.lit(pattern_in),
                                                                       f.lit('%Y-%m-%d %H:%M:%S'), f.lit(null)))
        return self

    @to_doc(indent=2)
    def add_null_columns(self, cols=None, none_val='None'):
        """Creates columns named {i}cols{/i} with static value {i}none_val{/i}"""
        for col in cols:
            self.obj = sf.add_static_column(self.obj, col=col, val=none_val)
        return self

    @to_doc(indent=2)
    def add_exempt_null_columns(self, cols=None):
        """Creates columns that can pass nullability checks but will be loaded as None"""
        for col in cols:
            self.obj = sf.add_static_column(self.obj, col=col, val="edm_exempt")
        return self

    # #---------------------------------------------------------------# #
    # #                      Simple SQL operations                    # #
    # #---------------------------------------------------------------# #

    @to_doc(indent=2)
    def select(self, cols):
        """Select list of columns """
        self.obj = sf.select(self.obj, cols)
        return self

    @to_doc(indent=2)
    def distinct(self):
        """ Select distinct combination of columns """
        self.obj = sf.distinct(self.obj)
        return self

    @to_doc(indent=2)
    def group_by(self, cols):
        """Group by fields from grp_expr"""
        self.obj = sf.group_by(self.obj, cols)
        return self

    @to_doc(indent=2)
    def agg(self, expr):
        """ Aggregate a groupby object """
        self.obj = sf.agg(self.obj, expr)

        # handle renaming
        for cid, eid in expr.items():
            self.obj = sf.rename(self.obj, col='{}({})'.format(eid, cid), out=cid)
            self.obj = self.obj.drop(f.col('{}({})'.format(eid, cid)))

        return self

    @to_doc(indent=2)
    def simple_filter(self, col, values, include):
        """ {h2}{/h2}"""
        # TODO - Tori add ad
        if include:
            self.obj = self.obj.filter(self.obj[col].isin(values))
        else:
            self.obj = self.obj.filter(~(self.obj[col].isin(values)))
        return self

    # #---------------------------------------------------------------# #
    # #                     Advanced SQL operations                   # #
    # #---------------------------------------------------------------# #
    @to_doc(indent=2)
    def explode(self, cols=["per_crd", "first_name", "last_name"], types=[StringType, StringType, StringType],
                out=["ex_per_crd", "ex_first_name", "ex_last_name"], delim='/', outer=True):
        """Chops CRD Numbers and explodes to include nulls"""
        self.obj = sf.explode(self.df, cols, types, out)
        return self

    @to_doc(indent=2)
    def explode_split(self, cols, out, delim='/', outer=True):
        """ Splits by a delimiter and explodes to new row"""
        self.obj = sf.explode_split(self, cols, out, delim, outer)
        return self

    @to_doc(indent=2)
    def melt(self, cols, out):
        """ Melts multiple groups of columns into single rows """
        self.obj = sf.melt(self.obj, cols, out)
        return self

    @to_doc(indent=2)
    def switch_case(self, col, out, statement, default='unknown'):
        """ switch case implementation in spark """
        self.obj = sf.switch_case(self.obj, col, out, statement, default)
        return self

    @to_doc(indent=2)
    def switch_case_2(self, col, out, statement, default='unknown'):
        """ switch case implementation in spark """
        self.obj = sf.switch_case_2(self.obj, col, out, statement, default)
        return self

    # #---------------------------------------------------------------# #
    # #                         Math operations                       # #
    # #---------------------------------------------------------------# #

    @to_doc(indent=2)
    def abs(self, col=None, cols=None, out=None):
        """ Returns the absolute value"""
        if col:
            self.obj = sf.abs(self.obj, col, out if out else col)
        if cols:
            for ci in cols:
                self.obj = self.abs(self.obj, ci)

        return self

    @to_doc(indent=2)
    def multiply_cols(self, a, b, out):
        """df.out = df.a * df.b"""
        self.obj = sf.multiply_cols(self.obj, a, b, out)
        return self

    @to_doc(indent=2)
    def divide_cols(self, a, b, out):
        """df.out = df.a / df.b"""
        self.obj = sf.divide_cols(self.obj, a, b, out)
        return self

    @to_doc(indent=2)
    def sub_cols(self, a, b, out):
        """df.out = df.a - df.b"""
        self.obj = sf.sub_cols(self.obj, a, b, out)
        return self

    @to_doc(indent=2)
    def is_negative(self, col, out, cast=False, bool=False):
        """Returns if col is negative in out as 'true' or 'false' """
        if bool:
            false = False
            true = True
        else:
            false = "false"
            true = "true"
        if cast:
            self.cast(cols=[col], typecast="FLOAT")

        self.obj = sf.switch_case_3(self.obj, in_col=col, out_col=out, statement=[(0, false)], default=true,
                                    func_name='gte')

        if cast:
            self.cast(cols=[col], typecast="STRING")

        return self

    # #---------------------------------------------------------------# #
    # #                        String operations                      # #
    # #---------------------------------------------------------------# #
    @to_doc(indent=2)
    def split(self, cols, out, delim='/'):
        """ Split a column into two columns"""
        self.obj = sf.split(self.obj, cols, out, delim)
        return self

    @to_doc(indent=2)
    def concatenate_cols(self, cols, out, delim=" ", drop_cols=False, opt='string'):
        """Concatenate multiple cols passed as list and merge to out column with given deliminator"""
        self.obj = sf.concatenate_cols(self.obj, cols, out, delim=delim, drop_cols=drop_cols, opt=opt)
        return self

    @to_doc(indent=2)
    def prefix_col(self, col, prefix, out=None):
        """Add a prefix to a column"""
        self.obj = sf.prefix_col(self.obj, col, prefix, out)
        return self

    @to_doc(indent=2)
    def lower(self, cols):
        """Convert to lowercase"""
        self.obj = sf.lower(self.obj, cols)
        return self

    @to_doc(indent=2)
    def hash(self, cols, out):
        """ Hashes {b}cols{/b} into {b}out{/b} """
        self.obj = sf.hash(self.obj, cols, out)

        return self

    @to_doc(indent=2)
    def create_hashed_column(self, hashed_column_name, input_columns_list):
        """Get a list of relevant columns from our df"""
        return self.hash(cols=hashed_column_name, out=input_columns_list)

    @to_doc(indent=2)
    def trim_columns(self):
        """Remove spaces"""
        self.obj = sf.trim_columns(self.obj.columns)(self.obj)
        return self

    @to_doc(indent=2)
    def substring_column(self, col, pos, len):
        """Remove spaces"""
        self.obj = sf.substring_column(self.obj, col, pos, len)
        return self

    @to_doc(indent=2)
    def remove_prefix_column(self, col, prefix):
        """Remove spaces"""
        self.obj = sf.remove_prefix_column(self.obj, col, prefix)
        return self

    # #---------------------------------------------------------------# #
    # #                        Type operations                        # #
    # #---------------------------------------------------------------# #

    @to_doc(indent=2)
    def cast(self, cols, typecast="INTEGER"):
        """"Typecast a column"""
        self.obj = sf.cast(self.obj, cols, typecast)
        return self

    # #---------------------------------------------------------------# #
    # #                  Transformer  protocol functions              # #
    # #---------------------------------------------------------------# #

    def commit(self):
        """Saves dynamic obj to static df"""
        self.df = self.obj
        return self

    def reset(self):
        """Swaps the dynamic object self.obj with df"""
        self.obj = self.df_orig
        return self

    def map_(self):
        for oo in self.schema:
            self.out_df[oo] = self.df.select([name for name in self.schema[oo]['fields'] if name in self.df.schema.names])
        return self

    def map(self):
        for oo in self.schema:
            self.df.select([name for name in self.schema[oo]['fields'] if name in self.df.schema.names]).registerTempTable(
                oo)
            self.out_df[oo] = self.spark.sql("select * from {}".format(oo))
        return self

    def process(self):
        """Order of execution for transforming a Transformer object"""
        return self.commit().map()

    def _process(self):
        """ Collects docstrings without actually processing"""
        self.__doc__ = self.__doc__ + ("\n\033[1m" + "Process Path" + "\033[0;0m")
        self.read_only = True
        check = self.process()
        self.read_only = False
        return check
