__date__ = "10/23/2018"
__version__ = "Base"
__status__ = "Done"

from pyspark.sql.window import Window
import pyspark.sql.functions as f
# from cm_commons.encryption.encryption_schema import encrypt_actions
from cm_commons.spark import build_session
#TODO spark handle should be passed from ETL class, not imported
from cm_commons.decorators import to_doc, css
from cm_commons.colors import out_print, suc_print, err_print
from cm_commons.util.safe_count import safe_count, SC_CONST

import sys
import os
import shutil
from cm_commons import colors

def union_all(dfs):
    df_left = dfs[0]
    if len(dfs) > 1:
        df_right = union_all(dfs[1:])
        # columns not in df_left
        for ii in list(set(df_right.columns) - set(df_left.columns)):
            colors.err_print(f' Missing {ii} from left',indent=3)
            df_left = df_left.withColumn(ii, f.lit('None'))
        # columns not in df_rightm
        for jj in set(df_left.columns) - set(df_right.columns):
            colors.err_print(f' Missing {jj} from right', indent=3)
            df_right = df_right.withColumn(jj, f.lit('None'))
        df_left = df_left.select(df_right.columns)
        return df_left.unionAll(df_right)
    else:
        return df_left

class Loader:
    """
# #---------------------------------------------------------------# #
# #                         General Loader                        # #
# #---------------------------------------------------------------# #
    """
    def __init__(self, out_df, schema, conf, x_cols, cxn, spark,  dest="client_master"):
        self.fields = out_df.keys()
        self.db = {'tables': {}, 'connection': None}
        self.cxn = cxn
        self.prefix = conf['prefix']
        self.conf = conf
        self.output_dir = conf['output_location'][conf['environment']]
        self.read_only = False
        self.dest = dest
        self.spark = spark

        for tbl in self.fields:
            fields = dict(**schema[tbl]['fields'], **x_cols) if x_cols else schema[tbl]['fields']
            self.db['tables'][tbl] = self.Table(df=out_df[tbl], name=tbl,
                                                fields=fields,
                                                e_fields=None,
                                                p_key=schema[tbl]["primaryKey"][0]["field"],
                                                f_key='none',
                                                date=self.conf['file_date'],
                                                jobid=self.conf.get("jobid"))
            self.db['tables'][tbl].build()

    class Table:
        def __init__(self, df, name, fields, e_fields, p_key, f_key, date, jobid):
            self.df = df
            self.obj = df
            self.name = name
            self.fields = fields
            self.e_fields = e_fields
            self.p_key = p_key
            self.f_key = f_key   # e.g. f-key = {<f_key> : (<f_table>, <f_field>
            self.date = date
            if jobid:
                self.jobid = jobid
            else:
                colors.war_print("No job id for file ", indent=1)
                self.jobid = "no-job-id"


            # for docstring
            self.read_only = False
            self.__doc__ = str('{h1}' + name + '{/h1}' + ': ' +
                           '\n\t{b}Included columns{/b}: ' + '{h2}' + ', '.join([fi for fi in list(set(fields.keys()) & set(df.columns))])+'{/h2} ' +
                           '\n\t{b}Missed columns{/b}: ' + '{err}' + ', '.join([fi for fi in list(set(fields.keys()) - set(df.columns))])+'{/err}').format(**css)

        @to_doc(indent=1)
        def dedupe(self):
            """ Remove whole-row duplicates"""
            self.obj = self.obj.dropDuplicates()
            return self

        @to_doc(indent=1)
        def dedupe_dated(self, col):
            """ Remove whole-row duplicates and accept latest date """

            #print([ii for ii in self.obj.schema.names if not (ii == col)])
            if col in self.obj.schema.names:
                self.obj = self.obj.sort(f.desc(col)).dropDuplicates([ii for ii in self.obj.schema.names if not (ii == col)])
            return self

        @to_doc(indent=1)
        def key_collision(self, p_key):
            """Asserts primary key and writes to obj and err_df"""
            #df.registerTempTable("entities")


            window_spec = Window.partitionBy(p_key)
            #self.err_df=spark.sql("SELECT *  FROM( SELECT *, ROW_NUMBER() OVER(PARTITION BY "+p_key+" ORDER BY "+p_key+"  DESC) rn FROM entities) y  WHERE rn > 1")
            self.obj = self.obj.withColumn('dupeCount', f.count(p_key).over(window_spec))
            self.obj = self.obj.withColumn('error', f.when(f.col('dupeCount') == 1, f.lit('none')).otherwise(f.lit('dupe')))
            self.obj = self.obj.drop('dupeCount')

            return self

        @to_doc(indent=1)
        def solve_key_collision(self, p_key):
            """Asserts primary key and writes to obj and err_df"""
            # df.registerTempTable("entities")
            if "updated_at" in self.obj.schema.names and "created_at" in self.obj.schema.names:
                colors.suc_print(f"updated_at and/or created_at not found in {self.name}, using no filter" ,indent=3)
                self.obj = self.obj.withColumn("updated_at_date", f.to_date("updated_at"))
                self.obj = self.obj.withColumn("created_at_date", f.to_date("created_at"))
                window_spec = Window.partitionBy(p_key).orderBy(f.col("updated_at_date").desc(), f.col("created_at_date").desc())
            else:
                colors.war_print(f"updated_at and/or created_at not found in {self.name}, using no orderby" ,indent=3)
                window_spec = Window.partitionBy(p_key).orderBy(f.lit("A"))

            #self.err_df=spark.sql("SELECT *  FROM( SELECT *, ROW_NUMBER() OVER(PARTITION BY "+p_key+" ORDER BY "+p_key+"  DESC) rn FROM entities) y  WHERE rn > 1")
            self.obj = self.obj.withColumn('dupeCount', f.count(p_key).over(window_spec))
            self.obj = self.obj.withColumn('error', f.when(f.col('dupeCount') == 1, f.lit('none')).otherwise(f.lit('dupe')))
            self.obj = self.obj.drop('dupeCount')

            #window_spec = Window.partitionBy(p_key).orderBy(f.col("updated_at_date").desc(),
            #                                                f.col("created_at_date").desc())
            self.obj = self.obj.withColumn("rn", f.row_number().over(window_spec)).where(f.col("rn") == 1).drop("rn")

            self.obj = self.obj.drop("created_at_date", "updated_at_date")

            return self


        @to_doc(indent=1)
        def cast_all_str(self, df=None):
            """ Cast all as string, pre-encryption"""
            if df is None:
                colors.out_print("casting all as string", indent=4)
                for cid in self.obj.schema.names:
                    self.obj = self.obj.withColumn(cid, self.obj[cid].cast("String"))

                return self
            else:
                colors.out_print("casting all as string", indent=4)
                for cid in df.schema.names:
                    df = df.withColumn(cid, df[cid].cast("String"))

                return df

        @to_doc(indent=1)
        def replace_all_none(self, df=None):
            """ replace all none with null"""
            if df is None:
                colors.out_print("replacing all with none", indent=4)
                for cid in self.obj.schema.names:
                    if cid in self.fields.keys():
                        self.obj = self.obj.withColumn(cid, f.when(f.lower(f.col(cid)).isin(['none', 'edm_exempt', 'exempt', 'edm-881', 'edm-494',  'edm-1030', 'edm-1090']),
                                                            f.lit(None)).otherwise(f.col(cid)))
                    else:
                        colors.war_print(f"not replacing {cid}", indent=5)
                return self
            else:
                for cid in df.schema.names:
                    if cid in self.fields.keys():
                        df = df.withColumn(cid, f.when(f.lower(f.col(cid)).isin(['none', 'edm_exempt', 'exempt', 'edm-881', 'edm-494', 'edm-1030', 'edm-1090']),
                                                       f.lit(None)).otherwise(f.col(cid)))
                    else:
                        colors.war_print(f"not replacing {cid}", indent=5)
                return df
        #testing
        @to_doc(indent=1)
        def encrypt(self, cols):
            """ Encrypts columns based on encrypt_action rules {deprecated} """
            pass
            #udf_encrypt = f.udf(lambda x: encrypt(x))
            #for col_name in cols:
            #    self.obj = self.obj.withColumn(col_name, udf_encrypt(self.obj[col_name]))
            return self

        @to_doc(indent=1)
        def output_to_csv(self, dir):
            """ Write to .csv """
            self.obj.write.mode("overwrite").csv(dir + self.name + '/' + self.date + '.csv')

        @to_doc(indent=1)
        def output_to_parquet(self, dir):
            """ Write to parquet"""
            #print('\033[34m'+dir+self.name+'/'+self.date+'.parquet'+'\033[0m')
            colors.out_print(f"Writing to dir={dir}, self.name={self.name}, self.date={self.date}, self.jobid={self.jobid}")
            self.obj.write.mode("overwrite").parquet(f"{dir}{self.name}/{self.date}/{self.jobid}.parquet")

        @to_doc(indent=1)
        def output_to_postgres(self, url=None, table=None, mode='overwrite', properties=None):
            """ Save table to Posgres DB """
            self.obj.write.jdbc(url=url, table=table, mode=mode, properties=properties)
            # TODO - add pkey for indexing

        def build(self):
            """ Build the table with DB constraints"""
            #enc = [item for item, value in self.fields.items()
            #       if item in self.obj.columns
            #       and encrypt_actions['load'][value['encrypted']]]
            self.dedupe().dedupe_dated('updated_at').key_collision(p_key=self.p_key)#.cast_all_str()#.encrypt(cols=enc)
            return self

        #@TODO - Figure out how to link to SQLAlchemy models. Right now I'm just setting up a sample dict
        def cast_typed(self):
            #@TODO - Fix this dictionary
            sample_type_dict = {"aum_id" : "STRING", "amount": "DECIMAL"}
            """
            https://anish749.github.io/spark/exception-handling-spark-data-frames/
            val rddWithExcep = df.rdd.map
                            {row: Row = >
                                val memberIdStr = row.getAs[String]("member_id")
                                val memberIdInt = Try(memberIdStr.toInt) match {
                                    case Success(integer) = > List(integer, null)
                                    case Failure(ex) = > List(null, ex.toString)
                            }
                            Row.fromSeq(row.toSeq.toList + + memberIdInt)
                        }

            val castWithExceptionSchema = StructType( df.schema.fields + + Array(StructField("member_id_int", IntegerType, true), 
                                                                                 StructField("exceptions", StringType, true)))

            val cast ExcepDf = sparkSession.sqlContext.createDataFrame(rddWithExcep, castWithExceptionSchema)

            castExcepDf.printSchema()
            castExcepDf.show()
            """

    def mk_out_dir(self):
        """ Makes output directory for file outputs """
        if not os.path.exists("output"):
            os.mkdir("output")
        if os.path.exists(os.path.join("output", self.conf["source_name"])):
            print("OVERWRITING OLD OUTPUT")
            shutil.rmtree(os.path.join("output", self.conf["source_name"]))

        os.mkdir(os.path.join("output/", self.conf["source_name"]))

    def absorb_docstring(self, item):
        """ Pulls a table's docstring into Load's docstring"""
        self.__doc__ = self.__doc__ + '\n' + item.__doc__
        return self

    def process(self):
        """ Processes all tables. For table level processing see Table.build()"""
        for tbl in self.fields:
            #print('\033[32;4m'+'#########{}##PLAN#############'.format(tbl.upper())+'\033[0m')

            t = self.db['tables'][tbl]
            self.absorb_docstring(item=t)

            if 'postgres' in self.conf['destinations']:
                if self.prefix is not None and self.prefix != "":
                    table = self.prefix + '_' + t.name
                else:
                    table = t.name
                t.output_to_postgres(url=self.cxn['url'],
                                     table=table,
                                     mode="overwrite",
                                     properties=self.cxn['properties'])
            if 'parquet' in self.conf['destinations']:
                t.output_to_parquet(dir=self.output_dir)
                # t.output_to_csv(dir=self.output_dir)

            if 'csv' in self.conf['destinations']:
                t.output_to_csv(dir=self.output_dir)

            #t.obj.explain()

            #print('\033[31;4m'+'#########{}##END #############'.format(tbl.upper())+'\033[0m')
        return self


class MDMLoader(Loader):
    """
# #---------------------------------------------------------------# #
# #                           MDM Loader                          # #
# #---------------------------------------------------------------# #
    """
    @to_doc(indent=1)
    def filter(self, df, crit, indent=2):
        """ Filter"""
        # FILTERING
        colors.out_print(f"Filtering records for mastered", indent=indent)
        return self

    @to_doc(indent=1)
    def select(self, df, crit):
        """ Filter"""
        return self

    @to_doc(indent=1)
    def cast(self, df, crit):
        """ Filter"""
        return self

    @to_doc(indent=1)
    def write(self, df, crit):
        """ Filter"""
        return self

    def make_backup(self, table_name):
        # Make backup
        colors.out_print(f"Backing up {table_name}", indent=2)
        from cm_commons.db.cm_conn import cm_cxn
        import psycopg2
        conn = psycopg2.connect(dbname=cm_cxn['db_name'],
                                user=cm_cxn['user'],
                                host=cm_cxn['location'],
                                password=cm_cxn['password'])
        cur = conn.cursor()
        cur.execute(f"select * from information_schema.tables where table_name='{table_name}_prv'", (table_name,))
        prv_exists = bool(cur.rowcount)

        cur.execute(f"select * from information_schema.tables where table_name='{table_name}'", (table_name,))
        tbl_exists = bool(cur.rowcount)

        cur.execute("select * from information_schema.tables where table_name=%s", (table_name,))
        if bool(cur.rowcount):
            if tbl_exists:
                if prv_exists:
                    colors.out_print(f"Dropping {table_name}_prv", indent=3)
                    cur.execute(f"drop table {table_name}_prv")
                    conn.commit()

                colors.out_print(f"Copying {table_name} to {table_name}_prv", indent=3)
                cur.execute(f"create table {table_name}_prv as SELECT * FROM {table_name}")
                conn.commit()
            else:
                colors.out_print(f"{table_name} doesn't exist, no copy needed")

    @to_doc(indent=1)
    def load_cncr_post_talend(self):
        """ Writes CNCR output to
              | DB - Talend
              | postfix - _cncr_post_talend
              | mode - append
        """
        for tbl in self.fields:
            # Grab the table
            t = self.db['tables'][tbl]

            # Take the docstring from Table and feed to Loader
            self.absorb_docstring(item=t)

            # Make table name
            if self.prefix != "":
                table = self.prefix + '_' + t.name + '_cncr_post_talend'
            else:
                table = t.name + '_cncr_post_talend'

            # Filter out non-master records and write to table with cm_prefix
            t.cast_all_str().obj.write.jdbc(url=self.cxn['url'], table=table, mode="overwrite", properties=self.cxn['properties'])
        return self

    def load_apiFailures2devDS(self):
        return self

    def load_etlFailures2devDS(self):
        return self

    def load_mdmFailures2devDS(self):
        return self

    def load_match_failures(self):
        """ Writes CNCR output to
                              | DB - Talend
                              | postfix - _match_failures
                              | mode - append
                """
        # Iterate over dict version of sqlalchemy target model
        for tbl in self.fields:
            # Grab the table
            t = self.db['tables'][tbl]

            # Take the docstring from Table and feed to Loader
            self.absorb_docstring(item=t)

            # Make table name
            if self.prefix != "":
                table = self.prefix + '_' + t.name + '_match_failures'
            else:
                table = t.name + '_match_failures'

            # Filter out non-master records and write to table with cm_prefix
            if ('tds_master' in t.obj.schema.names) and ('tds_match_yn' in t.obj.schema.names):
                out_df = t.obj.filter(
                    (
                            t.obj['tds_master'].isin(['true']) |
                            t.obj['tds_match_yn'].isin(['n'])
                    ) &
                    (
                            t.obj['etl_source'].isin(['amg', 'sv', 'ldw', 'ft', 'registreet']) &
                            (~t.obj['crm_id'].isin(['None']))
                    )
                )

                out_df.write.jdbc(url=self.cxn['url'], table=table, mode="overwrite", properties=self.cxn['properties'])
            else:
                t.obj.write.jdbc(url=self.cxn['url'], table=table, mode="overwrite", properties=self.cxn['properties'])
                print(t.name + " did not process through match, loading without filters")  # or something like that
        return self


    def load_mastered2clientmaster(self):
        """ Writes CNCR output to Client Master
            Details
                | DB - Talend
                | prefix - ''
                | postfix - ''
                | mode - upsert
            Filters
                | ignore all error columns
        """
        # Iterate over dict version of sqlalchemy target model
        for tbl in self.fields:

            # Grab the table
            t = self.db['tables'][tbl]

            # Take the docstring from Table and feed to Loader
            self.absorb_docstring(item=t)

            # Make table name
            # table = 'cm_sf_mdm_test_' + t.name
            table = self.prefix + t.name

            out_print("################",indent=1)
            out_print(f"Loading {table} to master", indent=1)
            out_print("################", indent=1)

            # Solve deduplication
            colors.out_print("Solving key collisions", indent=2)
            t = t.solve_key_collision(t.p_key)

            # Filter out non-master records and write to table with cm_prefix
            if ('tds_master' in t.obj.schema.names) and ('tds_match_yn' in t.obj.schema.names):
                if 'nullability_error' in t.obj.schema.names and 'typecast_error' in t.obj.schema.names:
                    colors.suc_print(t.name + " processed through DEDUPLICATION and VALIDATION", indent=2)

                    # Filtering
                    colors.out_print(f"Filtering records for mastered", indent=3)
                    df = t.obj.filter(
                        (   # Deduplication filters
                            t.obj['tds_master'].isin(['true']) | # filter include exact match records
                            t.obj['tds_match_yn'].isin(['n'])    # filter include non-matched records
                        ) &
                        (   # Resolution filters
                            ~t.obj['nullability_error'].isin(['Error']) & # filter exclude nullability errors
                            ~t.obj['typecast_error'].isin(['Error'])      # filter exclude typecast errors
                        )
                    )
                    post_filter_count = safe_count(df, dummy_str=True)
                    colors.out_print(f"Filter found {post_filter_count} records for mastered", indent=4)

                    # SELECTING
                    colors.out_print(f"Selecting names from schema + x_cols", indent=3)

                    schema_fields_list = list(t.fields.keys())
                    print(f"schema_fields_list = {schema_fields_list}")
                    # TODO: Check and fix why obj_schema doesn't have ingested_at column
                    # schema_fields_list.append('ingested_at')
                    # print(f"nav_debug in masteredToCM1, after append, schema_fields_list = {schema_fields_list}")
                    # df = df.select([fn for fn in list(t.fields.keys()) if fn in df.schema.names])
                    df = df.select([fn for fn in schema_fields_list if fn in df.schema.names])

                    df = df.drop("nullability_error", "type_cast_error")
                    # CASTING
                    colors.out_print(f"Casting records for mastered", indent=3)
                    df = t.cast_all_str(df=df)
                    df = t.replace_all_none(df=df)
                    post_cast_count = safe_count(df)
                    if post_cast_count == SC_CONST:
                        colors.saf_print(f"Ignored count after casting", indent=4)
                    elif post_cast_count == post_filter_count:
                        colors.suc_print(f"After casting {post_cast_count} records to mastered", indent=4)
                    else:
                        colors.err_print(f"{post_cast_count} records after casting", indent=4)

                    # WRITING
                    colors.out_print(f"Writing records to {table}" , indent=3)
                    df.write.jdbc(url=self.cxn['url'], table=table,
                                 mode="overwrite", properties=self.cxn['properties'])

                else:
                    colors.war_print(t.name + " did not process through VALIDATION. Processing with DEDUPLICATION filter")

                    # FILTERING
                    colors.out_print(f"Filtering records for mastered", indent=3)
                    df = t.obj.filter(
                        (  # Deduplication filters
                                t.obj['tds_master'].isin(['true']) |  # filter include exact match records
                                t.obj['tds_match_yn'].isin(['n'])  # filter include non-matched records
                        ))

                    # SELECTING
                    colors.out_print(f"Selecting names from schema + x_cols", indent=3)

                    schema_fields_list = list(t.fields.keys())
                    print(f"schema_fields_list = {schema_fields_list}")
                    # TODO: Check and fix why obj_schema doesn't have ingested_at column
                    # schema_fields_list.append('ingested_at')
                    # print(f"nav_debug in masteredToCM2, after append, schema_fields_list = {schema_fields_list}")

                    df = df.select([fn for fn in schema_fields_list if fn in df.schema.names])
                    # df = df.select([fn for fn in list(t.fields.keys()) if fn in df.schema.names])

                    # CASTING
                    colors.out_print(f"Casting records for mastered", indent=3)
                    df = t.cast_all_str(df=df)
                    df = t.replace_all_none(df=df)

                    post_cast_count = safe_count(df)
                    if post_cast_count == SC_CONST:
                        colors.saf_print(f"Ignored count after casting", indent=4)
                    elif post_cast_count == post_cast_count:
                        colors.suc_print(f"After casting {post_cast_count} records to mastered", indent=4)
                    else:
                        colors.err_print(f"{post_cast_count} records after casting", indent=4)

                    # WRITING
                    colors.out_print(f"Writing records to {table}" , indent=3)

                    df.write.jdbc(url=self.cxn['url'], table=table,
                                 mode="overwrite", properties=self.cxn['properties'])
            else:
                if 'nullability_error' in t.obj.schema.names and 'typecast_error' in t.obj.schema.names:
                    colors.war_print(t.name + " did not process through DEDUPLICATION. Processing with VALIDATION filter", indent=2)

                    # FILTERING
                    colors.out_print(f"Filtering records for mastered", indent=3)
                    df = t.obj.filter(
                        (  # Resolution filters
                                (~t.obj['nullability_error'].isin(['Error'])) &  # filter exclude nullability errors
                                (~t.obj['typecast_error'].isin(['Error']))  # filter exclude typecast errors
                        )
                    )

                    post_filter_count = safe_count(df, dummy_str=True)
                    colors.out_print(f"Filter found {post_filter_count} records for mastered", indent=4)

                    # SELECTING
                    colors.out_print(f"Selecting names from schema + x_cols", indent=3)

                    schema_fields_list = list(t.fields.keys())
                    print(f"schema_fields_list = {schema_fields_list}")
                    # TODO: Check and fix why obj_schema doesn't have ingested_at column
                    # schema_fields_list.append('ingested_at')
                    # print(f"nav_debug in masteredToCM3, after append, schema_fields_list = {schema_fields_list}")


                    df = df.select([fn for fn in schema_fields_list if fn in df.schema.names])
                    # df = df.select([fn for fn in list(t.fields.keys()) if fn in df.schema.names])

                    # CASTING
                    colors.out_print(f"Casting records for mastered", indent=3)
                    df = t.cast_all_str(df=df)
                    df = t.replace_all_none(df=df)
                    post_cast_count = safe_count(df)
                    if post_cast_count == SC_CONST:
                        colors.saf_print(f"Ignored count after casting", indent=4)
                    elif post_cast_count == post_cast_count:
                        colors.suc_print(f"After casting {post_cast_count} records to mastered", indent=4)
                    else:
                        colors.err_print(f"{post_cast_count} records after casting", indent=4)

                    # ADD DATE
                    # WRITING
                    colors.out_print(f"Writing records to {table}" , indent=3)
                    df.write.jdbc(url=self.cxn['url'], table=table,
                                      mode="overwrite", properties=self.cxn['properties'])
                else:
                    err_print(t.name + " did not process through ANYTHING", indent=2)

        return self

    @to_doc(indent=1)
    def load_deduplicaton2preTalend(self):
        """ {h2}Writes CNCR output to{/h2}
              | DB - Talend
              | postfix - _match_pre
              | mode - append
        """
        for tbl in self.fields:
            # Grab the table
            t = self.db['tables'][tbl]

            # Take the docstring from Table and feed to Loader
            self.absorb_docstring(item=t)

            # Make table name
            table = self.prefix + t.name + '_deduplication'

            out_print("################", indent=1)
            out_print(f"Loading {table} to deduplication", indent=1)
            out_print("################", indent=1)

            if ('tds_master' in t.obj.schema.names) and ('tds_match_yn' in t.obj.schema.names):
                colors.suc_print(t.name + " processed through DEDUPLICATION ", indent=2)

                # ADD COLUMNS
                df = t.obj.withColumn("record_id", f.monotonically_increasing_id())
                df = df.withColumn("ds_ingested_at", f.lit(""))


                # CAST
                colors.out_print(f"Casting records for mastered", indent=3)

                pre_cast_count = safe_count(df)
                df = t.cast_all_str(df=df)
                post_cast_count = safe_count(df)

                if (post_cast_count == SC_CONST) or (post_cast_count == SC_CONST):
                    colors.saf_print("Ignoring casting compare counts",indent=4)
                elif post_cast_count == pre_cast_count:
                    colors.suc_print(f"After casting {post_cast_count} records to mastered", indent=4)
                else:
                    colors.err_print(f"{post_cast_count} records after casting", indent=4)

                # FILTER
                df = df.filter(f.col('tds_match_yn') == 'y')

                colors.bug_print("01/02 MEMORY ERROR")
                colors.bug_print(f"COUNT BEFORE JDBC WRITE: {str(df.count())}")

                df.write.jdbc(url=self.cxn['url'], table=table, mode="overwrite", properties=self.cxn['properties'])
                from cm_commons.util.boto_functions import get_s3_bucket
                from datetime import datetime
                import calendar
                d = datetime.utcnow()
                unixtime = calendar.timegm(d.utctimetuple())

                # df.write.parquet(f"s3://{get_s3_bucket()}/CIRCE/data/{t.name}/dedupe_{unixtime}.parquet"

            else:
                err_print(t.name + " did not process through deduplication",indent=2)
        return self

    @to_doc(indent=1)
    def load_resolution2preTalend(self):
        """ {h2}Writes Nullability/Type failures{/h2}
              | DB - Talend
              | postfix - _resolve_pre
              | mode - append
        """


        colors.out_print("Loading resolution", indent=1)

        for tbl in self.fields:
            # Grab the table
            t = self.db['tables'][tbl]
            colors.out_print(f"Loading table {tbl}", indent=2)

            # Take the docstring from Table and feed to Loader
            self.absorb_docstring(item=t)

            # Make table name
            # table = 'cm_sf_mdm_test_' + t.name
            table = self.prefix + t.name + '_resolution'

            # make backup
            self.make_backup(table_name=table)

            colors.out_print(f"Output table name: {table}", indent=3)

            # Write only nullability failures
            # - nullability
            # - type casting
            if ('nullability_error' in t.obj.schema.names) and ('typecast_error' in t.obj.schema.names):
                colors.suc_print(t.name + " processed through validity", indent=4)
                # FILTER

                df = t.obj.filter(
                    t.obj['nullability_error'].isin(['Error']) |
                    t.obj['typecast_error'].isin(['Error'])
                )


                df = t.replace_all_none(df=df)
                df = t.cast_all_str(df=df)


                # SELECT
                schema_fields_list = list(t.fields.keys())
                print(f"schema_fields_list = {schema_fields_list}")
                # TODO: Check and fix why obj_schema doesn't have ingested_at column
                # schema_fields_list.append('ingested_at')
                # print(f"nav_debug in Resolution, after append, schema_fields_list = {schema_fields_list}")


                # df = df.select([fn for fn in list(t.fields.keys()) if fn in df.schema.names])
                df = df.select([fn for fn in schema_fields_list if fn in df.schema.names])

                num_records = safe_count(df)

                if num_records == SC_CONST:
                    colors.saf_print("Ignoring filter count", indent=5)
                elif num_records == 0:
                    colors.war_print("No records found", indent=5)
                else:
                    colors.suc_print(f"Filter success: {num_records} records found", indent=5)

                from cm_commons.db.cm_conn import cm_cxn
                import psycopg2

                conn = psycopg2.connect(dbname=cm_cxn['db_name'],
                                        user=cm_cxn['user'],
                                        host=cm_cxn['location'],
                                        password=cm_cxn['password'])
                cur = conn.cursor()
                cur.execute(f"select * from information_schema.tables where table_name='{table}'")
                res_exists = bool(cur.rowcount)


                if res_exists:
                    ext_df = self.spark.read.jdbc(url=self.cxn['url'], table=table,
                                                  properties=self.cxn['properties'])

                    df = union_all([ext_df, df])


                #if 'ds_ingested_at' not in df.schema.names:
                #    df = df.withColumn("ds_ingested_at", f.lit(None))
                #else:
                #    df = df.filter(f.col("ds_ingested_at").isNull())

                df = df.withColumn("record_id", f.monotonically_increasing_id())

                df.write.jdbc(url=self.cxn['url'], table=table, mode="append",
                              properties=self.cxn['properties'])

                colors.suc_print(f"Filter success: {num_records} records found", indent=5)
            else:
                err_print(t.name + " did not process through validity")
        return self


    def process(self):

        if self.dest == "deduplication":
            self.load_deduplicaton2preTalend()

        if self.dest == "validation":
            self.load_resolution2preTalend()

        if self.dest == "mastered":
            self.load_mastered2clientmaster()

        return self

