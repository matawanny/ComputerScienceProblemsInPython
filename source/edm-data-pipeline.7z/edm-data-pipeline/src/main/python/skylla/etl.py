import json
from cm_commons.util.system import env
from cm_commons.spark import build_session
from cm_commons import colors

from pyspark.sql.types import *
from pprint import pprint
import skylla
import cm_commons
import pyspark
import boto3
from urllib.parse import urlparse


class ETL:
    def __init__(self, conf,
                 src_cxn=None, trg_cxn=None):

        self.conf, self.src_schema, self.trg_schema = self._configure(conf)
        self.spark = build_session(app_name=self.conf['etl_name'])

        self.extractor = getattr(skylla.extract, 'Extractor')
        self.transformer = getattr(skylla.transform, self.conf['transformer'])
        self.enricher = getattr(skylla.enrich, 'Enricher')
        self.loader = getattr(skylla.load, 'Loader')

        self.src_cxn = src_cxn
        self.trg_cxn = trg_cxn
        self.df = None
        self.out_df = {}

    def _configure(self, conf_loc):
        """
            Configures conf and secrets
        """
        conf = self.read_conf(conf_loc)

        # Schema management
        src = getattr(cm_commons.models.src_files, conf['source_schema_name'])
        trg = getattr(cm_commons.models.trg_files, conf['target_schema_name'])

        trg_schema = {'mapping': {},
                      'schema': self.read_schema(trg)}
        src_schema = self.read_schema(src)

        # Set Target DB - default value is configured in cm_conn
        if "target_db" in conf.keys():
            url = self.trg_cxn["url"]
            self.trg_cxn["url"] = url[:url.rindex("/")+1] + conf["target_db"]
        return conf, src_schema, trg_schema

    @staticmethod
    def read_conf(conf_loc, spark=None):
        """
            Current: Read configuration json file
            Future: BIGGER configuration files
        """

        def row_to_dict(df):

            if isinstance(df, pyspark.sql.Row):
                i_d = df.asDict()
                o_d = {}
                for kk, vv in i_d.items():
                    o_d[kk] = row_to_dict(vv)
                return o_d
            else:
                return df

        if isinstance(conf_loc, str):
            if env == "emr":
                o = urlparse(conf_loc)
                s3 = boto3.resource('s3')

                obj = s3.Object(o.netloc, o.path[1:])
                conf = json.loads(obj.get()['Body'].read().decode('utf-8'))
                #cdf = spark.read.json(conf_loc, multiLine=True)
                #conf = row_to_dict(cdf.collect()[0])

            else:
                with open(conf_loc) as conf_file:
                    conf = json.load(conf_file)
        else:
            conf = conf_loc

        conf['environment'] = env # imported from sources
        conf['file_ext'] = conf["input_location"][conf['environment']].split('.')[-1]
        return conf

    @staticmethod
    def read_schema(schema, tables = ['entity','agreement','portfolio','flow']):
        """
            Current: read schema dict from .json file location (str) or dictionary generated in commons/models (dict)
            Future: expand central model class
        """
        if isinstance(schema, str):
            with open(schema) as sc:
                schema_dic = json.load(sc)
            if schema_dic['target']:
                return schema_dic['out']
            elif schema_dic['source']:
                return schema_dic
        elif isinstance(schema, dict):
            return schema
        else:
            print(type(schema))

            raise TypeError('read_schema does not support {} types'.format(type(schema)))

    def extract(self, extractor=None):
        colors.out_print("Extracting...", indent=0)
        extractor = self.extractor
        self.extractor = extractor(spark=self.spark, cxn=self.src_cxn, conf=self.conf, schema=self.src_schema).process()
        self.df = self.extractor.df
        return self

    # TODO: test use only!!!
    def registreet_enrich(self):
        colors.out_print("Running RS specific enrich...", indent=0)
        from skylla.enrich import Single_Enricher
        from skylla.enrich.ref_ref import au_raw_salesforce_id
        se = Single_Enricher(df=self.df, table='entity', rules=[au_raw_salesforce_id])
        return self

    def transform(self, transformer=None, extractor=None, step=False):

        colors.out_print("Transforming...", indent=0)
        transformer = self.transformer
        ext = self.extractor if not extractor else extractor
        self.transformer = transformer(df=ext.df, schema=self.trg_schema['schema'],
                                       spark=self.spark, conf=self.conf)
        if not step:
            self.transformer.process()

        self.df = self.transformer.df

        return self

    def enrich(self):
        colors.out_print("Enriching...", indent=0)
        self.enricher = self.enricher(dfs=self.transformer.out_df, conf=self.conf).process()
        return self

    def load(self):
        colors.out_print("Loading...", indent=0)

        loader = self.loader
        x_fields = {'enrichment_error': {'encrypted': 'None', 'nullable': True, 'type': 'String'}}
        self.loader = loader(out_df=self.transformer.out_df,
                             schema=self.trg_schema['schema'],
                             conf=self.conf, x_cols=x_fields,
                             cxn=self.trg_cxn,
                             spark=self.spark).process()
        return self

    def print_doc(self):
        """ Prints docstrings """
        print(self.extractor.__doc__)
        print(self.transformer.__doc__)
        print(self.enricher.__doc__)
        print(self.loader.__doc__)
