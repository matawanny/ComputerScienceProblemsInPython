from builtins import staticmethod
from cm_commons import colors
from cm_commons.db.cm_conn import cm_cxn
from cm_commons.db.postgregsql_pool import *
import kalypso


class dbsync_executor:
    PostGregSQLPool.initialize(database=cm_cxn['db_name'],
                               user=cm_cxn['user'],
                               host=cm_cxn['location'],
                               password=cm_cxn['password'])
    @staticmethod
    def get_prefix_and_active_stage(cur, prefix):
        switch_tbl = 'edm_params'
        switch_col = 'value1'
        switch_key = 'active_mdm_stage'
        if not prefix:
            cur.execute(f"select {switch_col} from {switch_tbl} WHERE key = '{switch_key}'")
            active_stage = str(cur.fetchall()[0][0])
            if not active_stage.startswith('stg_'):
                prefix = f'stg_{active_stage}'
            else:
                prefix = active_stage
        else:
            if prefix.startswith('stg_'):
                active_stage = prefix[4:]
            else:
                active_stage = prefix
        return prefix, active_stage

    @staticmethod
    def sv_fop_export(prefix, new_fop=None, delta=None):
        """Generates sv_fop_export tables"""
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)
        #kalypso.views.sf_api_entity_export_v(prefix, active_stage, new_fop, delta)
        kalypso.views.sv_fop_export_v(prefix, active_stage)

    @staticmethod
    def sf_fop_export(prefix, new_fop=None, delta=None):
        """Generates sv_fop_export tables"""
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)
        kalypso.views.sv_fop_export_v(prefix, active_stage)
        kalypso.views.sf_fop_export_v(prefix, active_stage)

    @staticmethod
    def sv_fop_export_print(prefix, new_fop=None, delta=None):
        """Generates sv_fop_export tables"""
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)
        #kalypso.views.print_sf_api_entity_query(prefix, active_stage, new_fop, delta)
        kalypso.views.print_sv_fop_export(prefix, active_stage)

    @staticmethod
    def sf_fop_export_print(prefix, new_fop=None, delta=None):
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)
        """Generates sv_fop_export tables"""
        kalypso.views.print_sf_query(prefix, active_stage)

    @staticmethod
    def sv_fop_ancestry(prefix, new_fop=None, delta=None):
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)
        """Generates sv_fop_export tables"""
        kalypso.views.sv_fop_export_v(prefix, active_stage)

    @staticmethod
    def sf_fop_ancestry(prefix, new_fop=None, delta=None):
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)
        """Generates sv_fop_export tables"""
        kalypso.views.sf_fop_export_v(prefix, active_stage)

    @staticmethod
    def sv_fopm_export(prefix, new_fop=None, delta=None):
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)

        """Generates sv_fopm_export tables"""
        kalypso.views.sv_fop_export_v(prefix, active_stage)
        kalypso.views.sv_mrg_export_v(prefix, active_stage)

    @staticmethod
    def sf_fopm_export(prefix, new_fop=None, delta=None):
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)
        """Generates sv_fopm_export tables"""
        kalypso.views.sf_fop_export_v(prefix, active_stage)
        kalypso.views.sf_mrg_export_v(prefix, active_stage)

    @staticmethod
    def blank_sv_fop_export(prefix, new_fop=None, delta=None):
        """Generates sv_fop_export tables"""
        kalypso.views.blank_sv_fop_export_v()

    @staticmethod
    def sf_entity_api(prefix=None, new_fop=None, delta=None):
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)
        """Generates sf_entity_api for tables"""
        kalypso.views.sf_api_entity_export_v(prefix, active_stage, new_fop, delta)

    @staticmethod
    def sf_agreement_api(prefix=None, new_fop=None, delta=None):
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)
        """Generates sf_agreement_api for tables"""
        kalypso.views.sf_api_agreement_export_v(prefix, active_stage, delta)

        colors.out_print('Generating invalid agreement tables from SF send', indent=0)
        kalypso.tables.sf_agreement_generate_invalid_tables(prefix, active_stage)

    @staticmethod
    def cm_flows(prefix=None, new_fop=None, delta=None):
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)
        """Generates sf_agreement_api for tables"""
        kalypso.views.cm_flows(prefix, active_stage)

    @staticmethod
    def sf_new_entity_api(prefix=None, new_fop=None, delta=None):
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)
        """Generates sf_entity_api for tables"""
        kalypso.views.sf_api_entity_export_v(prefix, active_stage)

    @staticmethod
    def instantiate_system_tables(prefix=None, new_fop=None, delta=None):
        colors.out_print("Instantiating system tables", indent=0)
        kalypso.tables.instantiate_edm_params()

    @staticmethod
    def flip_staging_tables(prefix=None, new_fop=None, delta=None):
        colors.out_print("Flipping staging tables", indent=0)
        kalypso.tables.flip_edm_params()

    @staticmethod
    def sf_generate_invalid_agreements(prefix=None, new_fop=None, delta=None):
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)
        colors.out_print('Generating invalid agreement tables from SF send', indent=0)
        kalypso.tables.sf_agreement_generate_invalid_tables(prefix, active_stage)

    @staticmethod
    def sf_generate_invalid_entites(prefix=None, new_fop=None, delta=None):
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)

        colors.out_print('Generating invalid entity tables from SF send', indent=0)
        kalypso.tables.sf_entity_generate_invalid_tables(prefix, active_stage)

    @staticmethod
    def blank_persist_tables(prefix=None, new_fop=None, delta=None):
        colors.out_print("Initializing persistence tables", indent=0)
        kalypso.tables.blank_persist_tables()

    @staticmethod
    def sf_mrg_export(prefix=None, new_fop=None, delta=None):
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)
        """Generates sf_mrg_export tables"""
        kalypso.views.sf_mrg_export_v(prefix, active_stage)

    @staticmethod
    def post_mdm_indexing(prefix=None, new_fop=None):
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)

        """index post MDM tables"""
        kalypso.procedures.post_mdm_indexing(prefix, active_stage)

    @staticmethod
    def sf_merge_api(prefix=None, new_fop=None, delta=None):
        with CursorFromConnectionPool() as cur:
            prefix, active_stage = dbsync_executor.get_prefix_and_active_stage(cur, prefix)

        """Run Merge DBSync for target dataset"""
        kalypso.views.sf_api_entity_export_v(prefix, active_stage, new_fop, delta)
        kalypso.views.sf_api_merge_export_v(prefix, active_stage, new_fop, delta)
