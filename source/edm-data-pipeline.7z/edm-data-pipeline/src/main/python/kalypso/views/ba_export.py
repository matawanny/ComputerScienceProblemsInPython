import psycopg2
from cm_commons.db.cm_conn import cm_cxn

def drop_ba(cur, active_stage):
    sql = f""" 
                drop table if exists ba_{active_stage}_entity cascade;
                drop table if exists ba_{active_stage}_agreement cascade;
                drop table if exists ba_{active_stage}_agreement_entity_xref;
                drop table if exists ba_{active_stage}_aum cascade;
                drop table if exists ba_{active_stage}_trade;
                drop table if exists ba_{active_stage}_sales_owner_agreement_xref cascade;
                drop table if exists ba_{active_stage}_sub_agreement cascade;
        """
    cur.execute(sql)

def create_ba(cur, active_stage):
    sql = f""" 
                create table ba_{active_stage}_entity
                    AS SELECT * FROM stg_{active_stage}_entity;
                create table ba_{active_stage}_agreement
                    AS SELECT * FROM stg_{active_stage}_agreement;
                create table ba_{active_stage}_agreement_entity_xref
                    AS SELECT * FROM stg_{active_stage}_agreement_entity_xref;
                create table ba_{active_stage}_aum
                    AS SELECT * FROM stg_{active_stage}_aum;
                create table ba_{active_stage}_trade
                    AS SELECT * FROM stg_{active_stage}_trade;
                drop table if exists ba_{active_stage}_sales_owner_agreement_xref
                    AS SELECT * FROM stg_{active_stage}_sales_owner_agreement_xref;
                drop table if exists ba_{active_stage}_sub_agreement
                    AS SELECT * FROM stg_{active_stage}_sub_agreement;
        """
    cur.execute(sql)

def index_ba(cur, active_stage):
    sql = f"""
    create index ba_{active_stage}_aum__agreement_id on ba_{active_stage}_aum (agreement_id);
    create index ba_{active_stage}_as_of_date on ba_{active_stage}_aum (as_of_date);
    create index ba_{active_stage}_sub_agreement__agreement_id on ba_{active_stage}_sub_agreement (agreement_id);
    create index ba_{active_stage}_entity__entity_id on ba_{active_stage}_entity (entity_id);
    create index ba_{active_stage}_agreement_entity_xref__entity_id on ba_{active_stage}_agreement_entity_xref (entity_id);
    create index ba_{active_stage}_agreement_entity_xref__agreement_id on ba_{active_stage}_agreement_entity_xref (agreement_id);
"""

def sv_fop_export_v():

    from cm_commons import colors
    colors.out_print(f"Running sf_api_agreement_export_v", indent=1)

    src_cxn = psycopg2.connect(dbname=cm_cxn['db_name'],
                               user=cm_cxn['user'],
                               host=cm_cxn['location'],
                               password=cm_cxn['password'])
    cur = src_cxn.cursor()

    switch_tbl = 'edm_params'
    switch_col = 'value1'
    switch_key = 'active_mdm_stage'

    cur.execute(f"select {switch_col} from {switch_tbl} WHERE key = '{switch_key}'")
    active_stage = str(cur.fetchall()[0][0])
    colors.out_print("BA Export", indent=1)

    drop_ba(cur=cur, active_stage=active_stage)
    create_ba(cur=cur, active_stage=active_stage)
    index_ba(cur=cur,active_stage=active_stage)

    colors.out_print("Committing and closing", indent=2)
    src_cxn.commit()
    cur.close()
    src_cxn.close()
