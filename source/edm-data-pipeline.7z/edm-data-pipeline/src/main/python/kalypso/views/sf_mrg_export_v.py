from cm_commons import colors
from cm_commons.db.postgregsql_pool import *
mrg_sql = """
    DROP TABLE IF EXISTS sf_export_mrg CASCADE;
    
    CREATE TABLE sf_export_mrg AS
        SELECT 
            CASE 
               WHEN entity_type_id LIKE '1%' THEN 'P'
               WHEN entity_type_id LIKE '2%' THEN 'O'
               WHEN entity_type_id LIKE '3%' THEN 'F'
               ELSE NULL
            END as merge_type,
            sf_invalid as sf_from_id,
            sf_valid as sf_to_id,
            invalid_value as crm_from_id,
            valid_value as crm_to_id
        FROM {prefix}salesforce_merge_rules
        WHERE (sf_invalid is not NULL) and (invalid_value is not NULL)
;
"""


def sf_mrg_export_v(prefix, active_stage):

    colors.out_print(f"Using prefix {prefix}", indent=1)
    with CursorFromConnectionPool() as cur:
        cur.execute(mrg_sql.format(prefix=prefix))
