sql = """
DROP TABLE IF EXISTS entity_linked_list_sv_anc CASCADE
;

CREATE TABLE entity_linked_list_sv_anc as
WITH RECURSIVE tree AS (
         SELECT {prefix}entity.entity_id,
            {prefix}entity.parent_id,
            {prefix}entity.salesvision_id,
            {prefix}entity.entity_type_id,
            {prefix}entity.crd,
            ARRAY[{prefix}entity.entity_id] AS id_path,
            ARRAY[LEFT({prefix}entity.entity_type_id,1)] AS type_path,
            ARRAY[{prefix}entity.salesvision_id] AS sv_path,
            ARRAY[{prefix}entity.parent_id] AS parent_path
           FROM {prefix}entity
          WHERE ({prefix}entity.parent_id IS NULL) and ({prefix}entity.salesvision_id IS NOT NULL)
        UNION ALL
         SELECT c.entity_id,
            c.parent_id,
            c.salesvision_id,
            c.entity_type_id,
            c.crd,
            (t_1.id_path || c.entity_id),
            (t_1.type_path || LEFT(c.entity_type_id,1)),
            (t_1.sv_path || c.salesvision_id),
            (t_1.parent_path || c.parent_id)
           FROM (tree t_1
             JOIN {prefix}entity c ON ((c.parent_id = t_1.entity_id)))
        )
 SELECT t.entity_id,
        t.parent_id,
        t.salesvision_id,
        t.entity_type_id,
        t.id_path,
        t.parent_path,
        t.sv_path,
        t.type_path
   FROM tree t
;
"""

from cm_commons.db.cm_conn import cm_cxn
import psycopg2


def sv_fop_export_v():

    from cm_commons import colors
    src_cxn = psycopg2.connect(dbname=cm_cxn['db_name'],
                               user=cm_cxn['user'],
                               host=cm_cxn['location'],
                               password=cm_cxn['password'])
    cur = src_cxn.cursor()
    switch_tbl = 'edm_params'
    switch_col = 'value1'
    switch_key = 'active_mdm_stage'

    cur.execute(f"select {switch_col} from {switch_tbl} WHERE key = '{switch_key}'")
    active_stage = str(cur.fetchall()[0][0])
    prefix = f"stg_{active_stage}_"
    colors.out_print(f"Using prefix {prefix}", indent=1)
    colors.sql_print(sql.format(prefix=prefix), indent=2)
    try:
        cur.execute(sql.format(prefix=prefix))
    except Exception as e:
        cur.close()
        src_cxn.close()
        raise e
    src_cxn.commit()
    cur.close()
    src_cxn.close()
