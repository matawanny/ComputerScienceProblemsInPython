from cm_commons import colors
from cm_commons.db.postgregsql_pool import *

debug_var = ""


def create_ect_functions(cur, mock=False):
    colors.out_print(f"creating ect helper functions", indent=2)
    sql = f"""
    CREATE OR replace FUNCTION array_except(anyarray, anyarray) returns anyarray 
    AS
      $$ 
      SELECT array_agg(elements) 
      FROM   ( 
             ( 
                    SELECT unnest($1) 
                    EXCEPT 
                    SELECT unnest($2)) ) AS r (elements) $$ LANGUAGE SQL strict immutable;

    CREATE OR REPLACE FUNCTION array_greatest(anyarray)
    RETURNS anyelement LANGUAGE SQL AS $$
    SELECT max(x) FROM unnest($1) x;
    $$;

    CREATE OR REPLACE FUNCTION get_sf_entity_date() RETURNS timestamp AS $$
    SELECT TO_TIMESTAMP(value1, 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone
    FROM edm_params
    WHERE key = 'sf_export_date'
    $$ LANGUAGE SQL;

    CREATE OR REPLACE FUNCTION get_sf_last_ingested_date() RETURNS timestamp AS $$
    SELECT TO_TIMESTAMP(value1, 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone
    FROM edm_params
    WHERE key = 'sf_last_ingested_date'
    $$ LANGUAGE SQL;

    CREATE OR REPLACE FUNCTION get_last_send_to_sf_date(stage text) RETURNS timestamp AS $$
    SELECT TO_TIMESTAMP(send_to_sf_date, 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone
    FROM edm_export_params
    WHERE mdm_stage = stage
    $$ LANGUAGE SQL;
    """
    if not mock:
        cur.execute(sql)
    return sql


def drop_previous_tables(cur, prefix, mock=False):
    colors.out_print(f"Dropping previous tables", indent=2)
    sql = f"""
        DROP TABLE IF EXISTS {debug_var}entity_linked_list_sf cascade;
        DROP TABLE IF EXISTS {debug_var}fop_sf_fir_ll cascade;
        DROP TABLE IF EXISTS {debug_var}fop_sf_ofl_ll;
        DROP TABLE IF EXISTS {debug_var}fop_sf_per_ll;
        DROP TABLE IF EXISTS {debug_var}sf_stage_fir cascade;
        DROP TABLE IF EXISTS {debug_var}sf_stage_ofl;
        DROP TABLE IF EXISTS {debug_var}sf_stage_per;
        DROP TABLE IF EXISTS {debug_var}sf_export_fir cascade;
        DROP TABLE IF EXISTS {debug_var}sf_export_ofl;
        DROP TABLE IF EXISTS {debug_var}sf_export_per;
    """
    if not mock:
        cur.execute(sql)
    return sql


def build_sf_tree(cur, prefix, mock=False):
    colors.out_print(f'building sf entity tree', indent=1)
    sql = f"""
    CREATE TABLE entity_linked_list_sf 
    as
        WITH RECURSIVE tree AS (
                 SELECT {prefix}_entity.entity_id,
                    {prefix}_entity.parent_id,
                    {prefix}_entity.salesforce_id,
                    {prefix}_entity.entity_type_id,
                    {prefix}_entity.crd,
                    CASE
                        WHEN {prefix}_entity.etl_source = 'sv' and {prefix}_entity.sv_event_code = 'I'
                            THEN TRUE
                        ELSE
                            CASE
                                WHEN {prefix}_entity.salesforce_id is not null or (({prefix}_entity.ect_entity_id = 'a0W1N00000Qw7zGUAR' and {prefix}_entity.ect_channel_id = 'a0U1N00000G4uZwUAJ' and {prefix}_entity.ect_team_id = 'a0c1N00000RvRacQAF') or ({prefix}_entity.ect_entity_id = 'a0W1N00000Qw7zGUAR' and {prefix}_entity.ect_channel_id = 'a0U1N00000G4ua1UAB' and {prefix}_entity.ect_team_id = 'a0c1N00000RvRawQAF'))
                                    THEN TRUE
                                ELSE FALSE
                            END
                    END as is_valid,
                    ARRAY[{prefix}_entity.entity_id] AS id_path,
                    ARRAY[LEFT({prefix}_entity.entity_type_id,1)] AS type_path,
                    ARRAY[
                    CASE
                        WHEN {prefix}_entity.etl_source = 'sv' and {prefix}_entity.sv_event_code = 'I'
                            THEN TRUE
                        ELSE
                            CASE
                                WHEN {prefix}_entity.salesforce_id is not null or (({prefix}_entity.ect_entity_id = 'a0W1N00000Qw7zGUAR' and {prefix}_entity.ect_channel_id = 'a0U1N00000G4uZwUAJ' and {prefix}_entity.ect_team_id = 'a0c1N00000RvRacQAF') or ({prefix}_entity.ect_entity_id = 'a0W1N00000Qw7zGUAR' and {prefix}_entity.ect_channel_id = 'a0U1N00000G4ua1UAB' and {prefix}_entity.ect_team_id = 'a0c1N00000RvRawQAF'))
                                    THEN TRUE
                                ELSE FALSE
                            END
                    END
                    ] as valid_path,
                    ARRAY[{prefix}_entity.salesforce_id] AS sf_path,
                    ARRAY[{prefix}_entity.parent_id] AS parent_path
                   FROM {prefix}_entity
                  WHERE ({prefix}_entity.parent_id is null)
                UNION ALL
                 SELECT c.entity_id,
                    c.parent_id,
                    c.salesforce_id,
                    c.entity_type_id,
                    c.crd,
                    CASE
                        WHEN c.etl_source = 'sv' and c.sv_event_code = 'I'
                            THEN TRUE
                        ELSE
                            CASE
                                WHEN c.salesforce_id is not null or ((c.ect_entity_id = 'a0W1N00000Qw7zGUAR' and c.ect_channel_id = 'a0U1N00000G4uZwUAJ' and c.ect_team_id = 'a0c1N00000RvRacQAF') or (c.ect_entity_id = 'a0W1N00000Qw7zGUAR' and c.ect_channel_id = 'a0U1N00000G4ua1UAB' and c.ect_team_id = 'a0c1N00000RvRawQAF'))
                                    THEN TRUE
                                ELSE FALSE
                            END
                    END,
                    (t_1.id_path || c.entity_id),
                    (t_1.type_path || LEFT(c.entity_type_id,1)),
                    (t_1.valid_path || CASE
                        WHEN c.etl_source = 'sv' and c.sv_event_code = 'I'
                            THEN TRUE
                        ELSE
                            CASE
                                WHEN c.salesforce_id is not null or ((c.ect_entity_id = 'a0W1N00000Qw7zGUAR' and c.ect_channel_id = 'a0U1N00000G4uZwUAJ' and c.ect_team_id = 'a0c1N00000RvRacQAF') or (c.ect_entity_id = 'a0W1N00000Qw7zGUAR' and c.ect_channel_id = 'a0U1N00000G4ua1UAB' and c.ect_team_id = 'a0c1N00000RvRawQAF'))
                                    THEN TRUE
                                ELSE FALSE
                            END
                    END),                    (t_1.sf_path || c.salesforce_id),
                    (t_1.parent_path || c.parent_id)
                   FROM (tree t_1
                     JOIN {prefix}_entity c ON ((c.parent_id = t_1.entity_id)))
                )
        SELECT  t.entity_id,
                t.parent_id,
                t.entity_type_id,
                t.id_path,
                t.parent_path,
                t.sf_path,
                t.type_path,
                t.valid_path
        FROM tree t;


    """
    if not mock:
        cur.execute(sql)
    return sql


def build_fop_tables(cur, prefix, mock=False):
    """Builds temp tables for firm, office, and person that determine the closest relevant parent"""
    colors.out_print(f'building FOP linked list tables', indent=1)

    colors.out_print(f'building firm linked list', indent=2)
    fir_ll = f"""
    CREATE TABLE fop_sf_fir_ll 
    as
        SELECT DISTINCT
            id_path[firm_position] as firm_id
        FROM
            (
              select  ll.id_path, 
                      type_path, 
                      sf_path,
                      unnest(array_except(array_positions(type_path, '3'), array_positions(valid_path, False))) as firm_position
              FROM entity_linked_list_sf ll
            ) mm;
    """
    if not mock:
        cur.execute(fir_ll)

    colors.out_print(f'building office linked list', indent=2)
    ofl_ll = f"""
    CREATE TABLE fop_sf_ofl_ll 
    as
        SELECT DISTINCT
            id_path[array_greatest(firm_position)] as firm_id,
            id_path[office_position] as office_id
        FROM
            (
              SELECT    ll.id_path, 
                        type_path, 
                        sf_path, 
                        array_except(array_positions(type_path, '3'), array_positions(valid_path, False)) as firm_position,
                        unnest(array_except(array_positions(type_path, '2'), array_positions(valid_path, False))) as office_position
              FROM entity_linked_list_sf ll
            ) mm;
    """
    if not mock:
        cur.execute(ofl_ll)

    colors.out_print(f'building person linked list', indent=2)
    per_ll = f"""
    CREATE TABLE fop_sf_per_ll 
    as
      SELECT DISTINCT
            id_path[array_greatest(firm_position)] as firm_id,
            id_path[array_greatest(office_position)] as office_id,
            id_path[person_position] as person_id
      FROM
            (
              SELECT 
                  ll.id_path, 
                  type_path, 
                  sf_path, 
                  array_except(array_positions(type_path, '3'), array_positions(valid_path, False)) as firm_position,
                  array_except(array_positions(type_path, '2'), array_positions(valid_path, False)) as office_position,
                  unnest(array_except(array_positions(type_path, '1'), array_positions(valid_path, False))) as person_position
              FROM entity_linked_list_sf ll
            ) mm;
    """
    if not mock:
        cur.execute(per_ll)

    return fir_ll + ofl_ll + per_ll


def build_valid_xref(cur, prefix, mock=False):
    """Build temp tables that selects the most valid address/phone/email per entity_id"""
    colors.out_print(f"Building valid SV metadata tables", indent=1)

    colors.out_print(f"Building valid address selection tables", indent=2)
    sf_valid_addy = f"""
    create temp table sf_export_valid_addresses
    as
        SELECT * 
        FROM {prefix}_entity_address_xref 
        WHERE address_type_id = '601'
        UNION
        SELECT xref.*
        FROM 
        (
          SELECT distinct(entity_id)
          FROM {prefix}_entity_address_xref
          GROUP BY entity_id
          HAVING max(CASE "address_type_id"  WHEN '601' THEN 1 ELSE 0 END) = 0
        ) s
        JOIN {prefix}_entity_address_xref xref
            ON xref.entity_id = s.entity_id
        WHERE address_type_id = '300';
    """
    if not mock:
        cur.execute(sf_valid_addy)

    sf_valid_phone = f"""
    create temp table sf_export_valid_phones
    as
        SELECT * 
        FROM {prefix}_entity_phone_xref 
        WHERE phone_type_id = '3'
        UNION
        SELECT xref.*
        FROM 
        (
          SELECT distinct(entity_id)
          FROM {prefix}_entity_phone_xref
          GROUP BY entity_id
          HAVING max(CASE "phone_type_id"  WHEN '3' THEN 1 ELSE 0 END) = 0
        ) s
        JOIN {prefix}_entity_phone_xref xref
            ON xref.entity_id = s.entity_id
        WHERE phone_type_id = '1';
    """
    if not mock:
        cur.execute(sf_valid_phone)

    sf_valid_emails = f"""
    create temp table sf_export_valid_emails
    as
        SELECT * 
        FROM {prefix}_entity_email_xref 
        WHERE email_type_id = '3'
        UNION
        SELECT xref.*
        FROM 
        (
          SELECT distinct(entity_id)
          FROM {prefix}_entity_email_xref
          GROUP BY entity_id
          HAVING max(CASE "email_type_id"  WHEN '3' THEN 1 ELSE 0 END) = 0
        ) s
        JOIN {prefix}_entity_email_xref xref
            ON xref.entity_id = s.entity_id
        WHERE email_type_id = '1';
    """
    if not mock:
        cur.execute(sf_valid_emails)
    return sf_valid_addy + sf_valid_phone + sf_valid_emails


def build_sf_stage_tables(cur, prefix, mock=False):
    """Build staging tables that show a FULL export set"""
    colors.out_print(f'building FOP tables for SV export', indent=1)

    colors.out_print(f'building firm SV export', indent=2)
    sf_fir = f"""
    CREATE TABLE sf_stage_fir
    AS
      SELECT DISTINCT
              (
                SELECT MAX(ua)
                FROM unnest(ARRAY[ent.updated_at,
                                  adr.updated_at]) ua
              ) AS max_updated_at,
              ent.ingested_at as ingested_at,
              ent.salesforce_id as sf_firm_id,
              ent.entity_name as firm_name,
              adr.street_address_1 as address_line_1,
              adr.street_address_2 as address_line_2,
              adr.city as address_city,
              adr.country || '-' || adr.state as address_state,
              adr.postal_code as address_zipcode,
              adr.country as address_country,
              ent.persistence_id as crm_firm_id,
              CASE 
                    WHEN ent.ended_at is NOT NULL
                        THEN 'D'
                    WHEN ent.salesforce_id is NULL 
                        THEN 'I'
                    ELSE 'U'
              END as event_code,
              NULL as crm_service_request_id,
              CASE
                      WHEN ent.created_at is NULL
                      THEN to_char(NOW(), 'YYYY-MM-DD HH24:MI:SS')
                 ELSE ent.created_at
                 END
              as create_date,
              'laz_cm_sf_api' as create_user,
              NULL as maintenance_date, -- TODO: pass meaningful maintenance date
              'laz_cm_sf_api' as maintenance_user
      FROM {prefix}_entity ent
      JOIN (SELECT DISTINCT(firm_id) as firm_id FROM fop_sf_fir_ll) ll
          ON ll.firm_id = ent.entity_id
      JOIN sf_export_valid_addresses adr
          ON adr.entity_id = ent.entity_id
      WHERE ent.entity_type_id LIKE '3%';
    """
    if not mock:
        cur.execute(sf_fir)

    colors.out_print(f'building office SV export', indent=2)
    sf_ofl = f"""
    CREATE TABLE sf_stage_ofl
    AS
      SELECT DISTINCT
              (
                SELECT MAX(ua)
                FROM unnest(ARRAY[ent.updated_at, 
                                 -- fir.updated_at, 
                                  adr.updated_at]) ua
              ) AS max_updated_at,
              ent.ingested_at as ingested_at,
              fir.salesforce_id as sf_firm_id,
              ent.salesforce_id as sf_office_id,
              adr.street_address_1 as address_line_1,
              CASE
                WHEN adr.street_address_2 = ''
                  THEN Null
                ELSE adr.street_address_2
              END as address_line_2,
              NULL as address_line_3,
              adr.city as address_city,
              adr.country || '-' || adr.state as address_state,
              adr.postal_code as address_zipcode,
              adr.country as address_country,
              fir.persistence_id as crm_firm_id,
              ent.persistence_id as crm_office_id,
              CASE 
                    WHEN ent.ended_at is NOT NULL
                        THEN 'D'
                    WHEN ent.salesforce_id is NULL 
                        THEN 'I'
                    ELSE 'U'
              END as event_code,
              NULL as crm_service_request_id,
              CASE
                  WHEN ent.created_at is NULL
                  THEN to_char(NOW(), 'YYYY-MM-DD HH24:MI:SS')
              ELSE ent.created_at
              END
              as create_date,
              'laz_cm_sf_api' as create_user,
              NULL as maintenance_date,
              'laz_cm_sf_api' as maintenance_user
      FROM {prefix}_entity ent
      JOIN (SELECT office_id, firm_id FROM fop_sf_ofl_ll) ll
        ON ll.office_id = ent.entity_id
      JOIN {prefix}_entity fir
        ON fir.entity_id = ll.firm_id
      JOIN sf_export_valid_addresses adr
        ON adr.entity_id = ent.entity_id
      WHERE ent.entity_type_id  LIKE '2%';
    """
    if not mock:
        cur.execute(sf_ofl)

    colors.out_print(f'building person SV export', indent=2)
    sf_per = f"""
    CREATE TABLE sf_stage_per
    AS
      SELECT  (
                SELECT MAX(ua)
                FROM unnest(ARRAY[per_updated_at, 
    --                              ofl_updated_at, 
    --                              fir_updated_at, 
                                  phone_updated_at, 
                                  email_updated_at]) ua
              ) AS max_updated_at,
              s.ingested_at as ingested_at,
              sf_firm_id,
              sf_office_id,
              sf_person_id,
              CASE
                WHEN ent_name[1] in ('', 'null', 'NULL', 'Null')
                  THEN NULL
                ELSE ent_name[1]
              END
              as last_name,
              CASE
                WHEN ent_name[2] in ('', 'null', 'NULL', 'Null')
                  THEN NULL
                ELSE ent_name[2]
              END
              as first_name,
              CASE
                WHEN ent_name[3] in ('', 'null', 'NULL', 'Null')
                  THEN NULL
                ELSE ent_name[3]
              END
              as middle_name,
              CASE
                WHEN entity_type_id='101'
                  THEN 'N'
                WHEN entity_type_id='102'
                  THEN 'Y'
                ELSE '?'
              END as broker_team,
              crm_firm_id,
              crm_office_id,
              crm_person_id,
              CASE 
                    WHEN s.ended_at is NOT NULL
                        THEN 'D'
                    WHEN s.salesforce_id is NULL 
                        THEN 'I'
                    ELSE 'U'
              END as event_code,
              NULL as crm_service_request_id,
              'C' as person_status,
              NULL as home_office_flag,
              phone_number,
              email_address,
              crd as crd_number,
              NULL as broker_rep_code,
              CASE
                WHEN created_at is NULL
                  THEN to_char(NOW(), 'YYYY-MM-DD HH24:MI:SS')
                ELSE created_at
              END
              as create_date,
              'laz_cm_sf_api' as create_user,
              NULL as maintenance_date,
              'laz_cm_sf_api' as maintenance_user
      FROM
      (
        SELECT  regexp_split_to_array(ent.entity_name, '\|') ent_name,
                ent.*,
                ent.updated_at as per_updated_at,
                ofl.persistence_id as crm_office_id,
                fir.persistence_id as crm_firm_id,
                ent.persistence_id as crm_person_id,
                ofl.salesforce_id as sf_office_id, 
                fir.salesforce_id as sf_firm_id,
                ofl.updated_at as ofl_updated_at,
                fir.updated_at as fir_updated_at,
                ent.salesforce_id as sf_person_id,
                pho.phone_number, pho.updated_at as phone_updated_at,
                ema.email_address, ema.updated_at as email_updated_at
        FROM {prefix}_entity ent
        JOIN (SELECT person_id, office_id, firm_id FROM fop_sf_per_ll) ll
          ON ll.person_id = ent.entity_id
        JOIN {prefix}_entity ofl
            ON office_id = ofl.entity_id
        JOIN {prefix}_entity fir
            ON firm_id = fir.entity_id
        LEFT JOIN sf_export_valid_phones pho
            ON pho.entity_id = ent.entity_id
        LEFT JOIN sf_export_valid_emails ema
            ON ema.entity_id = ent.entity_id
        --WHERE (pho.phone_type_id = '3') OR (pho.phone_type_id is NULL) AND (ema.email_type_id = '3') OR (ema.email_type_id is NULL) AND ent.entity_type_id  LIKE '1%'
      ) s;
    """
    if not mock:
        cur.execute(sf_per)
    return sf_fir + sf_ofl + sf_per


def build_sf_export_tables(cur, active_stage, mock=False):
    sql = """
    CREATE TABLE sf_export_fir 
    AS
        SELECT DISTINCT sf_firm_id,firm_name,address_line_1,address_line_2,address_city,address_state,address_zipcode,address_country,crm_firm_id,event_code,crm_service_request_id,create_date,create_user,maintenance_date,maintenance_user
        FROM sf_stage_fir
        WHERE ingested_at::timestamp > get_last_send_to_sf_date('{active_stage}') 
        UNION
        SELECT null, firm_name,address_line_1,address_line_2,address_city,address_state,address_zipcode,address_country,crm_firm_id,event_code,crm_service_request_id,create_date,create_user,maintenance_date,maintenance_user
        FROM sv_export_fir;

    CREATE TABLE sf_export_ofl 
    AS
        SELECT DISTINCT sf_firm_id,sf_office_id,address_line_1,address_line_2,address_line_3,address_city,address_state,address_zipcode,address_country,crm_firm_id,crm_office_id,event_code,crm_service_request_id,create_date,create_user,maintenance_date,maintenance_user
        FROM sf_stage_ofl
        WHERE ingested_at::timestamp > get_last_send_to_sf_date('{active_stage}') 
        UNION
        SELECT null, null, address_line_1,address_line_2,address_line_3,address_city,address_state,address_zipcode,address_country,crm_firm_id,crm_office_id,event_code,crm_service_request_id,create_date,create_user,maintenance_date,maintenance_user
        FROM sv_export_ofl;

    CREATE TABLE sf_export_per 
    AS
        SELECT  DISTINCT sf_firm_id,sf_office_id,sf_person_id,last_name,first_name,middle_name,broker_team,crm_firm_id,crm_office_id,crm_person_id,event_code,crm_service_request_id,person_status,home_office_flag,phone_number,email_address,crd_number,broker_rep_code,create_date,create_user,maintenance_date,maintenance_user
        FROM sf_stage_per
        WHERE ingested_at::timestamp > get_last_send_to_sf_date('{active_stage}') 
        UNION
        SELECT null, null, null, last_name,first_name,middle_name,broker_team,crm_firm_id,crm_office_id,crm_person_id,event_code,crm_service_request_id,person_status,home_office_flag,phone_number,email_address,crd_number,broker_rep_code,create_date,create_user,maintenance_date,maintenance_user
        FROM sv_export_per;
    """
    if not mock:
        cur.execute(sql)
    return sql


def sf_fop_export_v(prefix, active_stage):
    colors.out_print(f"Running SV export generation", indent=1)
    if debug_var != "":
        colors.bug_print(f"Using debug_var: {debug_var}", indent=2)

    with CursorFromConnectionPool() as cur:
        colors.out_print(f"Building from {prefix}_*", indent=1)

        create_ect_functions(cur)
        drop_previous_tables(cur, prefix)
        build_sf_tree(cur, prefix)
        build_fop_tables(cur, prefix)
        build_valid_xref(cur, prefix)
        build_sf_stage_tables(cur, prefix)
        build_sf_export_tables(cur, active_stage)


def print_sf_query(prefix, active_stage):
    with CursorFromConnectionPool() as cur:
        colors.out_print(f"Building from {prefix}_*", indent=1)
        query = ''
        query += '\n' + create_ect_functions(cur, mock=True)
        query += '\n' + drop_previous_tables(cur, prefix, mock=True)
        query += '\n' + build_sf_tree(cur, prefix, mock=True)
        query += '\n' + build_fop_tables(cur, prefix, mock=True)
        query += '\n' + build_valid_xref(cur, prefix, mock=True)
        query += '\n' + build_sf_stage_tables(cur, prefix, mock=True)
        query += '\n' + build_sf_export_tables(cur, active_stage, mock=True)
        print(query)
