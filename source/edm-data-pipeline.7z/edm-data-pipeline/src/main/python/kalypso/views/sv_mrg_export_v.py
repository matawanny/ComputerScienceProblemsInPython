from cm_commons import colors
from cm_commons.db.postgregsql_pool import *
mrg_sql = """
    DROP TABLE IF EXISTS sv_export_mrg CASCADE;
    
    CREATE TABLE sv_export_mrg AS
        SELECT 
            CASE 
               WHEN entity_type_id LIKE '1%' THEN 'P'
               WHEN entity_type_id LIKE '2%' THEN 'O'
               WHEN entity_type_id LIKE '3%' THEN 'F'
               ELSE NULL
            END as merge_type,
            sv_invalid as sv_from_id,
            sv_valid as sv_to_id,
            invalid_value as crm_from_id,
            valid_value as crm_to_id,
            NULL as crm_service_request_id
        FROM {prefix}_merge_rules
        WHERE created_by = 'circe_sf_merge'
        AND valid_value is not NULL AND invalid_value is not NULL
        AND created_at::timestamp > get_last_send_to_sv_date('{active_stage}')
;
"""


def sv_mrg_export_v(prefix, active_stage):
    colors.out_print(f"Using prefix {prefix}", indent=1)
    with CursorFromConnectionPool() as cur:
        colors.sql_print(mrg_sql.format(prefix=prefix,active_stage=active_stage), indent=2)
        cur.execute(mrg_sql.format(prefix=prefix,active_stage=active_stage))
