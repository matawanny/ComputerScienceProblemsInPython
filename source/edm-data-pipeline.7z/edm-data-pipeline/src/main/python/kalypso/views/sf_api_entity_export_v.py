from datetime import datetime

from cm_commons import colors
from cm_commons.db.postgregsql_pool import *
from cm_commons.util.sql_functions import table_exists, update_params_by_job

debug_var = ''


def create_delta_function(cur, mock=False):
    """
    Create/replace SQL function that is used to grab the timestamp of the last run FOP DBSync job.
    This function is used in delta calculations in the `valid_entities` table.
    :param cur:
    :param mock
    :return:
    """
    sql = """
    CREATE OR REPLACE FUNCTION get_last_job_ts(trg_key text) RETURNS timestamp AS $$
        SELECT TO_TIMESTAMP(value1, 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone
        FROM edm_params
        WHERE key = trg_key
    $$ LANGUAGE SQL;
    """
    if not mock:
        colors.out_print('create/replace delta function', indent=1)
        cur.execute(sql)
    return sql


def build_blank_table(cur, tbl_name, fields,  mock=False):
    """
    Helper function designed to build a blank table (if necessary)
    :param cur:
    :param tbl_name:
    :param fields:
    :param mock:
    :return:
    """
    fields_list = ",\n".join([f"{k} {v}" for k, v in fields.items()])
    sql = f"""
        create table {tbl_name} ({fields_list});
    """
    if not mock:
        cur.execute(sql)
    return sql


def drop_previous_tables(cur, mock=False):
    """
    Function used to drop all previous DBSync tables, looping throw two lists: one for `cm_*` prefixed tables,
    and one for `valid_*` prefixed tables
    :param cur:
    :param mock:
    """
    cm_tables = ['cm_entity', 'cm_entity_address_xref', 'cm_entity_email_xref', 'cm_entity_phone_xref',
                 'cm_entity_team_xref', 'cm_sv_sales_person', 'cm_sv_sales_hierarchy']
    valid_tables = ['valid_joined_entities', 'valid_entity_linked_list_m', 'valid_entities_full', 'valid_entities',
                    'valid_teams']

    if not mock:
        for tbl in cm_tables + valid_tables:
            sql = f'drop table if exists {debug_var}{tbl} cascade;'
            cur.execute(sql)
    else:
        sqls = ''
        for tbl in cm_tables + valid_tables:
            sql = f'drop table if exists {debug_var}{tbl} cascade;'
            sqls += '\n' + sql
        return sqls


def build_cm_entity(cur, prefix, mock=False):
    """
    Function that copies post-MDM tables into the `cm_*` prefixed tables to avoid creating unnecessary locks on
    MDM target tables. These `cm_*` tables are used for the CM API to send data to Salesforce (after building a valid
    set of Entities to send)
    :param cur:
    :param prefix:
    :param mock:
    :return:
    """
    from cm_commons.models.trg_files.target_models import SF_API_ENTITY
    schema = SF_API_ENTITY

    sql = """"""
    for tbl, val in schema.items():
        colors.out_print(f"Processing {tbl}", indent=3)

        src = f"{prefix}_{tbl}"

        # Special cases for ETL/non-MDM tables
        if tbl == "sv_sales_hierarchy":
            src = "sv_sales_hier_sv_sales_hierarchy"
        elif tbl == "sv_sales_person":
            src = "sv_sales_per_sv_sales_person"

        trg = f"cm_{debug_var}{tbl}"
        if table_exists(cur, src):
            colors.sql_print(f"create table {trg} as select * from {src};", indent=4)
            sql = sql + f"\ncreate table {trg} as select * from {src};"
        else:
            colors.war_print(f"{src} does not exist, building blank {trg} using schema", indent=4)
            s = build_blank_table(cur=cur, tbl_name=trg, fields={fld: 'varchar(255)' for fld in val['fields']},
                                  mock=mock)
            sql = sql + s

    if not mock:
        colors.out_print(f"Building cm_{debug_var}* tables", indent=2)
        cur.execute(sql)
    return sql


def create_entity_indexes(cur, mock=False):
    """
    Function to create indexes on `cm_*` tables for performance
    :param cur:
    :param mock:
    :return:
    """
    sql = f"""
            CREATE INDEX idx_cm_{debug_var}entity_entity_id ON cm_{debug_var}entity(entity_id);
            CREATE INDEX idx_cm_{debug_var}entity_address_xref_entity_id ON cm_{debug_var}entity_address_xref(entity_id);
            CREATE INDEX idx_cm_{debug_var}entity_email_xref_entity_id ON cm_{debug_var}entity_email_xref(entity_id);
            CREATE INDEX idx_cm_{debug_var}entity_phone_xref_entity_id ON cm_{debug_var}entity_phone_xref(entity_id);
        """
    colors.sql_print(sql, indent=4)
    if not mock:
        colors.out_print(f"Creating cm_{debug_var}entity indexes", indent=2)
        cur.execute(sql)
    return sql


def create_valid_joined(cur, mock=False):
    """
    Function that creates `valid_joined_entities`. This table is used to check the validity of an Entity by it's
    metadata:
    - Entities like type '3%' or '2%' MUST have an address to be considered valid
    - Entities where type is '101' MUST have either an email or phone associated to be considered valid
    :param cur:
    :param mock:
    :return:
    """
    sql = f""" 
        create temp table cm_{debug_var}entity_existing_addresses
        as
            select entity_id, street_address_1, city, state, country, postal_code, max(updated_at) as updated_at
            from cm_{debug_var}entity_address_xref
            where lower(CONCAT(street_address_1, city, state, country, postal_code)) not like '%unknown%'
                and updated_at is not null
            group by entity_id, street_address_1, city, state, country, postal_code;
        
        create temp table cm_{debug_var}entity_existing_emails
        as
            select entity_id, email_type_id, email_address, max(updated_at) as updated_at
            from cm_{debug_var}entity_email_xref
            where email_address is not null
                and updated_at is not null
            group by entity_id, email_type_id, email_address;
        
        create temp table cm_{debug_var}entity_existing_phones
        as
            select entity_id, phone_type_id, phone_number, max(updated_at) as updated_at
            from cm_{debug_var}entity_phone_xref
            where phone_number is not null
                and updated_at is not null
            group by entity_id, phone_type_id, phone_number;
        
        CREATE INDEX idx_cm_{debug_var}entity_existing_addresses_entity_id
        ON cm_{debug_var}entity_existing_addresses(entity_id);
        CREATE INDEX idx_cm_{debug_var}entity_existing_emails_entity_id
        ON cm_{debug_var}entity_existing_emails(entity_id);
        CREATE INDEX idx_cm_{debug_var}entity_existing_phones_entity_id
        ON cm_{debug_var}entity_existing_phones(entity_id);
        
        create table {debug_var}valid_joined_entities
        as
            select
                e.entity_id, 
                e.persistence_id, 
                e.parent_id, 
                e.entity_type_id, 
                e.crd, 
                e.salesforce_id, 
                (
                    SELECT MAX(ua)
                    FROM unnest(ARRAY[e.updated_at, xa.updated_at]) ua
                ) AS max_updated_at
            from cm_{debug_var}entity e
            join cm_{debug_var}entity_existing_addresses xa on xa.entity_id = e.entity_id
            where (e.entity_type_id like '3%')
              and e.ended_at is null
              and (
                (xa.country != 'US')
                OR
                  (
                    (
                      xa.country in (select country_iso from salesforce_address_enum)
                      and xa.state in (select state_iso from salesforce_address_enum)
                    )
                  OR (xa.country = 'US' and xa.street_address_1 is null and xa.city is null and xa.state is null and xa.postal_code is null)
                )
              )
            UNION
            select
                e.entity_id, 
                e.persistence_id, 
                e.parent_id, 
                e.entity_type_id, 
                e.crd, 
                e.salesforce_id, 
                (
                    SELECT MAX(ua)
                    FROM unnest(ARRAY[e.updated_at, xa.updated_at]) ua
                ) AS max_updated_at
            from cm_{debug_var}entity e
            join cm_{debug_var}entity_existing_addresses xa on xa.entity_id = e.entity_id
            where e.entity_type_id like '2%'
                and e.ended_at is null
                and ((xa.country != 'US')
                OR (
                    (xa.country in (select country_iso from salesforce_address_enum)   
                    and xa.state in (select state_iso from salesforce_address_enum))   
                  )
                )  
            UNION
            select 
                conts.entity_id, 
                conts.persistence_id, 
                conts.parent_id, 
                conts.entity_type_id, 
                conts.crd, 
                conts.salesforce_id, 
                max(conts.max_updated_at) as max_updated_at
            from (
                select  
                    e.entity_id, 
                    e.persistence_id, 
                    e.parent_id, 
                    e.entity_type_id, 
                    e.crd, 
                    e.salesforce_id, 
                    (
                        SELECT MAX(ua)
                        FROM unnest(ARRAY[e.updated_at, xe.updated_at]) ua
                    ) AS max_updated_at
                from cm_{debug_var}entity e
                join cm_{debug_var}entity_existing_emails xe on e.entity_id = xe.entity_id
                where e.entity_type_id = '101'
                    and e.ended_at is null
                UNION
                select
                    e.entity_id, 
                    e.persistence_id, 
                    e.parent_id, 
                    e.entity_type_id, 
                    e.crd, 
                    e.salesforce_id, 
                    (
                        SELECT MAX(ua)
                        FROM unnest(ARRAY[e.updated_at, xp.updated_at]) ua
                    ) AS max_updated_at
                from cm_{debug_var}entity e
                join cm_{debug_var}entity_existing_phones xp on e.entity_id = xp.entity_id
                where e.entity_type_id = '101'
                    and e.ended_at is null
            ) conts
            group by conts.entity_id, conts.persistence_id, conts.parent_id, conts.entity_type_id, conts.crd, conts.salesforce_id; 
    """
    if not mock:
        colors.out_print(f"Creating {debug_var}valid_joined_entities", indent=2)
        cur.execute(sql)
    return sql


def create_entity_linked_list(cur, mock=False):
    """
    Function that creates the `valid_entity_linked_list` table, which maintains parent/child FOP structure. In this
    table, the only time records fall out is if the parent is INVALID.
    - E.g.: consider a parent/child relationship  between an Office and a Contact. If the Office is not valid up to
    this point, the child Contact would fall out here, becoming invalid.
    :param cur:
    :param mock:
    :return:
    """
    sql = f""" 
        create table {debug_var}valid_entity_linked_list_m 
        as
          WITH recursive tree AS 
          ( 
                 SELECT {debug_var}valid_joined_entities.entity_id,
                        {debug_var}valid_joined_entities.parent_id,
                        {debug_var}valid_joined_entities.persistence_id,
                        {debug_var}valid_joined_entities.entity_type_id,
                        {debug_var}valid_joined_entities.crd,
                        {debug_var}valid_joined_entities.salesforce_id,
                        {debug_var}valid_joined_entities.max_updated_at,
                        array[{debug_var}valid_joined_entities.entity_id]      AS id_path,
                        array[{debug_var}valid_joined_entities.entity_type_id] AS type_path,
                        array[{debug_var}valid_joined_entities.persistence_id] AS persist_path,
                        array[{debug_var}valid_joined_entities.max_updated_at] AS max_ua_path 
                 FROM   {debug_var}valid_joined_entities 
                 WHERE  {debug_var}valid_joined_entities.parent_id is null
                 UNION ALL 
                 SELECT c.entity_id, 
                        c.parent_id,
                        c.persistence_id,
                        c.entity_type_id,
                        c.crd,
                        c.salesforce_id,
                        c.max_updated_at,
                        (t.id_path || c.entity_id), 
                        (t.type_path || c.entity_type_id),
                        (t.persist_path || c.persistence_id),
                        (t.max_ua_path || c.max_updated_at)
                 FROM   (tree t 
                 JOIN   {debug_var}valid_joined_entities c 
                 ON     (( c.parent_id = t.entity_id ))))
          SELECT  t.entity_id    AS entity_id,
                  t.persistence_id as persistence_id,
                  t.entity_type_id as entity_type_id,
                  t.crd as crd,
                  t.max_updated_at as max_updated_at,
                  t.id_path[1]   AS level_1,
                  t.type_path[1] AS type_1,
                  t.persist_path[1] AS persist_1,
                  t.max_ua_path[1] AS max_ua_1,
                  t.id_path[2]   AS level_2,
                  t.type_path[2] AS type_2,
                  t.persist_path[2] AS persist_2,
                  t.max_ua_path[2] AS max_ua_2,
                  t.id_path[3]   AS level_3,
                  t.type_path[3] AS type_3,
                  t.persist_path[3] AS persist_3,
                  t.max_ua_path[3] AS max_ua_3,
                  t.id_path[4]   AS level_4,
                  t.type_path[4] AS type_4,
                  t.persist_path[4] AS persist_4,
                  t.max_ua_path[4] AS max_ua_4,
                  t.id_path[5]   AS level_5,
                  t.type_path[5] AS type_5,
                  t.persist_path[5] AS persist_5,
                  t.max_ua_path[5] AS max_ua_5,
                  t.id_path[6]   AS level_6,
                  t.type_path[6] AS type_6,
                  t.persist_path[6] AS persist_6,
                  t.max_ua_path[6] AS max_ua_6,
                  t.id_path[7]   AS level_7,
                  t.type_path[7] AS type_7,
                  t.persist_path[7] AS persist_7,
                  t.max_ua_path[7] AS max_ua_7
          FROM   tree t;
    """
    if not mock:
        colors.out_print(f"Creating {debug_var}valid_entity_linked_list_m", indent=2)
        cur.execute(sql)
    return sql


def create_full_valid_entities(cur, mock=False):
    """
    Function that creates the `valid_entities_full` table; which is ALL entities considered valid (after metadata and
    relationship checks). This table will always be the total population of entities that are valid in the context of
    Salesforce.

    Note: Entity "House Accounts" and any entity with "Unknown" in it's name are considered invalid, and filtered out
    as a part of this table.
    :param cur:
    :param mock:
    :return:
    """
    sql = f""" 
            create table {debug_var}valid_entities_full
            as
                select s.hierarchy, s.entity_id, s.persistence_id, s.entity_type_id, s.max_updated_at
                from
                    (
                        SELECT DISTINCT unnest(array[generate_series(1,7)]) AS hierarchy,
                        unnest(array[level_1, level_2, level_3, level_4, level_5, level_6, level_7]) AS entity_id,
                        unnest(array[persist_1, persist_2, persist_3, persist_4, persist_5, persist_6, persist_7]) AS persistence_id,
                        unnest(array[type_1, type_2, type_3, type_4, type_5, type_6, type_7]) AS entity_type_id,
                        unnest(array[max_ua_1, max_ua_2, max_ua_3, max_ua_4, max_ua_5, max_ua_6, max_ua_7]) AS max_updated_at
                        FROM {debug_var}valid_entity_linked_list_m
                    ) s
                join cm_{debug_var}entity e on e.entity_id = s.entity_id
                where s.entity_id is not null
                    and (
                        e.entity_name is null or 
                            (
                                lower(entity_name) not like lower('%HOUSE ACCOUNT%')
                                    and lower(entity_name) not like lower('ACCOUNT|%')
                                    and lower(entity_name) not like lower('%|HOUSE|%')
                                    and lower(entity_name) not like lower('%UNKNOWN%')
                            )
                        )
                order by entity_type_id, parent_id, persistence_id;
    """
    if not mock:
        colors.out_print(f"Creating {debug_var}valid_entities_full", indent=2)
        cur.execute(sql)
    return sql


def create_final_valid_entities(cur, new_fop, delta, mock=False):
    """
    Function that generates the `valid_entities` table, which is functionally different from `valid_entities_full`.
    The "full" table contains all entities currently on a given data set that CM considers valid in the context of
    Salesforce. The non-full table is assumed to always be a "delta set"; whether that delta is by time, by controlled
    targeted entities (merge records, new to SF entities, etc), or otherwise.

    Note: this table is used exclusively by the CM API to send data to Salesforce. For data analysis, please use the
    `valid_entities_full` table for reliable analysis of validity.
    :param cur:
    :param new_fop:
    :param delta:
    :param mock:
    :return:
    """
    log = f"Creating final {debug_var}valid_entities view"
    if delta:
        log = log + ' using delta param'
    if new_fop:
        log = log + ' & new FOP'

    sql = f"""
        create table {debug_var}valid_entities
        as
            select ve.hierarchy, ve.entity_id, ve.persistence_id, ve.entity_type_id, ve.max_updated_at
            from valid_entities_full ve
            join cm_{debug_var}entity e on e.entity_id = ve.entity_id
            where e.salesforce_id is not null;
    """
    if delta:
        sql = sql + ' and ve.max_updated_at::timestamp >= get_last_job_ts(\'sf_entity_api\')'
    if new_fop:
        sql = sql.replace('e.salesforce_id is not null', 'e.salesforce_id is null')
    sqls = ''
    if not mock:
        colors.sql_print(sql, indent=4)
        colors.out_print(log, indent=2)
        cur.execute(sql)
    sqls += '\n' + sql

    sql = f"""
        CREATE INDEX idx_{debug_var}valid_entities_entity_id ON {debug_var}valid_entities(entity_id);
        CREATE INDEX idx_{debug_var}valid_entities_full_entity_id ON {debug_var}valid_entities_full(entity_id);
    """
    if not mock:
        colors.sql_print(sql, indent=4)
        cur.execute(sql)
    sqls += '\n' + sql
    return sqls


def create_valid_teams(cur, mock=False):
    """
    Function that creates the `valid_teams` tables, which is a table that checks the valiidty of team members on a given
    team.
    :param cur:
    :param mock:
    :return:
    """
    sql = f""" 
        create table valid_teams
        as
            SELECT * FROM
            (
                SELECT team_entity_id, array_agg(distinct(per.persistence_id)) valid_persons
                FROM cm_entity_team_xref team_xref
                LEFT JOIN 
                (
                    SELECT p.persistence_id, p.crd FROM cm_entity p
                    JOIN valid_entities valid_per
                        ON p.persistence_id = valid_per.persistence_id
                ) per 
                    ON team_xref.entity_crd = per.crd
                GROUP BY team_entity_id
             ) s
          WHERE
            NOT (TRUE = ANY (SELECT unnest(valid_persons) IS NULL));
    """
    if not mock:
        colors.out_print(f"Creating {debug_var}valid_teams", indent=2)
        cur.execute(sql)
    return sql


def mirror_valid_views(cur, active_stage, mock=False):
    """
    Function to mirror the current set of valid views (freshly generated). These are used for backups/analysis.
    :param cur:
    :param active_stage:
    :param mock:
    :return:
    """
    sql = f"""
        drop table if exists sf_{active_stage}_valid_entities_full;
        drop table if exists sf_{active_stage}_valid_entities;
        drop table if exists sf_{active_stage}_valid_teams;
        
        create table sf_{active_stage}_valid_entities_full as select * from valid_entities_full;
        create table sf_{active_stage}_valid_entities as select * from valid_entities;
        CREATE INDEX idx_sf_{active_stage}_valid_entities_entity_id ON sf_{active_stage}_valid_entities(entity_id);
        create table sf_{active_stage}_valid_teams as select * from valid_teams;
    """
    if not mock:
        colors.out_print(f'mirroring current valid view set as sf_{active_stage}_valid_*', indent=2)
        cur.execute(sql)
    return sql


def sf_api_entity_export_v(prefix, active_stage, new_fop=None, delta=None):
    colors.out_print(f"Running sf_api_export_v", indent=1)
    if debug_var != "":
        colors.bug_print(f"Using debug_var: {debug_var}", indent=2)

    with CursorFromConnectionPool() as cur:
        colors.out_print(f"Building from {prefix}_*", indent=1)
        create_delta_function(cur)
        drop_previous_tables(cur)
        build_cm_entity(cur, prefix)
        create_entity_indexes(cur)
        create_valid_joined(cur)
        create_entity_linked_list(cur)
        create_full_valid_entities(cur)
        create_final_valid_entities(cur, new_fop, delta)
        create_valid_teams(cur)
        mirror_valid_views(cur, active_stage)
        update_params_by_job(cur, job_type='sf_entity_api', timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))


def print_sf_api_entity_query(prefix, active_stage, new_fop=None, delta=None):
    with CursorFromConnectionPool() as cur:
        colors.out_print(f"Building from {prefix}_*", indent=1)
        query = ''
        query += '\n' + create_delta_function(cur, mock=True)
        query += '\n' + drop_previous_tables(cur, mock=True)
        query += '\n' + build_cm_entity(cur, prefix, mock=True)
        query += '\n' + create_entity_indexes(cur, mock=True)
        query += '\n' + create_valid_joined(cur, mock=True)
        query += '\n' + create_entity_linked_list(cur, mock=True)
        query += '\n' + create_full_valid_entities(cur, mock=True)
        query += '\n' + create_final_valid_entities(cur, new_fop, delta, mock=True)
        query += '\n' + create_valid_teams(cur, mock=True)
        query += '\n' + mirror_valid_views(cur, active_stage, mock=True)
        print(query)
