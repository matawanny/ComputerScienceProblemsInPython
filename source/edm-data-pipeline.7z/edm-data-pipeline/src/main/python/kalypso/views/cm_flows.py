from cm_commons import colors
from cm_commons import colors
from cm_commons.db.postgregsql_pool import *


debug_var = ""


def create_cm_flows(cur):
    colors.out_print(f"Creating {debug_var}cm_flows", indent=2)
    sql = f"""
    create materialized view cm_flows
    as
        select t.trade_id, t.agreement_id, tce.flow_type, sum(t.amount::float) as net, t.currency_id, t.start_date, t.end_date
        from cm_agreement a
        join cm_trade t on t.agreement_id = a.agreement_id
        join trade_code_enum tce on tce.aggregator_trade_code = t.aggregator_trade_code
        where tce.aggregator_id = t.aggregator_id
        group by t.trade_id, t.agreement_id, tce.flow_type, t.amount, t.currency_id, t.start_date, t.end_date;
    """
    cur.execute(sql)


def cm_flows(prefix, active_stage):
    colors.out_print(f"Running cm_flows", indent=1)
    if debug_var != "":
        colors.bug_print(f"Using debug_var: {debug_var}", indent=2)

    colors.out_print("cm_flows", indent=1)
    with CursorFromConnectionPool() as cur:
        create_cm_flows(cur)
