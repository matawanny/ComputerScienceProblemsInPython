from cm_commons.models.sqlalchemy import SVExportFir, SVExportOfl, SVExportPer, Base
from cm_commons.db.cm_conn import create_cm_conn
from kalypso.procedures.sqlalchemy import drop_table, create_table

from cm_commons import colors


def blank_sv_fop_export_v():
    engine, session = create_cm_conn()
    Base.metadata.bind = engine
    tables = ["sv_export_fir",
              "sv_export_ofl",
              "sv_export_per",
              "sv_export_mrg"]

    colors.out_print(f"Dropping tables {tables}", indent=1)
    drop_table(engine=engine, base=Base, table_names=tables)
    colors.out_print(f"Creating tables {tables}", indent=1)
    create_table(engine=engine, base=Base, table_names=tables)

