from datetime import datetime

from cm_commons import colors
from cm_commons.db.cm_conn import cm_cxn
from cm_commons.db.postgregsql_pool import *
from cm_commons.util.sql_functions import psql_table_exists, update_params_by_job

debug_var = ''


def create_delta_function(cur):
    """
    Create/replace SQL function that is used to grab the timestamp of the last run Agreement DBSync job.
    This function is used in delta calculations in the `valid_agreements`/`valid_subagreements` table.
    :param cur:
    :return:
    """
    colors.out_print('create/replace delta function', indent=1)
    sql = """
    CREATE OR REPLACE FUNCTION get_last_job_ts(trg_key text) RETURNS timestamp AS $$
        SELECT TO_TIMESTAMP(value1, 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone
        FROM edm_params
        WHERE key = trg_key
    $$ LANGUAGE SQL;
    """
    cur.execute(sql)


def build_blank_table(cur, tbl_name, fields):
    """
    Helper function designed to build a blank table (if necessary)
    :param cur:
    :param tbl_name:
    :param fields:
    :param mock:
    :return:
    """
    fields_list = ",\n".join([f"{k} {v}" for k, v in fields.items()])
    sql = f"""
        create table {tbl_name} ({fields_list});
    """
    cur.execute(sql)


def drop_previous_tables(cur):
    """
    Function used to drop all previous DBSync tables, looping throw two lists: one for `cm_*` prefixed tables,
    and one for `valid_*` prefixed tables
    :param cur:
    :param mock:
    """
    colors.out_print(f"Dropping cm_{debug_var}* tables", indent=2)
    cm_tables = ['cm_agreement', 'cm_agreement_entity_xref', 'cm_aum', 'cm_max_aum', 'cm_trade',
                 'cm_sales_owner_agreement_xref', 'cm_flows', 'cm_trades_direction']
    lob_tables = ['sv_lob', 'amg_lob', 'au_lob', 'ft_lob', 'aup_lob', 'valid_lob']
    valid_tables = ['valid_employees', 'valid_agreement_pmf_xref', 'valid_agreements_full', 'valid_agreements',
                    'valid_sub_agreements_full', 'valid_sub_agreements', 'valid_flows']
    for tbl in cm_tables + lob_tables + valid_tables:
        sql = f'drop table if exists {debug_var}{tbl} cascade;'
        cur.execute(sql)


def build_cm_agreement(cur, prefix):
    """
    Function that copies post-MDM tables into the `cm_*` prefixed tables to avoid creating unnecessary locks on
    MDM target tables. These `cm_*` tables are used for the CM API to send data to Salesforce (after building a valid
    set of agreements to send).

    Note: this function explicitly picks the columns it needs between agreement/subagreement.
    :param cur:
    :param prefix:
    :param mock:
    :return:
    """
    colors.out_print(f"Building cm_{debug_var}* tables", indent=2)
    from cm_commons.models.trg_files.target_models import SF_API_AGREEMENT
    schema = SF_API_AGREEMENT

    for tbl, val in schema.items():
        sql = """"""
        colors.out_print(f"Processing {tbl}", indent=3)

        src = f"{prefix}_{tbl}"

        # special case for agreement, skip sub
        if tbl == 'sub_agreement':
            continue
        if tbl == 'agreement':
            agr_tbl = f'{prefix}_agreement'
            sub_agr_tbl = f'{prefix}_sub_agreement'

            # create two separate queries for agreement/subagreement
            agr_sql = f"""select '1' as agreement_type, agreement_id, agreement_name, account_number, channel_id, money_type_id, firm_type_id, benchmark_id, ta_number, external_identifier, external_identifier_type, erisa_plan, preferred_currency_id, unit_holder_code, ipo_flag, ocio_flag, inception_date, ended_at, origin_id, aggregator_id, created_at, updated_at, etl_source, enriched_at, error, nullability_error, typecast_error, 'None' as parent_agreement_id, external_agreement_id  
                    from {prefix}_agreement"""
            sub_agr_sql = f"""select '2' as agreement_type, agreement_id, agreement_name, account_number, channel_id, money_type_id, null as firm_type_id, benchmark_id, ta_number, external_identifier, external_identifier_type, erisa_plan, preferred_currency_id, unit_holder_code, ipo_flag, ocio_flag, inception_date, ended_at, origin_id, aggregator_id, created_at, updated_at, etl_source, enriched_at, error, nullability_error, typecast_error, parent_agreement_id, external_agreement_id
                    from {prefix}_sub_agreement"""

            # combine above queries based on what tables are present
            if psql_table_exists(cm_cxn, agr_tbl) and not psql_table_exists(cm_cxn, sub_agr_tbl):
                final_agr_sql = f"""
                create table cm_agreement
                as 
                    {agr_sql}
                """
            elif psql_table_exists(cm_cxn, sub_agr_tbl) and not psql_table_exists(cm_cxn, agr_tbl):
                final_agr_sql = f"""
                create table cm_agreement
                as 
                    {sub_agr_sql}
                """
            else:
                final_agr_sql = f"""
                create table cm_agreement 
                as 
                    ({agr_sql})
                    UNION
                    ({sub_agr_sql})
                """
            colors.sql_print(f"{final_agr_sql};", indent=4)
            cur.execute(final_agr_sql + ';')
            continue

        trg = f"cm_{debug_var}{tbl}"
        if psql_table_exists(cm_cxn, src):
            sql = f"create table {trg}  as select * from {src};"
            colors.sql_print(sql, indent=4)
            cur.execute(sql)
        else:
            colors.war_print(f"{src} does not exist, building blank {trg} using schema", indent=4)
            build_blank_table(cur=cur, tbl_name=trg, fields={fld: 'varchar(255)' for fld in val['fields']})


def create_valid_employees(cur):
    """
    Function that builds the `valid_employees` table. This is used downstream in this job to validate sales ownership.
    :param cur:
    :return:
    """
    sql = f"""
        create table valid_employees
        as
          SELECT DISTINCT ent.employee_id,  empl_xref.employee_type, 
                          empl_xref.sales_owner_id, empl_xref.sales_owner_id_type
          FROM cm_entity ent
          LEFT JOIN 
              ( 
                  SELECT sap_employee_id as employee_id, sap_type as employee_type,
                         sap_employee_id as sales_owner_id, 'sv' as sales_owner_id_type
                  FROM cm_{debug_var}sv_sales_person svp
              ) empl_xref
          ON empl_xref.employee_id = ent.employee_id
          UNION
          SELECT DISTINCT ent.employee_id, empl_xref.employee_type, 
                          empl_xref.sales_owner_id, empl_xref.sales_owner_id_type
          FROM cm_entity ent
          LEFT JOIN
              ( 
                  SELECT sales_owner_id as employee_id, 'amg' as employee_type,
                         sales_owner_id, sales_owner_id_type
                  FROM cm_{debug_var}sales_owner_agreement_xref soa
                  where sales_owner_id_type = 'clnt_svc_rep_employee_id'
              ) empl_xref
          ON empl_xref.employee_id = ent.employee_id;
    """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)


def create_agreement_indexes(cur):
    """
    Function to create indexes on `cm_*` tables for performance
    :param cur:
    :param mock:
    :return:
    """
    colors.out_print(f"Creating {debug_var}agreement_indexes", indent=2)
    sql = f""" 
        CREATE INDEX idx_cm_{debug_var}aum_as_of_date ON cm_{debug_var}aum(as_of_date);
        CREATE INDEX idx_cm_{debug_var}aum_agreement_id ON cm_{debug_var}aum(agreement_id);
        CREATE INDEX idx_cm_{debug_var}trade_end_date ON cm_{debug_var}trade(end_date);
        CREATE INDEX idx_cm_{debug_var}trade_agreement_id ON cm_{debug_var}trade(agreement_id);
        CREATE INDEX idx_cm_{debug_var}agreement_entity_xref_agreement_id ON cm_{debug_var}agreement_entity_xref(agreement_id);
        CREATE INDEX idx_cm_{debug_var}sales_owner_xref_agreement_id ON cm_{debug_var}sales_owner_agreement_xref(agreement_id);
    """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)


def create_max_aum(cur):
    """
    Function that creates the `cm_max_aum` table, which maintains an agreement's latest AUM. This helper table is used
    to avoid querying the large post-MDM AUM table multiple times.
    :param cur:
    :return:
    """
    colors.out_print(f"creating cm_{debug_var}max_aum", indent=2)
    sql = f"""
        CREATE INDEX idx_composite_cm{debug_var}_max_aum ON cm_{debug_var}aum (agreement_id, as_of_date DESC);
    """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)

    sql = f"""
        create table cm_{debug_var}max_aum
        as
            select distinct 
                a1.agreement_id, 
                a1.aum_id, 
                a2.as_of_date, 
                a1.amount as raw_amount,
                CAST(amount::numeric * fx_rate::numeric as varchar) as usd_amount,
                a1.updated_at, 
                curr.currency_iso3_code
            from cm_{debug_var}aum a1
            join (
                select agreement_id, max(as_of_date) as as_of_date, max(updated_at) as max_updated_at
                from cm_{debug_var}aum
                group by agreement_id
            ) a2 on a1.agreement_id = a2.agreement_id 
                and a1.as_of_date = a2.as_of_date
                and a1.updated_at = a2.max_updated_at
            join currency_enum curr on curr.currency_id = a1.currency_id
            join fx_rate_conversion fx on curr.currency_iso3_code = fx.current_symbol 
                    and fx.rate_date = a2.as_of_date
            where fx.target_symbol = 'USD'
    """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)

    # add index to new table to make joins faster
    sql = f"""
        CREATE INDEX idx_agreement_id_cm{debug_var}_max_aum on cm_max_aum(agreement_id);
    """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)


def create_valid_agreement_pmf_xref(cur):
    """
    Function that creates the `valid_agreement_pmf_xref` table, which is used to link agreements and their products
    at Lazard.
    :param cur:
    :return:
    """
    colors.out_print(f"Creating {debug_var}valid_agreement_pmf_xref", indent=2)
    sql = f""" 
        create table valid_agreement_pmf_xref 
        as
            select agr.agreement_id, agr.external_identifier, agr.external_identifier_type, sc.product_id as pmf_symbol, sc.product_name as fund_name, sc.share_class_id, sc.share_class_name, sc.sub_strategy_id, sc.vehicle_type_id
            from cm_agreement agr
            join share_class_enum sc 
                on UPPER(agr.external_identifier) = sc.cusip
            WHERE agr.external_identifier_type = 'cusip'
            UNION
            -- match on isin
            select agr.agreement_id, agr.external_identifier, agr.external_identifier_type, sc.product_id as pmf_symbol, sc.product_name as fund_name, sc.share_class_id, sc.share_class_name, sc.sub_strategy_id, sc.vehicle_type_id
            from cm_agreement agr
            join share_class_enum sc
                on agr.external_identifier = sc.isin
            WHERE agr.external_identifier_type = 'isin'
            UNION
            -- SA but Not SV: match on pmf id (product_id in SC ENUM) and source!=SV
            select agr.agreement_id, agr.external_identifier, agr.external_identifier_type, sc.product_id as pmf_symbol, sc.product_name as fund_name, sc.share_class_id, sc.share_class_name, sc.sub_strategy_id, sc.vehicle_type_id
            from cm_agreement agr
            join share_class_enum sc 
                ON agr.external_identifier = CAST(sc.sub_strategy_id as TEXT)
            WHERE agr.external_identifier_type = 'product_id'
                AND sc.vehicle_type_id = '1'
                AND (share_class_name = '' OR share_class_name IS NULL)
                AND share_class_id != '551'
                AND agr.aggregator_id != '1'
            UNION
            -- SV and SMA-Only: match on pmf id (product_id in SC ENUM) and share_class_name=SMA and source SV
            select agr.agreement_id, agr.external_identifier, agr.external_identifier_type, sc.product_id as pmf_symbol, sc.product_name as fund_name, sc.share_class_id, sc.share_class_name, sc.sub_strategy_id, sc.vehicle_type_id
            from cm_agreement agr
            join share_class_enum sc 
                ON agr.external_identifier = CAST(sc.sub_strategy_id as TEXT)
            join map_origin_fundtype mof
                ON mof.origin_id = agr.origin_id and mof.fund_type = 'SMA'
            WHERE agr.aggregator_id = '1' 
                AND agr.external_identifier_type = 'product_id' 
                AND sc.vehicle_type_id = '1' 
                AND share_class_name = 'SMA'
            UNION
            -- match on share class name 
            select agr.agreement_id, agr.external_identifier, agr.external_identifier_type, sc.product_id as pmf_symbol, sc.product_name as fund_name, sc.share_class_id, sc.share_class_name, sc.sub_strategy_id, sc.vehicle_type_id
            from cm_agreement agr
            join share_class_enum sc
                ON agr.external_identifier = sc.share_class_name
            WHERE agr.external_identifier_type = 'share_class_id'
            UNION
            -- match on APIR code
            select agr.agreement_id, agr.external_identifier, agr.external_identifier_type, sc.product_id as pmf_symbol, sc.product_name as fund_name, sc.share_class_id, sc.share_class_name, sc.sub_strategy_id, sc.vehicle_type_id
            from cm_agreement agr
            join share_class_enum sc
                ON agr.external_identifier = sc.apir_code
            WHERE agr.external_identifier_type = 'apir_code' 
                OR agr.external_identifier_type = 'apir'
    """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)

    sql = f"""
        CREATE INDEX idx_valid_agreement_pmf_xref_agreement_id ON valid_agreement_pmf_xref(agreement_id);
    """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)


def create_valid_lob(cur):
    """
    Function that creates the `valid_lob` table, which links agreement with their "Line of Business"
    :param cur:
    :return:
    """
    colors.out_print(f"Creating {debug_var}valid_lob", indent=2)
    colors.out_print('creating temp tables for Valid LOB', indent=3)
    sql = f""" 
            CREATE TEMP TABLE sv_lob
            AS
            SELECT
                svp.ssh_sah_id      as sales_owner_id,
                'aaa_sah_id'::text  as sales_owner_id_type,
                -- EDM-2257
                CASE
                  WHEN svp.sap_employee_id IS NOT NULL THEN svp.sap_employee_id
                  WHEN svh.shd_territory = 'FIG House' THEN 'FIG_HOUSE'
                  WHEN svh.shd_territory = 'RIS House' THEN 'RIS_HOUSE'
                  ELSE NULL
                --  WHEN svp.ssh_sah_id = '1078' THEN 'FIG_House'
                --  WHEN svp.ssh_sah_id = '1018' THEN NULL
                -- WHEN svp.ssh_sah_id = '1902' THEN NULL
                --  WHEN svp.ssh_sah_id = '1258' THEN NULL
                END as employee_id,
                -- svp.sap_employee_id as employee_id,
                svp.sap_type        as employee_type,
                svh.shd_lob         as line_of_business,
                svh.shd_channel     as channel_id,
                svh.shd_region      as region_name,
                svh.shd_territory   as territory_name
            FROM cm_sv_sales_person svp
            JOIN cm_sv_sales_hierarchy svh ON svh.shd_sah_id = svp.ssh_sah_id
            WHERE LOWER(svh.shd_channel) not in (
                '10',  -- house in cm_enrichment db, sv_channel_id table 
                '102', -- unassigned in cm_enrichment db, sv_channel_id table
                '14')  -- omnibus in cm_enrichment db, sv_channel_id table
                AND LOWER( svh.shd_territory) not in ('cag house');

            CREATE TEMP TABLE amg_lob 
            AS
                SELECT 
                    sales_owner_id, 
                    'clnt_svc_rep_employee_id'::text AS sales_owner_id_type,
                    sales_owner_id  AS employee_id, 
                    NULL::text      AS employee_type,
                    NULL::text      AS line_of_business, 
                    NULL::text      AS channel_name,
                    NULL::text      AS region_name,  
                    NULL::text      AS territory_name
                FROM cm_sales_owner_agreement_xref
                WHERE cm_sales_owner_agreement_xref.sales_owner_id_type = 'clnt_svc_rep_employee_id';

            CREATE TEMP TABLE au_lob
            AS
                SELECT 
                    sales_owner_id, 
                    'au_sales_rep_id'::text AS sales_owner_id_type,
                    '903170'        AS employee_id, 
                    'Internal'      AS employee_type,
                    NULL::text      AS line_of_business, 
                    NULL::text      AS channel_name,
                    NULL::text      AS region_name, 
                    NULL::text      AS territory_name
                FROM cm_sales_owner_agreement_xref 
                WHERE cm_sales_owner_agreement_xref.sales_owner_id_type = 'au_sales_rep_id'::text;

            CREATE TEMP TABLE ft_lob
            AS
                SELECT 
                    sales_owner_id, 
                    'fishtank'::text   AS sales_owner_id_type,
                    sales_owner_id     AS employee_id, 
                    'Internal'         AS employee_type,
                    NULL::text         AS line_of_business, 
                    NULL::text         AS channel_name,
                    NULL::text         AS region_name, 
                    NULL::text         AS territory_name
                FROM cm_sales_owner_agreement_xref
                WHERE cm_sales_owner_agreement_xref.sales_owner_id_type = 'fishtank'::text;

            CREATE TEMP TABLE aup_lob
            AS 
                SELECT 
                    sales_owner_id, 
                    sales_owner_id_type AS sales_owner_id_type,
                    sales_owner_id      AS employee_id, 
                    'Internal'          AS employee_type,
                    NULL::text          AS line_of_business, 
                    NULL::text          AS channel_name,
                    NULL::text          AS region_name, 
                    NULL::text          AS territory_name
                FROM cm_sales_owner_agreement_xref
                WHERE cm_sales_owner_agreement_xref.sales_owner_id_type = 'au_platform_sales_rep_id'::text;
    """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)

    colors.out_print('building master Valid LOB', indent=3)
    sql = f"""
            CREATE table valid_lob
            AS
                SELECT 
                    soa.agreement_id, car.sales_owner_id,
                    car.sales_owner_id_type, car.employee_id,
                    car.employee_type,
                    COALESCE(car.channel_id, agr.channel_id) as channel_id,
                    chan.sf_channel_id as sf_channel_id,
                    car.region_name, car.territory_name 
                FROM (
                    SELECT * FROM sv_lob
                    UNION
                    SELECT * FROM amg_lob
                    UNION
                    SELECT * FROM au_lob
                    UNION
                    SELECT * FROM ft_lob
                    UNION
                    SELECT * FROM aup_lob  
                ) car
                JOIN cm_sales_owner_agreement_xref soa
                    ON (soa.sales_owner_id = car.sales_owner_id) AND (soa.sales_owner_id_type = car.sales_owner_id_type)
                JOIN (SELECT distinct(employee_id) FROM cm_entity
                        UNION 
                      SELECT * FROM (VALUES ('FIG_HOUSE'), ('RIS_HOUSE')) AS t (employee_id)
                      ) ent ON lower(car.employee_id) = lower(ent.employee_id)
                JOIN cm_agreement agr ON agr.agreement_id = soa.agreement_id
                JOIN channel_enum chan ON chan.channel_id = COALESCE(car.channel_id, agr.channel_id);
    """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)


def create_full_valid_agreements(cur):
    """
    Function that creates `valid_agreements_full`, which is the total set of all valid agreements.
    :param cur:
    :return:
    """
    colors.out_print(f"Creating {debug_var}valid_agreements_full", indent=2)
    sql = f"""
        create table valid_agreements_full
        as
            select distinct 
                agr.agreement_id, 
                agr.aggregator_id, 
                aum_id, 
                as_of_date, 
                raw_amount,
                usd_amount,
                currency_iso3_code, 
                ve.persistence_id,
                (SELECT MAX(ua)
                 FROM unnest(ARRAY[agr.updated_at, 
                                   aum.updated_at]) 
                                   ua) AS max_updated_at
            from cm_{debug_var}agreement agr
            join cm_{debug_var}agreement_entity_xref agrent_o on agrent_o.agreement_id = agr.agreement_id
            join valid_entities_full ve on ve.entity_id = agrent_o.entity_id
            join cm_{debug_var}entity e on e.entity_id = ve.entity_id
            join cm_{debug_var}max_aum aum on aum.agreement_id = agr.agreement_id
            join valid_lob lob on lob.agreement_id = agr.agreement_id
            join valid_agreement_pmf_xref pmf on pmf.agreement_id = agr.agreement_id
            where (agrent_o.relationship_type_id = '100' and ve.entity_type_id != '101') 
              and agr.agreement_type = '1'
              and ((lob.channel_id != '14' and agr.origin_id = '200') or agr.origin_id != '200' or agr.origin_id is null) 
              and (agr.channel_id != '6' and agr.channel_id != '10')
              and e.salesforce_id is not null
            order by ve.persistence_id desc;
    """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)


def create_final_valid_agreements(cur, delta):
    """
    Function that creates the `valid_agreements` table, which is always assumed to be a delta table.
    :param cur:
    :param delta:
    :return:
    """
    log = f'creating final {debug_var}valid_agreements'
    if delta:
        log = log + ' using delta param'
    colors.out_print(log, indent=2)

    sql = f"""
        create table valid_agreements
        as
            select *
            from valid_agreements_full
    """
    if delta:
        sql = sql + """
            where max_updated_at::timestamp >= get_last_job_ts('sf_agreement_api')
        """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)

    sql = f"""
        CREATE INDEX idx_{debug_var}valid_agreements_agreement_id ON {debug_var}valid_agreements(agreement_id);
    """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)


def create_full_valid_sub_agreements(cur):
    """
        Function that creates `valid_sub_agreements_full`, which is the total set of all valid sub agreements.
        :param cur:
        :return:
        """
    colors.out_print(f"Creating {debug_var}valid_sub_agreements_full", indent=2)
    sql = f""" 
        create table valid_sub_agreements_full
        as
            select distinct 
                agr.agreement_id, 
                agr.aggregator_id, 
                aum_id, 
                as_of_date, 
                raw_amount,
                usd_amount,
                currency_iso3_code, 
                ve.persistence_id,
                (SELECT MAX(ua)
                 FROM unnest(ARRAY[agr.updated_at, 
                                   aum.updated_at]) 
                                   ua) AS max_updated_at
            from cm{debug_var}_agreement agr
            join cm{debug_var}_agreement_entity_xref agrent_o on agrent_o.agreement_id = agr.agreement_id
            join valid_entities_full ve on ve.entity_id = agrent_o.entity_id
            join cm{debug_var}_entity e on e.entity_id = ve.entity_id
            join cm{debug_var}_max_aum aum on aum.agreement_id = agr.agreement_id
            join valid_lob lob on lob.agreement_id = agr.agreement_id
            join valid_agreement_pmf_xref pmf on pmf.agreement_id = agr.agreement_id
            where (agrent_o.relationship_type_id = '100' and ve.entity_type_id != '101') 
                and agr.agreement_type = '2' 
                and (agr.channel_id != '6' and agr.channel_id != '10')
                and e.salesforce_id is not null
            order by ve.persistence_id desc
    """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)


def create_final_valid_sub_agreements(cur, delta):
    """
    Function that creates the `valid_agreements` table, which is always assumed to be a delta table.
    :param cur:
    :param delta:
    :return:
    """
    log = f'creating final {debug_var}valid_sub_agreements'
    if delta:
        log = log + ' using delta param'
    colors.out_print(log, indent=2)

    sql = f"""
        create table valid_sub_agreements
        as
            select *
            from valid_sub_agreements_full
    """
    if delta:
        sql = sql + """
            where max_updated_at::timestamp >= get_last_job_ts('sf_agreement_api')
        """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)

    sql = f"""
        CREATE INDEX idx_{debug_var}valid_sub_agreements_agreement_id ON {debug_var}valid_sub_agreements(agreement_id);
    """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)


def create_cm_flows(cur):
    """
    Function that creates two tables for valid Flow calculations.
    1. `cm_trades_direction`: this is a joined table between trades and Trade Code ENUM to determine if a given flow is
    an in/out flow.
    2. `cm_flows`: using the data in `cm_trades_direction`, `cm_flows` adds an FX Rate conversion into "USD"
    :param cur:
    :return:
    """
    colors.out_print(f'creating cm_{debug_var}flows', indent=2)
    sql = f"""
        create table cm_{debug_var}trades_direction
        as
            select
                md5(ROW(agreement_id, end_date, flow_type)::varchar) as flow_id,
                t.agreement_id,
                t.flow_type,
                sum(t.amount) as amount,
                t.currency_id,
                t.currency_iso3_code,
                t.start_date,
                t.end_date,
                min(t.created_at) as created_at,
                max(t.updated_at) as updated_at,
                t.aggregator_id,
                array_agg(t.trade_id) as original_trade_ids
            from (
                select
                    d.agreement_id,
                    (amount::numeric * direction::numeric) as amount,
                    tce.flow_type,
                    d.created_at,
                    d.updated_at,
                    d.start_date,
                    d.end_date,
                    d.currency_id,
                    curr.currency_iso3_code,
                    d.aggregator_id,
                    d.trade_id
                from cm_{debug_var}trade d
                join trade_code_enum tce on tce.aggregator_trade_code = d.aggregator_trade_code 
                    and tce.aggregator_id = d.aggregator_id
                join currency_enum curr on curr.currency_id = d.currency_id
            ) t
            group by
                t.start_date,
                t.end_date,
                t.agreement_id, 
                t.flow_type,
                t.currency_id,
                t.aggregator_id,
                t.currency_iso3_code
        ;

        create table cm_flows
        as
            select 
                t.flow_id, 
                t.flow_type, 
                t.agreement_id, 
                t.amount::varchar, 
                fx.fx_rate, 
                CAST(amount::numeric * fx_rate::numeric as varchar) as usd_amount,
                t.currency_id, 
                t.start_date, 
                t.end_date,
                t.created_at,
                t.updated_at,
                t.aggregator_id,
                t.original_trade_ids
            from cm_trades_direction t
            join fx_rate_conversion fx on t.currency_iso3_code = fx.current_symbol 
                and (t.end_date = fx.rate_date or t.end_date = fx.end_date)
            where currency_iso3_code != 'USD'
                and amount != 0
            UNION
            select 
                t.flow_id, 
                t.flow_type, 
                t.agreement_id, 
                t.amount::varchar, 
                '1' as fx_rate,
                amount::varchar as usd_amount,
                t.currency_id, 
                t.start_date, 
                t.end_date,
                t.created_at,
                t.updated_at,
                t.aggregator_id,
                t.original_trade_ids
            from cm_trades_direction t
            where currency_iso3_code = 'USD'
                and amount != 0
        ;
    """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)


def create_valid_flows(cur):
    """
    Function that generates the total set of "valid flows"
    :param cur:
    :return:
    """
    colors.out_print(f'creating valid_flows')
    sql = f"""
        create table valid_flows
        as
            select     
                e.salesforce_id,
                e.entity_id,
                f.agreement_id,
                md5(ROW(f.flow_id, e.salesforce_id)::varchar) as flow_id,
                f.flow_type,
                f.amount,
                f.usd_amount,
                f.currency_id,
                a.external_identifier,
                a.external_identifier_type,
                pmf.vehicle_type_id,
                f.start_date,
                f.end_date,
                f.created_at,
                f.updated_at,
                f.aggregator_id,
                f.original_trade_ids
            from cm_{debug_var}flows f
            join valid_agreements va on va.agreement_id = f.agreement_id
            join cm_{debug_var}agreement a on a.agreement_id = va.agreement_id
            join cm_{debug_var}agreement_entity_xref x on x.agreement_id = f.agreement_id
            join valid_entities ve on ve.entity_id = x.entity_id
            join cm_{debug_var}entity e on e.entity_id = ve.entity_id
            join valid_agreement_pmf_xref pmf on pmf.agreement_id = f.agreement_id
            where e.salesforce_id is not null
                and (x.relationship_type_id = '100' and e.entity_type_id != '101')
    """
    if psql_table_exists(cm_cxn, 'valid_sub_agreements'):
        sql = sql + f"""
            UNION
            select     
                e.salesforce_id,
                e.entity_id,
                f.agreement_id,
                md5(ROW(f.flow_id, e.salesforce_id)::varchar) as flow_id,
                f.flow_type,
                f.amount,
                f.usd_amount,
                f.currency_id,
                a.external_identifier,
                a.external_identifier_type,
                pmf.vehicle_type_id,
                f.start_date,
                f.end_date,
                f.created_at,
                f.updated_at,
                f.aggregator_id,
                f.original_trade_ids
            from cm_flows f
            join valid_sub_agreements va on va.agreement_id = f.agreement_id
            join cm_agreement a on a.agreement_id = va.agreement_id
            join cm_agreement_entity_xref x on x.agreement_id = f.agreement_id
            join valid_entities ve on ve.entity_id = x.entity_id
            join cm_entity e on e.entity_id = ve.entity_id
            join valid_agreement_pmf_xref pmf on pmf.agreement_id = f.agreement_id
            where e.salesforce_id is not null
                and (x.relationship_type_id = '100' and e.entity_type_id != '101')
        """
    colors.sql_print(sql + ';', indent=4)
    cur.execute(sql)


def mirror_valid_views(cur, active_stage):
    colors.out_print(f'mirroring current valid view set as sf_{active_stage}_valid_*', indent=2)
    sql = f"""
        drop table if exists sf_{active_stage}_valid_lob;
        drop table if exists sf_{active_stage}_valid_agreement_pmf_xref;
        drop table if exists sf_{active_stage}_valid_agreements;
        drop table if exists sf_{active_stage}_valid_sub_agreements;
        drop table if exists sf_{active_stage}_valid_flows;

        create table sf_{active_stage}_valid_lob as select * from valid_lob;
        create table sf_{active_stage}_valid_agreement_pmf_xref as select * from valid_agreement_pmf_xref;
        create table sf_{active_stage}_valid_agreements as select * from valid_agreements;
        create table sf_{active_stage}_valid_sub_agreements as select * from valid_sub_agreements;
        create table sf_{active_stage}_valid_flows as select * from valid_flows;
    """
    colors.sql_print(sql, indent=4)
    cur.execute(sql)


def sf_api_agreement_export_v(prefix=None, active_stage=None, delta=None):
    colors.out_print(f"Running sf_api_agreement_export_v", indent=1)
    if debug_var != "":
        colors.bug_print(f"Using debug_var: {debug_var}", indent=2)

    with CursorFromConnectionPool() as cur:
        colors.out_print(f"Building from {prefix}_*", indent=1)
        drop_previous_tables(cur)
        # create CM tables
        build_cm_agreement(cur, prefix)
        create_agreement_indexes(cur)
        create_max_aum(cur)

        # create valid tables
        create_valid_employees(cur)
        create_valid_agreement_pmf_xref(cur)
        create_valid_lob(cur)
        create_full_valid_agreements(cur)
        create_full_valid_sub_agreements(cur)
        create_final_valid_agreements(cur, delta)
        create_final_valid_sub_agreements(cur, delta)

        create_cm_flows(cur)
        create_valid_flows(cur)

        mirror_valid_views(cur, active_stage)
        update_params_by_job(cur, job_type='sf_agreement_api', timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

        colors.out_print("Committing and closing", indent=2)
