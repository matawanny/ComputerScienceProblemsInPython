import pandas as pd
import psycopg2
from cm_commons.db.cm_conn import create_cm_conn
from cm_commons import colors

cxn = create_cm_conn()
debug_var="testing_"

def instantiate_edm_params():
    colors.out_print("Instantiating_edm_params with 1 for mdm and 2 for api", indent=1)
    df = pd.DataFrame({"key":["active_mdm_stage", "active_api_stage"],
                       "value1":["1", "2"],
                       "value2":[None, None],
                       "active":["y", "y"]})

    df = df.set_index(['key'])

    df.to_sql(f"{debug_var}edm_params", cxn[0], if_exists="replace")
    colors.suc_print(f"{debug_var}edm_params", indent=2)

def flip_edm_params():
    df = pd.read_sql(f"SELECT * FROM {debug_var}edm_params", cxn[0])
    df = df.set_index(['key'])
    mdm_val = df.loc['active_mdm_stage']['value1']
    api_val = df.loc['active_api_stage']['value1']

    df.loc['active_mdm_stage', 'value1'] = api_val
    df.loc['active_api_stage', 'value1'] = mdm_val

    print(df.head())
    df.to_sql(f"{debug_var}edm_params", cxn[0], if_exists="replace")