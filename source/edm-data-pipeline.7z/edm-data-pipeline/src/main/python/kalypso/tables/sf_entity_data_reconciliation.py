from cm_commons.db.postgregsql_pool import *
from cm_commons import colors

debug_var = ""


def drop_previous_tables(cur, active_stage):
    colors.out_print(f"Dropping previous invalid_{active_stage}_{debug_var}* tables", indent=2)
    sql = f"""
        drop table if exists sf_invalid_{active_stage}_{debug_var}valid_joined_entities cascade;
        drop table if exists sf_invalid_{active_stage}_{debug_var}entity_tree cascade;
        drop table if exists sf_{active_stage}_{debug_var}entity_data_reconciliation cascade;
    """
    cur.execute(sql)


def build_invalid_tables(cur, active_stage):
    colors.out_print(f"Creating {debug_var}invalid tables", indent=2)

    sql = f"""
        create table sf_invalid_{active_stage}_{debug_var}valid_joined_entities
        AS
            select e.entity_type_id, e.entity_id, e.persistence_id, e.salesforce_id, e.salesvision_id
            from (
                select distinct(entity_id)
                from cm_entity
                EXCEPT
                select distinct(entity_id)
                from valid_joined_entities) s
            join cm_entity e on e.entity_id = s.entity_id;"""
    cur.execute(sql)

    sql = f"""create table sf_invalid_{active_stage}_{debug_var}entity_tree
        AS
            select e.entity_type_id, e.entity_id, e.persistence_id, e.salesforce_id, e.salesvision_id
            from (
                select distinct(entity_id)
                from cm_entity
                EXCEPT
                select distinct(entity_id)
                from entity_linked_list_m) s
            join cm_entity e on e.entity_id = s.entity_id;
    """
    cur.execute(sql)


def build_reconciliation_table(cur, active_stage):
    colors.out_print(f'generating reconciliation from {active_stage}', indent=1)
    sql = f"""
    create table sf_{active_stage}_{debug_var}entity_data_reconciliation
    AS
        select entity_type_id, entity_id, persistence_id, salesforce_id, salesvision_id, 'missing/invalid address' as failure_reason
        from sf_invalid_valid_joined_entities
        where entity_type_id like '3%' or entity_type_id like '2%';
       
    INSERT INTO sf_{active_stage}_{debug_var}entity_data_reconciliation (entity_type_id, entity_id, persistence_id, salesforce_id, salesvision_id, failure_reason)
        select entity_type_id, entity_id, persistence_id, salesforce_id, salesvision_id, 'missing/invalid phone/email' as failure_reason
        from sf_invalid_valid_joined_entities
        where entity_type_id = '101';
    
    INSERT INTO sf_{active_stage}_{debug_var}entity_data_reconciliation (entity_type_id, entity_id, persistence_id, salesforce_id, salesvision_id, failure_reason)
        select entity_type_id, entity_id, persistence_id, salesforce_id, salesvision_id, 'missing/invalid entity tree' as failure_reason
        from sf_invalid_entity_tree
        where entity_type_id != '102';
    """
    cur.execute(sql)


def sf_entity_generate_invalid_tables(prefix, active_stage):
    colors.out_print(f"Running sf_send_generate_invalid_tables", indent=1)
    if debug_var != "":
        colors.bug_print(f"Using debug_var: {debug_var}", indent=2)

    colors.out_print(f"Building from {prefix}_*", indent=1)
    with CursorFromConnectionPool() as cur:
        drop_previous_tables(cur, active_stage)
        build_invalid_tables(cur, active_stage)
        build_reconciliation_table(cur, active_stage)