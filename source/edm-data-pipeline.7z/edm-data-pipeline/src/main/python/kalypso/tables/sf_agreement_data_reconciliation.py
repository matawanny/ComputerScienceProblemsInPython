from cm_commons import colors
from cm_commons.db.postgregsql_pool import *
from cm_commons.db.cm_conn import cm_cxn
from cm_commons.util.sql_functions import psql_table_exists, update_params_by_job

debug_var = ""


def drop_previous_tables(cur, active_stage):
    colors.out_print(f"Dropping previous sf_{active_stage}_invalid_{debug_var}* tables", indent=2)
    sql = f"""
        drop table if exists sf_{active_stage}_invalid_{debug_var}agreement_invalid_related_entity;
        drop table if exists sf_{active_stage}_invalid_{debug_var}agreement_invalid_aum;
        drop table if exists sf_{active_stage}_invalid_{debug_var}agreement_invalid_lob;
        drop table if exists sf_{active_stage}_invalid_{debug_var}agreement_invalid_product;
        drop table if exists sf_{active_stage}_invalid_{debug_var}invalid_trade_code;
        drop table if exists sf_{active_stage}_invalid_{debug_var}invalid_fx_conversion;
        drop table if exists sf_{active_stage}_{debug_var}agreement_data_reconciliation;
        drop table if exists sf_{active_stage}_{debug_var}agreement_batch_send_reconciliation;
    """
    cur.execute(sql)


def build_invalid_tables(cur, active_stage):
    colors.out_print(f"Creating {debug_var}invalid tables", indent=2)

    sql = f"""create table sf_{active_stage}_invalid_{debug_var}agreement_invalid_related_entity
              AS
                select a.agreement_type, a.agreement_id
                from (
                    SELECT DISTINCT(agreement_id) 
                        FROM cm_agreement
                    EXCEPT 
                    SELECT DISTINCT(agreement_id) 
                        FROM cm_agreement_entity_xref agrent_o
                        join valid_entities m on m.entity_id = agrent_o.entity_id    
                      ) s
                join cm_agreement a on a.agreement_id = s.agreement_id;"""
    cur.execute(sql)

    sql = f"""create table sf_{active_stage}_invalid_{debug_var}agreement_invalid_aum
              AS
                select a.agreement_type, a.agreement_id
                from (
                    select distinct(agreement_id)
                    from cm_agreement
                    EXCEPT
                    select distinct(agreement_id)
                    from cm_aum) s
                join cm_agreement a on a.agreement_id = s.agreement_id;"""
    cur.execute(sql)

    sql = f"""create table sf_{active_stage}_invalid_{debug_var}agreement_invalid_lob
              AS
                select a.agreement_type, a.agreement_id
                from (
                    select distinct(agreement_id)
                    from cm_agreement
                    EXCEPT
                    select distinct(agreement_id)
                    from valid_lob) s
                join cm_agreement a on a.agreement_id = s.agreement_id;"""
    cur.execute(sql)

    sql = f"""create table sf_{active_stage}_invalid_{debug_var}agreement_invalid_product
              AS
                select a.agreement_type, a.agreement_id
                from (
                    select distinct(agreement_id)
                    from cm_agreement
                    EXCEPT
                    select distinct(agreement_id)
                    from agreement_pmf_xref) s
                join cm_agreement a on a.agreement_id = s.agreement_id;
    """
    cur.execute(sql)

    sql = f"""create table sf_{active_stage}_invalid_{debug_var}invalid_trade_code
              AS
                select distinct a.agreement_type, a.agreement_id
                from cm_agreement a
                join cm_trade t on t.agreement_id = a.agreement_id
                where not exists (
                    select 1
                    from cm_trades_direction d
                    where a.agreement_id = d.agreement_id
                );
        """
    cur.execute(sql)

    sql = f"""create table sf_{active_stage}_invalid_{debug_var}invalid_fx_conversion
              AS
                select distinct a.agreement_type, a.agreement_id
                from cm_agreement a
                join cm_trade t on t.agreement_id = a.agreement_id
                where not exists (
                    select 1
                    from cm_flows d
                    where a.agreement_id = d.agreement_id
                );
            """
    cur.execute(sql)


def build_reconciliation_table(cur, active_stage):
    colors.out_print(f'generating agreement reconciliation from cm (raw stg data: {active_stage})', indent=1)
    sql = f"""create table sf_{active_stage}_{debug_var}agreement_data_reconciliation
              AS
                select ir.agreement_type, ir.agreement_id, 'missing/invalid related entity' as failure_reason, array_agg(x.entity_id) as affected_entities
                from sf_{active_stage}_invalid_{debug_var}agreement_invalid_related_entity ir
                join cm_agreement_entity_xref x on x.agreement_id = ir.agreement_id
                group by ir.agreement_type, ir.agreement_id
                UNION
                select agreement_type, agreement_id, 'missing/invalid aum' as failure_reason, null as affected_entities
                from sf_{active_stage}_invalid_{debug_var}agreement_invalid_aum
                UNION
                select agreement_type, agreement_id, 'missing/invalid line of business' as failure_reason, null as affected_entities
                from sf_{active_stage}_invalid_{debug_var}agreement_invalid_lob
                UNION
                select agreement_type, agreement_id, 'missing/invalid external identifier' as failure_reason, null as affected_entities
                from sf_{active_stage}_invalid_{debug_var}agreement_invalid_product
                UNION
                select agreement_type, agreement_id, 'missing/invalid trade code mapping' as failure_reason, null as affected_entities
                from sf_{active_stage}_invalid_{debug_var}invalid_trade_code
                UNION
                select agreement_type, agreement_id, 'missing/invalid fx conversion or trade amount > 0' as failure_reason, null as affected_entities
                from sf_{active_stage}_invalid_{debug_var}invalid_fx_conversion
    """
    if psql_table_exists(cm_cxn, f'stg_{active_stage}_agreement_resolution'):
        sql = sql + f"""
            UNION 
            select '1' as agreement_type, agreement_id, 'agreement in resolution' as failure_reason, null as affected_entities
            from stg_{active_stage}_agreement_resolution
        """

    if psql_table_exists(cm_cxn, f'stg_{active_stage}_sub_agreement_resolution'):
        sql = sql + f"""
            UNION
            select '2' as agreement_type, agreement_id, 'subagreement in resolution' as failure_reason, null as affected_entities
            from stg_{active_stage}_sub_agreement_resolution
        """
    cur.execute(sql)


def build_cmsf_send_recon(cur, active_stage):
    colors.out_print(f'generating agreement send recon query', indent=1)
    sql = f"""create table sf_{active_stage}_agreement_batch_send_reconciliation
              as
                SELECT distinct agr.agreement_id, aggregator_name, currency_iso3_code, amount::float, as_of_date
                FROM cm_entity ent
                JOIN cm_agreement_entity_xref xref
                    ON ent.entity_id = xref.entity_id
                JOIN cm_agreement agr
                    ON agr.agreement_id = xref.agreement_id
                JOIN (
                        SELECT aum.* FROM cm_aum aum
                        JOIN 
                            ( SELECT agreement_id, max(as_of_date) max_date
                            FROM cm_aum
                            GROUP BY agreement_id ) s
                        ON s.agreement_id = aum.agreement_id 
                        AND s.max_date = aum.as_of_date
                    ) aum
                    ON aum.agreement_id = agr.agreement_id
                JOIN aggregator agg
                    ON agg.aggregator_id::text = agr.aggregator_id
                JOIN currency_enum cur
                    ON cur.currency_id::text = aum.currency_id;
    """
    cur.execute(sql)


def sf_agreement_generate_invalid_tables(prefix, active_stage):
    colors.out_print(f"Running sf_send_generate_invalid_tables", indent=1)
    if debug_var != "":
        colors.bug_print(f"Using debug_var: {debug_var}", indent=2)

    colors.out_print(f"Building from {prefix}_*", indent=1)
    with CursorFromConnectionPool() as cur:
        drop_previous_tables(cur, active_stage)
        build_invalid_tables(cur, active_stage)
        build_reconciliation_table(cur, active_stage)
        build_cmsf_send_recon(cur, active_stage)

        colors.out_print("Committing and closing", indent=2)
