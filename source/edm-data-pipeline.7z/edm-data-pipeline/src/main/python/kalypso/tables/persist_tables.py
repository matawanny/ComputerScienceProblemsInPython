from cm_commons.models.sqlalchemy import SVExportFir, SVExportOfl, SVExportPer, Base
from cm_commons.db.cm_conn import create_cm_conn
from kalypso.procedures.sqlalchemy import drop_table, create_table

from cm_commons import colors

def blank_persist_tables():
    engine, session = create_cm_conn()
    Base.metadata.bind = engine
    tables = [
              "entity_persist_rules",
              "agreement_entity_xref_persist_rules"
             ]

    colors.out_print(f"Dropping tables {tables}", indent=1)
    drop_table(engine=engine, base=Base, table_names=tables)
    colors.out_print(f"Creating tables {tables}", indent=1)
    create_table(engine=engine, base=Base, table_names=tables)

