class MDM:

    def __init__(self, cxn ):
        self.cxn = cxn



    def copy_table(self):
        return self

    def process(self):
        return self
