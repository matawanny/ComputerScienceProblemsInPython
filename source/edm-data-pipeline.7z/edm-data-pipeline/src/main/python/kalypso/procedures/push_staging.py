import psycopg2
from cm_commons.db.cm_conn import cm_cxn as cxn
from cm_commons import colors

debug_var="testing_"

def find_staging(stage):
    conn = psycopg2.connect(dbname=cxn['db_name'],
                            user=cxn['user'],
                            host=cxn['location'],
                            password=cxn['password'])
    cur = conn.cursor()
    cur.execute(f"select * from information_schema.tables where table_name LIKE 'stg_{stage}'")

    return cur.fetchall()

def drop_tables(tables):
    colors.out_print(f"Dropping cm_{debug_var}* tables", indent=2)
    sql = f""""""
    for tbl in tables:
        sql = sql + f"\nDROP TABLE IF EXISTS {debug_var}{tbl}"




