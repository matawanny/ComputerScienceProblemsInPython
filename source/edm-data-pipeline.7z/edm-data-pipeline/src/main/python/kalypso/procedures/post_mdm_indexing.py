from datetime import datetime
from cm_commons import colors
from cm_commons.db.postgregsql_pool import *
from cm_commons.util.sql_functions import psql_table_exists, update_params_by_job

debug_var = ''


def build_mdm_indexes(cur, prefix,active_stage):
    """
    Index post MDM tables using active stage and a prefix
    :param cur:
    :param active_stage:
    :param prefix:
    :return:
    """
    sql = f"""
        CREATE INDEX idx_{prefix}_{active_stage}_aum_agreement_id ON {prefix}_{active_stage}_aum(agreement_id);
        CREATE INDEX idx_{prefix}_{active_stage}_aum_as_of_date ON {prefix}_{active_stage}_aum(as_of_date);
        CREATE INDEX idx_{prefix}_{active_stage}_aum_aggregator_id ON {prefix}_{active_stage}_aum(aggregator_id);
        CREATE INDEX idx_{prefix}_{active_stage}_aum_currency_id ON {prefix}_{active_stage}_aum(currency_id);
        CREATE INDEX idx_{prefix}_{active_stage}_agreement_agreement_id ON {prefix}_{active_stage}_agreement(agreement_id);
        CREATE INDEX idx_{prefix}_{active_stage}_agreement_channel_id ON {prefix}_{active_stage}_agreement(channel_id);
        CREATE INDEX idx_{prefix}_{active_stage}_agreement_origin_id ON {prefix}_{active_stage}_agreement(origin_id);
        CREATE INDEX idx_{prefix}_{active_stage}_agreement_ta_number ON {prefix}_{active_stage}_agreement(ta_number);
        CREATE INDEX idx_{prefix}_{active_stage}_agreement_entity_xref_agreement_id ON {prefix}_{active_stage}_agreement_entity_xref(agreement_id);
        CREATE INDEX idx_{prefix}_{active_stage}_agreement_entity_xref_entity_id ON {prefix}_{active_stage}_agreement_entity_xref(entity_id);
        CREATE INDEX idx_{prefix}_{active_stage}_agreement_entity_xref_external_entity_id ON {prefix}_{active_stage}_agreement_entity_xref(external_entity_id);
        CREATE INDEX idx_{prefix}_{active_stage}_agreement_entity_xref_relationship_type_id ON {prefix}_{active_stage}_agreement_entity_xref(relationship_type_id);
        CREATE INDEX idx_{prefix}_{active_stage}_entity_entity_id ON {prefix}_{active_stage}_entity(entity_id);
        CREATE INDEX idx_{prefix}_{active_stage}_entity_parent_id ON {prefix}_{active_stage}_entity(parent_id);
        CREATE INDEX idx_{prefix}_{active_stage}_entity_salesforce_id ON {prefix}_{active_stage}_entity(salesforce_id);
        CREATE INDEX idx_{prefix}_{active_stage}_entity_salesvision_id ON {prefix}_{active_stage}_entity(salesvision_id);
        CREATE INDEX idx_{prefix}_{active_stage}_entity_entity_type_id ON {prefix}_{active_stage}_entity(entity_type_id);
        CREATE INDEX idx_valid_entities_persistence_id ON valid_entities(persistence_id);
        CREATE INDEX idx_valid_entities_entity_id ON valid_entities(entity_id);
        CREATE INDEX idx_valid_entities_entity_type_id ON valid_entities(entity_type_id);
    """
    cur.execute(sql)


def post_mdm_indexing(prefix, active_stage):
    colors.out_print(f"Running sf_api_agreement_export_v", indent=1)
    if debug_var != "":
        colors.bug_print(f"Using debug_var: {debug_var}", indent=2)

    colors.out_print("Post-MDM Indexing", indent=1)
    colors.out_print(f"Indexing {prefix}_*", indent=1)
    with CursorFromConnectionPool() as cur:
        build_mdm_indexes(cur, prefix, active_stage)
