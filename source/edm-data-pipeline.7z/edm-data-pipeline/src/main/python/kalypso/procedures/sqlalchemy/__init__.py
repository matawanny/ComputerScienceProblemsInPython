from kalypso.procedures.sqlalchemy.table_procedures import *


# def drop_table(engine, base, table_names, indent=2):
#     for table_name in table_names:
#         metadata = MetaData(engine, reflect=True)
#         table = metadata.tables.get(table_name)
#         if table is not None:
#             colors.suc_print(f'Deleting {table_name} table', indent=indent)
#             base.metadata.drop_all(engine, [table], checkfirst=True)
#         else:
#             colors.war_print(f'Could not find {table_name}', indent=indent)
#
#
#
# def create_table(engine, base, table_names, indent=2):
#     for table_name in table_names:
#         colors.suc_print(f'Creating {table_name} table', indent=indent)
#         base.metadata.tables[table_name].create(bind=engine)