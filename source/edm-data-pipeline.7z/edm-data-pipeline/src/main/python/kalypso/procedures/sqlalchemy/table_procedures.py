from sqlalchemy import MetaData
from cm_commons import colors


def drop_table(engine, base, table_names, indent=2):
    for table_name in table_names:
        if table_name in base.metadata.tables:
            base.metadata.tables[table_name].drop(bind=engine, checkfirst=True)
            colors.suc_print(f'{table_name} dropped', indent=indent + 1)
        else:
            colors.war_print(f'{table_name} does not exist', indent=indent+1)

def create_table(engine, base, table_names, indent=2):
    for table_name in table_names:
        colors.out_print(f'Creating {table_name} table', indent=indent)
        base.metadata.tables[table_name].create(bind=engine)