from pyspark.sql.types import ArrayType, StructType, StructField, IntegerType, StringType
import pyspark.sql.functions as f
import functools as ft


# #---------------------------------------------------------------# #
# #                      Simple SQL operations                    # #
# #---------------------------------------------------------------# #

def select(df, cols):
    """Select list of columns """
    df = df.select(cols)
    return df

def distinct(df):
    """ Select distinct combination of columns """
    df = df.distinct()
    return df

def group_by(df, cols):
    """ Group by fields from grp_expr """
    df = df.groupBy(cols)
    return df

def agg(df, expr):
    """ Aggregate a groupby object """
    df = df.agg(expr)
    return df

