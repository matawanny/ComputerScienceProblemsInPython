import pyspark.sql.functions as f


# #---------------------------------------------------------------# #
# #                         Math operations                       # #
# #---------------------------------------------------------------# #

def sub_cols(df, a, b, out):
    """df.out = df.a - df.b"""
    df = df.withColumn(out, df[a] - df[b])
    return df


def multiply_cols(df, a, b, out):
    """df.out = df.a * df.b"""
    df = df.withColumn(out, df[a] * df[b])
    return df


def abs(df, col, out=None):
    """Return the absolute column"""
    df = df.withColumn(out if out else col, f.abs(f.col(col)))
    return df


def divide_cols(df, a, b, out):
    """df.out = df.a * df.b"""
    df = df.withColumn(out, df[a] / df[b]).fillna(0)
    return df
