from pyspark.sql.types import ArrayType, StructType, StructField, IntegerType, StringType, Row
import pyspark.sql.functions as f
import functools as ft
from functools import partial
import itertools
from collections import defaultdict


# #---------------------------------------------------------------# #
# #                     Advanced SQL operations                   # #
# #---------------------------------------------------------------# #


def explode(df, cols, types, out):
    """Chops CRD Numbers and explodes to include nulls"""
    zip_ = f.udf(
        lambda ll: list(zip(ii for ii in ll)),
        ArrayType(StructType([StructField(oo, tt) for oo, tt in zip(out, types)]))
    )
    tmp = df.withColumn("tmp", zip_(cols)).withColumn("tmp", f.explode("tmp"))
    for cc, oo in zip(cols, out):
        tmp.withColumn(oo, tmp.select(f.col('tmp.' + oo)))

    df = tmp
    return df


def explode_split(df, cols, out, delim, outer):
    """ Splits by a delimiter and explodes to new row"""
    for cc, oo in zip(cols, out):
        if outer:  # Leave Nulls
            df = df.withColumn(oo, f.explode_outer(f.split(df[cc], delim)))
        else:  # Remove Nulls
            df = df.withColumn(oo, f.explode(f.split(df[cc], delim)))
    return df


def melt(df, cols, out):
    """ Melts multiple groups of columns into single rows """
    non_string_cols = (c for c, t in df.dtypes if t != 'string')
    for column in non_string_cols:
        print(f"cast column '{column}' to string")
        df = df.withColumn(column, f.when(f.isnan(f.col(column)), None).otherwise(f.col(column).cast('string')))

    for cc in cols:
        df = df.withColumn(cc + '_melt_id', f.lit(cc))
        df = df.withColumn(cc + '_melt', f.array(*cols[cc], cc + '_melt_id'))

    df = df.withColumn(str(*out.keys()) + '_melt', f.explode_outer(f.array(*[cc + '_melt' for cc in cols])))
    for ii, cc in enumerate(list(*out.values())):
        df = df.withColumn(cc, df[str(*out.keys()) + '_melt'][ii])
    df = df.drop(*[cc + '_melt_id' for cc in cols], *[cc + '_melt' for cc in cols], *[cc + '_melt' for cc in out])
    return df


def switch_case(df, col, out, statement, default='unknown'):
    """ switch case implementation in spark """
    c = f.col(col)
    expr = ft.reduce(lambda acc, kv: f.when(c.isin([kv[0]]) if kv[0] is not None else c.isNull(), kv[1]).otherwise(acc), statement, default).alias(out)
    df = df.select("*", expr)
    return df


def switch_case_2(df, in_col, out_col, statement, default='unknown'):
    """ switch case implementation in spark """
    c = f.col(in_col)
    expr = ft.reduce(lambda acc, kv: f.when(c.isin([kv[0]]) if kv[0] is not None else c.isNull(), kv[1]).otherwise(acc), statement, default).alias('temp_999')
    df = df.select("*", expr)
    df = df.withColumn(out_col, f.col('temp_999')).drop(f.col('temp_999'))
    return df

def switch_case_3(df, in_col, out_col, statement, default='unknown', func_name='isin'):
    """ switch case implementation in spark """
    assert func_name in ('isin', 'gte'), "func_name should be isin or gte"
    c = f.col(in_col)
    if func_name == 'isin':
        expr = ft.reduce(lambda acc, kv: f.when(c.isin([kv[0]]) if kv[0] is not None else c.isNull(), kv[1]).otherwise(acc), statement, default).alias('temp_999')
    elif func_name == 'gte':
        expr = ft.reduce(lambda acc, kv: f.when(c >= kv[0], kv[1]).otherwise(acc), statement, default).alias('temp_999')
    df = df.select("*", expr)
    df = df.withColumn(out_col, f.col('temp_999')).drop(f.col('temp_999'))
    return df

def resolve_pkey_collision(spark, df, rules: defaultdict, source_rankings: defaultdict, pkey: str, source_col: str):
    """cncr function to choose field value based on rankings when records have the same pkey

    :param spark: spark session
    :param df: the input dataframe
    :param rules: defaultdict
    :param source_rankings: defaultdict
    :param pkey: str
    :param source_col: str
    :return: :class:`DataFrame`

    Example,

    The input dataframe is
    +----+----+-----+------+----------+
    |pkey|name|sv_id|source|updated_at|
    +----+----+-----+------+----------+
    |1   |Bren|1a   |sv    |2019-06-05|
    |1   |Bran|2a   |sv    |2019-06-06|
    |1   |BRAN|3a   |cm    |2019-06-05|
    |2   |Dave|77   |cm    |2019-06-04|
    +----+----+-----+------+----------+

    Then it is transformed by combining rankings and the field values together into struct
    +----+---------------------+-------------------+------+----------+
    |pkey|name                 |sv_id              |source|updated_at|
    +----+---------------------+-------------------+------+----------+
    |1   |[2019-06-05, 2, Bren]|[1, 2019-06-05, 1a]|sv    |2019-06-05|
    |1   |[2019-06-06, 2, Bran]|[1, 2019-06-06, 2a]|sv    |2019-06-06|
    |1   |[2019-06-05, 1, BRAN]|[2, 2019-06-05, 3a]|cm    |2019-06-05|
    |2   |[2019-06-04, 1, Dave]|[2, 2019-06-04, 77]|cm    |2019-06-04|
    +----+---------------------+-------------------+------+----------+

    Then the new dataframe allows us to reduceByKey and choose max value between two field values based on the rankings
    The final step is to get the original field value out of the struct
    +----+----+-----+------+----------+
    |pkey|name|sv_id|source|updated_at|
    +----+----+-----+------+----------+
    |1   |Bran|3a   |sv    |2019-06-06|
    |2   |Dave|77   |cm    |2019-06-04|
    +----+----+-----+------+----------+


    """
    schema = df.schema
    for column in set(df.columns) - set(itertools.chain(*rules.values())) - set([pkey]): # exclude the ranking columns and pkey column from the transformation
        df = df.withColumn(column, f.struct([df[i] if i != source_col else f.udf(partial(lambda source, rankings: rankings[source], rankings=source_rankings[column]))(df[i]) for i in rules[column] + (column,)]))

    newdatalist = df.rdd.map(lambda x: (x[pkey], x)).reduceByKey(lambda a, b: list(map(max, zip(a, b)))).map(lambda x: [i[-1] if isinstance(i, Row) else i for i in x[1]])
    return spark.createDataFrame(newdatalist, schema=schema)
