from pyspark.sql.types import ArrayType, StructType, StructField, IntegerType, StringType
import pyspark.sql.functions as f
import functools as ft


# #---------------------------------------------------------------# #
# #                      maintenance operations                   # #
# #---------------------------------------------------------------# #


def rename(df, col, out):
    """Replace column header names"""
    df = df.withColumn(out, df[col])
    return df


def add_prefix(df, prefix):
    """Add a prefix to each column"""
    for c in df.columns:
        df = df.withColumnRenamed(c, '{}{}'.format(prefix, c))
    return df


def fill_nulls(df, col, item=0):
    """ Fill null with item """
    df = df.fillna(item, subset=col)
    return df


def add_static_column(df, col, val):
    """Add a column with a single value"""
    df = df.withColumn(col, f.lit(val))
    return df


def trim_columns(col_names):
    def inner(ldf):
        for col_name in col_names:
            ldf = ldf.withColumn(col_name, f.trim(ldf[col_name]))
        return ldf

    return inner


def substring_column(df, col_name, pos, len):
    df = df.withColumn('POS', f.lit(pos)) \
        .withColumn('LEN', f.lit(len)) \
        .withColumn(col_name, f.expr(f"""substr({col_name}, POS, LEN)""")) \
        .drop('POS').drop('LEN')
    return df


def remove_prefix_column(df, col_name, prefix):
    df = df.withColumn('POS', f.lit(len(prefix))) \
        .withColumn('LEN', f.length(f.col(col_name)) - f.lit(len(prefix))) \
        .withColumn(col_name, f.expr(f"""substr({col_name}, POS, LEN)""")) \
        .drop('POS').drop('LEN')
    return df
