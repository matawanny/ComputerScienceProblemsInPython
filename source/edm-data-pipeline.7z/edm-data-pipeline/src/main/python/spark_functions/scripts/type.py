from pyspark.sql.types import ArrayType, StructType, StructField, IntegerType, StringType
import pyspark.sql.functions as f
import functools as ft


# #---------------------------------------------------------------# #
# #                        Type operations                        # #
# #---------------------------------------------------------------# #

# TODO: When cast from integer to string, NaN becomes string 'NaN', where it should be None.

def cast(df, cols, typecast="INTEGER"):
    """"Typecast a column"""
    for cid in cols:
        df = df.withColumn(cid, f.expr("CAST({} AS {})".format(cid, typecast)))
    return df


