import pyspark.sql.functions as f


def is_null(col, null_val=["none", "null", 'edm-881', 'edm-494', "edm-1030", "edm-1090", "edm_exempt"]):
    """

    :param col: Column<[String]>
    :param null_val: [String]
    :return: Column<boolean>
    """

    return f.lower(f.col(col)).isin(null_val) | f.col(col).isNull()

