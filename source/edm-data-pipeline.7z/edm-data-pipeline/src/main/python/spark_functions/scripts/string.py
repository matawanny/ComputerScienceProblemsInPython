from pyspark.sql.types import ArrayType, StructType, StructField, IntegerType, StringType
import pyspark.sql.functions as f

# #---------------------------------------------------------------# #
# #                        String operations                      # #
# #---------------------------------------------------------------# #

def split(df, cols, out, delim='/'):
    """ Split a column into two columns"""
    for cc, oo in zip(cols,out):
        df = df.withColumn(oo, f.split(df[cc]))

    return df


def concatenate_cols(df, cols, out, delim=" ", drop_cols=False, opt='string'):
    """Concatenate multiple cols passed as list and merge to out column with given deliminator"""

    concated_vals = [df[o] for o in cols]
    if opt == 'string':
        df = df.withColumn(out, f.concat_ws(delim, *concated_vals))
    if opt == 'array':
        df = df.withColumn(out, f.array(*concated_vals))
    if drop_cols:
        df = df.drop(*cols)
    return df


def prefix_col(df, col, prefix, out=None):
    """Add a prefix to a column"""
    df = df.withColumn(col, f.concat(f.lit(prefix), f.col(col)))
    return df

def lower(df, cols):
    """Convert to lowercase"""
    for cid in cols:
        df = df.withColumn(cid, f.lower(f.col(cid)))
    return df

def hash(df, cols, out):
    """Hash one or more columns"""

    formatted_input = []
    for entry in cols:
        formatted_input.append(df[entry])

    df = df.withColumn(out, f.md5(f.concat_ws("_", *formatted_input)))
    return df


def create_hashed_column(df, hashed_column_name, input_columns_list):
    """Get a list of relevant columns from our df"""
    return df.hash(cols=hashed_column_name, out=input_columns_list)