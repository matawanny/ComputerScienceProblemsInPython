import pyspark.sql.functions as f
from pyspark.sql import Row


def compare_rows(merged_row, row):
    cols_to_skip = ["created_at", "enriched_at", "etl_source", "nullability_error",
                    "typecast_error", "error", "updated_at"]
    result_list = []
    mismatch = False

    for k1, v1, k2, v2 in zip(merged_row.__fields__, merged_row, row.__fields__, row):
        if k1 in cols_to_skip or k2 in cols_to_skip:
            continue
        # Logic to add the newer row which has differences in field values between rows
        if v2 is not None and v1 is not None \
                and v2.strip() != 'None' and v1.strip() != 'None' \
                and v1.strip().lower() not in ["edm-881", "edm-494", "edm-1030", "edm-1090", "edm_exempt"] \
                and v2.strip().lower() not in ["edm-881", 'edm-494', "edm-1030", "edm-1090", "edm_exempt"] \
                and v1.strip() != v2.strip():
            result_list.append(Row(**merged_row.asDict()))
            result_list.append(Row(**row.asDict()))
            mismatch = True
            break
    if mismatch:
        return result_list
    # Logic to handle updating fields from newer rows to the merged row
    localDict = merged_row.asDict()
    for k1, v1, k2, v2 in zip(merged_row.__fields__, merged_row, row.__fields__, row):
        if k1 == 'updated_at':
            if (v1 is None or v1.strip()=='None') \
                    or ((v2 is not None or v2.strip()!='None') and (v2 > v1)):
                localDict[k1] = v2
        else:
            if ((v1 is None or v1.strip()=='None' ) \
                    and (v2 is not None or v2.strip()!='None')):
                localDict[k1] = v2
    return Row(**localDict)


def merge_rows(x):
    row_list = []
    set_first_row = True
    for row in list(x):
        row_obj = Row(**row.asDict())
        if set_first_row == True:
            set_first_row = False
            row_list.append(row_obj)
        else:
            result_list = compare_rows(row_list[0], row_obj)
            if len(result_list) == 2:
                row_list.append(result_list[1])
            else:
                row_list[0] = result_list
    return row_list


def exact_match_compare_rows_old(merged_row, row):
    # Logic to handle updating fields from newer rows to the merged row
    localDict = merged_row.asDict()
    source = str(row.etl_source).lower()
    is_master_rec = True if source == "salesforce" or source.startswith("sf") else False
    for k1, v1, k2, v2 in zip(merged_row.__fields__, merged_row, row.__fields__, row):
        if (v1 is None and v2 is not None and not is_master_rec) or (is_master_rec and v2 is not None):
            localDict[k1] = v2
    return Row(**localDict)


def exact_match_compare_rows(merged_row, row):
    # Logic to handle updating fields from newer rows to the merged row
    localDict = merged_row.asDict()
    source = str(row.etl_source).lower()

    source_rankings = {'circe': 1,
                       'sf': 2,
                       'cm': 3,
                       'sv_person': 4,
                       'sv_office': 4,
                       'sv_firm': 4,
                       'sv_holding': 5,
                       'sv_match': 5,
                       'sv_asset': 5,
                       'sv_trade': 5,
                       'amg': 6,
                       'ldw': 7}

    new_rank = 10
    merged_rank = 10
    for kw, kv in source_rankings.items():
        if str(row.etl_source).lower().startswith(kw):
            new_rank = kv
        if str(merged_row.etl_source).lower().startswith(kw):
            merged_rank = kv

    if new_rank < merged_rank:
        is_master_rec = True
    elif (new_rank == merged_rank) and \
            (row.updated_at and merged_row.updated_at) and \
            (row.updated_at > merged_row.updated_at):
        is_master_rec = True
    else:
        is_master_rec = False

    # is_master_rec=True if source=="salesforce" or source.startswith("sf") else False
    for k1, v1, k2, v2 in zip(merged_row.__fields__, merged_row, row.__fields__, row):
        # if (v1 is None and v2 is not None and not is_master_rec) \
        #        or (is_master_rec and v2 is not None):
        if ( (v1 is None or str(v1).lower() == "none") and v2 is not None and not is_master_rec ) \
                or ( is_master_rec and (v2 is not None and str(v2).lower() != "none") ):
            localDict[k1] = v2
    return Row(**localDict)


def exact_match_merge_rows(x):
    row_list = []
    set_first_row = True
    x = sorted(x, key=lambda f: f['updated_at'], reverse=True)
    for row in list(x):
        row_obj = Row(**row.asDict())
        if set_first_row == True:
            set_first_row = False
            row_list.append(row_obj)
        else:
            result_list = exact_match_compare_rows(row_list[0], row_obj)
            row_list[0] = result_list
    return row_list


def exact_match_select_newer(merged_row, row):
    # Logic to handle updating fields from newer rows to the merged row
    localDict = merged_row.asDict()
    source = str(row.etl_source).lower()

    # source_rankings = {'circe': 1,
    #                    'sf': 2,
    #                    'cm': 3,
    #                    'sv_person': 4,
    #                    'sv_office': 4,
    #                    'sv_firm': 4,
    #                    'sv_holding': 5,
    #                    'sv_asset': 5,
    #                    'sv_trade': 5,
    #                    'amg': 6,
    #                    'ldw': 7}

    # TODO - switch on for delta updates
    source_rankings = {'circe': 1,
                       'sf': 2,
                       'cm': 3,
                       'sv_person': 4,
                       'sv_office': 4,
                       'sv_firm': 4,
                       'sv_holding': 5,
                       'sv_asset': 5,
                       'sv_trade': 5,
                       'amg': 6,
                       'ldw': 7}

    src_rank = 10
    mas_rank = 10
    for kw, kv in source_rankings.items():
        if str(row.etl_source).lower().startswith(kw):
            src_rank = kv
        if str(row.etl_source).lower().startswith(kw):
            mas_rank = kv

    if src_rank > mas_rank:
        is_master_rec = True
    elif (src_rank == mas_rank) and (row.created_at > merged_row.created_at):
        is_master_rec = True
    else:
        is_master_rec = False

    # is_master_rec=True if source=="salesforce" or source.startswith("sf") else False
    for k1, v1, k2, v2 in zip(merged_row.__fields__, merged_row, row.__fields__, row):
        if (v1 is None and v2 is not None and not is_master_rec) or (is_master_rec and v2 is not None):
            localDict[k1] = v2
    return Row(**localDict)
