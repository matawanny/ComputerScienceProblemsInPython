from spark_functions import hash
import pyspark.sql.functions as f
from cm_commons import colors
from pyspark.sql.window import Window


def min_max_updated_at(df, delta_columns, key, date_col, source_col='etl_source', source_rank_col='etl_source_rank'):
    """ source_rank_col is the integer rank value"""
    # EDM-2088
    df = hash(df, cols=delta_columns, out='delta_hash')

    # 1 sv record, 1 amg record (entity) --> 2 groups key (1,5)
    # | key | source_rank | min_date | max_date| cardinality | (rn) |
    # | 1   |      1      |   01/01  | 01/01   |   1         |  1   |
    # | 1   |      5      |   02/02  | 02/02   |   1         |  2   |

    # 1 sv record, 1 sf record (entity) --> 1 group per key (1)
    # | key | source_rank | min_date | max_date| cardinality | (rn) |
    # | 1   |      1      |   01/01  | 02/02   |     2       |  1   |

    # TODO convert date_col to date_type
    jdf = df.groupBy(key, source_rank_col).agg(f.min(f.col(date_col)).alias("min_date"),
                                               f.max(f.col(date_col)).alias("max_date"),
                                               # f.min(f.col(source_rank_col)).alias("min_rank"),
                                               f.countDistinct("delta_hash").alias("cardinality_hash"))

    # Select only the latest
    window_spec = Window.partitionBy(key).orderBy(f.col(source_rank_col).asc())
    jdf = jdf.withColumn("rn", f.row_number().over(window_spec)).where(f.col("rn") == 1).drop("rn", "etl_source_rank")

    # Set correct updated_at
    df = df.join(jdf, key).withColumn("mmua_" + date_col,
                                      f.when(f.col('cardinality_hash') > 1,
                                             f.col('max_date')).
                                      otherwise(f.col('min_date')))
    jdf.unpersist()
    # Don't need anymore because source rank happens first
    # # Find the minimum source rank and pick one of the lowest for that entity
    # jdf_src = df.filter(f.col("max_date") == f.col(date_col)).\
    #              withColumn("rn",
    #                         f.row_number().over(Window.partitionBy(key).orderBy(f.to_date(date_col).desc()))
    #                         ).where(f.col("rn") == 1).select(f.col(key),
    #                                                          f.col("etl_source").alias("min_etl_source")
    #                                                          )
    # Join source_rank and
    # df = df.join(jdf_src, key).withColumn(source_col, f.col("min_etl_source"))

    # Clean up columns
    df = df.drop("min_date", "max_date", "min_etl_source", "min_rank", "cardinality_hash", "delta_hash")
    return df


def min_max_ingested_at(df, delta_columns, key, ingested_at_col, source_rank_col='etl_source_rank'):
    """ source_rank_col is the integer rank value"""
    # EDM-2331
    df = hash(df, cols=delta_columns, out='delta_hash')

    # TODO convert date_col to date_type
    jdf = df.groupBy(key, source_rank_col).agg(f.min(f.col(ingested_at_col)).alias("min_date_ingested"),
                                               f.max(f.col(ingested_at_col)).alias("max_date_ingested"),
                                               f.countDistinct("delta_hash").alias(
                                                   "cardinality_hash_ingested"))

    # Select only the latest ingested_at
    window_spec_ingested = Window.partitionBy(key).orderBy(f.col(source_rank_col).asc())
    jdf = jdf.withColumn("rn", f.row_number().over(window_spec_ingested)).where(
        f.col("rn") == 1).drop("rn", "etl_source_rank")

    # Set correct ingested_at. If a record comes in without any actual updates, we should use the older ingested_at date
    df = df.join(jdf, key).withColumn("mmua_" + ingested_at_col,
                                      f.when(f.col('cardinality_hash_ingested') > 1,
                                             f.col('max_date_ingested')).
                                      otherwise(f.col('min_date_ingested')))
    jdf.unpersist()
    df = df.drop("min_etl_source", "min_date_ingested", "max_date_ingested", "cardinality_hash_ingested")
    return df


def min_max_ingested_at_updated_at(df, delta_columns, key, date_col, ingested_at_date_col, ingested_at_col='ingested_at',
                                   source_rank_col='etl_source_rank'):
    """ source_rank_col is the integer rank value"""
    # EDM-2331
    # TODO convert date_col to date_type
    jdf = df.groupBy(key, source_rank_col, ingested_at_date_col).agg(f.min(f.col(date_col)).alias("min_date"),
                                                                     f.max(f.col(date_col)).alias("max_date"),
                                                                     f.countDistinct("delta_hash").alias("cardinality_hash"))
    # Select only the latest
    window_spec = Window.partitionBy(key).orderBy(f.col(source_rank_col).asc(), f.col(ingested_at_date_col).desc())
    jdf = jdf.withColumn("rn", f.row_number().over(window_spec)).where(f.col("rn") == 1).drop("rn", "etl_source_rank", "ingested_at_date")

    # Set correct updated_at. If a record comes in without any actual updates, we should use the older updated_at date
    df = df.join(jdf, key).withColumn("mmua_" + date_col,
                                      f.when(f.col('cardinality_hash') > 1,
                                             f.col('max_date')).
                                      otherwise(f.col('min_date')))
    df = df.drop("min_date", "max_date", "min_etl_source", "min_rank", "cardinality_hash", "delta_hash")
    jdf.unpersist()
    return df


def get_window_function(df, consider_ingested_at, key, indent, inp_date_col='updated_at', out_date_col='updated_at_date'):
    """ Gets window function based on what's available in schema
     TODO - removed hard coded schema parameters
    """
    if inp_date_col in df.schema.names:
        df = df.withColumn(out_date_col, f.to_timestamp(inp_date_col))
        if ("etl_source" in df.schema.names) and consider_ingested_at:
            df = df.withColumn('ingested_at_date', f.to_date(f.col('ingested_at')))
            colors.suc_print(f"{inp_date_col} found in dataframe using etl_source, ingested_at, {inp_date_col}",
                             indent=indent)
            window_spec = Window.partitionBy(key).orderBy(f.col('etl_source_rank').asc(),
                                                          f.col(out_date_col).desc(),
                                                          f.col('ingested_at_date').desc())
        elif ("etl_source" in df.schema.names) and (not consider_ingested_at):
            # this is the original one, only based on etl_source and updated_at to decide ranking
            colors.suc_print(f"{inp_date_col} found in dataframe using etl_source, {inp_date_col}", indent=indent)
            window_spec = Window.partitionBy(key).orderBy(f.col('etl_source_rank').asc(),
                                                          f.col(out_date_col).desc())
        elif ("etl_source" not in df.schema.names) and consider_ingested_at:
            df = df.withColumn('ingested_at_date', f.to_date(f.col('ingested_at')))
            colors.suc_print(f"{inp_date_col} found in dataframe using ingested_at, {inp_date_col}", indent=indent)
            window_spec = Window.partitionBy(key).orderBy(f.col(out_date_col).desc(),f.col('ingested_at_date').desc())
        else:
            colors.war_print(f"`etl_source` not found in dataframe, using `{inp_date_col}`", indent=indent)
            window_spec = Window.partitionBy(key).orderBy(f.col(inp_date_col).desc())
    else:
        colors.err_print(f"`{inp_date_col}`  not found in dataframe, no order used for pkey reduction",
                         indent=indent)
        window_spec = Window.partitionBy(key).orderBy(f.lit("A"))

    return df, window_spec