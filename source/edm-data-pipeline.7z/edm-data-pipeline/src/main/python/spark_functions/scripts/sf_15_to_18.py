# udf wrapper
import pyspark.sql.functions as f


def sf_eighteen(sf_fifteen):
    """
    Helper function to convert 15-char SF IDs to 18-char
    :param sf_fifteen:
    :return:
    """
    # set default value to 'None'
    new_sf_eighteen = 'None'

    if sf_fifteen is None:
        return new_sf_eighteen
    if len(sf_fifteen) == 18:
        new_sf_eighteen = sf_fifteen  # will default to return the sf_fifteen, if length is not 15
    if len(sf_fifteen) == 15:
        final_string = ""
        # only return sf_eighteen if sf_fifteen is fifteen chars long
        for letter_group in range(0, 3):
            letter_place = 0
            for check_letter in range(0, 5):

                this_letter = sf_fifteen[letter_group * 5 + check_letter]
                upper_letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                if this_letter in upper_letters:
                    # print("This is an upper letter: " + this_letter)
                    # print("This is the check letter: " + str(check_letter))

                    # this is the method for selecting the new letter. It depends on how many capital letters are in the block of 5, and originally used a bitwise left operator to increase the letter position
                    # however the bitwise left operator can be reduced to: two to the power of the letter position in the block of 5; then these are added together to find the designated letter in the final letter range
                    letter_place = letter_place + (1 * (2 ** check_letter))

                    # print("This is the letter_place found: " + str(letter_place))

            final_letter_range = "ABCDEFGHIJKLMNOPQRSTUVWXYZ012345"
            final_letter = final_letter_range[letter_place]
            final_string = final_string + final_letter

        new_sf_eighteen = sf_fifteen + final_string

    return new_sf_eighteen


udf_15_to_18 = f.udf(sf_eighteen)

# this is an example of the use of the function in python.
# print(sf_eighteen("0033l00002KEC6v"))
