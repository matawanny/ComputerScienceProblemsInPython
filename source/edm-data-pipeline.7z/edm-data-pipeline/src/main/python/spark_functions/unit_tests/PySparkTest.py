import unittest
import logging
from pyspark.sql import SparkSession

from typing import Any

class PySparkTest(unittest.TestCase):

    @classmethod
    def suppress_py4j_logging(cls):
        logger = logging.getLogger("py4j")
        logger.setLevel(logging.WARN)

    @classmethod
    def create_testing_pyspark_session(cls):
        spark = SparkSession.builder.appName("UnitTest").master('local').getOrCreate()
        return spark

    @classmethod
    def setUpClass(cls):
        cls.suppress_py4j_logging()
        cls.spark = cls.create_testing_pyspark_session()

    @classmethod
    def tearDownClass(cls):
          cls.spark.stop()

    def assertSparkDataFrameEqual(self, first, second, msg: Any = ...):
        self.assertEqual.__self__.maxDiff = None
        self.assertDictEqual(first.toPandas().to_dict(), second.toPandas().to_dict(), msg)
