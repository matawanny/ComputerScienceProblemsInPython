from kharybdis.cncr.cncr import CNCR
