import pyspark.sql.functions as f
from pyspark.sql import Row

import spark_functions as sf
from cm_commons import colors
from datetime import datetime
from cm_commons.db.cm_conn import cm_cxn_jdbc


class CNCR:
    """
    Combine Non-Conflicting Records
    """

    def __init__(self, spark, df_dict, schema, conf):
        self.conf = conf
        self.spark = spark
        self.dfs = df_dict
        self.schema = schema
        self.cols_to_skip = ["created_at", "updated_at", "etl_source", "enriched_at"]

    def process(self):
        ''' Not used any more. Replaced by mdm.combine_non_conflicting_values()'''
        # nav_flag=False
        for df_name in self.dfs.keys():
            colors.out_print(f"Processing non-conflicting records for {df_name}", indent=1)
            # if df_name in ["entity_address_xref", "entity_email_xref", "entity_phone_xref"]: continue
            df = self.dfs[df_name]
            p_key = self.schema[df_name]["primaryKey"][0]["field"]
            table_name = self.schema[df_name]["primaryKey"][0]["table"]
            colors.suc_print(f"df_name={df_name} with p_key={p_key} in table={table_name}", indent=2)
            colors.suc_print(f"{datetime.now().time()}", indent=3)



            if df.rdd.getNumPartitions() <= 2:
                colors.suc_print(f"Resizing current paritions for {df_name}", indent=2)
                df = df.repartition(1)

            df = df.withColumn("primary_key", f.col(p_key))


            # exclude = ['etl_source', 'updated_at', 'created_at']
            # df_g = df.groupby([ii for ii in df.schema.names if ii not in exclude]).orderBy(f.col('updated_at').desc)
            #
            # def return_cm(grp):
            #     default = None
            #     for row in grp:
            #         if row['etl_source'] == 'cm':
            #             return row
            #         default = row
            #     return default
            #

            df_new = df.rdd.map(lambda x: (x.primary_key, x)).groupByKey().mapValues(sf.merge_rows)

            # df_new=df_new.flatMap(lambda x: x[1]).toDF(sampleRatio=0.2).drop("primary_key")
            rdd_final = df_new.flatMap(lambda x: x[1])

            # rdd_final=self.spark.parallelize([x for x in rdd_final.glom().collect() if x!=[]], df.rdd.getNumPartitions())

            """
            if df_name=="entity_address_xref" or nav_flag==True:
                nav_flag=True
                print("Nbr of partitions =",rdd_final.getNumPartitions())
                colors.suc_print(f"rdd_final = {rdd_final.glom().collect()}")
            """

            first_row = rdd_final.first()
            columnList = list(first_row.asDict().keys())

            df_new = None
            try:
                colors.suc_print(f"Converting {df_name} rdd to {df_name} dataframe..", indent=2)
                df_new = rdd_final.toDF(schema=columnList, sampleRatio=0.5)
            except:
                colors.suc_print(f"Using spark session to create {df_name} dataframe..", indent=2)
                df_new = self.spark.createDataFrame(rdd_final, schema=columnList, samplingRatio=0.5)

            df_new = df_new.drop("primary_key")
            self.dfs[df_name] = df_new
            colors.suc_print(f"Finished processing table: {df_name}", indent=2)
        return self

    def process_exact_match_old(self, match_criteria):

        for df_name in self.dfs.keys():

            df = self.dfs[df_name]
            match_criteria_fields_exist = True
            table_name = self.schema[df_name]["primaryKey"][0]["table"]
            colors.suc_print(f"Processing {df_name} in table={table_name} with match_criteria: {match_criteria}", indent=1)
            colors.out_print(f"{datetime.now().time()}", indent=2)

            for match_field in match_criteria:
                if match_field not in df.columns:
                    match_criteria_fields_exist = False
            if not match_criteria_fields_exist:
                colors.err_print(f"One or more match criteria field(s) do not"
                                 f" exist in {df_name}, Skipping", indent=3)
                colors.out_print(f"{datetime.now().time()}", indent=4)
                continue

            df = df.withColumn("group_name", f.concat_ws("_", *match_criteria))
            df = df.withColumn("tds_id", f.md5(df.group_name))


            if 'ended_at' in df.schema.names:
                colors.suc_print("",indent=3)
                # If ended_at is not null, the match_criteria are null
                sql_filter_for_nulls = f"ended_at not in ('None', 'edm_exempt') OR "
                # If ended_at is null, the match_criteria is non null and should be matched
                sql_filter_to_include_non_nulls = f"ended_at in ('None', 'edm_exempt') AND "

                colors.suc_print(f"including {sql_filter_for_nulls} in null query", indent=3)
            else:
                sql_filter_for_nulls = ""
                sql_filter_to_include_non_nulls = ""
                colors.war_print(f"ended_at not found, only using nulls in null query", indent=3)

            for field in match_criteria:
                sql_filter_for_nulls += f"{field} in ('None', 'edm_exempt') OR "
                sql_filter_to_include_non_nulls += f"{field} not in ('None','edm_exempt') AND "
                colors.bug_print(f"sql_filter_for_nulls: {sql_filter_for_nulls}", indent=4)
                colors.bug_print(f"sql_filter_to_include_non_nulls: {sql_filter_to_include_non_nulls}", indent=4)

            sql_filter_for_nulls = sql_filter_for_nulls[:-3]
            sql_filter_to_include_non_nulls = sql_filter_to_include_non_nulls[:-4]

            null_key_data_df = df.filter(sql_filter_for_nulls)
            colors.out_print(f"Number of nulls for {str(match_criteria)} = {null_key_data_df.count()}", indent=2)

            null_key_data_df = null_key_data_df.withColumn("group_name", f.lit(None))
            null_key_data_df = null_key_data_df.withColumn("group_count", f.lit(1))

            df = df.filter(sql_filter_to_include_non_nulls)

            non_null_count = df.count()
            colors.out_print(f"Number of non-nulls for {str(match_criteria)} = {non_null_count}",indent=2)

            if non_null_count == 0:
                colors.war_print(f"No non-null records for {str(match_criteria)}. ABANDONING exact_match for {df_name}", indent=2)
                continue

            gdf = df.groupby(df.tds_id).agg(f.count("tds_id").alias("group_count"))

            if 'group_count' in df.columns:
                df=df.drop('group_count')

            joined_df = df.join(gdf, "tds_id")
            matched_df = joined_df.where("group_count>1")
            unmatched_df = joined_df.filter("group_count<=1")

            unmatched_df = unmatched_df.withColumn("tds_master", f.lit("false")).withColumn("tds_match_yn", f.lit("n"))
            # unmatched_df.show()
            matched_list = matched_df.take(1)
            colors.out_print("Checking if atleast one item exist in the matched_df", indent=2)

            if matched_list != []:
                rdd_final = matched_df.rdd.map(lambda x: (x.tds_id, x)).groupByKey().mapValues(
                    sf.exact_match_merge_rows)
                rdd_final = rdd_final.flatMap(lambda x: x[1])

                if rdd_final.isEmpty():
                    colors.war_print('No matches found')
                    continue

                # df_final = spark.createDataFrame(rdd_final)
                df_final = rdd_final.toDF(sampleRatio=1)
                colors.suc_print(f"{df_final.count()} records found for match criteria {str(match_criteria)}", indent=3)
                df_final.drop(df_final.etl_source)
                df_final = df_final.withColumn("tds_master", f.lit("true"))\
                    .withColumn("etl_source", f.lit(f"{self.conf['match_source'].lower()}_match"))

                matched_df = matched_df.withColumn("tds_master", f.lit("false"))
                new_col_names = matched_df.columns
                df_final = df_final.select([col for col in new_col_names])
                df_union = df_final.union(matched_df).withColumn("tds_match_yn", f.lit("y"))
                df_union = df_union.union(unmatched_df)
            else:
                colors.err_print(f"No matches for {str(match_criteria)} found", indent=2)
                df_union = unmatched_df

            null_key_data_df = null_key_data_df.withColumn("tds_master", f.lit("false"))\
                .withColumn("tds_match_yn", f.lit("n"))

            def union_all(dfs):
                df_left = dfs[0]
                if len(dfs) > 1:
                    df_right = union_all(dfs[1:])
                    # columns not in df_left
                    for ii in list(set(df_right.columns) - set(df_left.columns)):
                        colors.err_print(f' Missing {ii} from left', indent=3)
                        df_left = df_left.withColumn(ii, f.lit('None'))
                    # columns not in df_rightm
                    for jj in set(df_left.columns) - set(df_right.columns):
                        colors.err_print(f' Missing {jj} from right', indent=3)
                        df_right = df_right.withColumn(jj, f.lit('None'))
                    df_left = df_left.select(df_right.columns)
                    return df_left.unionAll(df_right)
                else:
                    return df_left

            # colors.bug_print(f"{df_union.schema.names}")
            # colors.bug_print(f"{null_key_data_df.schema.names}")
            df_final_union = union_all([df_union, null_key_data_df])

            # colors.suc_print(f"{datetime.now().time()} - EXACT-MATCH: Sample of final unioned dataset of df_name={df_name}:{df_final_union.show(n=5)}")
            self.dfs[df_name] = df_final_union
        return self

    @staticmethod
    def process_exact_match(df, df_name, table_name, match_criteria, match_source):
        match_criteria_fields_exist = True
        df_orig = df
        colors.suc_print(f"Processing {df_name} in table={table_name} "
                         f" match_criteria: {match_criteria}"
                         f" match_source: {match_source}", indent=1)
        colors.out_print(f"{datetime.now().time()}", indent=2)

        for match_field in match_criteria:
            if match_field not in df.columns:
                match_criteria_fields_exist = False
        if not match_criteria_fields_exist:
            colors.err_print(f"One or more match criteria field(s) do not"
                             f" exist in {df_name}, Skipping", indent=3)
            colors.out_print(f"{datetime.now().time()}", indent=4)
            return df_orig

        df = df.withColumn("group_name", f.concat_ws("_", *match_criteria))
        df = df.withColumn("tds_id", f.md5(df.group_name))


        if 'ended_at' in df.schema.names:
            colors.suc_print("",indent=3)
            # If ended_at is not null, the match_criteria are null
            sql_filter_for_nulls = f"ended_at not in ('None', 'edm_exempt') OR "
            # If ended_at is null, the match_criteria is non null and should be matched
            sql_filter_to_include_non_nulls = f"ended_at in ('None', 'edm_exempt') AND "

            colors.suc_print(f"including {sql_filter_for_nulls} in null query", indent=3)
        else:
            sql_filter_for_nulls = ""
            sql_filter_to_include_non_nulls = ""
            colors.war_print(f"ended_at not found, only using nulls in null query", indent=3)

        for field in match_criteria:
            sql_filter_for_nulls += f"{field} in ('None', 'edm_exempt') OR "
            sql_filter_to_include_non_nulls += f"{field} not in ('None','edm_exempt') AND "
            colors.bug_print(f"sql_filter_for_nulls: {sql_filter_for_nulls}", indent=4)
            colors.bug_print(f"sql_filter_to_include_non_nulls: {sql_filter_to_include_non_nulls}", indent=4)

        sql_filter_for_nulls = sql_filter_for_nulls[:-3]
        sql_filter_to_include_non_nulls = sql_filter_to_include_non_nulls[:-4]

        null_key_data_df = df.filter(sql_filter_for_nulls)
        colors.out_print(f"Number of nulls for {str(match_criteria)} = {null_key_data_df.count()}", indent=2)

        null_key_data_df = null_key_data_df.withColumn("group_name", f.lit(None))
        null_key_data_df = null_key_data_df.withColumn("group_count", f.lit(1))
        # colors.out_print("nav_debug: null_key_data_df(nulls):")
        # null_key_data_df.show(10, False)

        df = df.filter(sql_filter_to_include_non_nulls)

        non_null_count = df.count()
        colors.out_print(f"Number of non-nulls for {str(match_criteria)} = {non_null_count}",indent=2)
        # colors.out_print("nav_debug: df(non-nulls):")
        # df.show(10, False)

        if non_null_count == 0:
            colors.war_print(f"No non-null records for {str(match_criteria)}. ABANDONING exact_match for {df_name}", indent=2)
            return df_orig

        gdf = df.groupby(df.tds_id).agg(f.count("tds_id").alias("group_count"))

        if 'group_count' in df.columns:
            df=df.drop('group_count')

        joined_df = df.join(gdf, "tds_id")
        matched_df = joined_df.where("group_count>1")
        unmatched_df = joined_df.filter("group_count<=1")

        unmatched_df = unmatched_df.withColumn("tds_master", f.lit("false")).withColumn("tds_match_yn", f.lit("n"))

        # colors.out_print("nav_debug: unmatched_df:")
        # unmatched_df.show(10, False)
        # colors.out_print("nav_debug: matched_df:")
        # matched_df.show(10, False)

        # unmatched_df.show()
        matched_list = matched_df.take(1)
        colors.out_print("Checking if atleast one item exist in the matched_df", indent=2)

        if matched_list != []:
            rdd_final = matched_df.rdd.map(lambda x: (x.tds_id, x)).groupByKey().mapValues(
                sf.exact_match_merge_rows)
            rdd_final = rdd_final.flatMap(lambda x: x[1])

            if rdd_final.isEmpty():
                colors.war_print('No matches found')
                return df_orig

            # df_final = spark.createDataFrame(rdd_final)
            df_final = rdd_final.toDF(sampleRatio=1)
            colors.suc_print(f"{df_final.count()} records found for match criteria {str(match_criteria)}", indent=3)
            df_final.drop(df_final.etl_source)
            df_final = df_final.withColumn("tds_master", f.lit("true"))\
                .withColumn("etl_source", f.lit(f"{match_source}_match"))

            matched_df = matched_df.withColumn("tds_master", f.lit("false"))
            new_col_names = matched_df.columns
            df_final = df_final.select([col for col in new_col_names])
            df_union = df_final.union(matched_df).withColumn("tds_match_yn", f.lit("y"))
            df_union = df_union.union(unmatched_df)
        else:
            colors.err_print(f"No matches for {str(match_criteria)} found", indent=2)
            df_union = unmatched_df

        null_key_data_df = null_key_data_df.withColumn("tds_master", f.lit("false"))\
            .withColumn("tds_match_yn", f.lit("n"))

        def union_all(dfs):
            df_left = dfs[0]
            if len(dfs) > 1:
                df_right = union_all(dfs[1:])
                # columns not in df_left
                for ii in list(set(df_right.columns) - set(df_left.columns)):
                    colors.err_print(f' Missing {ii} from left', indent=3)
                    df_left = df_left.withColumn(ii, f.lit('None'))
                # columns not in df_rightm
                for jj in set(df_left.columns) - set(df_right.columns):
                    colors.err_print(f' Missing {jj} from right', indent=3)
                    df_right = df_right.withColumn(jj, f.lit('None'))
                df_left = df_left.select(df_right.columns)
                return df_left.unionAll(df_right)
            else:
                return df_left

        # colors.bug_print(f"{df_union.schema.names}")
        # colors.bug_print(f"{null_key_data_df.schema.names}")
        df_final_union = union_all([df_union, null_key_data_df])

        # colors.suc_print(f"{datetime.now().time()} - EXACT-MATCH: Sample of final unioned dataset of df_name={df_name}:{df_final_union.show(n=5)}")
        return df_final_union



    @staticmethod
    def process_exact_match_2(df, match_criteria, null_words=['None', 'edm_exempt']):
        return df
