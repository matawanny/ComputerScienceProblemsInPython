from itertools import chain
from cm_commons import colors
import spark_functions as sf
import pyspark.sql.functions as f


# TODO - generalize and move somewhere
def append_source_rankings(df, src_rankings, src_column='etl_source', src_rank_colummn='etl_source_rank'):
    mapping_expr = f.create_map([f.lit(x) for x in chain(*src_rankings.items())])

    df = df.withColumn(src_rank_colummn, mapping_expr.getItem(f.col(src_column)))
    return df


class Resolver:

    def __init__(self, indent):
        self.indent = indent

    @staticmethod
    def solve_key_collision(df, key, indent=0, delta_columns=[]):
        """Asserts primary key and writes to obj and err_df"""
        # df.registerTempTable("entities")

        # TODO - make source_rankings robust enough to handle `table` and `field` level ranking differences
        entity_source_rankings = {
            'circe': 1,
            'cm': 1,
            'sf': 1,
            'sf_entity': 1,
            'SF_Entity': 1,
            'sv_person': 1,
            'sv_office': 1,
            'sv_firm': 1,
            'sv_holding': 1,
            'sv_asset': 1,
            'sv_trade': 1,
            'sv_sales_hier': 1,
            'sv_sales_per': 1,
            'sv': 1,
            'amgwm': 5,
            'amg': 5,
            'ldw_aum': 5,
            'ldw_trade': 5,
            'au_platform_files': 5,
            'datacleaner_agreement': 5,
            "datacleaner_entity": 5,
            'registreet_aum': 5,
            'registreet_trade': 5,
            'ft': 5
        }

        default_source_rankings = {
            'circe': 1,
            'cm': 1,
            'sf': 1,
            'sf_entity': 1,
            'SF_Entity': 1,
            'sv_person': 1,
            'sv_office': 1,
            'sv_firm': 1,
            'sv_holding': 1,
            'sv_asset': 1,
            'sv_trade': 1,
            'sv_sales_hier': 1,
            'sv_sales_per': 1,
            'sv': 1,
            'amgwm': 1,
            'amg': 1,
            'ldw_aum': 1,
            'ldw_trade': 1,
            'au_platform_files': 1,
            'datacleaner_agreement': 1,
            "datacleaner_entity": 1,
            'registreet_aum': 1,
            'registreet_trade': 1,
            'ft': 1
        }

        colors.bug_print(f"key: {str(key)}", indent=1)
        colors.bug_print(f"delta_columns: {str(delta_columns)}", indent=1)

        # `entity`` table will use the entity_source_rankings
        if key == 'entity_id':
            source_rankings = entity_source_rankings
        else:
            source_rankings = default_source_rankings

        df = append_source_rankings(df,
                                    src_rankings=source_rankings,
                                    src_column='etl_source',
                                    src_rank_colummn='etl_source_rank')

        if 'ingested_at' not in df.columns:
            consider_ingested_at = False
        else:
            row_list = df.select(f.countDistinct('ingested_at')).collect()

            ingested_at_count = row_list[0][0]
            if ingested_at_count == 1:
                consider_ingested_at = False
            else:
                ingested_at_null_count = df.filter((df['ingested_at'].isNull())).count()
                ingested_at_default_count = df.filter(df['ingested_at'] == 'default_ingested_at').count()
                if df is None or len(df.take(1)) == 0:
                    raise ValueError(f"ERROR in solve_key_collision: dataframe {df} cannot be None or Empty")
                if ingested_at_null_count / df.count() >= 0.5 \
                        or ingested_at_default_count / df.count() >= 0.5:
                    consider_ingested_at = False
                else:
                    consider_ingested_at = True
        # Get the window spec we want to use (order by, fields to use, etc.)
        print(f'consider_ingested_at={consider_ingested_at}')
        upd_df = None
        upd_del_df = None
        if not consider_ingested_at:
            # print("nav_debug(consider_ingested_at) b4 df:")
            # df.show(10, False)

            # code block for consider_ingested_at = False:
            df, window_spec = sf.get_window_function(df, consider_ingested_at, key, indent)

            if 'updated_at' in df.schema.names:
                # Get the appropriate_min_max based off of delta_columns
                df = sf.min_max_updated_at(df, delta_columns, key, date_col='updated_at')
            else:
                colors.war_print(f"Could not find 'updated_at' in table, skipping min_max_update_at", indent=indent + 1)

            # Get only the top rows
            df = df.withColumn("rn", f.row_number().over(window_spec))

            # print("nav_debug(consider_ingested_at) df:")
            # df.show(10, False)

            upd_df = df.where(f.col("rn") == 2)
            # print("nav_debug(consider_ingested_at) upd_df:")
            # upd_df.show(10, False)

            for col in upd_df.columns:
                upd_df = upd_df.withColumnRenamed(col, 'upd_del_'+col)
            upd_del_df = df.join(upd_df, (df[key]==upd_df['upd_del_'+key]), 'inner').filter(f.col('rn')==1)
            for col in upd_del_df.columns:
                if 'upd_del_' in col:
                    upd_del_df = upd_del_df.drop(col)

            # Capture updates & deletes:
            if 'sv_event_code' in df.columns:
                if upd_del_df != None and upd_del_df.take(1) != [] :
                    upd_del_df = upd_del_df.union(df.filter((f.col('rn')==1) &
                                                            (
                                                                (f.col('ended_at').isNotNull()
                                                                    & ~f.col("ended_at").isin("edm_exempt", "None", "none")
                                                                    &  (f.col('sv_event_code')=='D')) |
                                                                ((f.col("ended_at").isin("edm_exempt", "None", "none")
                                                                        | f.col("ended_at").isNull())
                                                                    &  (f.col('sv_event_code')=='U'))
                                                            ))
                                                  )
                else:
                    upd_del_df = df.filter((f.col('rn') == 1) &
                                           (
                                                   (f.col('ended_at').isNotNull()
                                                        & ~f.col("ended_at").isin("edm_exempt", "None", "none")
                                                        & (f.col('sv_event_code') == 'D')) |
                                                   ((f.col("ended_at").isin("edm_exempt", "None", "none")
                                                            | f.col("ended_at").isNull())
                                                        & (f.col('sv_event_code') == 'U'))
                                           ))

            # print("nav_debug(consider_ingested_at) upd_del_df:")
            # upd_del_df.show(10, False)

            df = df.where(f.col("rn") == 1)

            if 'updated_at' in df.schema.names:
                # After we drop the row, let's update the `updated_at` col with the min_max_updated_at val
                df = df.drop("updated_at").withColumn("updated_at", f.col("mmua_updated_at")).drop("mmua_updated_at")
                upd_del_df = upd_del_df.drop("updated_at").withColumn("updated_at", f.col("mmua_updated_at")).drop("mmua_updated_at")

            # Clean up extra columns
            df = df.drop("etl_source_rank", "updated_at_date").drop('dupeCount').drop("rn")
            upd_del_df = upd_del_df.drop("etl_source_rank", "updated_at_date").drop('dupeCount').drop("rn")
        else:
            # code block for consider_ingested_at = True:

            # print("nav_debug(consider_ingested_at) b4 df:")
            # df.show(10, False)

            df, window_spec = sf.get_window_function(df, consider_ingested_at, key, indent)
            # Process ingested_at
            if 'ingested_at' in df.schema.names:
                # Get the appropriate_min_max based off of delta_columns
                ingested_at_df = sf.min_max_ingested_at(df, delta_columns, key, ingested_at_col='ingested_at')
            else:
                colors.war_print(f"Could not find 'ingested_at' in table, skipping min_max_update_at",
                                 indent=indent + 1)

            # Get only the top rows
            ingested_at_df = ingested_at_df.withColumn("rn", f.row_number().over(window_spec))
            ingested_at_df = ingested_at_df.where(f.col("rn") == 1)

            # After we drop the row, let's update the `ingested_at` col with the min_max_ingested_at val
            '''commenting this line as it is overwriting with max ingested_at & causing issue with subsequent right join
            ingested_at_df = ingested_at_df.drop("ingested_at").withColumn("ingested_at",
                                                                           f.col("mmua_ingested_at")).drop("mmua_ingested_at")
             '''

            # Clean up extra columns
            # ingested_at_df = ingested_at_df.drop('dupeCount').drop("rn")
            print('ingested_at_df\n')
            if 'parent_id' in df.columns:
                ingested_at_df.orderBy(key, ascending=True).select(
                    [key, "parent_id", "ingested_at", "updated_at", "etl_source"]).show(10, False)
            else:
                ingested_at_df.orderBy(key, ascending=True).select(
                    [key, "ingested_at", "updated_at", "etl_source"]).show(10, False)

            # ingested_at_df = ingested_at_df.select([key, 'ingested_at', 'updated_at', 'etl_source', 'delta_hash'])
            ingested_at_df = ingested_at_df.select([key, 'ingested_at', f.col('updated_at').alias('updated_at'),
                                                    'etl_source', 'delta_hash']).drop('ingested_at')

            df = df.drop('ingested_at_date', 'etl_source')
            # key_1 = key + "_1"
            # df = df.withColumnRenamed(key, key_1) \
            #     .withColumnRenamed('ingested_at', 'ingested_at_1') \
            #     .withColumnRenamed('etl_source', 'etl_source_1')
            # df = df.join(ingested_at_df, (df[key_1] == ingested_at_df[key])
            #              & (df['ingested_at_1'] == ingested_at_df['ingested_at']), how='right')
            #navin comment: df = df.join(ingested_at_df, [key, 'ingested_at', 'updated_at'], how='right')
            df = df.join(ingested_at_df, [key, 'updated_at'], how='right')

            ingested_at_df.unpersist()
            # df = df.drop(key_1, 'ingested_at_1', 'etl_source_1')
            df = df.withColumn('ingested_at_date', f.to_date(f.col('ingested_at')))
            print('after join\n')
            if 'parent_id' in df.columns:
                df.orderBy(key, ascending=True).select(
                    [key, "parent_id", "ingested_at", "updated_at", "etl_source"]).show(10, False)
            else:
                df.orderBy(key, ascending=True).select([key, "ingested_at", "updated_at", "etl_source"]).show(10, False)

            if 'updated_at' in df.schema.names:
                # Get the appropriate_min_max based off of delta_columns
                df = sf.min_max_ingested_at_updated_at(df, delta_columns, key, date_col='updated_at',
                                                       ingested_at_date_col='ingested_at_date')

            else:
                colors.war_print(f"Could not find 'updated_at' in table, skipping min_max_update_at", indent=indent + 1)

            # Get only the top rows
            # window_spec = Window.partitionBy(key).orderBy(f.col('etl_source_rank').asc(), f.col('updated_at_date').desc())
            df = df.withColumn("rn", f.row_number().over(window_spec))
            # print("nav_debug(consider_ingested_at) df:")
            # df.show(10, False)

            upd_df = df.where(f.col("rn") == 2)
            # print("nav_debug(consider_ingested_at) upd_df:")
            # upd_df.show(10, False)

            for col in upd_df.columns:
                upd_df = upd_df.withColumnRenamed(col, 'upd_del_'+col)

            # join back with df to get the latest record for that key which indicates Updates/Deletes i.e rn=1
            upd_del_df = df.join(upd_df, (df[key]==upd_df['upd_del_'+key]), 'inner').filter(f.col('rn')==1)
            # print("nav_debug(consider_ingested_at) upd_del_df:")
            # upd_del_df.show(10, False)

            for col in upd_del_df.columns:
                if 'upd_del_' in col:
                    upd_del_df = upd_del_df.drop(col)

            # Capture updates & deletes:
            if 'sv_event_code' in df.columns:
                if upd_del_df != None and upd_del_df.take(1) != [] :
                    upd_del_df = upd_del_df.union(df.filter((f.col('rn')==1) &
                                                            (
                                                                (f.col('ended_at').isNotNull()
                                                                    & ~f.col("ended_at").isin("edm_exempt", "None", "none")
                                                                    &  (f.col('sv_event_code')=='D')) |
                                                                ((f.col("ended_at").isin("edm_exempt", "None", "none")
                                                                        | f.col("ended_at").isNull())
                                                                    &  (f.col('sv_event_code')=='U'))
                                                            ))
                                                  )
                else:
                    upd_del_df = df.filter((f.col('rn') == 1) &
                                           (
                                                   (f.col('ended_at').isNotNull()
                                                        & ~f.col("ended_at").isin("edm_exempt", "None", "none")
                                                        & (f.col('sv_event_code') == 'D')) |
                                                   ((f.col("ended_at").isin("edm_exempt", "None", "none")
                                                            | f.col("ended_at").isNull())
                                                        & (f.col('sv_event_code') == 'U'))
                                           ))

            # print("nav_debug(consider_ingested_at) upd_del_df:")
            # upd_del_df.show(10, False)

            df = df.where(f.col("rn") == 1)

            if 'updated_at' in df.schema.names:
                # After we drop the row, let's update the `updated_at` col with the min_max_updated_at val
                df = df.drop("updated_at").withColumn("updated_at", f.col("mmua_updated_at")).drop("mmua_updated_at")
                upd_del_df = upd_del_df.drop("updated_at").withColumn("updated_at", f.col("mmua_updated_at")).drop("mmua_updated_at")

            # Clean up extra columns
            df = df.drop("etl_source_rank", "updated_at_date", "ingested_at_date").drop('dupeCount').drop("rn")
            upd_del_df = upd_del_df.drop("etl_source_rank", "updated_at_date", "ingested_at_date").drop('dupeCount').drop("rn")

        return df, upd_del_df

    @staticmethod
    def solve_non_conflicting_values(df, key,
                                     cols=None,
                                     none_vals=["edm-881", "edm-494", "edm-1030", "edm-1090", "none", "edm_exempt"],
                                     indent=0):
        """CNCR Replacement"""
        colors.out_print(f"Solving non conflicting values by key={key}", indent)

        if not cols:
            cols = [fi for fi in df.schema.names if fi != key and fi != 'ingested_at']

        colors.out_print(f"cols = {cols}", indent)

        # Null out values
        null_df = df
        for fi in cols:
            null_df = null_df.withColumn(fi,
                                         f.when(f.col(fi).isNull() | f.lower(f.col(fi)).isin(none_vals),
                                                f.lit(None))
                                         .otherwise(f.col(fi))
                                         )

        # Generate a "master_df" col from the first non-null value
        null_df = null_df.withColumn("join_crit", f.col(key))
        master_df = null_df.groupBy("join_crit").agg(  # f.first(key),
            *(f.first(ff, ignorenulls=True).alias(ff + '_master') for ff in cols if ff != key))

        df = df.withColumn("join_crit", f.col(key))

        # Join master to df
        df = df.join(master_df, "join_crit", how="left")

        # colors.out_print("nav_debug df:")
        # df.show(2, False)

        # For each column, if the original value is none, use the master
        for fi in cols:
            df = df.withColumn(fi,
                               f.when((f.col(fi + "_master").isNotNull()) &
                                      (f.col(fi).isNull() | f.lower(f.col(fi)).isin(none_vals)),
                                      f.col(fi + '_master'))
                               .otherwise(f.col(fi))
                               )

        df = df.drop(*(ii for ii in master_df.schema.names if ii != key))
        df = df.drop("join_crit")
        return df

    @staticmethod
    def solve_parent_move(df, pkey='entity_id',
                          skey='persistence_id',
                          date_col='updated_at', end_date=None,
                          return_moves=False,
                          indent=0):
        """If a parent moves, end_date the older record and """

        from datetime import datetime
        from cm_commons.util.safe_count import safe_count

        if not end_date:
            end_date = datetime.now().strftime("%Y-%m-%d")

        # Look at all non-end-dated records
        jdf = df.filter(f.col("ended_at").isin("edm_exempt", "None", "none") | f.col("ended_at").isNull())
        jdf = jdf.withColumn('sv_source_1_0', f.when(f.lower(f.col('etl_source')).startswith('sv'), f.lit('1'))
                                                .otherwise(f.lit('0')))
        # Group by `skey` and get the max updated_at and
        date_pattern = "yyyy-MM-dd HH:mm:ss"
        jdf = jdf.withColumn("join_crit", f.col(skey))
        jdf = jdf.groupBy("join_crit").agg(f.from_unixtime(f.max(f.unix_timestamp(f.col(date_col),
                                                                                  format=date_pattern)),
                                                           date_pattern).alias("max_date"),
                                           f.countDistinct(pkey).alias(f"{pkey}_cardinality"),
                                           f.sum(f.col('sv_source_1_0').cast('int')).alias('sv_source_1_0_sum'))

        # Get the groups where there are multiple pkeys
        jdf = jdf.filter(f.col(f"{pkey}_cardinality") > 1)

        count_mult = jdf.count()
        if count_mult == 0:
            colors.war_print("no pkey duplicates found, returning original df", indent=indent + 1)
            return df, None, None

        colors.suc_print(f"{str(count_mult)} pkey duplicates found", indent=indent + 1)

        df = df.withColumn("join_crit", f.col(skey))
        # Join back to original
        df = df.join(jdf, "join_crit", how='left')

        # If updated_at is not the max date, end_date the record, else keep whatever was there originally
        # or if updated_at is same for the matched records then pick the sv rec as the winner if it exists
        df = df.withColumn("to_be_end_dated",
                           ((f.col("max_date").isNotNull()) &
                           (f.col("max_date") != f.col("updated_at")) &
                           (f.col("ended_at").isin("edm_exempt", "None", "none"))) |
                           ((f.col("max_date").isNotNull()) &
                            (f.col("sv_source_1_0_sum").cast('int') > 0) &
                            ~(f.lower(f.col("etl_source")).startswith('sv')))
                           ).drop("sv_source_1_0_sum")

        df = df.withColumn("ended_at",
                           f.when(f.col("to_be_end_dated"),
                                  f.col("max_date"))
                           .otherwise(f.col("ended_at")))

        count_of_moves = df.filter(f.col("to_be_end_dated")).count()
        if count_of_moves > 0:
            # colors.out_print("to_be_end_dated df:")
            # df.filter(f.col("to_be_end_dated")).show(2, truncate=False)
            colors.saf_print(f"Count of moved_records: {str(count_of_moves)}")

        # Resolve salesforce values on persistence_id
        colors.out_print(f"Solving non conflicting values by pkey={skey}", indent=indent + 1)
        df = Resolver.solve_non_conflicting_values(df=df, key=skey,
                                                   cols=['salesforce_id', 'crm_id', 'job_desc', "client_type_id"],
                                                   none_vals=["edm-881", "edm-494", "edm-1030", "edm-1090", "none",
                                                              "edm_exempt"],
                                                   indent=0)

        # Prepare log df
        colors.out_print(f"Prepare log df..", indent)
        move_cols = ['entity_id', 'persistence_id', 'entity_type_id', 'salesvision_id', 'salesforce_id',
                     'etl_source', 'sv_event_code',
                     'ended_at', 'updated_at', 'created_at', 'maint_moved_at']
        log_df = df.withColumn('maint_moved_at', f.lit(datetime.now().strftime("%Y-%m-%d")))
        log_df = log_df.filter(f.col("to_be_end_dated")).select(move_cols)

        colors.out_print(f"Creating dead_df...", indent)
        dead_df = log_df.select(f.col('entity_id').alias('dead_entity_id'), 'persistence_id', 'entity_type_id')
        # colors.out_print(f"dead_df:")
        # dead_df.show(2, False)

        # get live entities which matched with dead:
        colors.out_print(f"Creating live_df...", indent)
        '''
        live_df = df.filter((f.col("max_date").isNotNull()) &
                            (f.col("max_date") == f.col("updated_at")) &
                            (f.col("ended_at").isin("edm_exempt", "None", "none")))\
                    .select(f.col('entity_id').alias('live_entity_id'), 'persistence_id', 'entity_type_id')
        '''
        live_df = df.filter(~f.col("to_be_end_dated"))\
                    .select(f.col('entity_id').alias('live_entity_id'),
                            f.col('persistence_id').alias('live_persistence_id'),
                            f.col('entity_type_id').alias('live_entity_type_id'))
        colors.out_print(f"live_df:")
        live_df.show(2, False)

        # create dead-live mapper:
        colors.out_print(f"create dead-live mapper...")
        dead_live_map_df = dead_df.join(live_df,
                                        (f.col('persistence_id')==f.col('live_persistence_id')) &
                                        ((f.col('entity_type_id')==f.col('live_entity_type_id')) |
                                         (f.col('entity_type_id').substr(1, 1)
                                          == f.col('live_entity_type_id').substr(1, 1))),
                                        how='inner')\
                                    .drop('live_persistence_id', 'live_entity_type_id')
        dead_live_map_df = dead_live_map_df.select('dead_entity_id', 'live_entity_id',
                                                   f.col('persistence_id').alias('live_pid'),
                                                   f.col('entity_type_id').alias('live_entity_type_id'))

        # Re-parenting children - update children who have old/dead parent with new/live parent:
        colors.out_print(f"join df with dead_live_map_df ...", indent)
        df = df.join(dead_live_map_df, (df['parent_id'] == dead_live_map_df['dead_entity_id']) &
                     (((df['entity_type_id'].substr(1, 1) == '1') &
                       (dead_live_map_df['live_entity_type_id'].substr(1, 1) == '2')) |
                      ((df['entity_type_id'].substr(1, 1) == '2') &
                       (dead_live_map_df['live_entity_type_id'].substr(1, 1) == '3'))),
                     how='left')

        colors.out_print(f"updating dead parents with live parents...", indent)
        df = df.withColumn('parent_id', f.when(f.col('dead_entity_id').isNotNull() &
                                               (f.col('ended_at').isNull() |
                                                (f.col('ended_at') == '') |
                                                f.col("ended_at").isin("edm_exempt", "None", "none")),
                                               f.col('live_entity_id'))
                                            .otherwise(f.col('parent_id')))

        # Drop join columns
        df = df.drop("max_date", f"{pkey}_cardinality", "to_be_end_dated", "join_crit",
                     "dead_entity_id", "live_entity_id", "live_pid", "live_entity_type_id")

        # If return moves is true, return a dataframe
        if return_moves:
            return df, log_df, dead_live_map_df
        else:
            return df, None

    def cascade_entity_move_in_xref(df_name, map_df, df):
            """
            map_df cols: dead_entity_id, live_entity_id,live_pid,live_entity_type_id
            """
            if 'team_xref' not in df_name:
                df = df.join(map_df, df['entity_id'] == map_df['dead_entity_id'], how='left')
                df = df.withColumn('entity_id', f.when(f.col('dead_entity_id').isNotNull(),
                                                       f.col('live_entity_id'))
                                                    .otherwise(f.col('entity_id')))
            else:
                df = df.join(map_df, df['team_entity_id'] == map_df['dead_entity_id'], how='left')
                df = df.withColumn('team_entity_id', f.when(f.col('dead_entity_id').isNotNull(),
                                                       f.col('live_entity_id'))
                                                    .otherwise(f.col('team_entity_id')))

            return df
