from kharybdis.resolve.resolve import Resolver

import pyspark.sql.functions as f
import spark_functions as sf
from cm_commons.db.cm_conn import cm_cxn_jdbc as opt
from cm_commons import colors

from pyspark.sql.types import BooleanType

import spark_functions as sf


class ParentResolver(Resolver):

    def __init__(self, df, anc_df=None, anc_tbl='entity_linked_list_sv_anc', cxn=opt, spark=None, indent=0):

        self.indent = indent
        colors.out_print("Resolving parent_id", indent=self.indent)

        self.df = df

        if not anc_df:
            colors.out_print(f"Reading {anc_tbl} from DB", indent=indent+1)
            self.ancestry_df = spark.read.jdbc(url=cxn['url'], table=anc_tbl, properties=cxn['properties'])

        else:
            self.ancestry_df = anc_df
            colors.tst_print(f"Using test dataset with {anc_df.count()} records", indent=indent+1)

        self.ancestry_df = sf.add_prefix(self.ancestry_df, "anc_")

        self.spark = spark


    @staticmethod
    def join_ancestry(df, ancestry_df):
        """Join ancestry table to entity table"""

        # TODO - joining on salesvision_id for now. Long term will trust persist so that entity_id is correct
        tbl_key = 'salesvision_id'
        anc_key = "anc_salesvision_id"

        sv_df = df.filter(~sf.is_null(col="salesvision_id", null_val=["none", "null", ""]))
        non_sv_df = df.filter(sf.is_null(col="salesvision_id"))



        joined_sv_df = df.join(ancestry_df, (ancestry_df.anc_entity_type_id ==
                                      sv_df.entity_type_id) &
                                      (ancestry_df.anc_salesvision_id ==
                                       sv_df.salesvision_id),
                               how="left_outer"
                               )

        # For null joins (no ancestry), make sure we still join and treat as "non-sv" record
        # TODO - check anc_<pkey>, it's safer
        null_join_df = joined_sv_df.filter(f.col("anc_salesvision_id").isNull())

        for fn in ancestry_df.schema.names:
            null_join_df = null_join_df.drop(fn)

        non_sv_df = non_sv_df.union(null_join_df)

        # Drop the null joins
        joined_sv_df = joined_sv_df.filter(f.col("anc_salesvision_id").isNotNull())

        return joined_sv_df, non_sv_df

    # Can unit test
    @staticmethod
    def assign_valid_parent(sv_df):
        """Assign valid parent if old parent is in lineage"""
        array_contains_col = f.udf(lambda array, id: id in array, returnType=BooleanType())

        # if ancestor parent_path does not contain the new parent, accept the new parrent
        sv_df = sv_df.withColumn("accept_new_parent", ~array_contains_col(f.col("anc_parent_path"),
                                                                          f.col("parent_id")))

        sv_df = sv_df.withColumn("parent_id", f.when(f.col("accept_new_parent"),
                                                     f.col("parent_id")).otherwise(f.col("anc_parent_id")))

        return sv_df

    # Can integration test
    def process(self):
        sv_df, non_sv_df = self.join_ancestry(self.df, self.ancestry_df)

        # Get valid parent_id
        val_df = self.assign_valid_parent(sv_df=sv_df)

        # Drop joined columns and union
        for fn in self.ancestry_df.schema.names:
            val_df = val_df.drop(fn)
        val_df = val_df.drop("accept_new_parent")

        df = val_df.union(non_sv_df)

        return df


