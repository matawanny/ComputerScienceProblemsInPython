from cm_commons.util.system import env
import cm_commons.models.trg_files.target_models as models
import datetime
import pyspark.sql.functions as f
from pprint import pprint
from cm_commons import colors

def create_predicates(table_name):
    dt = datetime.datetime.today()

    if table_name == 'aum':
        #TODO: Find the right lower bound dynamically
        year_lower_bound = 2018
        year_upper_bound = int(dt.year) + 1
        curr_month_upper_bound = int(dt.month) + 1

        predicate_prefix = "EXTRACT(YEAR FROM  as_of_date::date)::text || EXTRACT(MONTH FROM  as_of_date::date)::text ="
        predicate = []

        for yr in range(year_lower_bound, year_upper_bound):
            for mth in range(1, 13):

                if yr == (year_upper_bound - 1) and mth == curr_month_upper_bound-1:
                    break
                predicate.append(predicate_prefix + "'" + str(yr) + str(mth) + "'")
                # print(predicate)

        predicate.append(predicate_prefix + "'" + str(year_upper_bound-1) + str(curr_month_upper_bound-1) + "'")

    if table_name == 'entity':
        predicate = [
            "substring(entity_id, 1,1)  = '0'",
            "substring(entity_id, 1,1)  = '1'",
            "substring(entity_id, 1,1)  = '2'",
            "substring(entity_id, 1,1)  = '3'",
            "substring(entity_id, 1,1)  = '4'",
            "substring(entity_id, 1,1)  = '5'",
            "substring(entity_id, 1,1)  = '6'",
            "substring(entity_id, 1,1)  = '7'",
            "substring(entity_id, 1,1)  = '8'",
            "substring(entity_id, 1,1)  = '9'",
            "substring(entity_id, 1,1) in ('a','g','h','i')",
            "substring(entity_id, 1,1) in ('b','j','k','l')",
            "substring(entity_id, 1,1) in ('c','m','n','o')",
            "substring(entity_id, 1,1) in ('d','p','q','r')",
            "substring(entity_id, 1,1) in ('e','s','t','u','v')",
            "substring(entity_id, 1,1) in ('f','w','x','y','z')"
        ]

    if table_name == 'trade':
        predicate = [
            "substring(agreement_id, 1,1)  = '0'",
            "substring(agreement_id, 1,1)  = '1'",
            "substring(agreement_id, 1,1)  = '2'",
            "substring(agreement_id, 1,1)  = '3'",
            "substring(agreement_id, 1,1)  = '4'",
            "substring(agreement_id, 1,1)  = '5'",
            "substring(agreement_id, 1,1)  = '6'",
            "substring(agreement_id, 1,1)  = '7'",
            "substring(agreement_id, 1,1)  = '8'",
            "substring(agreement_id, 1,1)  = '9'",
            "substring(agreement_id, 1,1) in ('a','g','h','i')",
            "substring(agreement_id, 1,1) in ('b','j','k','l')",
            "substring(agreement_id, 1,1) in ('c','m','n','o')",
            "substring(agreement_id, 1,1) in ('d','p','q','r')",
            "substring(agreement_id, 1,1) in ('e','s','t','u','v')",
            "substring(agreement_id, 1,1) in ('f','w','x','y','z')"
        ]

    # print(predicate)
    return predicate

class Stager:
    """ Staging class for loading intermediary files.
Long term this will become a component of Extract"""
    def __init__(self, spark, conf, cxn, schema):
        self.spark = spark
        self.conf = conf
        self.cxn = cxn
        self.schema = schema

        self.dirs = {}
        self.dfs = {}

    def read_conf(self):
        temp = '{output_location[' + env + ']}'
        dirs_query = [temp.format(**self.conf['etl'])]
        tbls_query = list(getattr(models, self.conf['etl']['target_schema_name']).keys())

        if self.conf['etl'].get("jobid"):
           jobid = self.conf['etl'].get("jobid")
        else:
            jobid = "no-job-id"
        file_query = [f"{self.conf['etl']['file_date']}/{jobid}.parquet"]

        colors.out_print(f"Reading conf: {dirs_query}/.../{file_query}",indent=2)
        #print(f"dirs_query: {dirs_query}")
        #print(f"tbls_query: {tbls_query}")
        #print(f"file_query: {file_query}")
        for tt in tbls_query:
            if tt in self.schema.keys():
                colors.suc_print(f"{tt} parquet found", indent=3)
                self.dirs[tt] = []
                for dd in dirs_query:
                    for ff in file_query:
                        self.dirs[tt].append(dd+tt+'/'+ff)
            else:
                colors.war_print(f"{tt} parquet found, but is not in MDM_schema", indent=3)
        #pprint(self.dirs)
        return self

    def read_client_master(self, prefix, table, s3_folder, date, key, pid):
        colors.out_print("Reading from Client Master...", indent=1)
        table_name = f"{prefix}{table}"
        colors.out_print(f"Checking for {table_name}", indent=2)

        from cm_commons.db.cm_conn import cm_cxn
        import psycopg2
        conn = psycopg2.connect(dbname=cm_cxn['db_name'],
                                user=cm_cxn['user'],
                                host=cm_cxn['location'],
                                password=cm_cxn['password'])
        cur = conn.cursor()
        cur.execute(f"select * from information_schema.tables where table_name='{table_name}_prv'")
        prv_exists = bool(cur.rowcount)

        cur.execute(f"select * from information_schema.tables where table_name='{table_name}'")
        if bool(cur.rowcount):
            if prv_exists:
                colors.out_print(f"Dropping {table_name}_prv",indent=2)
                cur.execute(f"drop table {table_name}_prv")
                conn.commit()

            colors.out_print(f"Copying {table_name} to {table_name}_prv", indent=2)
            cur.execute(f"create table {table_name}_prv as SELECT * FROM {table_name}")
            conn.commit()

            colors.out_print(f"Loading {table} from client master", indent=2)

            if table not in ['entity', 'trade', 'aum']:
                self.dfs[table] = self.spark.read.jdbc(url=self.cxn['url'],
                                                       table=table_name,
                                                       properties=self.cxn['properties'])
            else:
                colors.out_print(f"Loading {table} from client master using custom paritioning", indent=2)
                pred = create_predicates(table)
                if table == 'aum':
                    colors.out_print("Following buckets(yyyyM) will be loaded:")
                    buckets = [(p[p.find('\'') + 1:-1]) for p in pred]
                    print(buckets)

                self.dfs[table] = self.spark.read.jdbc(url=self.cxn['url'],
                                                        table=table_name,
                                                        properties=self.cxn['properties'],
                                                        predicates = pred)

            addr = f"{s3_folder}/{date}/{pid}/{key}/{table}.parquet"
            colors.out_print(f"Caching {table} after db read to {addr}")
            self.dfs[table].write.mode("overwrite").parquet(addr)
            self.dfs[table] = self.spark.read.parquet(addr)

            colors.out_print(f"Number of partitions for {table}={self.dfs[table].rdd.getNumPartitions()}")

            colors.out_print(f"Dropping non-essential columns in self.dfs[{table}]", indent=2)
            df = self.dfs[table]
            df = df.drop(*[k for k in df.columns if
                           k in [ "etl_source", "enriched_at", "error", "tds_master",
                                 "nullability_error", "typecast_error"]])
            self.dfs[table] = df

            # If we fill all schema column null values with edm_exmempt, it will allow any cm record to repass all
            # validity rules without source specific knowledge
            self.dfs[table] = self.dfs[table].fillna('edm_exempt', subset=self.dfs[table].schema.names)
            self.dfs[table] = self.dfs[table].withColumn('etl_source', f.lit('cm'))
            self.dfs[table] = self.dfs[table].withColumn('enriched_at', f.current_timestamp())

        else:
            colors.err_print(f"Could not find {table_name} in client master", indent=3)
            self.dfs[table] = []
        cur.close()

        return self

    def read_parquet(self):
        """ Read spark """

        colors.out_print("Loading parquet files", indent=3)
        for tt in list(self.dirs.keys()):
            if tt in self.schema.keys():
                colors.suc_print(f"Loading {tt} parquet files", indent=4)

                self.dfs[tt] = self.spark.read.load(self.dirs[tt])
                self.dfs[tt].cache()
                self.dfs[tt] = self.dfs[tt].withColumn('etl_source', f.lit(self.conf['etl']['source_name']))
                self.dfs[tt] = self.dfs[tt].withColumn('enriched_at', f.current_timestamp())
                self.dfs[tt] = self.dfs[tt].fillna('None', subset=self.dfs[tt].schema.names)
            else:
                colors.war_print(f"{tt} not in MDM_schema, not loading parquet files", indent=4)
        return self

    def stage(self):
        """ Executor function """
        self.read_conf()
        self.read_parquet()

        return self

    def process(self):
        self.stage()
        return self

