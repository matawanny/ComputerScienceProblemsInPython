import json, os, time, calendar
from collections import defaultdict
from pprint import pprint
from urllib.parse import urlparse
import hashlib
from datetime import datetime

import boto3
import pyspark.sql.functions as f

import cm_commons
import kharybdis
import skylla
from circe import process_ds
from cm_commons import colors, conf
from cm_commons.spark import build_session
from cm_commons.util.boto_functions import get_s3_bucket, delete_s3_folder
from cm_commons.util.jobstatus import getTime
from cm_commons.util.safe_count import safe_count, SC_CONST
from cm_commons.util.system import env
from skylla.load import MDMLoader


def union_all(dfs):
    df_left = dfs[0]
    if len(dfs) > 1:
        df_right = union_all(dfs[1:])
        # columns not in df_left
        for ii in list(set(df_right.columns) - set(df_left.columns)):
            colors.err_print(f' Missing {ii} from left', indent=3)
            df_left = df_left.withColumn(ii, f.lit('None'))
        # columns not in df_rightm
        for jj in set(df_left.columns) - set(df_right.columns):
            colors.err_print(f' Missing {jj} from right', indent=3)
            df_right = df_right.withColumn(jj, f.lit('None'))
        df_left = df_left.select(df_right.columns)
        return df_left.unionAll(df_right)
    else:
        return df_left


class MDM:
    def __init__(self, conf, cxn, move_flag=True):

        self.conf = conf
        self.conf['environment'] = env
        self.move_flag = move_flag

        self.etl_conf_locs = []
        self.etl_job_ids = []

        self.etl_confs = self.get_source_confs()

        self.env = env
        self.spark = build_session(app_name=self.conf['mdm_name'])

        self.schema = getattr(cm_commons.models.trg_files, conf['schema_name'])
        self.cxn = cxn

        self.stager = kharybdis.Stager
        self.persister = kharybdis.Persister
        self.loader = skylla.load.MDMLoader

        self.cncr = kharybdis.CNCR
        self.validater = kharybdis.Validater

        self.dfs = {}
        self.resolve_params = {}

        self.pid = str(os.getpid())
        self.run_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        md5_param = f"{str(self.pid)}_{str(self.run_date)}"
        # self.audit_log_id = hashlib.md5(str(md5_param).encode('utf-8')).hexdigest()
        self.audit_log_id = str(calendar.timegm(time.gmtime()))



    def get_source_confs(self):
        o = urlparse(self.conf['input_location'][env])
        s3 = boto3.resource('s3')
        objs = s3.Bucket(o.netloc).objects.filter(Prefix=o.path[1:])
        confs = []

        for oo in objs:
            if oo.key.endswith('.json') or oo.key.endswith('.conf') or oo.key[-1].isdigit():
                # try:
                colors.out_print(f"Reading {oo.key}", indent=1)
                obj = s3.Object(o.netloc, oo.key)
                conf = json.loads(obj.get()['Body'].read().decode('utf-8'))

                jobid = conf.get("job-id")

                self.etl_job_ids.append(jobid)
                self.etl_conf_locs.append(f"s3://{o.netloc}/{oo.key}")
                jobdata = {
                    'jobid': jobid if jobid else "no-job-id",
                    'clmaster_mdm_start': getTime(),
                }
                # logCmJob(**jobdata)

                confs.append({'etl': conf})
                # except Exception as e:
                #    colors.err_print(f"Failed to read {oo.key}", indent=1)
                #    print(e)
                #    raise e

        print(f"\t{colors.colors['white']}")
        pprint(confs)
        print(f"\t{colors.colors['reset']}")
        pprint(self.etl_conf_locs)

        return confs

    def stage_incoming(self):
        colors.out_print("Staging Incoming", indent=0)
        colors.out_print("Loading from post-ETL confs", indent=1)
        for cc in self.etl_confs:
            stg = self.stager(spark=self.spark, conf=cc, cxn=self.cxn, schema=self.schema).process()
            for kk in stg.dfs:
                # colors.out_print(f" stg.dfs[{kk}]={stg.dfs[kk]}")
                # Adds new entry or appends to existing one
                if kk not in self.dfs.keys():
                    self.dfs[kk] = []
                self.dfs[kk].append(stg.dfs[kk])
        # self.dfs.setdefault(kk, []).append(stg.dfs[kk])

        colors.out_print("Unioning all", indent=1)
        temp_dfs = {}
        for tt in self.dfs:
            colors.out_print(f"Performing union for {len(self.dfs[tt])} sources for {tt}", indent=2)
            temp_tt = union_all(self.dfs[tt])
            record_count = safe_count(temp_tt)
            if record_count == SC_CONST:
                colors.saf_print(f"Ignoring record count", indent=3)
                temp_dfs[tt] = temp_tt
            elif record_count > 0:
                temp_dfs[tt] = temp_tt
                colors.suc_print(f"{record_count} records added", indent=3)
            else:
                colors.war_print(f"{record_count} records in {tt}, removing table from set", indent=3)
        self.dfs = temp_dfs
        return self

    def resolve_parent(self):
        """ For incoming records, see if we've seen this record before and correct parent if needed"""
        from kharybdis.resolve import ParentResolver

        if 'entity' in self.dfs:
            colors.out_print("Resolving entity parent", indent=0)
            colors.saf_print(f"{self.dfs['entity'].count()} reccrds in entity before", indent=1)

            res = ParentResolver(self.dfs['entity'], spark=self.spark, indent=1).process()
            self.dfs['entity'] = self.dfs['entity']

            colors.saf_print(f"{self.dfs['entity'].count()} reccrds in entity after", indent=1)

        else:
            colors.war_print("Not resolving entity parent", indent=0)

    def stage_cm(self):
        colors.out_print("Staging Client Master", indent=0)
        for table in self.dfs:
            stg = self.stager(spark=self.spark,
                              conf=None,
                              cxn=self.cxn,
                              schema=self.schema).read_client_master(prefix=self.conf['prefix'],
                                                                     table=table,
                                                                     s3_folder=f's3://{get_s3_bucket()}/cache',
                                                                     date=self.conf["file_date"],
                                                                     key=f'{self.conf["prefix"]}mdm-post-db-read',
                                                                     pid=self.pid)

            if (table in stg.dfs.keys()) and stg.dfs[table]:
                colors.suc_print(f"{safe_count(stg.dfs[table], count_bool=True, dummy_str=True)} "
                                 f"records for {table} from Client Master", indent=2)
                self.dfs[table] = [self.dfs[table], stg.dfs[table]]
                colors.out_print("Unioning all", indent=1)
                temp_tb = self.dfs[table]
                colors.out_print(f"Unioning client master {table} to incoming ", indent=2)
                temp_tt = union_all(self.dfs[table])
                record_count = safe_count(temp_tt, count_bool=True)  # need to count so we can remove blank sets
                if record_count == SC_CONST:
                    temp_tb = temp_tt
                    colors.saf_print(f"Ignored record count", indent=3)
                if record_count > 0:
                    temp_tb = temp_tt
                    colors.suc_print(f"{record_count} records added", indent=3)
                else:
                    colors.war_print(f"{record_count} records in {table}, removing table from set", indent=3)
                self.dfs[table] = temp_tb

                if record_count > 0:
                    colors.out_print(f"Number of partitions for unioned-{table} df"
                                     f" = {self.dfs[table].rdd.getNumPartitions()}")
            else:
                colors.war_print(f"0 records for {table} from Client Master", indent=2)

        return self

    def cast_as_string(self):
        colors.out_print("Casting all as STRING", indent=0)
        for tt in self.dfs:
            for cid in self.dfs[tt].columns:
                self.dfs[tt] = self.dfs[tt].withColumn(cid, self.dfs[tt][cid].cast("String"))
        return self

    def replace_null(self):
        colors.out_print("Replacing null with None", indent=0)
        for tt in self.dfs:
            self.dfs[tt] = self.dfs[tt].fillna("None")
        return self

    def get_rules(self):
        #TODO: need to generate rules automatically from data models for each dataframe in self.dfs
        rules = defaultdict(lambda: ('updated_at', 'etl_source'))
        rules.update({
            'entity_name': ('updated_at', 'etl_source'),
            'salesvision_id': ('etl_source', 'updated_at'),
        })

        self.resolve_params['entity'] = {'rules': rules,
                                         'source_rankings': defaultdict(lambda: {'SF_Entity': 1, 'cm': 2}),
                                         'pkey': 'entity_id',
                                         'source_col': 'etl_source'}

    def persist(self, indent=0):
        """ Enrich each table """

        from kharybdis import Persister
        from cm_commons.db.cm_conn import cm_cxn_jdbc

        # EDM-2120 - always include entity in the persist rules
        # TODO - generate this list from the schema
        persist_tbls = {tt: f"{self.conf['prefix']}persist_rules_{tt}" for tt in self.dfs.keys()}
        persist_tbls['entity'] = f"{self.conf['prefix']}persist_rules_entity"

        colors.out_print(f"Persisting...", indent=indent)
        self.dfs = Persister(dfs=self.dfs, schema=self.schema,
                             persist_dfs=None, persist_cxn=cm_cxn_jdbc,
                             persist_tbls=persist_tbls,
                             spark=self.spark,
                             s3_folder=f's3://{get_s3_bucket()}/cache',
                             date=self.conf["file_date"],
                             key=f'{self.conf["prefix"]}mdm-persist-rules-db-read',
                             pid=self.pid,
                             indent=1).process().dfs

        return self

    def resolve(self, indent=0):
        """ Resolve field level collisions """

        colors.out_print(f"Resolving...", indent=indent)

        colors.out_print(f"Resolving `parent_id`", indent=indent+1)
        kharybdis.ParentResolver(df=self.dfs['entity'], spark=self.spark, indent=indent+2).process()

        # for tt in self.resolve_params:
        #    self.dfs[tt] = resolve_pkey_collision(self.spark, self.dfs[tt], **self.resolve_params[tt])

    def combine(self):
        ''' Not used any more. Replaced by combine_non_conflicting_values()'''
        self.cncr = kharybdis.CNCR(self.spark, self.dfs, self.schema, self.conf)
        colors.out_print("Combining non-conflicting records...", indent=0)
        self.dfs = self.cncr.process().dfs
        return self

    def add_remove_entity_type_prefix(self, add):
        if add:
            colors.out_print("Adding entity_type_prefix column...", indent=0)
            for df_name in self.dfs.keys():
                df = self.dfs[df_name]
                if 'entity_type_id' in df.columns:
                    statement = [("301", "3"), ("302", "3"), ("303", "3"), ("304", "3"), ("305", "3")]
                    in_col = 'entity_type_id'
                    out_col = 'entity_type_prefix'
                    default = f.col("entity_type_id")
                    import spark_functions as sf
                    df = sf.switch_case_2(df, in_col, out_col, statement, default)
                    self.dfs[df_name] = df
        else:
            colors.out_print("Removing entity_type_prefix column...", indent=0)
            for df_name in self.dfs.keys():
                df = self.dfs[df_name]
                if 'entity_type_prefix' in df.columns:
                    df = df.drop('entity_type_prefix')
                    self.dfs[df_name] = df
        return self

    def exact_match_old(self):
        self.cncr = kharybdis.CNCR(self.spark, self.dfs, self.schema, self.conf)
        colors.out_print("Performing exact match...", indent=0)
        # match_criteria = ["salesvision_id", "entity_type_id"]
        match_criteria = self.conf['match_criteria']  # ['crm_id']
        self.dfs = self.cncr.process_exact_match_old(match_criteria).dfs
        return self

    def exact_match(self):
        colors.out_print("Performing exact_match...", indent=0)
        from kharybdis import CNCR
        for df_name in self.dfs.keys():
            self.dfs[df_name] = CNCR.process_exact_match(self.dfs[df_name],
                                                         df_name,
                                                         self.schema[df_name]["primaryKey"][0]["table"],
                                                         self.conf['match_criteria'],
                                                         self.conf['match_source'].lower())
        return self

    def validate(self):
        colors.out_print("Validating...", indent=0)
        for tt in self.dfs:
            colors.out_print("Validating {}".format(tt), indent=1)
            self.dfs[tt] = self.validater(df=self.dfs[tt],
                                          table=tt,
                                          conf=self.conf,
                                          schema=self.schema[tt],
                                          spark=self.spark).process().df
            null_count = safe_count(self.dfs[tt].filter(f.col('nullability_error').isin(['Error'])), dummy_str=True)
            type_count = safe_count(self.dfs[tt].filter(f.col('typecast_error').isin(['Error'])), dummy_str=True)
            vali_count = safe_count(self.dfs[tt].filter(~(f.col('nullability_error').isin(['Error']) |
                                                          f.col('typecast_error').isin(['Error']))), dummy_str=True)

            colors.out_print(f"{null_count} of null records captured", indent=4)
            colors.out_print(f"{type_count} of type records captured", indent=4)
            colors.out_print(f"{vali_count} of valid records captured", indent=4)

        return self

    def load(self, dest="client_master", cache_bool=True):
        if cache_bool:
            self.cache_all()

        colors.out_print("Loading...", indent=0)
        x_fields = {'etl_source': {'encrypted': 'None', 'nullable': True, 'type': 'String'},
                    'enriched_at': {'encrypted': 'None', 'nullable': True, 'type': 'String'},
                    'error': {'encrypted': 'None', 'nullable': True, 'type': 'String'},
                    'tds_master': {'encrypted': 'None', 'nullable': True, 'type': 'String'},
                    'nullability_error': {'encrypted': 'None', 'nullable': True, 'type': 'String'},
                    'typecast_error': {'encrypted': 'None', 'nullable': True, 'type': 'String'}}

        self.loader = MDMLoader(out_df=self.dfs,
                                schema=self.schema,
                                conf=self.conf, x_cols=x_fields,
                                cxn=self.cxn,
                                dest=dest,
                                spark=self.spark)
        self.loader.process()
        return self

    def cache_all(self):
        """ Caches all dataframes"""
        for tt in self.dfs:
            self.dfs[tt].cache()

        return self

    def filter_out(self, switch):
        if switch == "dupe":
            colors.out_print("Filtering out duplicate records from CNCR", 0)
            for tt in self.dfs:
                colors.out_print(f"Filtering {tt}", indent=1)

                df = self.dfs[tt]
                num_records_pre = safe_count(df, dummy_str=True)
                colors.out_print(f"{num_records_pre} records before", indent=2)

                if 'tds_master' in df.schema.names:
                    df = df.filter(
                        df['tds_master'].isin(['true']) |  # filter include exact match records
                        df['tds_match_yn'].isin(['n'])  # filter include non-matched records
                    )
                num_records_post = safe_count(df)

                if (num_records_post == SC_CONST) or (num_records_post == SC_CONST):
                    colors.saf_print(f"Ignored count for either pre or post filter", indent=2)
                else:
                    if num_records_post > 0:
                        colors.out_print(f"{num_records_pre-num_records_post} removed", indent=2)
                        colors.out_print(f"{num_records_post} records left after filter", indent=2)
                    else:
                        colors.war_print(f"{num_records_post} records left after filter", indent=2)
                self.dfs[tt] = df

        return self

    def write_read_reset(self, s3bucket=f's3://{get_s3_bucket()}/cache', date='today', key='something'):
        """ Write to S3, Read from S3, refreshes catalyst
            |  https://stackoverflow.com/questions/50891509/apache-spark-codegen-stage-grows-beyond-64-kb
        """
        for table in self.dfs:
            addr = f"{s3bucket}/{date}/{self.pid}/{key}/{table}.parquet"

            colors.out_print(f"Number of partitions before caching for {table} df"
                             f" = {self.dfs[table].rdd.getNumPartitions()}")
            colors.out_print(f"Caching to {addr}", indent=0)
            self.dfs[table].write.mode("overwrite").parquet(addr)

            self.dfs[table] = self.spark.read.parquet(addr)
            colors.out_print(
                f"Number of partitions after caching for {table} df "
                f"= {self.dfs[table].rdd.getNumPartitions()}")
            if self.dfs[table].rdd.getNumPartitions() < 3000:
                self.dfs[table] = self.dfs[table].repartition(3000)
                colors.out_print(f"Repartitioned {table} df to {self.dfs[table].rdd.getNumPartitions()}")

        return self

    def run_circe_process_ds(self):
        """ Run circe process_ds """
        ds_mastered_output_dir = f's3://{get_s3_bucket()}/etl-output/circe/exact_match_ds/'
        ds_conf_output_dir = f's3://{get_s3_bucket()}/MDM/conf/circe_incoming/'
        # conf_location = f's3://{get_s3_bucket()}/conf/source-files/DS/process_ds_conf_ENTITY_FULL.json'

        if self.conf['prefix'] == "":
            prefix = ""
        else:
            prefix = self.conf['prefix'][:-1]

        # Edit conf programmatically if necessary to include/exclude items in TABLES_LIST and PKEY_FKEY_MAPPINGS:
        circe_conf_dict = conf.circe_conf

        process_ds.start_process(circe_conf_dict=circe_conf_dict, table_prefix=prefix,
                                 src_db_name='edmcm', target_db_name='edmcm',
                                 ds_mastered_output_dir=ds_mastered_output_dir, ds_conf_output_dir=ds_conf_output_dir)

    def reduce_by_pkey(self):
        colors.out_print("Reducing by primary key", indent=0)
        from kharybdis import Resolver
        #from kharybdis.resolve.resolve import Resolver
        for tt in self.dfs:
            colors.out_print(f"Reducing {tt} by {self.schema[tt]['primaryKey'][0]['field']}", indent=1)
            bad_fields = ['updated_at', 'etl_source', 'enrichment_error', 'tds_master', 'typecast_error', 'record_id',
                          'err_msg']
            good_fields = list(set(self.schema[tt]['fields']) - set(bad_fields))
            refined_good_fields = [x for x in good_fields if x in self.dfs[tt].columns]
            colors.bug_print(f"Determing delta by {str(good_fields)}", indent=1)

            upd_df = None
            if self.dfs[tt] is None or len(self.dfs[tt].take(1)) == 0:
                continue
            self.dfs[tt], upd_df = Resolver.solve_key_collision(df=self.dfs[tt],
                                                        key=self.schema[tt]['primaryKey'][0]['field'],
                                                        delta_columns=refined_good_fields,
                                                        indent=1)
            if upd_df != None and 'entity' in tt:
                table_name = f"{self.conf['prefix']}{tt}_audit_log"

                for col in upd_df.columns:
                    if col in ['enrichment_error', 'edm_orig', 'group_name', 'tds_id', 'group_count', 'tds_match_yn']:
                        upd_df = upd_df.drop(col)

                if 'typecast_error' in upd_df.columns:
                    upd_df = upd_df.withColumn('typecast_error', f.when(f.col('typecast_error').isNotNull(),
                                                            f.col('typecast_error')).otherwise(f.lit(' ')))
                else:
                    upd_df = upd_df.withColumn('typecast_error', f.lit(' '))

                if tt == 'entity':
                    if 'tds_master' in upd_df.columns:
                        upd_df = upd_df.withColumn('tds_master', f.when(f.col('tds_master').isNotNull(),
                                                            f.col('tds_master')).otherwise(f.lit(' ')))
                    else:
                        upd_df = upd_df.withColumn('tds_master', f.lit(' '))
                else:
                    if 'nullability_error' in upd_df.columns:
                        upd_df = upd_df.withColumn('nullability_error', f.when(f.col('nullability_error').isNotNull(),
                                                            f.col('nullability_error')).otherwise(f.lit(' ')))
                    else:
                        upd_df = upd_df.withColumn('nullability_error', f.lit(' '))

                if 'etl_source' in upd_df.columns:
                    upd_df = upd_df.withColumn('etl_source',
                                               f.when(f.lower(f.col('etl_source')).startswith('sf'), f.lit('sf'))
                                                .when(f.lower(f.col('etl_source')).startswith('sv'), f.lit('sv'))
                                                .otherwise(f.lower(f.col('etl_source'))))
                else:
                    upd_df = upd_df.withColumn('etl_source', f.lower(f.col('etl_source')))

                upd_df = upd_df.withColumn('sv_event_code', f.lit('U'))

                if 'ended_at' in upd_df.columns:
                    upd_df = upd_df.withColumn('sv_event_code',
                                                 f.when(f.col('ended_at').isNotNull()
                                                        & ~f.col('ended_at').isin('None', 'edm_exempt'),
                                                        f.lit('D'))
                                                 .otherwise(f.col('sv_event_code'))
                                                 )

                upd_df = upd_df.replace(['None','edm_exempt'], [None, None])

                colors.out_print(f"Writing updated/deleted records to {table_name}", indent=2)
                print("nav_debug (U/D) upd_df:")
                upd_df.show(10, False)

                upd_df = upd_df.withColumn('audit_log_id', f.lit(self.audit_log_id))
                upd_df = upd_df.distinct()

                upd_df.write.jdbc(url=self.cxn['url'], table=table_name, mode="append",
                                  properties=self.cxn['properties'])

        return self

    def solve_parent(self):
        from kharybdis import Resolver

        dead_live_map_df = None

        for tt in self.dfs:

            if tt == 'entity':
                colors.out_print(f"Solving parent in  {tt} by {self.schema[tt]['primaryKey'][0]['field']}", indent=1)

                self.dfs[tt], log_df, dead_live_map_df = Resolver.solve_parent_move(df=self.dfs[tt],
                                                                  pkey='entity_id',
                                                                  skey='persistence_id',
                                                                  date_col='updated_at',
                                                                  end_date=None,
                                                                  return_moves=True)

                if log_df != None:
                    table_name = f"{self.conf['prefix']}log_entity_moves"
                    colors.out_print(f"Writing moved records to {table_name}", indent=2)
                    log_df.write.jdbc(url=self.cxn['url'], table=table_name, mode="overwrite", properties=self.cxn['properties'])

                if dead_live_map_df != None:
                    colors.out_print(f"Sample of dead_live_map_df:")
                    dead_live_map_df.show(10, False)
                    # dead_live_map_df.write.jdbc(url=self.cxn['url'], table='dead_live_map_df', mode="append", properties=self.cxn['properties'])


        for df_name in self.dfs:
            if 'xref' in df_name and dead_live_map_df != None:
                if any('entity_id' in field for field in self.schema[df_name]['fields'].keys()):
                    colors.out_print(f"Cascading entity moves in {df_name} table", indent=1)
                    self.dfs[df_name] = Resolver.cascade_entity_move_in_xref(df_name=df_name, map_df=dead_live_map_df, df=self.dfs[df_name])


        return self

    def combine_non_conflicting_values(self):
        colors.out_print("Reducing by primary key", indent=0)
        from kharybdis import Resolver
        for tt in self.dfs:
            colors.out_print(f"Combining {tt} by {self.schema[tt]['primaryKey'][0]['field']}", indent=1)
            self.dfs[tt] = Resolver.solve_non_conflicting_values(df=self.dfs[tt],
                                                                 key=self.schema[tt]['primaryKey'][0]['field'],
                                                                 none_vals=["edm-881", "edm-494",
                                                                            "edm-1030", "edm-1090",
                                                                            "none", "edm_exempt"],
                                                                 indent=1)
        return self


    def move_confs_to(self, source, target):
        if self.move_flag:
            from cm_commons.util.boto_functions import move_conf_along
            new_locs = []
            for cf in self.etl_conf_locs:
                new_locs.append(move_conf_along(cf, currentstep=source, nextstep=target))
            self.etl_conf_locs = new_locs
        else:
            colors.war_print("self.move_flag is OFF, files remaining in incoming", indent=0)

    def restore_from_backup(self, prefixed_table_name):
        """Restore _prv table to maing"""
        table_name = prefixed_table_name
        colors.out_print(f"Restoring {table_name} from backup", indent=0)
        from cm_commons.db.cm_conn import cm_cxn
        import psycopg2
        conn = psycopg2.connect(dbname=cm_cxn['db_name'],
                                user=cm_cxn['user'],
                                host=cm_cxn['location'],
                                password=cm_cxn['password'])
        cur = conn.cursor()
        cur.execute(f"select * from information_schema.tables where table_name='{table_name}'", (table_name,))
        tbl_exists = bool(cur.rowcount)

        cur.execute(f"select * from information_schema.tables where table_name='{table_name}_prv'", (table_name,))
        prv_exists = bool(cur.rowcount)

        cur.execute("select * from information_schema.tables where table_name=%s", (table_name,))
        if bool(cur.rowcount):
            if tbl_exists:
                if prv_exists:
                    colors.suc_print(f"Found valid {table_name}_prv and {table_name}", indent=2)
                    colors.out_print(f"Dropping {table_name}", indent=3)
                    cur.execute(f"drop table {table_name}")
                    conn.commit()

                    colors.out_print(f"Copying {table_name}_prv to {table_name}", indent=3)
                    cur.execute(f"create table {table_name} as SELECT * FROM {table_name}_prv")
                    conn.commit()

                    colors.out_print(f"Removing {table_name}_prv", indent=3)
                    cur.execute(f"drop table {table_name}_prv")
                    conn.commit()
                else:
                    colors.suc_print(f"No {table_name}_prv", indent=2)
                    colors.out_print(f"Dropping {table_name}", indent=3)
                    cur.execute(f"drop table {table_name}")
                    conn.commit()
            else:
                colors.war_print(f"Attempted to drop {table_name}, but it didn't exist", indent=2)

    def enrich_amg(self):
        colors.war_print(f"Enriching AMG from prod_id -> full_id", indent=0)
        from skylla.enrich.enrich import Single_Enricher
        from skylla.enrich.ref_ref import amg_salesforce_id_reverse

        self.dfs['entity'] = Single_Enricher(rules=[amg_salesforce_id_reverse],
                                             df=self.dfs['entity'],
                                             table='entity').process().df


    def generate_audit_log(self):
        from kharybdis.audit_log.audit_logger import AuditLogger

        colors.out_print("Generating data for audit log tables...", indent=0)

        for df_name in self.dfs:
            if 'entity' in df_name:
                self.dfs[df_name] = AuditLogger.generate_audit_log(self.spark, self.cxn, self.conf,
                                                                   self.schema[df_name],
                                                              self.dfs[df_name], df_name,
                                                              s3_folder=f's3://{get_s3_bucket()}/cache',
                                                              key=f'{self.conf["prefix"]}mdm-pre-audit-log-inserts',
                                                              pid = self.pid, audit_log_id = self.audit_log_id
                                                              )

        colors.out_print("Completed generating data for audit log tables", indent=0)
        return self

    def process(self):
        self.move_confs_to(source="incoming", target="active")

        colors.out_print(f"PID= {self.pid}, run_date={self.run_date}, audit_log_id={self.audit_log_id}")

        # Stage Incoming Files
        try:
            self.stage_incoming()
            # self.write_read_reset(date=self.conf["file_date"], key=f'pre_persist')
            # for tt in self.dfs:
            #     colors.bug_print(f"{tt} COUNT BEFORE PERSIST: {str(self.dfs[tt].count())}")
            self.persist()
            self.write_read_reset(date=self.conf["file_date"], key=f'{self.conf["prefix"]}mdm-post-persist')
            #
            # for tt in self.dfs:
            #     colors.bug_print(f"{tt} COUNT AFTER PERSIST: {str(self.dfs[tt].count())}")
            #self.resolve_parent()

        except Exception as e:
            colors.err_print("Staging incoming files failed, moving ETL confs to error bucket")
            self.move_confs_to(source="active", target="error")
            raise e

        try:
            self.cast_as_string()
            self.replace_null()

            self.stage_cm()
            self.cast_as_string()
            self.replace_null()
            #self.write_read_reset(date=self.conf["file_date"], key=f'persist_check')
            #self.combine()
            # self.write_read_reset(date=self.conf["file_date"], key=f'{self.conf["prefix"]}mdm-post-ncr')

            self.combine_non_conflicting_values()

            # self.write_read_reset(date=self.conf["file_date"], key=f'{self.conf["prefix"]}mdm-pre-ncr')
            self.reduce_by_pkey()

            self.write_read_reset(date=self.conf["file_date"], key=f'{self.conf["prefix"]}mdm-post-reduce-by-pkey')
            self.solve_parent()
            self.write_read_reset(date=self.conf["file_date"], key=f'{self.conf["prefix"]}mdm-post-solve-parent')
            self.add_remove_entity_type_prefix(add=True)
            self.exact_match()
            self.add_remove_entity_type_prefix(add=False)

            self.load(dest="deduplication", cache_bool=False)
            self.filter_out(switch="dupe")

            self.write_read_reset(date=self.conf["file_date"], key=f'{self.conf["prefix"]}mdm-pre-val')
            self.validate()
            self.write_read_reset(date=self.conf["file_date"], key=f'{self.conf["prefix"]}mdm-post-val')
        except Exception as e:
            colors.err_print("Procesing failed, moving ETL confs to error bucket")
            self.move_confs_to(source="active", target="error")
            raise e

        # self.enrich_amg()

        # Validation
        try:
            self.load(dest="validation", cache_bool=False)
        except Exception as e:
            colors.err_print("Procesing failed during validation load,"
                             "unstaging validation changes and moving ETL confs "
                             "to error bucket")
            self.move_confs_to(source="active", target="error")
            for tt in self.dfs:
                self.restore_from_backup(prefixed_table_name=f"{self.conf['prefix']}_{tt}_resolution")
            raise e

        try:
            self.load(dest="mastered", cache_bool=False)
        except Exception as e:
            colors.err_print("Procesing failed during mastered load,"
                             "unstaging mastered changes and moving ETL confs "
                             "to error bucket")
            self.move_confs_to(source="active", target="error")
            for tt in self.dfs:
                self.restore_from_backup(prefixed_table_name=f"{self.conf['prefix']}_{tt}")

            raise e

        try:
            self.generate_audit_log()
        except Exception as e:
            colors.err_print("Procesing failed during generate_audit_log"
                             "unstaging all changes and moving ETL confs "
                             "to error bucket")
            self.move_confs_to(source="active", target="error")
            raise e

        try:
            self.run_circe_process_ds()
        except Exception as e:
            colors.err_print("Procesing failed during circe"
                             "unstaging all changes and moving ETL confs "
                             "to error bucket")
            self.move_confs_to(source="active", target="error")
            raise e

        self.move_confs_to(source="active", target="done")
        delete_s3_folder(f's3://{get_s3_bucket()}/cache/{self.conf["file_date"]}/{self.pid}')


        for jid in self.etl_job_ids:
            jobdata = {
                'jobid': jid if jid else "no-job-id",
                'clmaster_mdm_start': getTime(),
            }
            # logCmJob(**jobdata)

        return self

    def print_doc(self):
        """ Prints docstrings """

        print(self.loader.__doc__)
