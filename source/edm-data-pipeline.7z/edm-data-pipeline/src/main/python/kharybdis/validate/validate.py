from cm_commons.spark import get_spark
import pyspark.sql.functions as f
import spark_functions as sf
from cm_commons import colors
from sqlalchemy import Boolean, DateTime, Integer, String, Float


class Validater:
    """
# #---------------------------------------------------------------# #
# #                             Validate                          # #
# #---------------------------------------------------------------# #
    """

    def __init__(self, df, table, conf, schema, spark):
        self.df = df
        self.table = table
        self.conf = conf
        self.schema = schema
        self.spark = spark
        self.obj = df
        self.df = df
        colors.out_print(f"validate_nulls(), self.schema[fields]={self.schema['fields']}")

    def validate_nulls(self):
        """ Validate nulls"""
        # get all etl_source types
        null_set = {}
        for fn in self.schema['fields']:
            # TODO - remove this if, all fields should be represented
            if fn in self.obj.schema.names:
                for etl_source in self.schema['fields'][fn]['required']:
                    if etl_source not in null_set:
                        null_set[etl_source] = [fn]
                    else:
                        null_set[etl_source].append(fn)
        # add column as null concatenate per source
        # TODO - for validity
        # self.obj.withColumn("null_ds", f.array())
        #
        # def array_position(arr, vals, header=None):
        #     if header:
        #         return [header[ii] for ii, x in enumerate(my_list) if x == "whatever"]

        colors.out_print(f"validate_nulls(), null_set = {null_set}")

        for etl_source in null_set:
            if etl_source == 'all':
                self.obj = self.obj.withColumn(etl_source + '_validity_null',
                                               f.array([field for field in null_set[etl_source]]))
                self.obj = self.obj.withColumn(etl_source + '_validity_null_bool',
                                               f.when(
                                                   f.array_contains(etl_source + '_validity_null', 'None') |
                                                   f.array_contains(etl_source + '_validity_null', ''),
                                                   False).otherwise(True)
                #                                    )
                # self.obj = self.obj.withColumn(etl_source + '_validity_null_list', f.array_position('None')
                #                                f.when(
                #                                    f.array_contains(etl_source + '_validity_null', 'None') |
                #                                    f.array_contains(etl_source + '_validity_null', ''),
                #                                    False).otherwise(True)
                                               )
                # # TODO - for DS
                # for cid in self.schema[self.table]['fields']:
                #     self.obj.withColumn("null_ds", f.when(f.lower(f.col(cid)).isin(['none', '']),
                #                                           f.concat(f.array(f.col(cid)), f.col('null_ds'))
                #                                           ).otherwise(f.col('null_ds'))
                # )
            else:
                self.obj = self.obj.withColumn(etl_source + '_validity_null', f.array([field for field in null_set[etl_source]]))
                self.obj = self.obj.withColumn(etl_source + '_validity_null_bool',
                                               f.when(
                                                   f.array_contains(etl_source + '_validity_null', 'None') &
                                                      (f.col('etl_source') == etl_source),
                                                      False).otherwise(True)
                                               )

        self.obj = self.obj.withColumn('validity_null_arr',
                                       f.array([etl_source + '_validity_null_bool'
                                               for etl_source in null_set]))

        self.obj = self.obj.withColumn('nullability_error',
                                       f.when(
                                           f.array_contains(f.col('validity_null_arr'), False),
                                           f.lit('Error')
                                       ).otherwise(f.lit("None")))

        if self.obj != None and self.obj.filter(f.col('nullability_error')=='Error').take(1) != []:
            colors.out_print("validate_nulls(), self.obj=")
            self.obj.filter(f.col('nullability_error')=='Error').show(2, False)

        for etl_source in null_set:
            self.obj = self.obj.drop(etl_source + '_validity_null_bool')
            self.obj = self.obj.drop(etl_source + '_validity_null')

        self.obj = self.obj.drop('validity_null_arr')

        return self

    def validate_types(self):

        typecast_map = {
            "VARCHAR": "string",
            "BOOLEAN": "boolean",
            "INTEGER": "int",
            "FLOAT": "float",
            "DATETIME": "string"  # TODO - exception for datetime types
        }
        for fn in self.schema['fields']:
            # TODO - remove this if, all fields should be represented
            if fn in self.obj.schema.names:
                typestr = typecast_map[self.schema['fields'][fn]['type'].__str__()]
                self.obj = self.obj.withColumn(fn + '_validity_type',
                                               f.when(
                                                   (
                                                       f.col(fn).cast(typestr).isNull() &
                                                       f.col(fn).isNotNull() &
                                                       ~f.lower(f.col(fn)).isin(["none", "null", 'edm-881', 'edm-494', "edm-1030", "edm-1090", "edm_exempt"])
                                                   ),
                                                   f.lit("Error")
                                               ).otherwise(f.lit("None")))

                # Typecasting columns in load will have to happen in the load class,
                # after the typecast failures complete
                # |  cannot resolve 'CASE WHEN (`<field>` = 'None')
                # |  THEN CAST(`do_not_contact` AS BOOLEAN) ELSE 'None' END'
                # |  THEN CAST(`do_not_contact` AS BOOLEAN) ELSE 'None' END'
                # |  due to data type mismatch:
                # |      THEN and ELSE expressions should all be same type or coercible to a common type;;
                #
                # self.obj = self.obj.withColumn(fn,
                #                                f.when(
                #                                    f.col(fn+'_validity_type') == "None",
                #                                    f.col(fn).cast(typestr)
                #                                ).otherwise(f.lit("None")))

        self.obj = self.obj.withColumn('validity_type_arr',
                                       f.array([fn + '_validity_type'
                                                for fn in self.schema['fields'] if fn in self.obj.schema.names]))
        self.obj = self.obj.withColumn('typecast_error',
                                       f.when(
                                           f.array_contains(f.col('validity_type_arr'), "Error"),
                                           f.lit('Error')
                                       ).otherwise("None"))

        if self.obj != None and self.obj.filter(f.col('typecast_error')=='Error').take(1) != []:
            colors.out_print("validate_types(), self.obj=")
            self.obj.filter(f.col('typecast_error')=='Error').show(2, False)

        for fn in self.obj.schema.names:
            self.obj = self.obj.drop(fn + '_validity_type')

        self.obj = self.obj.drop('validity_type_arr')

        return self

    def process(self):
        """ process """
        colors.out_print("\t\tvalidating nulls")
        self.validate_nulls()
        colors.out_print("\t\tvalidating types")
        self.validate_types()
        self.df = self.obj
        return self