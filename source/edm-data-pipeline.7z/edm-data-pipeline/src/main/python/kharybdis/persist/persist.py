# Rule list
# Dictionary

import spark_functions as sf
import pyspark.sql.functions as f
from cm_commons.db.cm_conn import cm_cxn_jdbc as p_cxn_jdbc
from cm_commons.db.cm_conn import cm_cxn_jdbc
import pandas as pd
from cm_commons import colors
import pyspark.sql.functions as f
from cm_commons.util.sql_functions import psql_table_exists

from cm_commons.util.safe_count import safe_count
from cm_commons.db.cm_conn import cm_cxn_jdbc as opt


class Persister:
    """
# #---------------------------------------------------------------# #
# #                              Persist                          # #
# #---------------------------------------------------------------# #
    """

    def __init__(self, dfs, schema,
                 persist_dfs=None, persist_tbls={'entity': 'entity_persist_rules'}, persist_cxn=opt,
                 spark=None, s3_folder=None, date=None, key=None, pid=None,
                 indent=0):
        """
        :param dfs: dictionary of dataframes
        :param schema: dictionary of table schemas
        :param persist_dfs: <optional> persistence dataframe to map by
        :param persist_tbls: if persist_dfs is not populated, tableset to populate persist_dfs
        :param persist_cxn: cxn to grab persists_tbls from
        :param spark: spark handle to use for session
        :param indent: indent level to start at for logging
        """

        self.dfs = dfs
        self.schema = schema
        self.spark = spark
        self.persist_cxn = persist_cxn

        self.s3_folder = s3_folder
        self.date = date
        self.key = key
        self.pid = pid

        # Standard loading clause
        if not persist_dfs:
            self.persist_dfs = {}
            for tbl, ptbl in persist_tbls.items():
                colors.out_print(f"Reading {ptbl} from DB", indent=indent + 1)
                from cm_commons.db.cm_conn import cm_cxn
                if psql_table_exists(cxn=cm_cxn, table_name=ptbl):
                    if tbl == 'entity':
                        pred = [
                            "substring(original_record_entity_id, 1,1)  = '0'",
                            "substring(original_record_entity_id, 1,1)  = '1'",
                            "substring(original_record_entity_id, 1,1)  = '2'",
                            "substring(original_record_entity_id, 1,1)  = '3'",
                            "substring(original_record_entity_id, 1,1)  = '4'",
                            "substring(original_record_entity_id, 1,1)  = '5'",
                            "substring(original_record_entity_id, 1,1)  = '6'",
                            "substring(original_record_entity_id, 1,1)  = '7'",
                            "substring(original_record_entity_id, 1,1)  = '8'",
                            "substring(original_record_entity_id, 1,1)  = '9'",
                            "substring(original_record_entity_id, 1,1) in ('a','g','h','i')",
                            "substring(original_record_entity_id, 1,1) in ('b','j','k','l')",
                            "substring(original_record_entity_id, 1,1) in ('c','m','n','o')",
                            "substring(original_record_entity_id, 1,1) in ('d','p','q','r')",
                            "substring(original_record_entity_id, 1,1) in ('e','s','t','u','v')",
                            "substring(original_record_entity_id, 1,1) in ('f','w','x','y','z')"
                        ]
                        self.persist_dfs[tbl] = spark.read.jdbc(url=persist_cxn['url'], table=ptbl,
                                                                properties=opt['properties'],
                                                                predicates=pred)
                    else:
                        self.persist_dfs[tbl] = spark.read.jdbc(url=persist_cxn['url'], table=ptbl, properties=opt['properties'])

                    addr = f"{self.s3_folder}/{self.date}/{self.pid}/{self.key}/{ptbl}.parquet"
                    colors.out_print(f"Caching {tbl} after db read to {addr}")
                    self.persist_dfs[tbl].write.mode("overwrite").parquet(addr)
                    self.persist_dfs[tbl] = self.spark.read.parquet(addr)

                    #colors.suc_print(f"Read {ptbl} into persist_dfs[{tbl}] with {safe_count(self.persist_dfs[tbl], dummy_str=True)} records",
                    #                 indent= indent + 2)
                    colors.suc_print(
                        f"Read {ptbl} into persist_dfs[{tbl}] with {self.persist_dfs[tbl].count()} records"
                        f" in {self.persist_dfs[tbl].rdd.getNumPartitions()} partitions",
                                     indent=indent + 2)

                    if self.persist_dfs[tbl].rdd.getNumPartitions() < 3000:
                        self.persist_dfs[tbl] = self.persist_dfs[tbl].repartition(3000)
                        colors.out_print(
                            f"Repartitioned persist_dfs[{tbl}] df to {self.persist_dfs[tbl].rdd.getNumPartitions()}",
                            indent=indent + 2)

                else:
                    colors.err_print(f"Could not find {ptbl}...", indent= indent + 2)

        else:
            colors.out_print(f"Using {', '.join(list(persist_tbls.keys()))} dataframes passed from outer", indent=indent + 1)
            self.persist_dfs = persist_dfs

        self.indent = indent

    @staticmethod
    def apply_fields(spark, s3_folder, date, df, persist_dfs=None, table='entity', pkey='entity_id', ignore=None, indent=0):
        """
            Apply field level persistence mappings.

        :param df:
        :param persist_dfs:
        :param table:
        :param pkey:
        :param ignore:
        :return:
        """

        if table in persist_dfs:

            df_orig_schema_names = df.schema.names

            colors.out_print(f"Running apply fields", indent)
            # Reduce join to relevant fields
            persist_df = persist_dfs[table].filter(
                persist_dfs[table].column_name.isin([ii for ii in df.schema.names if (ii not in ignore or ii == pkey)])
            )

            colors.saf_print(f"{safe_count(persist_df, dummy_str=True)} records for {table}.*", indent=indent+1)


            df = df.withColumn('etl_source', f.lower(f.col('etl_source')))

            # Drop dual occuring id sets
            persist_df = persist_df.drop('created_at')

            # Update each column
            for update_col in df.columns:
                if update_col not in ignore:

                    colors.out_print(f"Updating {update_col}", indent=(indent+1))
                    # join on `<update_col>` = `column_name` and primary key

                    fp_df = persist_df.filter(f.col("column_name").isin([update_col]))
                    rule_count = fp_df.count()

                    if rule_count == 0:
                        colors.war_print(f"No persist rules for `{update_col}`", indent=indent+2)
                    else:
                        colors.suc_print(f"{rule_count} records found for `{update_col}`", indent=indent+2)

                        if table == 'entity':
                            df = df.join(fp_df, (df[pkey] == fp_df[f"original_record_{pkey}"])
                                         & (df['entity_type_id'] == fp_df['entity_type_id']),
                                         "left_outer").drop(fp_df['entity_type_id'])
                        else:
                            if 'entity_type_id' in df.columns:
                                df = df.join(fp_df, df[pkey] == fp_df[f"original_record_{pkey}"],
                                             "left_outer").drop(fp_df['entity_type_id'])
                            else:
                                df = df.join(fp_df, df[pkey] == fp_df[f"original_record_{pkey}"], "left_outer")

                        df = df.withColumn(update_col,
                                           f.when(f.col(update_col) == f.col("invalid_value"),
                                               f.col("valid_value")
                                           ).otherwise(f.col(update_col))
                                           )
                        df = df.dropDuplicates()
                        for pfi in list(set(df.schema.names) - set(df_orig_schema_names)):
                            df = df.drop(pfi)
                '''
                addr = f"{s3_folder}/{date}/interim-apply_fields/{table}.parquet"
                colors.out_print(f"Number of partitions before caching for {table} df = {df.rdd.getNumPartitions()}")
                colors.out_print(f"Caching to {addr}", indent=0)
                df.write.mode("overwrite").parquet(addr)
                df = spark.read.parquet(addr)
                '''
        else:
            colors.war_print(f"Could not find any persistence records for {table}", indent=(indent + 1))

        return df.dropDuplicates()


    @staticmethod
    def apply_pkeys(df, persist_dfs=None, table='entity', pkey='entity_id', indent=0):
        """
            Apply primary key persistence mappings.

        :param df:
        :param persist_dfs:
        :param table:
        :param pkey:
        :param ignore:
        :return:
        """

        df_orig_schema_names = df.schema.names

        colors.out_print(f"Running apply pkeys", indent)
        # Reduce join to relevant fields

        if table in persist_dfs:
            persist_df = persist_dfs[table].filter(
                persist_dfs[table].column_name.isin([ii for ii in df.schema.names])
            )

            colors.saf_print(f"{safe_count(persist_df, dummy_str=True)} records for {table}.*", indent=indent+1)

            df = df.withColumn('etl_source', f.lower(f.col('etl_source')))

            # Drop dual occuring id sets
            persist_df = persist_df.drop('created_at')

            colors.out_print(f"Updating {pkey}", indent=(indent + 1))
            # join on `<update_col>` = `column_name` and primary key


            # Find all primary key changes
            fp_df = persist_df.filter(f.col("column_name").isin([pkey]))
            rule_count = fp_df.count()
            colors.suc_print(f"{rule_count} records found for `{pkey}`", indent=indent + 2)

            if table == 'entity':
                df = df.join(fp_df, (df[pkey] == fp_df[f"invalid_value"])
                                & (df['entity_type_id'] == fp_df['entity_type_id']),
                                "left_outer").drop(fp_df['entity_type_id'])
            else:
                if 'entity_type_id' in df.columns:
                    df = df.join(fp_df, df[pkey] == fp_df[f"invalid_value"],
                                 "left_outer").drop(fp_df['entity_type_id'])
                else:
                    df = df.join(fp_df, df[pkey] == fp_df[f"invalid_value"], "left_outer")

            # If the join worked, use the valid_value, otherwise keep the original_plkey
            df = df.withColumn(pkey,
                               f.when(f.col('rule_id').isNotNull(),
                                      f.col("valid_value")
                                      ).otherwise(f.col(pkey))
                               )

            for pfi in list(set(df.schema.names) - set(df_orig_schema_names)):
                df = df.drop(pfi)

        else:
            colors.war_print(f"Could not find any persistence records for {table}", indent=(indent + 1))

        return df.dropDuplicates()

    @staticmethod
    def apply_skeys(df, persist_dfs, table, skey, indent=0):
        """ Apply secondary keys a.k.a `persistence_id`"""

        df_orig_schema_names = df.schema.names

        colors.out_print(f"Running apply skeys", indent)

        if table in persist_dfs:
            # Reduce join to relevant fields
            persist_df = persist_dfs[table].filter(persist_dfs[table].column_name.isin([skey]))

            # Drop dual occuring id sets
            persist_df = persist_df.drop('entity_type_id')
            persist_df = persist_df.drop('created_at')

            colors.saf_print(f"{safe_count(persist_df.count, dummy_str=True)} records for {table}.{skey}")

            # Add pkey
            df = df.withColumn('skey', f.col(skey))
            df = df.withColumn('etl_source', f.lower(f.col('etl_source')))

            # Join raw to persist
            df = df.join(persist_df, df.skey == persist_df[f"invalid_value"], "left_outer").cache()

            # Update new_pkey
            df = df.withColumn("new_skey",
                               f.when(
                                     (df["column_name"].isin([skey])) &
                                     (df[skey] == df["invalid_value"]),
                                     f.col("valid_value")
                                 ).otherwise(f.col(skey))
                               )


            # Overwrite pkey
            df = df.withColumn(skey, f.col("new_skey"))

            # Drop old columns
            for pfi in list(set(df.schema.names) - set(df_orig_schema_names)):
                df = df.drop(pfi)
        else:
            colors.war_print(f"Could not find any persistence records for {table}", indent=(indent + 1))

        return df.dropDuplicates()

    @staticmethod
    def apply_fkeys(spark, s3_folder, date, df, persist_dfs=None, table='entity', fkeys=None, indent=0):
        """
                    Apply primary key persistence mappings.

        :param df:
        :param persist_dfs:
        :param table:
        :param pkey:
        :param ignore:
        :return:
        """

        df_orig_schema_names = df.schema.names

        colors.out_print(f"Running apply fkeys", indent)

        df = df.withColumn('etl_source', f.lower(f.col('etl_source')))

        for fkey in fkeys:
            if fkey['target_table'] in persist_dfs:
                colors.out_print(f"Updating {fkey['source_table']}.{fkey['source_field']} "
                                 f"from {fkey['target_table']}.{fkey['target_field']}",
                                 indent=(indent + 1))

                # Read persist_df for target_table / target_field
                persist_df = persist_dfs[fkey['target_table']].filter(f.col("column_name").isin([fkey['target_field']]))
                persist_df = persist_df.drop('created_at')
                rule_count = persist_df.count()
                colors.suc_print(f"{rule_count} records found for `{fkey['target_table']}.{fkey['target_field']}`",
                                 indent=indent + 2)

                if fkey['source_table'] == 'entity' and fkey['target_field'] == 'entity_id':
                    df = df.join(persist_df, (df[fkey['source_field']] == persist_df[f"invalid_value"])
                                            & (df['entity_type_id'] == persist_df['entity_type_id']),
                                            "left_outer").drop(persist_df['entity_type_id'])
                else:
                    if 'entity_type_id' in df.columns:
                        df = df.join(persist_df, df[fkey['source_field']] == persist_df[f"invalid_value"],
                                     "left_outer").drop(persist_df['entity_type_id'])
                    else:
                        df = df.join(persist_df, df[fkey['source_field']] == persist_df[f"invalid_value"], "left_outer")

                # If the join worked, use the valid_value, otherwise keep the original_plkey
                df = df.withColumn(fkey['source_field'],
                                   f.when(f.col('rule_id').isNotNull(),
                                          f.col("valid_value")
                                          ).otherwise(f.col(fkey['source_field']))
                                   )
                df = df.dropDuplicates()

                for pfi in list(set(df.schema.names) - set(df_orig_schema_names)):
                    df = df.drop(pfi)

                '''
                addr = f"{s3_folder}/{date}/interim-apply_fkeys/{table}.parquet"
                colors.out_print(f"Number of partitions before caching for {table} df = {df.rdd.getNumPartitions()}")
                colors.out_print(f"Caching to {addr}", indent=0)
                df.write.mode("overwrite").parquet(addr)
                df = spark.read.parquet(addr)
                '''
            else:
                colors.war_print(f"Could not find any persistence records for {fkey['target_table']}.{fkey['target_field']}",
                                 indent=(indent + 1))

        return df.dropDuplicates()

    @staticmethod
    def get_keys(schema, table_name):
        """Gets keys from the schema"""
        # Get primary key
        pkey = schema[table_name]['primaryKey'][0]['field']
        # Get foreign keys
        fkeys = schema[table_name]['foreignKey']
        return pkey, fkeys

    @staticmethod
    def write_read_reset(spark, s3_folder, date, df, table='entity', key='something', pid='pid'):
        """ Write to S3, Read from S3, refreshes catalyst
            |  https://stackoverflow.com/questions/50891509/apache-spark-codegen-stage-grows-beyond-64-kb
        """

        addr = f"{s3_folder}/{date}/{pid}/{key}/{table}.parquet"

        colors.out_print(f"Number of partitions before caching for {table} df = {df.rdd.getNumPartitions()}")
        colors.out_print(f"Caching to {addr}", indent=0)
        df.write.mode("overwrite").parquet(addr)
        df = spark.read.parquet(addr)

        return df

    def process(self):

        for table_name in self.dfs:
            # Get table
            df = self.dfs[table_name]
            colors.out_print(f"Persisting changes on {table_name}", indent=self.indent + 1)

            # Get keys
            pkey, fkeys = self.get_keys(schema=self.schema, table_name=table_name)
            colors.out_print(f"{table_name}[pkey]={pkey}")
            colors.out_print(f"{table_name}[fkeys]={fkeys}")

            # Apply field persistence
            colors.out_print(f"Applying fields for {table_name}", indent=self.indent + 2)
            df = self.apply_fields(self.spark, self.s3_folder, self.date, df,
                                   persist_dfs=self.persist_dfs,
                                   table=table_name,
                                   pkey=pkey,
                                   ignore=[pkey, 'record_id', 'created_at',
                                           'updated_at', 'etl_source', 'enrichment_error'],
                                   indent=3
                                   )
            df = self.write_read_reset(self.spark, self.s3_folder, self.date, df, table=table_name,
                                       key='post-apply_fields', pid=self.pid)


            colors.out_print(f"Applying pkey for {table_name}.{pkey}", indent=self.indent + 2)
            df = self.apply_pkeys(df=df,
                                  persist_dfs=self.persist_dfs,
                                  table=table_name,
                                  pkey=pkey,
                                  indent=3
                                  )
            df = self.write_read_reset(self.spark, self.s3_folder, self.date, df, table=table_name,
                                       key='post-apply_pkeys', pid=self.pid)

            colors.out_print(f"Persisting foreign keys for table {table_name}", indent=self.indent + 2)
            df = self.apply_fkeys(self.spark, self.s3_folder, self.date, df,
                                  persist_dfs=self.persist_dfs,
                                  table=table_name,
                                  fkeys=fkeys,
                                  indent=3
                                  )
            df = self.write_read_reset(self.spark, self.s3_folder, self.date, df, table=table_name,
                                       key='post-apply_fkeys', pid=self.pid)

            if table_name == 'entity':
                colors.out_print(f"Applying skey for {table_name}.{pkey}", indent=self.indent + 2)
                df = self.apply_skeys(df=df,
                                      persist_dfs=self.persist_dfs,
                                      table=table_name,
                                      skey='persistence_id',
                                      indent=3
                                     )
                df = self.write_read_reset(self.spark, self.s3_folder, self.date, df, table=table_name,
                                           key='post-apply_skeys', pid=self.pid)

            df = df.dropDuplicates()

            colors.out_print(f"Number of partitions before repartition for {table_name} df = {df.rdd.getNumPartitions()}")
            if df.rdd.getNumPartitions() < 3000:
                df = df.repartition(3000)
                colors.out_print(f"Repartitioned {table_name} df to {df.rdd.getNumPartitions()}")

            self.dfs[table_name] = df.dropDuplicates()

        return self
