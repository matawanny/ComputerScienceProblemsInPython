from cm_commons import colors
import spark_functions as sf
import pyspark.sql.functions as f
from datetime import datetime

class AuditLogger:

    def __init__(self, indent):
        self.indent = indent

    @staticmethod
    def create_predicates(table_name):
        predicate = None
        if table_name in ['entity', 'entity_address_xref', 'entity_phone_xref', 'entity_email_xref']:
            predicate = [
                "substring(entity_id, 1,1)  = '0'",
                "substring(entity_id, 1,1)  = '1'",
                "substring(entity_id, 1,1)  = '2'",
                "substring(entity_id, 1,1)  = '3'",
                "substring(entity_id, 1,1)  = '4'",
                "substring(entity_id, 1,1)  = '5'",
                "substring(entity_id, 1,1)  = '6'",
                "substring(entity_id, 1,1)  = '7'",
                "substring(entity_id, 1,1)  = '8'",
                "substring(entity_id, 1,1)  = '9'",
                "substring(entity_id, 1,1) in ('a','g','h','i')",
                "substring(entity_id, 1,1) in ('b','j','k','l')",
                "substring(entity_id, 1,1) in ('c','m','n','o')",
                "substring(entity_id, 1,1) in ('d','p','q','r')",
                "substring(entity_id, 1,1) in ('e','s','t','u','v')",
                "substring(entity_id, 1,1) in ('f','w','x','y','z')"
            ]

        # print(predicate)
        return predicate

    @staticmethod
    def generate_audit_log(spark, cxn, conf, obj_schema, df, table, s3_folder, key, pid, audit_log_id, indent=0):
        """
            Identify and write INSERTs & MOVEs
        """
        colors.out_print(f"Looking up inserts for {table}", indent)
        date = conf["file_date"]
        prefix = conf['prefix']
        table_name = f"{prefix}{table}"
        prv_table_name = f"{prefix}{table}_prv"
        audit_log_tablename = f"{table_name}_audit_log"
        colors.out_print(f"Checking for {table_name}", indent=2)

        # print("nav_debug(fresh inserts) df:")
        # df.show(10, False)

        from cm_commons.db.cm_conn import cm_cxn
        import psycopg2
        conn = psycopg2.connect(dbname=cm_cxn['db_name'],
                                user=cm_cxn['user'],
                                host=cm_cxn['location'],
                                password=cm_cxn['password'])
        cur = conn.cursor()
        cur.execute(f"select * from information_schema.tables where table_name='{prv_table_name}'")
        prv_exists = bool(cur.rowcount)

        if prv_exists:
            colors.out_print(f"Loading {prv_table_name} from client master using custom paritioning", indent=2)
            pred = AuditLogger.create_predicates(table)

            prv_df = spark.read.jdbc(url=cxn['url'], table=prv_table_name,
                                                    properties=cxn['properties'],
                                                    predicates = pred)

            addr = f"{s3_folder}/{date}/{pid}/{key}/{prv_table_name}.parquet"
            colors.out_print(f"Caching {prv_table_name} after db read to {addr}")
            prv_df.write.mode("overwrite").parquet(addr)
            prv_df = spark.read.parquet(addr)
            colors.out_print(f"Number of partitions for {prv_table_name}={df.rdd.getNumPartitions()}")

            for col in prv_df.columns:
                prv_df = prv_df.withColumnRenamed(col, 'prev_' + col)

            if table == 'entity':
                jdf = df.join(prv_df, (df['salesvision_id'] == prv_df['prev_salesvision_id']) & (
                            df['entity_type_id'] == prv_df['prev_entity_type_id']) & (
                                          df['entity_id'] == prv_df['prev_entity_id']) & (
                                          df['persistence_id'] == prv_df['prev_persistence_id']), "left_outer")
            elif table == 'entity_address_xref':
                jdf = df.join(prv_df, (df['entity_id'] == prv_df['prev_entity_id']) & (
                                          df['address_type_id'] == prv_df['prev_address_type_id']), "left_outer")
            elif table == 'entity_phone_xref':
                jdf = df.join(prv_df, (df['entity_id'] == prv_df['prev_entity_id']) & (
                                          df['phone_type_id'] == prv_df['prev_phone_type_id']), "left_outer")
            elif table == 'entity_email_xref':
                jdf = df.join(prv_df, (df['entity_id'] == prv_df['prev_entity_id']) & (
                                          df['email_type_id'] == prv_df['prev_email_type_id']), "left_outer")
            else:
                colors.war_print(f"Skipping functionality for {table} table...")
                cur.close()
                return df

            # jdf.filter(jdf['salesvision_id'].isNotNull() & jdf['prev_entity_id'].isNull()).count()
            audit_log_for_inserts_df = jdf.filter(jdf['prev_entity_id'].isNull())

            for col in audit_log_for_inserts_df.columns:
                if 'prev_' in col:
                    audit_log_for_inserts_df = audit_log_for_inserts_df.drop(col)

            colors.out_print(f"Writing INSERTS to {audit_log_tablename}", indent=3)

            # print(f"nav_debug audit_log_for_inserts_df:")
            # audit_log_for_inserts_df.show(2, False)

            for col in audit_log_for_inserts_df.columns:
                # if col == 'ingested_at':    continue
                if col in ['enrichment_error', 'edm_orig', 'group_name', 'tds_id', 'group_count', 'tds_match_yn'] \
                        or col not in obj_schema['fields'].keys():
                    audit_log_for_inserts_df = audit_log_for_inserts_df.drop(col)

            if 'typecast_error' in audit_log_for_inserts_df.columns:
                audit_log_for_inserts_df = audit_log_for_inserts_df.withColumn('typecast_error',
                                                                               f.when(f.col('typecast_error').isNotNull(),
                                                            f.col('typecast_error')).otherwise(f.lit(' ')))
            else:
                audit_log_for_inserts_df = audit_log_for_inserts_df.withColumn('typecast_error', f.lit(' '))

            if table  == 'entity':
                if 'tds_master' in audit_log_for_inserts_df.columns:
                    audit_log_for_inserts_df = audit_log_for_inserts_df.withColumn('tds_master',
                                                                                   f.when(f.col('tds_master').isNotNull(),
                                                            f.col('tds_master')).otherwise(f.lit(' ')))
                else:
                    audit_log_for_inserts_df = audit_log_for_inserts_df.withColumn('tds_master', f.lit(' '))
            else:
                if 'nullability_error' in audit_log_for_inserts_df.columns:
                    audit_log_for_inserts_df = audit_log_for_inserts_df.withColumn('nullability_error',
                                                                                   f.when(f.col('nullability_error').isNotNull(),
                                                                                          f.col('nullability_error'))
                                                                                   .otherwise(f.lit(' ')))
                else:
                    audit_log_for_inserts_df = audit_log_for_inserts_df.withColumn('nullability_error', f.lit(' '))

            audit_log_for_inserts_df = audit_log_for_inserts_df.withColumn('etl_source', f.lit(conf['match_source'].lower()))

            if 'sv_event_code' in audit_log_for_inserts_df.columns:
                audit_log_for_inserts_df = audit_log_for_inserts_df.withColumn('sv_event_code',
                                                f.when(f.col('sv_event_code').isNotNull(), f.col('sv_event_code'))
                                                .otherwise(f.lit('I'))
                                                )
            else:
                audit_log_for_inserts_df = audit_log_for_inserts_df.withColumn('sv_event_code',f.lit('I'))

            audit_log_for_inserts_df = audit_log_for_inserts_df.replace(['None','edm_exempt'], [None, None])

            audit_log_for_inserts_df = audit_log_for_inserts_df.withColumn('audit_log_id', f.lit(audit_log_id))
            audit_log_for_inserts_df = audit_log_for_inserts_df.distinct()

            audit_log_for_inserts_df.write.jdbc(url=cxn['url'], table=audit_log_tablename,
                          mode="append", properties=cxn['properties'])



            # write moves:
            if table == 'entity':
                cur.execute(f"select * from information_schema.tables where table_name='{conf['prefix']}log_entity_moves'")
                table_exists = bool(cur.rowcount)

                if not table_exists:
                    colors.war_print(f"{conf['prefix']}log_entity_moves does NOT exist. Skipping...")
                    cur.close()
                    return df

                colors.out_print(f"Loading from {conf['prefix']}log_entity_moves...", indent=3)
                log_entity_moves_df = spark.read.jdbc(url=cxn['url'], table=f"{conf['prefix']}log_entity_moves",
                                                            properties=cxn['properties'])

                """
                colors.out_print(f"Looking up for date={datetime.now().strftime('%Y-%m-%d')}")
                log_entity_moves_df = log_entity_moves_df.filter(f.col('maint_moved_at') ==
                                                                 f.lit(datetime.now().strftime("%Y-%m-%d")))
                """

                colors.out_print(f"Count of moves1={log_entity_moves_df.count()}")

                """ Alternate way if df is messed up still:
                colors.out_print(f"Loading {table_name} from client master using custom paritioning", indent=2)
                pred = AuditLogger.create_predicates(table)
                e_df = spark.read.jdbc(url=cxn['url'], table=table_name, properties=cxn['properties'],
                                            predicates=pred)
                """

                for col in log_entity_moves_df.columns:
                    log_entity_moves_df = log_entity_moves_df.withColumnRenamed(col, 'lem_' + col)

                # print("nav_debug(moves) df:")
                # df.show(10, False)

                colors.out_print(f"Count of moves2={log_entity_moves_df.count()}")
                audit_log_for_moves_df = df.join(log_entity_moves_df,
                                                 (df['persistence_id'] == log_entity_moves_df['lem_persistence_id']) &
                                                 (df['entity_type_id'] == log_entity_moves_df['lem_entity_type_id']),
                                                 how='inner')\
                                            .filter(df['ended_at'].isNull() |
                                                    df['ended_at'].isin('None', 'edm_exempt'))

                colors.out_print(f"Count of moves3={audit_log_for_moves_df.count()}")

                for col in log_entity_moves_df.columns:
                    if 'lem_' in col:
                        audit_log_for_moves_df = audit_log_for_moves_df.drop(col)

                colors.out_print(f"Count of moves4={audit_log_for_moves_df.count()}")

                colors.out_print(f"obj_schema['fields'].keys(): {obj_schema['fields'].keys()}")
                for col in audit_log_for_moves_df.columns:
                    if col == 'etl_source':
                        continue
                    if col in ['enrichment_error', 'edm_orig', 'group_name', 'tds_id', 'group_count', 'tds_match_yn',
                               'nullability_error'] or col not in obj_schema['fields'].keys():
                        audit_log_for_moves_df = audit_log_for_moves_df.drop(col)

                if 'typecast_error' in audit_log_for_moves_df.columns:
                    audit_log_for_moves_df = audit_log_for_moves_df.withColumn('typecast_error',
                                                                               f.when(f.col('typecast_error').isNotNull(),
                                                                                      f.col('typecast_error'))
                                                                               .otherwise(f.lit(' ')))
                else:
                    audit_log_for_moves_df = audit_log_for_moves_df.withColumn('typecast_error',f.lit(' '))


                if 'tds_master' in audit_log_for_moves_df.columns:
                    audit_log_for_moves_df = audit_log_for_moves_df.withColumn('tds_master',
                                                                               f.when(f.col('tds_master').isNotNull(),
                                                            f.col('tds_master')).otherwise(f.lit(' ')))
                else:
                    audit_log_for_moves_df = audit_log_for_moves_df.withColumn('tds_master', f.lit(' '))


                colors.out_print(f"Count of moves5={audit_log_for_moves_df.count()}")
                colors.out_print(f"Writing MOVES to {audit_log_tablename}", indent=3)

                audit_log_for_moves_df = audit_log_for_moves_df.withColumn('sv_event_code', f.lit('M'))
                audit_log_for_moves_df = audit_log_for_moves_df.replace(['None','edm_exempt'], [None, None])

                # print("nav_debug audit_log_for_moves_df:")
                # audit_log_for_moves_df.show(2, False)

                audit_log_for_moves_df = audit_log_for_moves_df.withColumn('audit_log_id', f.lit(audit_log_id))
                audit_log_for_moves_df = audit_log_for_moves_df.distinct()

                audit_log_for_moves_df.write.jdbc(url=cxn['url'], table=audit_log_tablename,
                                                    mode="append", properties=cxn['properties'])

        else:
            colors.err_print(f"Could not find {prv_table_name} in client master", indent=3)
            colors.out_print(f"Writing all records as INSERTS to {audit_log_tablename}", indent=3)

            colors.out_print(f"obj_schema['fields'].keys(): {obj_schema['fields'].keys()}")
            for col in df.columns:
                # TODO: Check and fix why obj_schema doesn't have ingested_at column
                # if col == 'ingested_at':    continue
                if col in ['enrichment_error', 'edm_orig', 'group_name', 'tds_id', 'group_count', 'tds_match_yn'] \
                        or col not in obj_schema['fields'].keys():
                    df = df.drop(col)

            if 'typecast_error' in df.columns:
                df = df.withColumn('typecast_error', f.when(f.col('typecast_error').isNotNull(),
                                                            f.col('typecast_error')).otherwise(f.lit(' ')))
            else:
                df = df.withColumn('typecast_error', f.lit(' '))


            df = df.withColumn('sv_event_code', f.lit('I'))\
                    .withColumn('etl_source', f.lit(conf['match_source'].lower()))

            if table  == 'entity':
                if 'tds_master' in  df.columns:
                    df = df.withColumn('tds_master', f.when(f.col('tds_master').isNotNull(),
                                                            f.col('tds_master')).otherwise(f.lit(' ')))
                else:
                    df = df.withColumn('tds_master', f.lit(' '))
            else:
                if 'nullability_error' in df.columns:
                    df = df.withColumn('nullability_error', f.when(f.col('nullability_error').isNotNull(),
                                                            f.col('nullability_error')).otherwise(f.lit(' ')))
                else:
                    df = df.withColumn('nullability_error', f.lit(' '))

            df = df.replace(['None','edm_exempt'], [None, None])

            # print(f"nav_debug(all as inserts) df for {table}:")
            # df.show(10, False)

            df = df.withColumn('audit_log_id', f.lit(audit_log_id))
            df = df.distinct()

            df.write.jdbc(url=cxn['url'], table=audit_log_tablename,
                                    mode="append", properties=cxn['properties'])

        cur.close()
        return df
