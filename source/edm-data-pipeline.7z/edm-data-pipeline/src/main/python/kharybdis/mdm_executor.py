from cm_commons.db.cm_conn import cm_cxn_jdbc
from cm_commons.util.boto_functions import move_conf_along, s3_move_file
from cm_commons.util.jobstatus import logCmJob
import psycopg2
from cm_commons import colors
from cm_commons.db.cm_conn import cm_cxn

import kharybdis

def mdm_executor(conf, conf_loc, move_files=True):
    MDM = kharybdis.MDM

    conn = psycopg2.connect(dbname=cm_cxn['db_name'],
                            user=cm_cxn['user'],
                            host=cm_cxn['location'],
                            password=cm_cxn['password'])
    cur = conn.cursor()

    switch_tbl = 'edm_params'
    switch_col = 'value1'
    switch_key = 'active_mdm_stage'

    cur.execute(f"select {switch_col} from {switch_tbl} WHERE key = '{switch_key}'")
    active_stage = str(cur.fetchall()[0][0])
    conf['prefix'] = f"{conf['prefix']}{active_stage}_"

    colors.out_print(f"Writing to stage {active_stage} with prefix {conf['prefix']}", indent=0)

    cm_mdm = MDM(conf=conf, cxn=cm_cxn_jdbc, move_flag=move_files)

    cm_mdm.process()
    cm_mdm.print_doc()

    cur.close()
    conn.close()


