import argparse

if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('-s', '--dbsync_method', nargs='+', help='<Required> Set flag', required=True)
    parser.add_argument('-p', '--prefix', help='prefix different from normal stg', required=False)
    parser.add_argument('-d', '--delta', action='store_true', help='flag for triggering deltas', required=False)
    parser.add_argument('-n', '--news', action='store_true', help='flag for generating new FOP in valid entities', required=False)

    args = parser.parse_args()
    a = args._get_kwargs()

    confs = []
    params = {var: val for var, val in a if val is not None and val}
    dbsync_methods = params['dbsync_method']

    prefix = None
    if 'prefix' in params:
        prefix = params['prefix']
    # if 'p' in params:
    #     prefix = params['p']
    print(f'prefix={prefix}')
    new_fop = None
    if 'news' in params:
        new_fop = True
    delta = None
    if 'delta' in params:
        delta = True


