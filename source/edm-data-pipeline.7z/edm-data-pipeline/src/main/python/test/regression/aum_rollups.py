from skylla.extract import Extractor
import boto3
import urlparse
import json

class SalesVisionTester:

    def __init__(self, confs):

        self.confs = {}
        for tbl, loc in confs.items():
            o = urlparse(loc)
            obj = boto3.resource('s3').Object(o.netloc, o.path[1:])
            self.confs[tbl] = json.loads(obj.get()['Body'].read().decode('utf-8'))

        self.post_fm = {}
        self.post_etl = {}
        self.post_mdm = {}

    def extract_post_fm(self):
        """ Extract all the csv files after uploaded by FM """
        # TODO - test
        for tbl, conf in self.confs.items():
            self.post_fm[tbl] = Extractor.csv_to_df(conf["input_location"]["emr"])

        return self

    def extract_post_etl(self):
        """ Extract all the parquet files written by ETL """
        # TODO - iterate over the tables per conf (like we do in MDM)
        for tbl, conf in self.confs.items():
            self.post_etl[tbl] = Extractor.parquet_to_df(f"{conf['outputput_location']['emr']}")
        return self

    def extract_post_mdm(self):
        """ Extract the current CM set from postgres post-MDM"""
        # TODO - reduce MDM schema to post_etl set
        from cm_commons.models.trg_files import MDM_schema
        from cm_commons.db.cm_conn import cm_cxn_jdbc

        for tbl in MDM_schema:
            # Load every tbl in MDM schema, hope we don't execute on all of them
            self.post_mdm[tbl] = Extractor.postgres_to_df(table=MDM_schema, cxn=cm_cxn_jdbc, spark=spark)
        return self


df = Extractor.parquet_to_df

if __name__ == "__main__":

    confs = {"firm": "s3://lazard-test-client-master/ETL/conf/done/TEST_salesvision_firm_profile_09_03_2019.gz_1567695389655",
             "office": "s3://lazard-test-client-master/ETL/conf/done/TEST_salesvision_office_profile_09_03_2019.gz_1567695399279",
             "person": "s3://lazard-test-client-master/ETL/conf/done/TEST_salesvision_person_profile_09_03_2019.gz_1567695409626",
             "holding": "s3://lazard-test-client-master/ETL/conf/done/CLTMSTRT_ADX_LQE_Holding_Files_2019-08-22_0000000000044.CSV.gz_1566838415451",
             "asset": "s3://lazard-test-client-master/ETL/conf/done/CLTMSTRT_ADX_LQE_Asset_File_2019-08-22_0000000000044.CSV.gz_1566838289101"
             }