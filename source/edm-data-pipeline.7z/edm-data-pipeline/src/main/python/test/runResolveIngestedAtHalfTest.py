from test.unit.kharybdis.resolve import resolveIngestedAtHalf

import sys
import unittest
loader = unittest.TestLoader()
suite = loader.loadTestsFromTestCase(resolveIngestedAtHalf.ResolveIngestedAtHalfTeset)
runner = unittest.TextTestRunner(verbosity=2, stream=sys.stderr)
runner.run(suite)
