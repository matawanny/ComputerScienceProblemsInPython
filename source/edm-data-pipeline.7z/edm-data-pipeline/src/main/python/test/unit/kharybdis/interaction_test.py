import pandas as pd
from spark_functions.unit_tests.PySparkTest import PySparkTest
from cm_commons.models.converters.slqalchemy_to_spark import sqla_to_sparkdf
from cm_commons.spark import build_session

from cm_commons import colors, models

from kharybdis import Persister
from kharybdis import Resolver


if 'spark' not in globals():
    print("Creating new spark context: InteractionTestSession")
    spark = build_session("InteractionTestSession")


class InteractionTest(PySparkTest):
    def test_persist_to_resolve(self):
        """ Testing process flow from persist to resolve
        """
        indent = 0

        in_dat = {"entity_id": ["1", "2", "3", "4", "5", "6"],
                  "entity_name": ["Brendan", "Brendan",
                                  "Adam", "David",
                                  "Ron", "Ron"],
                  "salesforce_id": ["A", "None", "B", "None", "C", "None"],
                  "salesvision_id": ["333", "333", "22", "22", "1", "1"],
                  "entity_type_id": ["301", "301", "201", "201", "101", "101"],
                  "parent_id": ["None", "", "1", "2", "3", "4"],
                  "persistence_id": ["1a", "2a", "3a", "4a", "5a", "6a"],
                  "etl_source": ["cm", "sv", "cm", "sv", "cm", "sv"],
                  "updated_at": ["2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00"]
                  }

        dfs = {}
        table_name = 'entity'
        dfs[table_name], keys = sqla_to_sparkdf("Entity",
                                      num_rows=6,
                                      field_vals=in_dat,
                                      spark=spark,
                                      key_bool=True,
                                      x_cols={'etl_source': 'varchar'})


        exp_dat = {"entity_id": ["1", "1", "3", "3", "5", "5"],
                   "entity_name": ["Brendan", "Brendan",
                                   "David", "Adam",
                                   "Ron", "Ron"],
                   "salesforce_id": ["A", "A", "B", "B", "C", "C"],
                   "salesvision_id": ["333", "333", "22", "22", "1", "1"],
                   "entity_type_id": ["301", "301", "201", "201", "101", "101"],
                   "parent_id": ["None", "None", "1", "1", "3", "3"],
                   "persistence_id": ["1a", "1a", "3a", "3a", "5a", "5a"],
                   "etl_source": ["cm", "sv", "sv", "cm", "cm", "sv"],
                   "updated_at": ["2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                  "2019-02-02 00:00:00", "2019-01-01 00:00:00",
                                  "2019-01-01 00:00:00", "2019-02-02 00:00:00"]
                   }
        exp_df = sqla_to_sparkdf("Entity", num_rows=6, field_vals=exp_dat, spark=spark, key_bool=False,
                                 x_cols={'etl_source': 'varchar'})
        exp_dfs = {'entity' : exp_df}

        schema = getattr(models.trg_files, "MDM_schema")


        map_dat = {
            "rule_id": ['1x', '2x', '3x', '4x',
                        '1y', '2y', '3y', '4y',
                        '1z', '2z', '3z', '4z'],
            "original_record_entity_id": ['2', '2', '2', '2',
                                          '4', '4', '4', '4',
                                          '6', '6', '6', '6'],
            "column_name": ['parent_id', 'salesforce_id', 'entity_id', 'persistence_id',
                            'parent_id', 'salesforce_id', 'entity_id', 'persistence_id',
                            'parent_id', 'salesforce_id', 'entity_id', 'persistence_id'],
            "invalid_value": ['', 'None', '2', '2a',
                              '2', 'None', '4', '4a',
                              '4', 'None', '6', '6a'],
            "valid_value": ['None', 'A', '1', '1a',
                            '1', 'B', '3', '3a',
                            '3', 'C', '5', '5a'],
            "stewardship_type": ['Correction', 'Correction', 'Correction', 'Correction',
                                 'Correction', 'Correction', 'Correction', 'Correction',
                                 'Correction', 'Correction', 'Correction', 'Correction'],
            "created_by": ['circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge',
                           'circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge',
                           'circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge']
        }
        map_df = sqla_to_sparkdf("EntityPersistRules", num_rows=12, field_vals=map_dat, spark=spark, key_bool=False)
        persist_dfs = {'entity': map_df}

        for table_name in dfs:

            # Get table
            df = dfs[table_name]
            exp_df = exp_dfs[table_name]

            print(f"************Persisting*****************")
            colors.out_print(f"Persisting changes on {table_name}", indent=indent + 1)

            # Get keys
            pkey, fkeys = Persister.get_keys(schema=schema, table_name=table_name)

            # Apply field persistence
            colors.out_print(f"Applying fields for {table_name}", indent=indent + 2)
            df = Persister.apply_fields(df=df,
                                   persist_dfs=persist_dfs,
                                   table=table_name,
                                   pkey=pkey,
                                   ignore=[pkey, 'record_id', 'created_at',
                                           'updated_at', 'etl_source', 'enrichment_error'],
                                   indent=3
                                   )


            colors.out_print(f"Applying pkey for {table_name}.{pkey}", indent=indent + 2)
            df = Persister.apply_pkeys(df=df,
                                  persist_dfs=persist_dfs,
                                  table=table_name,
                                  pkey=pkey,
                                  indent=3
                                  )

            colors.out_print(f"Persisting foreign keys for table {table_name}", indent=indent + 2)
            df = Persister.apply_fkeys(df=df,
                                  persist_dfs=persist_dfs,
                                  table=table_name,
                                  fkeys=fkeys,
                                  indent=3
                                  )


            colors.out_print(f"Applying skey for {table_name}", indent=indent + 2)
            df = Persister.apply_skeys(df=df,
                                  persist_dfs=persist_dfs,
                                  table=table_name,
                                  skey='persistence_id',
                                  indent=3
                                  )

            print(f">>df[{table_name}]:")
            df.show(100, False)

            print(f">>exp_df:")
            exp_df.show(100, False)

            col_order = ['entity_id', 'persistence_id', 'entity_type_id', 'entity_name', 'parent_id', 'salesforce_id', 'salesvision_id', 'updated_at', 'etl_source']
            self.assertSparkDataFrameEqual(exp_df.orderBy(col_order, ascending=True),
                                           df.orderBy(col_order, asecending=True))



            print("*********Resolving*************")

            print("Input DF(full):")
            df.orderBy('entity_id', ascending=True).show(10)

            print("Input DF:")
            df.orderBy('entity_id', ascending=True).select(["entity_id", "entity_name", "parent_id", "updated_at", "etl_source"]).show(10)

            df_result = Resolver.solve_key_collision(df=df,
                                                     key='entity_id',
                                                     delta_columns=['entity_name', 'parent_id'],
                                                     indent=0)

            exp_dat = {"entity_id": ["1",  "3", "5"],
                       "entity_name": ["Brendan", "David", "Ron"],
                       "salesforce_id": ["A",  "B", "C"],
                       "salesvision_id": ["333",  "22", "1"],
                       "entity_type_id": ["301",  "201", "101"],
                       "parent_id": ["None", "1", "3"],
                       "persistence_id": ["1a", "3a", "5a"],
                       "etl_source": ["sv", "sv", "sv"],
                       "updated_at": ["2019-01-01 00:00:00", "2019-02-02 00:00:00", "2019-01-01 00:00:00"]
                       }
            exp_df = sqla_to_sparkdf("Entity", num_rows=3, field_vals=exp_dat, spark=spark, key_bool=False,
                                     x_cols={'etl_source': 'varchar'})
            exp_dfs = {'entity': exp_df}

            print("Expected DF:")
            exp_df.orderBy('entity_id', ascending=True).select(["entity_id", "entity_name", "parent_id", "updated_at", "etl_source"]).show(10)
            print("Result DF:")
            df_result.orderBy('entity_id', ascending=True).select(["entity_id", "entity_name", "parent_id", "updated_at", "etl_source"]).show(10)

            self.assertSparkDataFrameEqual(exp_df.orderBy('entity_id', ascending=True),
                                           df_result.orderBy('entity_id', asecending=True))


            dfs[table_name] = df



        # print(f">>>>>>>>>dfs[{table_name}]:")
        # dfs[table_name].show(100, False)

        return self


if __name__ == "__main__":

    import sys
    import unittest

    loader = unittest.TestLoader()
    suite = loader.loadTestsFromModule(__name__)
    runner = unittest.TextTestRunner(verbosity=1, stream=sys.stderr)
    runner.run(suite)