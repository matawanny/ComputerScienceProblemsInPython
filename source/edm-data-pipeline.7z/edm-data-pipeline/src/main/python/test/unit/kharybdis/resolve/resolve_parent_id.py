from spark_functions.unit_tests.PySparkTest import PySparkTest
from cm_commons.spark import build_session
from pyspark.sql.types import StructType, StructField, StringType
from cm_commons.models.converters.slqalchemy_to_spark import sqla_to_sparkdf

from kharybdis.resolve.resolve_parent_id import ParentResolver


spark = build_session("ResolveTest")


class ResolveParentTest(PySparkTest):
    """ All unit tests (with model integration) for ResolveParentID"""

    def test_parent_is_ancestor_no_conflict(self):
        """
            Business Cases
                - SV OFFICE is `parent` of SF OFFICE
                - SV FIRM is `parent` of SF FIRM/OFFICE

            If the parent already exists we want to use the existing parent
                :: anc_data representation   :: sv_data representation ::   target representation   ::
                ::          3sv              ::          3sv           ::          3sv              ::
                ::          2sv              ::          2sv           ::          2sv              ::
                ::          2sf              ::          1sv           ::          2sf              ::
                ::          1sv              ::                        ::          1sv              ::
        """

        # TODO - add test case for firm case as well

        data = {
            "entity_id": ["1sv", "2sv", "3sv"],
            "entity_name": ["Brendan", "WF Regional", "WF"],
            "entity_type_id": [101, 201, 301],
            "parent_id": ["2sv", "3sv", None],
            "salesvision_id": [0, 2, 3]
        }

        data_schema, data_set = sqla_to_sparkdf("Entity", num_rows=3, field_vals=data)
        df = spark.createDataFrame(data_set, schema=data_schema)

        anc_data = {
            "entity_id": ["1sv", "2sf", "2sv", "3sv"],
            "salesvision_id": [0, None, 2, 3],
            'parent_id': ["2sf", "2sv", "3sv", None],
            "entity_type_id": [101, 201, 201, 301],
            "id_path": [[3, 2, 1, 0], [3, 2, 1], [3, 2], [3]],
            "parent_path": [[None, "3sv", "2sv", "2sf"], [None, "3sv", "2sv"], [None, "3sv"], [None]],
            "sv_path": [[3, 2, None, 0], [3, 2, None], [3, 2], [3]],
            "type_path": [[3, 2, 2, 1], [3, 2, 2], [3, 2], [3]]
        }

        anc_schema, anc_set = sqla_to_sparkdf("EntityLinkedListSVAncestor", num_rows=4, field_vals=anc_data)
        anc_df = spark.createDataFrame(anc_set, schema=anc_schema)

        # Expected data
        exp_data = {
            "entity_id": ["1sv", "2sv", "3sv"],
            "entity_name": ["Brendan", "WF Regional", "WF"],
            "entity_type_id": [101, 201, 301],
            "parent_id": ["2sf", "3sv", None],  # This is the field we are trying to get right
            "salesvision_id": [0, 2, 3]
        }

        exp_schema, exp_set = sqla_to_sparkdf("Entity", num_rows=3, field_vals=exp_data)
        exp_df = spark.createDataFrame(exp_set, schema=exp_schema)

        after_df = ParentResolver(df=df, anc_df=anc_df, spark=spark, indent=0).process()

        # Subselecting to make output logs more concise
        self.assertSparkDataFrameEqual(exp_df.select(list(exp_data.keys())),
                                       after_df.select(list(exp_data.keys())))

    def test_valid_moves(self):
        """
            Business Cases
                - PERSON moves to new OFFICE
                - OFFICE moves to new FIRM

             If the parent does not exist in the ancestry, then we register the action as a move.
             This involves ignoring the ancestor suggestion

                :: anc_data representation  :: sv_data representation   ::   target representation ::
                ::         301sv            ::          302sv           ::          302sv          ::
                ::         201sv            ::          202sv           ::          202sv          ::
                ::         101sv            ::          101sv           ::          101sf          ::
        """

        data = {
            "entity_id": ["101sv", "202sv", "302sv"],
            "entity_name": ["Brendan", "Citi Regional", "Citi"],
            "entity_type_id": [101, 201, 301],
            "parent_id": ["202sv", "302sv", None],
            "salesvision_id": [1, 22, 33]
        }

        data_schema, data_set = sqla_to_sparkdf("Entity", num_rows=3, field_vals=data)
        df = spark.createDataFrame(data_set, schema=data_schema)

        anc_data = {
            "entity_id": ["101sv", "202sv", "302sv"],
            "salesvision_id": [1, 2, 3],
            'parent_id': ["201sv", "301sv", None],
            "entity_type_id": [101, 201, 301],
            "id_path": [[3, 2, 1], [3, 2], [3]],
            "parent_path": [[None, "301sv", "201sv"], [None, "301sv"], [None]],
            "sv_path": [[3, 2, None], [3, 2], [3]],
            "type_path": [[3, 2, 1], [3, 2], [3]]
        }
        anc_schema, anc_set = sqla_to_sparkdf("EntityLinkedListSVAncestor", num_rows=3, field_vals=anc_data)
        anc_df = spark.createDataFrame(anc_set, schema=anc_schema)

        # Expected data
        exp_data = {
            "entity_id": ["101sv", "202sv", "302sv"],
            "entity_name": ["Brendan", "Citi Regional", "Citi"],
            "entity_type_id": [101, 201, 301],
            "parent_id": ["202sv", "302sv", None],
            "salesvision_id": [1, 22, 33]
        }

        exp_schema, exp_set = sqla_to_sparkdf("Entity", num_rows=3, field_vals=exp_data)
        exp_df = spark.createDataFrame(exp_set, schema=exp_schema)

        after_df = ParentResolver(df=df, anc_df=anc_df, spark=spark, indent=0).process()

        self.assertSparkDataFrameEqual(exp_df.select(list(exp_data.keys())),
                                       after_df.select(list(exp_data.keys())))


    #     TODO - need to think more about this case. Not currently coded
    # def parent_is_ancestor_w_conflict(self):
    #     """
    #         Business Cases
    #             - SV OFFICE is `parent` of SV OFFICE
    #             - SV FIRM is `parent` of SV FIRM/OFFICE
    #
    #         If both `current parent` and `new parent` are represented in the system providing `new parent` (e.g. SV)
    #         - then we need to select the `new parent` so that we are compatible with export rules
    #
    #             :: anc_data representation   :: sv_data representation ::   target representation   ::
    #             ::          3sv              ::          3sv           ::          3sv              ::
    #             ::          2sv              ::       2sv  2sf         ::          2sv              ::
    #             ::          2sf              ::       0sv              ::          2sf              ::
    #             ::          1sv              ::                        ::          0sv              ::
    #     """
    #
    #     data = {
    #         "entity_id": ["1sv", "2sv", "3sv"],
    #         "entity_name": ["Brendan", "WF Regional", "WF"],
    #         "entity_type_id": [101, 201, 301],
    #         "parent_id": ["2sv", "3sv", None],
    #         "salesvision_id": [0, 2, 3]
    #     }
    #
    #     data_schema, data_set = sqla_to_sparkdf("Entity", num_rows=3, field_vals=data)
    #     df = spark.createDataFrame(data_set, schema=data_schema)
    #
    #
    #
    #     anc_data = {
    #         "entity_id": ["1sv", "2sf", "2sv", "3sv"],
    #         "salesvision_id": [0, 1, 2, 3],
    #         'parent_id': ["2sf", "2sv", "3sv", None],
    #         "entity_type_id": [101, 201, 201, 301],
    #         "id_path": [[3, 2, 1, 0], [3, 2, 1], [3, 2], [3]],
    #         "parent_path": [[None, "3sv", "2sv", "2sf"], [None, "3sv", "2sv"], [None, "3sv"], [None]],
    #         "sv_path": [[3, 2, None, 0], [3, 2, None], [3, 2], [3]],
    #         "type_path": [[3, 2, 2, 1], [3, 2, 2], [3, 2], [3]]
    #     }
    #     anc_schema, anc_set = sqla_to_sparkdf("EntityLinkedListSVAncestor", num_rows=4, field_vals=anc_data)
    #     anc_df = spark.createDataFrame(anc_set, schema=anc_schema)
    #
    #     # Expected data
    #     exp_data = {
    #         "entity_id": ["1sv", "2sv", "3sv"],
    #         "entity_name": ["Brendan", "WF Regional", "WF"],
    #         "entity_type_id": [101, 201, 301],
    #         "parent_id": ["2sf", "3sv", None],  # This is the field we are trying to get right
    #         "salesvision_id": [0, 2, 3]
    #     }
    #
    #     exp_schema, exp_set = sqla_to_sparkdf("Entity", num_rows=3, field_vals=exp_data)
    #     exp_df = spark.createDataFrame(exp_set, schema=exp_schema)
    #
    #     after_df = ResolveParentID(df=df, anc_df=anc_df, spark=spark, indent=0).process()
    #
    #     self.assertSparkDataFrameEqual(exp_df, after_df)

