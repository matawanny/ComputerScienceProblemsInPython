from operator import add
from spark_functions.unit_tests.PySparkTest import PySparkTest
from spark_functions import rename
from spark_functions import melt
from spark_functions import switch_case
from spark_functions import switch_case_2
from spark_functions import switch_case_3
from spark_functions import resolve_pkey_collision
from spark_functions import add_prefix

from cm_commons.spark import build_session
import pandas as pd
from pyspark.sql.types import StructType, StructField, StringType

spark = build_session("ETLSparkTest")


class ETLSparkTest(PySparkTest):

    def test_basic(self):
        test_rdd = spark.sparkContext.parallelize(["cat dog mouse", "cat cat dog"], 2)
        results = test_rdd.flatMap(lambda line: line.split()).map(lambda word: (word, 1)).reduceByKey(add).collect()
        expected_results = [("cat", 3), ("dog", 2), ("mouse", 1)]
        self.assertEqual(set(results), set(expected_results))

    def test_rename(self):
        expected_df = {"a": [1], "z": [1], "b": [2]}
        df = spark.createDataFrame(pd.DataFrame({"a": [1], "b": [2]}))
        out_df = rename(df, "a", "z").toPandas().to_dict(orient='list')
        self.assertEqual(expected_df, out_df)

    def test_add_prefix(self):
        before_df = spark.createDataFrame({"a": [0, 1, 2], "b": [0, 1, 2]})
        after_df = add_prefix(df=before_df, prefix="test_pre_")
        expected_df = spark.createDataFrame({"test_pre_a": [0, 1, 2], "test_pre_b": [0, 1, 2]})

        self.assertSparkDataFrameEqual(expected_df, after_df)




    def test_melt(self):
        expected_df = spark.createDataFrame(pd.DataFrame(
            {"a": ["1", "1", "1", "4", "4", "4"],
             "b": ["2", "2", "2", "5", "5", "5"],
             "c": ["3", "3", "3", "6", "6", "6"],
             "d": ["1", "2", "3", "4", "5", "6"],
             }
        )
        )
        df = spark.createDataFrame(pd.DataFrame({"a": ["1", "4"], "b": ["2", "5"], "c": ["3", "6"]}))
        pre_melt = {'class_a': ['a'], 'class_b': ['b'], 'class_c': ['c']}
        post_melt = {"output": ["d"]}
        df = melt(df, pre_melt, post_melt)
        self.assertSparkDataFrameEqual(expected_df, df)

        expected_df = spark.createDataFrame(pd.DataFrame(
            {"a": ["1", "1", "4", "4"],
             "b": ["2", "2", "5", "5"],
             "c": ["3", "3", "6", "6"],
             "d": ["1", "2", "4", "5"]
             }
        )
        )
        df = spark.createDataFrame(pd.DataFrame({"a": ["1", "4"], "b": ["2", "5"], "c": ["3", "6"]}))
        pre_melt = {'class_a': ['a'], 'class_b': ['b']}
        post_melt = {"output": ["d"]}
        df = melt(df, pre_melt, post_melt)
        self.assertSparkDataFrameEqual(expected_df, df)

        expected_df = spark.createDataFrame(pd.DataFrame(
            {'a': {0: None, 1: None, 2: None, 3: '1.0', 4: '1.0', 5: '1.0'},
             'b': {0: None, 1: None, 2: None, 3: '5', 4: '5', 5: '5'},
             'c': {0: '3', 1: '3', 2: '3', 3: '6', 4: '6', 5: '6'},
             'd': {0: None, 1: None, 2: '3', 3: '1.0', 4: '5', 5: '6'}}
        )
        )
        df = spark.createDataFrame(pd.DataFrame({"a": [None, 1], "b": [None, "5"], "c": ["3", "6"]}))
        pre_melt = {'class_a': ['a'], 'class_b': ['b'], 'class_c': ['c']}
        post_melt = {"output": ["d"]}
        df = melt(df, pre_melt, post_melt)
        self.assertSparkDataFrameEqual(expected_df, df)

    def test_switch_case(self):
        expected_df = spark.createDataFrame(pd.DataFrame(
            {'a': {0: '1', 1: '4', 2: '7', 3: None}, 'b': {0: '2', 1: '5', 2: '2', 3: None},
             'c': {0: '3', 1: '6', 2: '5', 3: None},
             'c_new': {0: 'team', 1: 'person', 2: 'unknown', 3: 'office'}}))
        df = spark.createDataFrame(
            pd.DataFrame({"a": ["1", "4", "7", None], "b": ["2", "5", "2", None], "c": ["3", "6", "5", None]}))
        statement = [('3', 'team'), ('6', 'person'), (None, 'office')]
        df = switch_case(df, col='c', out='c_new',
                         statement=statement, default='unknown')
        self.assertSparkDataFrameEqual(expected_df, df)

    def test_switch_case_2(self):
        expected_df = spark.createDataFrame(pd.DataFrame(
            {'a': {0: '1', 1: '4', 2: '7', 3: None}, 'b': {0: '2', 1: '5', 2: '2', 3: None},
             'c': {0: '3', 1: '6', 2: '5', 3: None},
             'c_new': {0: 'team', 1: 'person', 2: 'unknown', 3: 'office'}}))
        df = spark.createDataFrame(
            pd.DataFrame({"a": ["1", "4", "7", None], "b": ["2", "5", "2", None], "c": ["3", "6", "5", None]}))
        statement = [('3', 'team'), ('6', 'person'), (None, 'office')]
        df = switch_case_2(df, in_col='c', out_col='c_new',
                           statement=statement, default='unknown')
        self.assertSparkDataFrameEqual(expected_df, df)

    def test_switch_case_3(self):
        expected_df_isin = spark.createDataFrame(pd.DataFrame(
            {'a': {0: '1', 1: '4', 2: '7', 3: None}, 'b': {0: '2', 1: '5', 2: '2', 3: None},
             'c': {0: '3', 1: '6', 2: '7', 3: None},
             'c_new': {0: False, 1: True, 2: False, 3: True}}))
        df = spark.createDataFrame(
            pd.DataFrame({"a": ["1", "4", "7", None], "b": ["2", "5", "2", None], "c": ["3", "6", "7", None]}))
        statement = [('6', True), (None, True)]
        df_isin = switch_case_3(df, in_col='c', out_col='c_new',
                                statement=statement, default=False, func_name='isin')
        self.assertSparkDataFrameEqual(expected_df_isin, df_isin)

        expected_df_gte = spark.createDataFrame(pd.DataFrame(
            {'a': {0: '1', 1: '4', 2: '7', 3: None}, 'b': {0: '2', 1: '5', 2: '2', 3: None},
             'c': {0: '3', 1: '6', 2: '7', 3: None},
             'c_new': {0: False, 1: True, 2: True, 3: False}}))
        df = spark.createDataFrame(
            pd.DataFrame({"a": ["1", "4", "7", None], "b": ["2", "5", "2", None], "c": ["3", "6", "7", None]}))
        statement = [('6', True), (None, True)]
        df_gte = switch_case_3(df, in_col='c', out_col='c_new',
                               statement=statement, default=False, func_name='gte')
        self.assertSparkDataFrameEqual(expected_df_gte, df_gte)

        expected_df_error = "func_name should be isin or gte"
        df = spark.createDataFrame(
            pd.DataFrame({"a": ["1", "4", "7", None], "b": ["2", "5", "2", None], "c": ["3", "6", "7", None]}))
        statement = [('6', True), (None, True)]
        try:
            switch_case_3(df, in_col='c', out_col='c_new', statement=statement, default=False,
                          func_name='error')
        except AssertionError as e:
            self.assertEqual(str(e), expected_df_error)

    def test_resolve_pkey_collision(self):
        dataList = [
            ['1', 'Bren', '1a', 'sv', '2019-06-05'],
            ['1', 'Bran', '2a', 'sv', '2019-06-06'],
            ['1', 'BRAN', '3a', 'cm', '2019-06-05'],
            ['2', 'Dave', '77', 'cm', '2019-06-04'],
        ]

        data_schema = [
            StructField('pkey', StringType(), True),
            StructField('name', StringType(), True),
            StructField('sv_id', StringType(), True),
            StructField('source', StringType(), True),
            StructField('updated_at', StringType(), True),
        ]
        input_struct = StructType(fields=data_schema)

        df = spark.createDataFrame(dataList, schema=input_struct)

        from collections import defaultdict

        rules = defaultdict(lambda: ('updated_at', 'source'))
        rules.update({
            'name': ('updated_at', 'source'),
            'sv_id': ('source', 'updated_at'),
            'updated_at': ('updated_at'),
        })

        source_rankings = defaultdict(lambda: {'sv': 1, 'cm': 2})
        source_rankings.update({'name': {'cm': 1, 'sv': 2}, 'sv_id': {'sv': 1, 'cm': 2}})

        newdf = resolve_pkey_collision(spark, df, rules, source_rankings, 'pkey', 'source')

        expected_df = spark.createDataFrame(pd.DataFrame(
            {'pkey': {0: '1', 1: '2'}, 'name': {0: 'Bran', 1: 'Dave'},
             'sv_id': {0: '2a', 1: '77'}, 'source': {0: 'sv', 1: 'cm'},
             'updated_at': {0: '2019-06-06', 1: '2019-06-04'}}))

        self.assertSparkDataFrameEqual(expected_df, newdf)
