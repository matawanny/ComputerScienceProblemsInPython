from kharybdis import Resolver
import pandas as pd
from spark_functions.unit_tests.PySparkTest import PySparkTest
from cm_commons.models.converters.slqalchemy_to_spark import sqla_to_sparkdf
from cm_commons.spark import build_session


if 'spark' not in globals():
    print("Creating new spark context: PersistRules")
    spark = build_session("PersistRules")


class ResolveIngestedAtHalfTeset(PySparkTest):

    def test_min_max_update(self):
        """ If a record comes in without any actual updates, we should use the older updated_at date
        """
        # Testing type
        in_dat = {"entity_id": ["1", "1", "1",
                                "3", "3",
                                "5", "5",
                                "6", "6"],
                  "entity_name": ["Brendan", "Brendan", "Brandon",
                                 "Adam", "David",
                                 "Ron", "Ron",
                                  "Philip", "Philippe"],
                  "parent_id": ["11", "11","11",
                                "13", "13",
                                "15", "16",
                                "17", "18"],
                  "ingested_at": ["2019-02-01 00:00:00", "",None,
                                 "2019-01-01 00:00:00", "",
                                 "2019-01-01 00:00:00", "",
                                "2019-01-01 00:00:00", None ],
                  "updated_at": ["2019-02-02 00:00:00", "2019-03-01 00:00:00", "2019-04-01 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-02-01 00:00:00", "2019-02-02 00:00:00",],
                  "etl_source": ["cm", "sf", "sv",
                                 "cm", "sf",
                                 "cm", "sf",
                                 "cm", "sf"]}
        in_df, keys = sqla_to_sparkdf("Entity",
                                      num_rows=9,
                                      field_vals=in_dat,
                                      spark=spark,
                                      key_bool=True,
                                      x_cols={'etl_source': 'varchar'})
        print("\nInput DF:")
        in_df.orderBy('entity_id', ascending=True).select(
            ["entity_id", "entity_name", "parent_id", "ingested_at", "updated_at", "etl_source"]).show(10)

        exp_dat = {"entity_id": ["1",
                                 "3",
                                 "5",
                                 "6"],
                  "entity_name": ["Brandon",
                                  "David",
                                  "Ron",
                                  "Philippe" ],
                  "parent_id": ["11",
                                "13",
                                "16",
                                "18"],
                  "ingested_at": [None, "",
                                  "", None],
                  "updated_at": ["2019-04-01 00:00:00",
                                 "2019-02-02 00:00:00",
                                 "2019-02-02 00:00:00",
                                 "2019-02-02 00:00:00"],
                  "etl_source": ["sv",
                                 "sf",
                                 "sf",
                                 "sf"]}

        exp_df = sqla_to_sparkdf("Entity", num_rows=4, field_vals=exp_dat, spark=spark, key_bool=False,
                                 x_cols={'etl_source': 'varchar',
                                         'created_at': 'varchar'})

        df_actual = Resolver.solve_key_collision(df=in_df,
                                                 key='entity_id',
                                                 delta_columns=['entity_name', 'parent_id'],
                                                 indent=0)

        print("Expected DF:")
        exp_df.orderBy('entity_id', ascending=True).select(["entity_id", "entity_name", "parent_id", "ingested_at", "updated_at", "etl_source"]).show(10)

        print("Actual DF:")
        df_actual.orderBy('entity_id', ascending=True).select(["entity_id", "entity_name", "parent_id", "ingested_at", "updated_at", "etl_source"]).show(10)
        self.assertSparkDataFrameEqual(exp_df.orderBy('entity_id', ascending=True),
                                       df_actual.orderBy('entity_id', asecending=True))
        # Testing type
        return self

    def test_amg_entity_interactions(self):
        """ AMG updates should be ignored
        """
        # Testing type
        in_dat = {"entity_id": ["1", "1"],
                  "entity_name": ["Brendan", "Brendan from AMG"],
                  "parent_id": ["11", "None"],
                  "ingested_at": ["2019-01-01 00:00:00", ""],
                  "updated_at": ["2019-01-01 00:00:00", "2019-02-02 00:00:00"],
                  "etl_source": ["cm", "amg"]}
        in_df, keys = sqla_to_sparkdf("Entity",
                                      num_rows=2,
                                      field_vals=in_dat,
                                      spark=spark,
                                      key_bool=True,
                                      x_cols={'etl_source': 'varchar'})
        print("\nInput DF:")
        in_df.orderBy('entity_id', ascending=True).select(
            ["entity_id", "entity_name", "parent_id", "ingested_at", "updated_at", "etl_source"]).show(10)


        exp_dat = {"entity_id": ["1"],
                   "entity_name": ["Brendan"],
                   "parent_id": ["11"],
                   "ingested_at": ["2019-01-01 00:00:00"],
                   "updated_at": ["2019-01-01 00:00:00"],
                   "etl_source": ["cm"]}

        exp_df = sqla_to_sparkdf("Entity", num_rows=1, field_vals=exp_dat, spark=spark, key_bool=False,
                                 x_cols={'etl_source': 'varchar',
                                         'created_at': 'varchar'})

        df_actual = Resolver.solve_key_collision(df=in_df,
                                                 key='entity_id',
                                                 delta_columns=['entity_name', 'parent_id'],
                                                 indent=0)

        print("Expected DF:")
        exp_df.orderBy('entity_id', ascending=True).select(
            ["entity_id", "entity_name", "parent_id", "ingested_at", "updated_at", "etl_source"]).show(10)
        exp_df.head(3)
        print("Actual DF:")
        df_actual.orderBy('entity_id', ascending=True).select(
            ["entity_id", "entity_name", "parent_id", "ingested_at", "updated_at", "etl_source"]).show(10)
        df_actual.head(3)
        self.assertSparkDataFrameEqual(exp_df.orderBy('entity_id', ascending=True),
                                       df_actual.orderBy('entity_id', asecending=True))
        # Testing type
        return self

    def test_resolve_non_conflicting(self):
        """ If a record comes in without any actual updates, we should use the older updated_at date
        """
        # Testing type
        in_dat = {"entity_id": ["1", "1",
                                "3", "3",
                                "5", "5",
                                "7", "7"],
                  "entity_name": ["Brendan", "Brendan",
                                  "Adam", "Adam",
                                  "RON", "Ron",
                                  "Navin", "Navin"],
                  "parent_id": ["11", "11",
                                "13", "13",
                                "15", "15",
                                "15", "17"],
                  "client_type_id": ["20", "edm_exempt",
                                     "20", None,
                                     "20", "None",
                                     "20", "EDM-1999"],
                  "ingested_at": ["2019-01-01 00:00:00", "",
                                 "2019-01-01 00:00:00", "",
                                 "2019-01-01 00:00:00", "",
                                 "2019-01-01 00:00:00", ""],
                  "updated_at": ["2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00"],
                  "etl_source": ["cm", "sf",
                                 "cm", "sf",
                                 "cm", "sf",
                                 "cm", "sf"]}
        in_df, keys = sqla_to_sparkdf("Entity",
                                      num_rows=8,
                                      field_vals=in_dat,
                                      spark=spark,
                                      key_bool=True,
                                      x_cols={'etl_source': 'varchar'})

        cols = ["entity_id", "entity_name", "parent_id", "client_type_id", "ingested_at", "updated_at", "etl_source"]
        print("\nInput DF:")
        in_df.orderBy(cols, ascending=True).select(cols).show(10)

        exp_dat = {"entity_id": ["1", "1",
                                "3", "3",
                                "5", "5",
                                "7", "7"],
                  "entity_name": ["Brendan", "Brendan",
                                  "Adam", "Adam",
                                  "RON", "Ron",
                                  "Navin", "Navin"],
                  "parent_id": ["11", "11",
                                "13", "13",
                                "15", "15",
                                "15", "17"],
                  "client_type_id": ["20", "20",
                                     "20", "20",
                                     "20", "20",
                                     "20", "EDM-1999"],
                  "ingested_at": ["2019-01-01 00:00:00", "",
                                  "2019-01-01 00:00:00", "",
                                  "2019-01-01 00:00:00", "",
                                  "2019-01-01 00:00:00", ""],
                  "updated_at": ["2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00"],
                  "etl_source": ["cm", "sf",
                                 "cm", "sf",
                                 "cm", "sf",
                                 "cm", "sf"]}

        exp_df = sqla_to_sparkdf("Entity", num_rows=8, field_vals=exp_dat, spark=spark, key_bool=False,
                                 x_cols={'etl_source': 'varchar',
                                         'created_at': 'varchar'})

        df_actual = Resolver.solve_non_conflicting_values(in_df, key='entity_id',
                                                          cols=None,
                                                          none_vals=["edm-881", "edm-494", "edm-1030", "edm-1090", "none", "edm_exempt"],
                                                          indent=0)

        print("Expected DF:")
        exp_df.orderBy(cols, ascending=True).select(cols).show(10)
        print("Actual DF:")
        df_actual.orderBy(cols, ascending=True).select(cols).show(10)

        self.assertSparkDataFrameEqual(exp_df.orderBy(cols, ascending=True),
                                       df_actual.orderBy(cols, asecending=True))
        # Testing type
        return self