from kharybdis import CNCR
import pandas as pd
from spark_functions.unit_tests.PySparkTest import PySparkTest
from cm_commons.models.converters.slqalchemy_to_spark import sqla_to_sparkdf
from cm_commons.spark import build_session
import pyspark.sql.functions as f


if 'spark' not in globals():
    print("Creating new spark context: PersistRules")
    spark = build_session("PersistRules")


class CNCRTest(PySparkTest):

    def test_exact_match(self):
        """"""
        # Testing type
        in_dat = {"salesvision_id": ["1", "1",
                                "1", "1"],
                  "entity_id": ["a1", "a2",
                                "a3", "a4"],
                  "persistence_id": ["11", "11",
                                     "11", "11"],
                  "entity_type_prefix": ["1", "1",
                                "1", "1"],
                  "entity_name": ["Brendan", "None",
                                  "Bren3", "Bran"],
                  "parent_id": ["101", None,
                                "103", "104"],
                  "client_type_id": ["20", "a2",
                                     "20", None],
                  "updated_at": ["2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00"
                                 ],
                  "ended_at": ["2019-01-01", "None",
                               "edm_exempt", "None"
                               ],
                  "etl_source": ["cm", "sf",
                                 "sv_person", "cm"
                                 ]}
        in_df, keys = sqla_to_sparkdf("Entity",
                                      num_rows=4,
                                      field_vals=in_dat,
                                      spark=spark,
                                      key_bool=True,
                                      x_cols={'etl_source': 'varchar'})

        in_df = in_df.withColumn("entity_type_prefix", f.lit("1"))
        print("Input DF:")
        in_df.orderBy('entity_id', ascending=True).select(list(in_dat.keys())).show(100)

        end_date = "YYYY-MM-DD"

        exp_dat = {"salesvision_id": ["1", "1", "1",
                                "1", "1"],
                  "entity_id": ["a1", "a2", "a2",
                                "a3", "a4"],
                  "persistence_id": ["11", "11", "11",
                                     "11", "11"],
                  "entity_type_prefix": ["1", "1", "1",
                                "1", "1"],
                  "entity_name": ["Brendan", "None", "Bran",
                                  "Bren3", "Bran"],
                  "parent_id": ["101", None, "104",
                                "103", "104"],
                  "client_type_id": ["20", "a2", "a2",
                                     "20", None],
                  "updated_at": ["2019-01-01 00:00:00", "2019-02-02 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00"
                                 ],
                  "ended_at": ["2019-01-01", "None", "edm_exempt",
                               "edm_exempt", "None"
                               ],
                  "etl_source": ["cm", "sf", "sv_match",
                                 "sv_person", "cm"
                                 ]}

        exp_df = sqla_to_sparkdf("Entity", num_rows=5, field_vals=exp_dat, spark=spark, key_bool=False,
                                 x_cols={'etl_source': 'varchar',
                                         'created_at': 'varchar'})
        exp_df = exp_df.withColumn("entity_type_prefix", f.lit("1"))

        output_df = CNCR.process_exact_match(in_df,'entity','entity',
                                                     ['salesvision_id', 'entity_type_prefix'],'sv')

        cols = ["entity_id", "etl_source"]
        print("Expected DF:")
        exp_df.orderBy(cols, ascending=True).select(list(in_dat.keys())).show(100)
        print("Output DF:")
        output_df.orderBy(cols, ascending=True).select(['salesvision_id', 'entity_id', 'persistence_id',
                                                               'entity_type_prefix', 'entity_name', 'parent_id',
                                                               'client_type_id', 'updated_at', 'ended_at',
                                                               'etl_source', 'tds_master']).show(100)

        self.assertSparkDataFrameEqual(exp_df.select(list(in_dat.keys())).orderBy(cols, ascending=True),
                                       output_df.select(list(in_dat.keys())).orderBy(cols, asecending=True))

        return self