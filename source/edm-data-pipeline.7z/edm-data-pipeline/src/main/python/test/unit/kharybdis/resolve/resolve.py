from kharybdis import Resolver
import pandas as pd
from spark_functions.unit_tests.PySparkTest import PySparkTest
from cm_commons.models.converters.slqalchemy_to_spark import sqla_to_sparkdf
from cm_commons.spark import build_session


if 'spark' not in globals():
    print("Creating new spark context: PersistRules")
    spark = build_session("PersistRules")


class ResolveTeset(PySparkTest):
    # def test_solve_key_collision(self):
    #     """ Simple fields mapping of salesforce_id
    #         - rules:
    #             - only non-pkey, non-extra
    #     """
    #     # Testing type
    #     in_dat = {"entity_id": ["1", "1",
    #                             "3", "3",
    #                             "5", "5"],
    #               "entity_name": ["Brendan", "BRENDAN",
    #                              "Adam", "ADAM",
    #                              "Ron", "RON"],
    #               "updated_at": ["2019-01-01 00:00:00", "2019-02-02 00:00:00",
    #                              "2019-01-01 00:00:00", "2018-01-01 00:00:00",
    #                              "2019-01-01 00:00:00", "2019-01-01 00:00:00"],
    #               "etl_source": ["cm", "sv_person",
    #                              "cm", "sv_person",
    #                              "cm", "sv_person"]}
    #     in_df, keys = sqla_to_sparkdf("Entity",
    #                                   num_rows=6,
    #                                   field_vals=in_dat,
    #                                   spark=spark,
    #                                   key_bool=True,
    #                                   x_cols={'etl_source': 'varchar'})
    #
    #     exp_dat = {"entity_id": ["1",
    #                              "3",
    #                              "5"],
    #               "entity_name": ["BRENDAN",
    #                               "Adam",
    #                               "RON"],
    #               "updated_at": ["2019-02-02 00:00:00",
    #                              "2019-01-01 00:00:00",
    #                              "2019-01-01 00:00:00"],
    #               "etl_source": ["cm",
    #                              "cm",
    #                              "cm"]}
    #
    #     exp_df = sqla_to_sparkdf("Entity", num_rows=3, field_vals=exp_dat, spark=spark, key_bool=False,
    #                              x_cols={'etl_source': 'varchar',
    #                                      'created_at': 'varchar'})
    #
    #     df_actual = Resolver.solve_key_collision(df=in_df,
    #                                              key='entity_id',
    #                                              indent=0)
    #
    #     print("Expected DF:")
    #     exp_df.orderBy('entity_id', ascending=True).select(["entity_id", "entity_name", "updated_at", "etl_source"]).show(10)
    #     print("Actual DF:")
    #     df_actual.orderBy('entity_id', ascending=True).select(["entity_id", "entity_name", "updated_at", "etl_source"]).show(10)
    #
    #     self.assertSparkDataFrameEqual(exp_df.orderBy('entity_id', ascending=True),
    #                                    df_actual.orderBy('entity_id', asecending=True))
    #     # Testing type
    #     return self

    def test_min_max_update(self):
        """
        If a record comes in without any actual updates, we should use the older updated_at date
        """
        # Testing type
        in_dat = {"entity_id": ["1", "1",
                                "3", "3",
                                "4", "4",
                                "5", "5",
                                "6"],
                  "entity_name": ["Brendan", "Brendan",
                                 "Adam", "David",
                                  "Miller|Philip|null", "Miller|Philip|Charles",
                                 "Ron", "Ron",
                                  "Gandhi|Karthik|null"],
                  "parent_id": ["11", "11",
                                "13", "13",
                                "14", "14",
                                "15", "16",
                                "17"],
                  "updated_at": ["2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2020-08-07 00:00:00", "2020-08-07 11:35:58",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                  "2020-01-01 00:00:00"],
                  "etl_source": ["cm", "sv",
                                 "cm", "sv",
                                 "cm", "sv",
                                 "cm", "sv",
                                 "sv"]}
        in_df, keys = sqla_to_sparkdf("Entity",
                                      num_rows=9,
                                      field_vals=in_dat,
                                      spark=spark,
                                      key_bool=True,
                                      x_cols={'etl_source': 'varchar'})

        cols = ["entity_id", "entity_name", "parent_id", "updated_at", "etl_source"]

        print("Input DF:")
        in_df.orderBy('entity_id', ascending=True).select(
            ["entity_id", "entity_name", "parent_id", "updated_at", "etl_source"]).show(20, False)

        exp_dat = {"entity_id": ["1",
                                 "3",
                                 "4",
                                 "5", "6"],
                  "entity_name": ["Brendan",
                                  "David",
                                  "Miller|Philip|Charles",
                                  "Ron", "Gandhi|Karthik|null"],
                  "parent_id": ["11",
                                "13",
                                "14",
                                "16", "17"],
                  "updated_at": ["2019-01-01 00:00:00",
                                 "2019-02-02 00:00:00",
                                 "2020-08-07 11:35:58",
                                 "2019-02-02 00:00:00", "2020-01-01 00:00:00"],
                  "etl_source": ["sv",
                                 "sv",
                                 "sv",
                                 "sv", "sv"]}

        exp_df = sqla_to_sparkdf("Entity", num_rows=5, field_vals=exp_dat, spark=spark, key_bool=False,
                                 x_cols={'etl_source': 'varchar',
                                         'created_at': 'varchar'})

        df_actual, upd_df = Resolver.solve_key_collision(df=in_df,
                                                 key='entity_id',
                                                 delta_columns=['entity_name', 'parent_id'],
                                                 indent=0)

        if upd_df != None:
            print("upd_df:")
            upd_df.show(20, False)



        print("Expected DF:")
        exp_df.orderBy('entity_id', ascending=True).select(["entity_id", "entity_name", "parent_id", "updated_at", "etl_source"]).show(20, False)
        print("Result DF:")
        df_actual.orderBy('entity_id', ascending=True).select(["entity_id", "entity_name", "parent_id", "updated_at", "etl_source"]).show(20, False)

        self.assertSparkDataFrameEqual(exp_df.orderBy(cols, ascending=True),
                                       df_actual.orderBy(cols, asecending=True))

        # Testing type
        return self

    def test_amg_entity_interactions(self):
        """ AMG updates should be ignored
        """
        # Testing type
        in_dat = {"entity_id": ["1", "1"],
                  "entity_name": ["Brendan", "Brendan from AMG"],
                  "parent_id": ["11", "None"],
                  "updated_at": ["2019-01-01 00:00:00", "2019-02-02 00:00:00"],
                  "etl_source": ["cm", "amg"]}
        in_df, keys = sqla_to_sparkdf("Entity",
                                      num_rows=2,
                                      field_vals=in_dat,
                                      spark=spark,
                                      key_bool=True,
                                      x_cols={'etl_source': 'varchar'})
        print("Input DF:")
        in_df.orderBy('entity_id', ascending=True).select(
            ["entity_id", "entity_name", "parent_id", "updated_at", "etl_source"]).show(20, False)


        exp_dat = {"entity_id": ["1"],
                   "entity_name": ["Brendan"],
                   "parent_id": ["11"],
                   "updated_at": ["2019-01-01 00:00:00"],
                   "etl_source": ["cm"]}

        exp_df = sqla_to_sparkdf("Entity", num_rows=1, field_vals=exp_dat, spark=spark, key_bool=False,
                                 x_cols={'etl_source': 'varchar',
                                         'created_at': 'varchar'})

        df_actual, upd_df = Resolver.solve_key_collision(df=in_df,
                                                 key='entity_id',
                                                 delta_columns=['entity_name', 'parent_id'],
                                                 indent=0)

        print("Expected DF:")
        exp_df.orderBy('entity_id', ascending=True).select(
            ["entity_id", "entity_name", "parent_id", "updated_at", "etl_source"]).show(20, False)
        print("Result DF:")
        df_actual.orderBy('entity_id', ascending=True).select(
            ["entity_id", "entity_name", "parent_id", "updated_at", "etl_source"]).show(20, False)

        self.assertSparkDataFrameEqual(exp_df.orderBy('entity_id', ascending=True),
                                       df_actual.orderBy('entity_id', asecending=True))
        # Testing type
        return self

    def test_resolve_non_conflicting(self):
        """
        If a record comes in without any actual updates, we should use the older updated_at date
        """
        # Testing type
        in_dat = {"entity_id": ["1", "1",
                                "3", "3",
                                "5", "5",
                                "7", "7",
                                "8", "8"],
                  "entity_name": ["Brendan", "Brendan",
                                  "Adam", "Adam",
                                  "RON", "Ron",
                                  "Navin", "Navin",
                                  "Miller|Philip|null", "Miller|Philip|Charles"],
                  "parent_id": ["11", "11",
                                "13", "13",
                                "15", "15",
                                "15", "17",
                                "16", "18"],
                  "client_type_id": ["20", "edm_exempt",
                                     "30", None,
                                     "40", "None",
                                     "50", "EDM-1999",
                                     None, "60"],
                  "updated_at": ["2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-03-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-04-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-05-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-06-02 00:00:00"],
                  "etl_source": ["cm", "sf",
                                 "cm", "sf",
                                 "cm", "sf",
                                 "cm", "sf",
                                 "cm", "sf"]}
        in_df, keys = sqla_to_sparkdf("Entity",
                                      num_rows=10,
                                      field_vals=in_dat,
                                      spark=spark,
                                      key_bool=True,
                                      x_cols={'etl_source': 'varchar'})

        cols = ["entity_id", "entity_name", "parent_id", "client_type_id", "updated_at", "etl_source"]
        print("Input DF:")
        in_df.orderBy(cols, ascending=True).select(cols).show(20, False)

        exp_dat = {"entity_id": ["1", "1",
                                "3", "3",
                                "5", "5",
                                "7", "7",
                                "8", "8"],
                  "entity_name": ["Brendan", "Brendan",
                                  "Adam", "Adam",
                                  "RON", "Ron",
                                  "Navin", "Navin",
                                  "Miller|Philip|null", "Miller|Philip|Charles"],
                  "parent_id": ["11", "11",
                                "13", "13",
                                "15", "15",
                                "15", "17",
                                "16", "18"],
                  "client_type_id": ["20", "20",
                                     "30", "30",
                                     "40", "40",
                                     "50", "EDM-1999",
                                     "60", "60" ],
                  "updated_at": ["2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-03-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-04-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-05-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-06-02 00:00:00"],
                  "etl_source": ["cm", "sf",
                                 "cm", "sf",
                                 "cm", "sf",
                                 "cm", "sf",
                                 "cm", "sf"]}

        exp_df = sqla_to_sparkdf("Entity", num_rows=10, field_vals=exp_dat, spark=spark, key_bool=False,
                                 x_cols={'etl_source': 'varchar',
                                         'created_at': 'varchar'})

        df_actual = Resolver.solve_non_conflicting_values(in_df, key='entity_id',
                                                          cols=None,
                                                          none_vals=["edm-881", "edm-494", "edm-1030", "edm-1090", "none", "edm_exempt"],
                                                          indent=0)

        print("Expected DF:")
        exp_df.orderBy(cols, ascending=True).select(cols).show(20, False)
        print("Result DF:")
        df_actual.orderBy(cols, ascending=True).select(cols).show(20, False)

        self.assertSparkDataFrameEqual(exp_df.orderBy(cols, ascending=True),
                                       df_actual.orderBy(cols, asecending=True))
        # Testing type
        return self

    def test_solve_parent_move(self):
        """"""
        # Testing type
        in_dat = {"entity_id": ["1", "2",
                                "3", "4",
                                "5", "6",
                                "7", "8",
                                "30", "40", "50", "60", # children of 3 and 5
                                "91", "92",
                                "93", "94"
                                ],
                  "persistence_id": ["11", "11",
                                     "33", "33",
                                     "55", "55",
                                     "77", "77",
                                     "300", "400", "500", "600",
                                     "900","900",
                                     "901", "901"
                                     ],
                  "entity_type_id": ["301", "301",
                                "301", "305",
                                "201", "201",
                                "301", "301",
                                "201", "201", "101", "101",  # children of 3 and 5
                                "101", "101", "101", "101"
                                ],
                  "entity_name": ["Brendan", "Brendan",
                                  "Adam", "Adam",
                                  "RON", "Ron",
                                  "Navin", "Navin",
                                  "AdamsChild", "AdamsChild", "RONsChild", "RonsChild",
                                  "Record", "SameRecordWithNewParent",
                                  "Record", "SV-SameRecordWithNewParent"
                                  ],
                  "parent_id": ["101", "102",
                                "103", "104",
                                "105", "106",
                                "107", "108",
                                "3", "3", "5", "5",
                                "0", "9",
                                "1.1", "9.1"
                                ],
                  "client_type_id": ["20", "edm_exempt",
                                     "20", None,
                                     "20", "None",
                                     "20", "EDM-1999",
                                     "200", "200", "200", "200",
                                     "999", "999", "899", "899"],
                  "updated_at": ["2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                 "2020-01-01 10:10:10", "2020-01-01 10:10:10",
                                 "2020-01-01 10:10:10", "2020-01-01 10:10:10"
                                 ],
                  "ended_at": ["2019-01-01", "None",
                               "edm_exempt", "None",
                               "None", "None",
                               "None", "2019-02-02",
                               "2020-02-02", None,
                               "2020-02-02", None,
                               None, None,
                               None, None
                               ],
                  "etl_source": ["cm", "sv_person",
                                 "cm", "sv_person",
                                 "cm", "sv_person",
                                 "cm", "sv_person",
                                 "cm", "sv_person",
                                 "cm", "sv_person",
                                 "cm", "sf",
                                 "cm", "sv_person"
                                 ]}
        in_df, keys = sqla_to_sparkdf("Entity",
                                      num_rows=16,
                                      field_vals=in_dat,
                                      spark=spark,
                                      key_bool=True,
                                      x_cols={'etl_source': 'varchar'})
        print("Input DF:")
        in_df.orderBy('entity_id', ascending=True).select(list(in_dat.keys())).show(20, False)

        end_date = "YYYY-MM-DD"

        exp_dat = {"entity_id": ["1", "2",
                                 "3", "4",
                                 "5", "6",
                                 "7", "8",
                                 "30", "40", "50", "60",
                                 "91", "92",
                                 "93", "94"
                                  ],
                   "persistence_id": ["11", "11",
                                      "33", "33",
                                      "55", "55",
                                      "77", "77",
                                      "300", "400", "500", "600",
                                      "900", "900",
                                      "901", "901"
                                      ],
                   "entity_type_id": ["301", "301",
                                 "301", "305",
                                 "201", "201",
                                 "301", "301",
                                 "201", "201", "101", "101",  # children of 3 and 5
                                 "101", "101", "101", "101"
                                 ],
                   "entity_name": ["Brendan", "Brendan",
                                   "Adam", "Adam",
                                   "RON", "Ron",
                                   "Navin", "Navin",
                                   "AdamsChild", "AdamsChild", "RONsChild", "RonsChild",
                                   "Record", "SameRecordWithNewParent",
                                   "Record", "SV-SameRecordWithNewParent"
                                   ],
                   "parent_id": ["101", "102",
                                 "103", "104",
                                 "105", "106",
                                 "107", "108",
                                 "3", "4", "5", "6",
                                 "0", "9", "1.1", "9.1"
                                 ],
                   "client_type_id": ["20", "20",
                                      "20", "20",
                                      "20", "20",
                                      "20", "EDM-1999",
                                      "200", "200", "200", "200",
                                      "999", "999", "899", "899"],
                   "updated_at": ["2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                  "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                  "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                  "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                  "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                  "2019-01-01 00:00:00", "2019-02-02 00:00:00",
                                  "2020-01-01 10:10:10", "2020-01-01 10:10:10",
                                  "2020-01-01 10:10:10", "2020-01-01 10:10:10"
                                  ],
                   "ended_at": ["2019-01-01", "None",
                                "2019-02-02 00:00:00", "None",
                                "2019-02-02 00:00:00", "None",
                                "None", "2019-02-02",
                                "2020-02-02", None,
                                "2020-02-02", None,
                                None, None,
                                "2020-01-01 10:10:10", None
                                ],
                   "etl_source": ["cm", "sv_person",
                                  "cm", "sv_person",
                                  "cm", "sv_person",
                                  "cm", "sv_person",
                                  "cm", "sv_person",
                                  "cm", "sv_person",
                                  "cm", "sf",
                                  "cm", "sv_person"]}

        exp_df = sqla_to_sparkdf("Entity", num_rows=16, field_vals=exp_dat, spark=spark, key_bool=False,
                                 x_cols={'etl_source': 'varchar',
                                         'created_at': 'varchar'})

        df_actual, log_df, dead_live_map_df = Resolver.solve_parent_move(in_df,
                                               pkey = 'entity_id',
                                               skey = 'persistence_id',
                                               date_col='updated_at',
                                               end_date=end_date,
                                               return_moves=True)

        if log_df != None:
            print("Log DF:")
            log_df.orderBy('entity_id', ascending=True).show(20, False)

        print("Expected DF:")
        exp_df.orderBy('entity_id', ascending=True).select(list(in_dat.keys())).show(20, False)
        print("Result DF:")
        df_actual.orderBy('entity_id', ascending=True).select(list(in_dat.keys())).show(20, False)

        self.assertSparkDataFrameEqual(exp_df.orderBy('entity_id', ascending=True),
                                       df_actual.orderBy('entity_id', asecending=True))

        # Testing type
        return self