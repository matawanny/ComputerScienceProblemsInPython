from kharybdis import Persister
import pandas as pd
from spark_functions.unit_tests.PySparkTest import PySparkTest
from cm_commons.models.converters.slqalchemy_to_spark import sqla_to_sparkdf
from cm_commons.spark import build_session


if 'spark' not in globals():
    print("Creating new spark context: PersistRules")
    spark = build_session("PersistRules")


class PersistTest(PySparkTest):
    def test_apply_fields(self):
        """
            Simple fields mapping of salesforce_id
            - rules:
                - only non-pkey, non-extra
        """
        # Testing type
        in_dat = {"entity_id": ["1", "2", "3", "4", "5", "6"],
                  "salesforce_id": ["A", "None", "B", "None", "C", "None"],
                  "salesvision_id": ["333", "333", "22", "22", "1", "1"],
                  "entity_type_id": ["301", "301", "201", "201", "101", "101"],
                  "parent_id": ["None", "", "1", "2", "3", "4"],
                  "etl_source": ["cm", "sv", "cm", "sv", "cm", "sv"]}
        in_df, keys = sqla_to_sparkdf("Entity",
                                      num_rows=6,
                                      field_vals=in_dat,
                                      spark=spark,
                                      key_bool=True,
                                      x_cols={'etl_source': 'varchar'})

        map_dat = {
            "rule_id": ['1x', '2x', '3x',
                        '1y', '2y', '3y',
                        '1z', '2z', '3z'],
            "original_record_entity_id": ['2', '2', '2',
                                          '4', '4', '4',
                                          '6', '6', '6'],
            "column_name": ['parent_id', 'salesforce_id', 'entity_id',
                            'parent_id', 'salesforce_id', 'entity_id',
                            'parent_id', 'salesforce_id', 'entity_id'],
            "invalid_value": ['', 'None', '2',
                              '2', 'None', '4',
                              '4', 'None', '6'],
            "valid_value": ['None', 'A', '1',
                            '1', 'B', '3',
                            '3', 'C', '5'],
            "stewardship_type": ['Correction', 'Correction', 'Correction',
                                 'Correction', 'Correction', 'Correction',
                                 'Correction', 'Correction', 'Correction'],
            "created_by": ['circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge',
                           'circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge',
                           'circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge']
        }
        map_df = sqla_to_sparkdf("EntityPersistRules", num_rows=9, field_vals=map_dat, spark=spark, key_bool=False)

        exp_dat = {"entity_id": ["1", "2", "3", "4", "5", "6"],
                   "salesforce_id": ["A", "A", "B", "B", "C", "C"],
                   "salesvision_id": ["333", "333", "22", "22", "1", "1"],
                   "entity_type_id": ["301", "301", "201", "201", "101", "101"],
                   "parent_id": ["None", "None", "1", "1", "3", "3"],
                   "etl_source": ["cm", "sv", "cm", "sv", "cm", "sv"]}

        exp_df = sqla_to_sparkdf("Entity", num_rows=6, field_vals=exp_dat, spark=spark, key_bool=False,
                                 x_cols={'etl_source': 'varchar',
                                         'created_at': 'varchar'})

        df_actual = Persister.apply_fields(df=in_df,
                                           persist_dfs={'entity': map_df},
                                           table='entity',
                                           pkey='entity_id',
                                           ignore=['entity_id', 'record_id', 'created_at',
                                                   'updated_at', 'etl_source', 'enrichment_error'])



        self.assertSparkDataFrameEqual(exp_df.orderBy('entity_id', ascending=True),
                                       df_actual.orderBy('entity_id', asecending=True))
        # Testing type
        return self

    # TODO - needs work
    def todo_test_apply_fields_scale(self):
        """
            Simple fields mapping of salesforce_id
            - rules:
                - only non-pkey, non-extra
        """
        NUM = 1000

        # Testing type
        in_dat = {"entity_id": [str(ii) for ii in range(NUM*2)],
                  "salesforce_id": ["001"+ str(ii) for ii in range(NUM)]+["None" for ii in range(NUM)],
                  "salesvision_id": [str(ii) for ii in range(NUM)]+[str(ii) for ii in range(NUM)],
                  "etl_source": ['cm' for ii in range(NUM)]+['sv' for ii in range(NUM)]}
        in_df, keys = sqla_to_sparkdf("Entity",
                                      num_rows=NUM*2,
                                      field_vals=in_dat,
                                      spark=spark,
                                      key_bool=True,
                                      x_cols={'etl_source': 'varchar'})

        map_dat = {
            "rule_id": [str(ii) for ii in range(NUM)],
            "original_record_entity_id": [str(ii+NUM) for ii in range(NUM)],
            "column_name": ["salesforce_id" for ii in range(NUM)],
            "invalid_value": ["None" for ii in range(NUM)],
            "valid_value": ["001"+ str(ii) for ii in range(NUM)]
        }
        map_df = sqla_to_sparkdf("EntityPersistRules", num_rows=9, field_vals=map_dat, spark=spark, key_bool=False)

        exp_dat = {"entity_id": [str(ii) for ii in range(NUM * 2)],
                   "salesforce_id": ["001" + str(ii) for ii in range(NUM)]+["001" + str(ii) for ii in range(NUM)],
                   "salesvision_id": [str(ii) for ii in range(NUM)]+[str(ii) for ii in range(NUM)],
                   "etl_source": ['cm' for ii in range(NUM)]+['sv' for ii in range(NUM)]}

        exp_df = sqla_to_sparkdf("Entity", num_rows=6, field_vals=exp_dat, spark=spark, key_bool=False,
                                 x_cols={'etl_source': 'varchar',
                                         'created_at': 'varchar'})

        df_actual = Persister.apply_fields(df=in_df,
                                           persist_dfs={'entity': map_df},
                                           table='entity',
                                           pkey='entity_id',
                                           ignore=['entity_id', 'record_id', 'created_at',
                                                   'updated_at', 'etl_source', 'enrichment_error'])


        self.assertSparkDataFrameEqual(exp_df.orderBy('entity_id', ascending=True),
                                       df_actual.orderBy('entity_id', asecending=True))
        # Testing type
        return self

    def test_apply_pkey(self):
        """
            Simple primary key mapping of entity_id
        """
        # Testing type
        in_dat = {"entity_id": ["1", "2", "3", "4", "5", "6"],
                  "salesforce_id": ["A", "None", "B", "None", "C", "None"],
                  "salesvision_id": ["333", "333", "22", "22", "1", "1"],
                  "entity_type_id": ["301", "301", "201", "201", "101", "101"],
                  "parent_id": ["None", "", "1", "2", "3", "4"],
                  "etl_source": ["cm", "sv", "cm", "sv", "cm", "sv"]}
        in_df, keys = sqla_to_sparkdf("Entity",
                                      num_rows=6,
                                      field_vals=in_dat,
                                      spark=spark,
                                      key_bool=True,
                                      x_cols={'etl_source': 'varchar'})

        map_dat = {
            "rule_id": ['1x', '2x', '3x',
                        '1y', '2y', '3y',
                        '1z', '2z', '3z'],
            "original_record_entity_id": ['2', '2', '2',
                                          '4', '4', '4',
                                          '6', '6', '6'],
            "column_name": ['parent_id', 'salesforce_id', 'entity_id',
                            'parent_id', 'salesforce_id', 'entity_id',
                            'parent_id', 'salesforce_id', 'entity_id'],
            "invalid_value": ['', 'None', '2',
                              '2', 'None', '4',
                              '4', 'None', '6'],
            "valid_value": ['None', 'A', '1',
                            '1', 'B', '3',
                            '3', 'C', '5'],
            "stewardship_type": ['Correction', 'Correction', 'Correction',
                                 'Correction', 'Correction', 'Correction',
                                 'Correction', 'Correction', 'Correction'],
            "created_by": ['circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge',
                           'circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge',
                           'circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge']
        }
        map_df = sqla_to_sparkdf("EntityPersistRules", num_rows=9, field_vals=map_dat, spark=spark, key_bool=False)

        exp_dat = {"entity_id": ["1", "1", "3", "3", "5", "5"],
                   "salesforce_id": ["A", "None", "B", "None", "C", "None"],
                   "salesvision_id": ["333", "333", "22", "22", "1", "1"],
                   "entity_type_id": ["301", "301", "201", "201", "101", "101"],
                   "parent_id": ["None", "", "1", "2", "3", "4"],
                   "etl_source": ["cm", "sv", "cm", "sv", "cm", "sv"]}
        exp_df = sqla_to_sparkdf("Entity", num_rows=6, field_vals=exp_dat, spark=spark, key_bool=False,
                                 x_cols={'etl_source': 'varchar',
                                         'created_at': 'varchar'})

        df_actual = Persister.apply_pkeys(df=in_df,
                                           persist_dfs={'entity': map_df},
                                           table='entity',
                                           pkey='entity_id'
                                          )



        self.assertSparkDataFrameEqual(exp_df.orderBy(['entity_id', 'etl_source'], ascending=True),
                                       df_actual.orderBy(['entity_id', 'etl_source'], asecending=True))
        # Testing type
        return self

    def test_apply_fkey_self_join(self):
        """
            Foreign key mapping that points to self
            """
        # Testing type
        in_dat = {"entity_id": ["1", "20"],
                  "parent_id": ["20", "None"],
                  "etl_source": ["sv", "sv"]}
        in_df, keys = sqla_to_sparkdf("Entity",
                                      num_rows=2,
                                      field_vals=in_dat,
                                      spark=spark,
                                      key_bool=True,
                                      x_cols={'etl_source': 'varchar'})

        map_dat = {
            "rule_id": ['1x'],
            "original_record_entity_id": ['1'],
            "column_name": ['entity_id'],
            "invalid_value": ['20'],
            "valid_value": ['30']
        }
        map_df = sqla_to_sparkdf("EntityPersistRules", num_rows=1, field_vals=map_dat, spark=spark, key_bool=False)

        exp_dat = {"entity_id": ["1", "20"],
                   "parent_id": ["30", "None"],
                   "etl_source": ["sv", "sv"]}
        exp_df, keys = sqla_to_sparkdf("Entity", num_rows=2, field_vals=exp_dat, spark=spark, key_bool=True,
                                 x_cols={'etl_source': 'varchar',
                                         'created_at': 'varchar'})

        df_actual = Persister.apply_fkeys(df=in_df,
                                          persist_dfs={'entity': map_df},
                                          table='entity',
                                          fkeys=keys['fkey']
                                          )



        self.assertSparkDataFrameEqual(exp_df.orderBy('entity_id', ascending=True),
                                       df_actual.orderBy('entity_id', asecending=True))
        # Testing type
        return self

    def test_apply_fkey_nonself_join(self):
        """ Foreign key mapping that points to another table """
        # Testing type
        in_dat = {"agreement_entity_xref_id": ['a1'],
                  "agreement_id": ["a"],
                  "entity_id": ["1"],
                  "etl_source": ["sv_holding"]}
        in_df, keys = sqla_to_sparkdf("AgreementEntity",
                                      num_rows=1,
                                      field_vals=in_dat,
                                      spark=spark,
                                      key_bool=True,
                                      x_cols={'etl_source': 'varchar'})

        agr_dat = {
            "rule_id": ['1x'],
            "original_record_agreement_id": ['a'],
            "column_name": ['agreement_id'],
            "invalid_value": ['a'],
            "valid_value": ['b']
        }
        agr_df = sqla_to_sparkdf("AgreementPersistRules", num_rows=1, field_vals=agr_dat, spark=spark, key_bool=False)

        ent_dat = {
            "rule_id": ['1x'],
            "original_record_entity_id": ['1'],
            "column_name": ['entity_id'],
            "invalid_value": ['1'],
            "valid_value": ['2']
        }
        ent_df = sqla_to_sparkdf("EntityPersistRules", num_rows=1, field_vals=ent_dat, spark=spark, key_bool=False)

        exp_dat = {"agreement_entity_xref_id": ['a1'],
                   "agreement_id": ["b"],
                   "entity_id": ["2"],
                   "etl_source": ["sv_holding"]}

        exp_df, keys = sqla_to_sparkdf("AgreementEntity", num_rows=1, field_vals=exp_dat, spark=spark, key_bool=True,
                                 x_cols={'etl_source': 'varchar',
                                         'created_at': 'varchar'})

        df_actual = Persister.apply_fkeys(df=in_df,
                                          persist_dfs={'entity': ent_df, 'agreement': agr_df},
                                          table='agreement_entity_xref',
                                          fkeys=keys['fkey']
                                          )



        self.assertSparkDataFrameEqual(exp_df, df_actual)
        # Testing type
        return self

    def test_persist_skey(self):
        """ Simple secondary key mapping of `persistence_id`
        """
        # Testing type
        in_dat = {"entity_id": ["1", "2", "3", "4", "5", "6"],
                  "salesforce_id": ["A", "None", "B", "None", "C", "None"],
                  "salesvision_id": ["333", "333", "22", "22", "1", "1"],
                  "entity_type_id": ["301", "301", "201", "201", "101", "101"],
                  "parent_id": ["None", "", "1", "2", "3", "4"],
                  "persistence_id": ["1a", "2a", "3a", "4a", "5a", "6a"],
                  "etl_source": ["cm", "sv", "cm", "sv", "cm", "sv"]}
        in_df, keys = sqla_to_sparkdf("Entity",
                                      num_rows=6,
                                      field_vals=in_dat,
                                      spark=spark,
                                      key_bool=True,
                                      x_cols={'etl_source': 'varchar'})

        map_dat = {
            "rule_id": ['1x', '2x', '3x', '4x',
                        '1y', '2y', '3y', '4y',
                        '1z', '2z', '3z', '4z'],
            "original_record_entity_id": ['2', '2', '2', '2',
                                          '4', '4', '4', '4',
                                          '6', '6', '6', '6'],
            "column_name": ['parent_id', 'salesforce_id', 'entity_id', 'persistence_id',
                            'parent_id', 'salesforce_id', 'entity_id', 'persistence_id',
                            'parent_id', 'salesforce_id', 'entity_id', 'persistence_id'],
            "invalid_value": ['', 'None', '2', '2a',
                              '2', 'None', '4', '4a',
                              '4', 'None', '6', '6a'],
            "valid_value": ['None', 'A', '1', '1a',
                            '1', 'B', '3', '3a',
                            '3', 'C', '5', '5a'],
            "stewardship_type": ['Correction', 'Correction', 'Correction', 'Correction',
                                 'Correction', 'Correction', 'Correction', 'Correction',
                                 'Correction', 'Correction', 'Correction', 'Correction'],
            "created_by": ['circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge',
                           'circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge',
                           'circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge', 'circe_sv_merge']
        }
        map_df = sqla_to_sparkdf("EntityPersistRules", num_rows=12, field_vals=map_dat, spark=spark, key_bool=False)

        exp_dat = {"entity_id": ["1", "2", "3", "4", "5", "6"],
                   "salesforce_id": ["A", "None", "B", "None", "C", "None"],
                   "salesvision_id": ["333", "333", "22", "22", "1", "1"],
                   "entity_type_id": ["301", "301", "201", "201", "101", "101"],
                   "parent_id": ["None", "", "1", "2", "3", "4"],
                   "persistence_id": ["1a", "1a", "3a", "3a", "5a", "5a"],
                   "etl_source": ["cm", "sv", "cm", "sv", "cm", "sv"]}
        exp_df = sqla_to_sparkdf("Entity", num_rows=6, field_vals=exp_dat, spark=spark, key_bool=False,
                                 x_cols={'etl_source': 'varchar'})

        df_actual = Persister.apply_skeys(df=in_df,
                                          persist_dfs={'entity': map_df},
                                          table='entity',
                                          skey='persistence_id'
                                          )

        self.assertSparkDataFrameEqual(exp_df.orderBy('entity_id', ascending=True),
                                       df_actual.orderBy('entity_id', asecending=True))
        # Testing type
        return self

    # TODO - during integration
    def test_persist_move(self):
        pass

    # TODO - during integration
    def test_persist_merge(self):
        pass

    # TODO - during integration
    def test_persist_move_merge(self):
        pass

    # TODO - during integration
    def test_persist_merge_move(self):
        pass


if __name__ == "__main__":

    import sys
    import unittest

    loader = unittest.TestLoader()
    suite = loader.loadTestsFromModule(__name__)
    runner = unittest.TextTestRunner(verbosity=1, stream=sys.stderr)
    runner.run(suite)