from test.unit.kharybdis.resolve import resolveIngestedAt

import sys
import unittest
loader = unittest.TestLoader()
suite = loader.loadTestsFromTestCase(resolveIngestedAt.ResolveIngestedAtTeset)
runner = unittest.TextTestRunner(verbosity=2, stream=sys.stderr)
runner.run(suite)
