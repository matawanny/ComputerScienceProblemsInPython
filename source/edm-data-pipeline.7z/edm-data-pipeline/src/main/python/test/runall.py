import sys
import unittest
from test.unit.kharybdis.persist import test_persist_field
loader = unittest.TestLoader()
suite = loader.loadTestsFromModule(test_persist_field)
runner = unittest.TextTestRunner(verbosity=1, stream=sys.stderr)
runner.run(suite)

from test.unit.kharybdis.resolve import resolve


import sys
import unittest
loader = unittest.TestLoader()
suite = loader.loadTestsFromTestCase(resolve.ResolveTeset)
runner = unittest.TextTestRunner(verbosity=2, stream=sys.stderr)
runner.run(suite)


from test.unit.kharybdis.persist import test_persist_field
import sys
import unittest
loader = unittest.TestLoader()
suite = loader.loadTestsFromTestCase(test_persist_field.PersistTest)
runner = unittest.TextTestRunner(verbosity=2, stream=sys.stderr)
runner.run(suite)
