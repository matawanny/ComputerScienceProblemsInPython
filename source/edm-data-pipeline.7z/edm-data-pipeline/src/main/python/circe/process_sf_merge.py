from datetime import datetime
import logging
import time

from pyspark.sql.functions import lit, col, monotonically_increasing_id, when, lower, collect_set, size, col, split, current_timestamp, trim, coalesce
from pyspark.sql.types import StructType, StringType, StructField

from circe.manipulator_base import GeneralManipulator, load_conf
from cm_commons.util.boto_functions import move_conf_along, get_files_from_s3_folder, put_file_in_s3, file_exists, read_json, get_s3_bucket
from cm_commons import colors
from cm_commons.db.cm_conn import cm_cxn_jdbc, cm_cxn

class SFMergeManipulator(GeneralManipulator):
    def __init__(self, conf_loc, table_prefix, src_db_name, target_db_name,\
                                            sf_mastered_output_dir, sf_conf_output_dir, sf_conf_batch_size):
        super(SFMergeManipulator, self).__init__(conf_loc, table_prefix, src_db_name, target_db_name, \
                                                                sf_mastered_output_dir, sf_conf_output_dir)
        self.input_df = None
        self.joined_df = None
        self.diff_df = None
        self.sf_conf_batch_size = int(sf_conf_batch_size)
        self.parquet_append_mode = False

    def clean_input_df(self, raw_df):
        """
        raw_df: Merge file contents
        Returns in this format:
        |entity_char|id_old            |id_new            |crm_id_old                      |crm_id_new                      |sv_from_id|sv_to_id|
        +-----------+------------------+------------------+--------------------------------+--------------------------------+----------+--------+
        |O          |0016300000pphj7AAA|0016300000pphjRAAQ|3c886601594dffe68ca2ed4b973f57cd|6bed5fc1d4fb8095bd5150eb03cc3591|null      |null    |
        """
        self.print_w_ts("Parsing input which has pre-defined column names...")
        raw_df = raw_df.withColumnRenamed('sf_from_id', 'id_old')
        raw_df = raw_df.withColumnRenamed('sf_to_id', 'id_new')
        raw_df = raw_df.withColumnRenamed('crm_from_id', 'crm_id_old')
        raw_df = raw_df.withColumnRenamed('crm_to_id', 'crm_id_new')
        raw_df = raw_df.withColumnRenamed('merge_type', 'entity_char')
        return raw_df

    def get_input_df(self, file_loc):
        raw_df = self.load_file_from_s3(file_loc)

        self.print_w_ts("Sample entries in raw merge file:")
        raw_df.show(10, False)

        raw_df = self.clean_input_df(raw_df)
        return raw_df

    def save_dfs(self, diff_df, circe_sf_merge_post_df, mode='overwrite'):

        self.write_rules(diff_df, self.raw_table_name)

        circe_sf_merge_post_df = circe_sf_merge_post_df.distinct()

        table_name = f"{self.table_name}_circe_sf_merge_post"
        self.output_df_to_rds(target_db=self.target_db,
                              df=circe_sf_merge_post_df,
                              table=table_name,
                              mode=mode)
        self.print_w_ts(f"circe_sf_merge_post_df written to RDS:{self.target_db}/{table_name}")

    def create_tds_df(self, df, yyyymmdd_str_key):
        """
        df: cleaned input df; Type: DataFrame[entity_char: string, id_old: string, id_new: string, crm_id_old: string, 
                                            crm_id_new: string, sv_from_id: string, sv_to_id: string]
        yyyymmdd_str_key: file date key; Type: String 
        """
        df = df.drop('crm_id_old').drop('crm_id_new')

        current_time_str = datetime.now().strftime("%Y-%m-%d")
        conf_date_stamp = yyyymmdd_str_key[0:4] + "-" + yyyymmdd_str_key[4:6] + "-" + yyyymmdd_str_key[6:]

        #Naming cols in df to avoid colliding with some columns from entity table
        sf_merge_prefix = 'sf_merge_'

        df = df.withColumn(sf_merge_prefix + self.conf["TDS_ID"], monotonically_increasing_id())
        df = df.withColumn("submitted_at", lit(current_time_str))

        master_n_df = df.select(sf_merge_prefix + self.conf["TDS_ID"],\
                                'submitted_at',\
                                col('id_old').alias('sf_id'))\
                                .withColumn(sf_merge_prefix + self.conf["STAGING_ID"],lit('false'))
        master_y_df = df.select(sf_merge_prefix + self.conf["TDS_ID"],\
                                'submitted_at',\
                                col('id_new').alias('sf_id'))\
                                .withColumn(sf_merge_prefix + self.conf["STAGING_ID"],lit('true'))

        master_y_n_df = master_y_df.union(master_n_df)

        # print('master_y_n_df=', master_y_n_df.columns)

        #self.entity_df = self.load_df_from_rds(target_db=self.src_db, table=self.table_name) #moved to process()

        if self.entity_df == None:
            raise RuntimeError

        # Drop tds_master column since it exists in the subsequent join:
        if self.conf["STAGING_ID"] in self.entity_df.columns:
            self.entity_df = self.entity_df.drop(self.conf["STAGING_ID"])

        joined_df = master_y_n_df.join(self.entity_df,\
                                        master_y_n_df.sf_id == self.entity_df.salesforce_id, how='left')

        persistence_map_df = df.join(joined_df, df['id_new'] == joined_df['sf_id'])

        persistence_map_df = persistence_map_df.select('id_old', 'id_new',\
                                                       col('persistence_id').alias('new_persistence_id'))
        joined_df = joined_df.join(persistence_map_df, joined_df.sf_id == persistence_map_df['id_old'], how='left')

        # print("NAV_DEBUG joined_df:")
        # joined_df.filter(col('sf_id').isin(['730993','1431124'])).show(10, False)

        joined_df = joined_df.withColumn('ended_at',
                                                when(joined_df[sf_merge_prefix + self.conf["STAGING_ID"]] == lit('false'),
                                                                   lit(conf_date_stamp)).otherwise(col('ended_at'))
                                                )
        '''
                                    .withColumn('persistence_id',
                                                when(joined_df['sf_id'] == joined_df['id_new'],
                                                     ## joined_df['old_persistence_id']).otherwise(col('persistence_id'))
                                                     joined_df['persistence_id']).otherwise(col('persistence_id'))
                                                )
        '''

        ##joined_df = joined_df.drop('old_persistence_id', 'id_old', 'id_new')
        out_df = joined_df

        # print("out_df", out_df.show(3, truncate=False))

        #Remove recs with null entity_id because of the earlier left join:
        out_df = out_df.select(self.entity_df.columns).filter(out_df['entity_id'].isNotNull())

        columns_list = joined_df.schema.names
        for cid in columns_list:
            joined_df = joined_df.withColumn(cid, when(
                lower(col(cid)).isin(['none', 'edm_exempt', 'exempt', 'edm-881', 'edm-494', 'edm-1090', 'edm-1030']),
                lit(None)).otherwise(col(cid)))
        # out_df = out_df.select(columns_list)

        joined_df_cols = master_y_n_df.columns + ['entity_id']

        #joined_df = joined_df.select(joined_df_cols)\
        joined_df = joined_df.withColumnRenamed(sf_merge_prefix + self.conf["STAGING_ID"], self.conf["STAGING_ID"])\
                            .withColumnRenamed(sf_merge_prefix + self.conf["TDS_ID"], self.conf["TDS_ID"])
        joined_df = joined_df.withColumn('created_at', lit(current_time_str))
        joined_df = joined_df.withColumn('etl_source', lit('salesforce'))

        #joined_df cols = ['tds_id',  'submitted_at', 'sf_id', 'tds_master', 'entity_id', 'salesforce_id', 'ended_at']
        # print('self.joined_df=',joined_df.columns)

        joined_df = joined_df.filter(joined_df['entity_id'].isNotNull())
        return joined_df, out_df

    def find_parent_change(self, df):
        gdf = df.groupBy(self.conf["TDS_ID"]).agg(collect_set('parent_id')).withColumnRenamed('collect_set(parent_id)', 'parent_id_set')
        gdf = gdf.withColumn('parent_id_length', size(gdf['parent_id_set'])).drop('parent_id_set')
        gdf = gdf.withColumnRenamed(self.conf["TDS_ID"], 'gdf_'+self.conf["TDS_ID"])
        df = df.join(gdf, df[self.conf["TDS_ID"]] == gdf['gdf_'+self.conf["TDS_ID"]], how='left' )
        df = df.withColumn('parent_change', when(df['parent_id_length']>1,\
                                            lit('y')).otherwise(lit('n')) )\
                .drop('parent_id_length').drop('gdf_'+self.conf["TDS_ID"])
        # print('df=', df.show(3,truncate=False))
        return df

    def filter_input_exceptions(self, merge_df, entity_df, conf_date):
        """
            Identify the valid entities which do not have entries in entity table
            Write the corresponding invalid entities into merge_exceptions table
            Filter off these invalid-valid pair(s) from going ahead with the merge process
            (As as result, the invalid entities will not get end-dated and can be tracked)
        """
        #TODO: This method needs clean up when Schema of exceptions table is changed.

        self.print_w_ts("Filteration process on merge contents started...")

        merge_df_cols = merge_df.columns
        merge_exceptions_df_cols = ['salesvision_id_old','salesvision_id_new','entity_id','persistence_id','entity_type_id',
                                        'salesforce_id','conf_date','created_by','created_at','reason','merge_id']
        merge_df = merge_df.join(entity_df,
                                        (col('id_old') == col('salesforce_id')) &
                                            (when(col('entity_char') == 'P', '1')
                                            .when(col('entity_char') == 'O', '2')
                                            .otherwise('3') == col('entity_type_id').substr(1, 1)),
                                            how='left_outer') \
                                .withColumn('salesvision_id_old', coalesce(col('sv_from_id'), col('salesvision_id'))) \
                                .select(merge_df_cols + ['salesvision_id_old'])
    
        merge_df = merge_df.join(entity_df,
                                        (col('id_new') == col('salesforce_id')) &
                                            (when(col('entity_char') == 'P', '1')
                                            .when(col('entity_char') == 'O', '2')
                                            .otherwise('3') == col('entity_type_id').substr(1, 1)),
                                            how='left_outer') \
                               .withColumn('salesvision_id_new', coalesce(col('sv_to_id'), col('salesvision_id'))) \
                                .select(merge_df_cols + ['salesvision_id_old','salesvision_id_new'])

        merge_df = merge_df.filter(~(col('id_old')==col('id_new')))

        exceptions_table_name = f"{self.table_prefix}_merge_exceptions"

        self.print_w_ts("Looking to filter-off one-to-many merges of invalid entities...")
        multi_merge_df = merge_df.groupBy('entity_char', 'id_old').count()\
                                    .filter(col('count') > 1)\
                                    .select('entity_char', 'id_old')

        multi_merge_df = merge_df.join(multi_merge_df, on=['entity_char', 'id_old'],how='left_semi') \
                                .select('entity_char', 'id_old','salesvision_id_old')

        merge_df = merge_df.join(multi_merge_df.drop('salesvision_id_old'),
                                 (merge_df['entity_char'] == multi_merge_df['entity_char']) &
                                 (merge_df['id_old'] == multi_merge_df['id_old']),
                                 how='left_anti')

        if multi_merge_df != None and multi_merge_df.take(1) != []:
            merge_exceptions_df = multi_merge_df.join(entity_df, (col('id_old') == col('salesforce_id')) &
                                                      (when(col('entity_char') == 'P', '1')
                                                       .when(col('entity_char') == 'O', '2')
                                                       .otherwise('3') == col('entity_type_id').substr(1, 1)),
                                                      how='inner')

            merge_exceptions_df = merge_exceptions_df.select('id_old', 'entity_id', 'persistence_id',
                                                             'entity_type_id', 'salesforce_id','salesvision_id_old')\
                                                        .withColumn('id_new', lit('MULTIPLE'))\
                                                        .withColumn('conf_date', lit(conf_date))\
                                                        .withColumn('created_by', lit(f'circe_{self.source_system_prefix}_merge'))\
                                                        .withColumn('created_at', current_timestamp())\
                                                        .withColumn('reason',
                                                                    lit('invalid merges with more than one valid')) \
                                                        .withColumn('salesforce_id',
                                                                    when(col('salesforce_id').isNull(), lit(" "))
                                                                    .otherwise(col('salesforce_id'))) \
                                                        .withColumn('salesvision_id_new', lit('MULTIPLE'))

            merge_exceptions_df = merge_exceptions_df.withColumn("merge_id", lit(self.merge_id))
            merge_exceptions_df = merge_exceptions_df.select(merge_exceptions_df_cols)

            self.print_w_ts("Sample of merge_exceptions_df:")
            merge_exceptions_df.show(2, False)
            merge_exceptions_df.write.jdbc(url=cm_cxn_jdbc['url'], table=exceptions_table_name,
                                           properties=cm_cxn_jdbc['properties'], mode='append')
            self.print_w_ts(f"merge_exceptions_df written to RDS:{exceptions_table_name}")

            s3_loc_name = f"s3://{get_s3_bucket()}/CIRCE/data/merge_exceptions/{conf_date}"
            self.print_w_ts(f"Writing merge_exceptions_df to {s3_loc_name}")
            merge_exceptions_df.write.mode("append").parquet(s3_loc_name)
            self.print_w_ts(f"merge_exceptions_df written to {s3_loc_name} for conf_date = {conf_date}")
        else:
            self.print_w_ts(f"No {self.source_system} merge exceptions due to one-to-many merges of invalid entities exists\
                                                                for conf_date = {conf_date}")

        self.print_w_ts("Looking for non-existent invalid entities...")
        no_invalid_df = merge_df.join(entity_df, (col('id_old')==col('salesforce_id')) &
                                        (when(col('entity_char') == 'P', '1')
                                         .when(col('entity_char') == 'O', '2')
                                         .otherwise('3') == col('entity_type_id').substr(1,1)),
                                    how='left_outer')\
                                .filter(col('entity_id').isNull())

        merge_df = merge_df.join(no_invalid_df.select('entity_char','id_old'),
                                            (merge_df['entity_char'] == no_invalid_df['entity_char']) &
                                            (merge_df['id_old'] == no_invalid_df['id_old']),
                                            how='left_anti')

        if no_invalid_df != None and no_invalid_df.take(1) != []:
            no_invalid_df = no_invalid_df.select('entity_char', 'id_old', 'id_new','salesvision_id_old','salesvision_id_new')\
                                    .withColumn('entity_id', lit('UNKNOWN'))\
                                    .withColumn('persistence_id', lit('UNKNOWN')) \
                                    .withColumn('entity_type_id',
                                                when(col('entity_char') == 'P', '101')
                                                .when(col('entity_char') == 'O', '201')
                                                .otherwise('301'))\
                                    .withColumn('salesforce_id', col('id_old')) #TODO This should be changed to UNKNOWN when the exception table schema is changed.
                                    #.withColumn('salesforce_id', lit('UNKNOWN'))

            merge_exceptions_df = no_invalid_df.select('id_old', 'id_new', 'entity_id','salesvision_id_old','salesvision_id_new',\
                                                        'persistence_id','entity_type_id', 'salesforce_id') \
                                                        .withColumn('conf_date', lit(conf_date)) \
                                                        .withColumn('created_by', lit(f'circe_{self.source_system_prefix}_merge')) \
                                                        .withColumn('created_at', current_timestamp()) \
                                                        .withColumn('reason', lit('invalid does not exist in cm')) \
                                                        .withColumn('salesvision_id_new', coalesce(col('salesvision_id_new'),lit('NEW')))

            merge_exceptions_df = merge_exceptions_df.withColumn("merge_id", lit(self.merge_id))
            merge_exceptions_df = merge_exceptions_df.select(merge_exceptions_df_cols)

            self.print_w_ts("Sample of merge_exceptions_df:")
            merge_exceptions_df.show(2, False)

            self.output_df_to_rds(target_db=self.target_db,
                                  df=merge_exceptions_df,
                                  table=exceptions_table_name,
                                  mode="append")
            colors.suc_print(f"merge_exceptions_df for {self.table_name}"
                             f" written to RDS:{self.target_db}/{exceptions_table_name}")

            s3_loc_name = f"s3://{get_s3_bucket()}/CIRCE/data/merge_exceptions/{conf_date}"
            merge_exceptions_df.write.mode("append").parquet(s3_loc_name)
            colors.suc_print(f"merge_exceptions_df written to {s3_loc_name} for conf_date = {conf_date}", indent=3)
        else:
            colors.suc_print(f"No {self.source_system} merge exceptions due to non-existent invalid entities exists\
                                    for conf_date = {conf_date}")



        self.print_w_ts("Looking for invalid entities with non-existent valid entities...")

        merge_df_cols = merge_df.columns

        joined_df = merge_df.join(entity_df, (col('id_new')==col('salesforce_id')) &
                                        (when(col('entity_char') == 'P', '1')
                                         .when(col('entity_char') == 'O', '2')
                                         .otherwise('3') == col('entity_type_id').substr(1,1)) &
                                  (col('ended_at').isNull() | (trim(col('ended_at')) == '')),
                                    how='left_outer')

        merge_exceptions_df = joined_df.filter(col('entity_id').isNull()\
                                               | (col('ended_at').isNotNull() & (trim(col('ended_at'))!='')))\
                                        .select(merge_df_cols)

        merge_exceptions_df = merge_exceptions_df.join(entity_df, (col('id_old')==col('salesforce_id')) &
                                                            (when(col('entity_char') == 'P', '1')
                                                                .when(col('entity_char') == 'O', '2')
                                                                .otherwise('3') == col('entity_type_id').substr(1,1)) &
                                                       (col('ended_at').isNull() | (trim(col('ended_at')) == '')),
                                                        how='inner')\
                                        .select('id_old', 'id_new','salesvision_id_old','salesvision_id_new',
                                                    'entity_id', 'persistence_id', 'entity_type_id', 'salesforce_id')\
                                        .withColumn('salesvision_id_new',
                                                    when(col('salesvision_id_new').isNull(), lit("NEW")).otherwise(col('salesvision_id_new'))) \
                                        .distinct()

        filtered_input_df = joined_df.filter(col('entity_id').isNotNull()\
                                             & ((col('ended_at').isNull()) | (trim(col('ended_at'))=='')) )\
                                .select(merge_df_cols).drop('salesvision_id_old','salesvision_id_new')

        self.print_w_ts("Sample filtered_input_df entries that will be used by merge process:")
        # filtered_input_df.filter(col('id_old').isin('1126861','1011980')).show(10, False)
        filtered_input_df.show(2, False)

        if merge_exceptions_df != None and merge_exceptions_df.take(1) != []:
            merge_exceptions_df = merge_exceptions_df \
                .withColumn('conf_date', lit(conf_date))\
                .withColumn('created_by', lit(f'circe_{self.source_system_prefix}_merge')) \
                .withColumn('created_at', current_timestamp()) \
                .withColumn('reason', lit('valid is either end-dated or does not exist in cm')) \
                .withColumn('salesforce_id',
                            when(col('salesforce_id').isNull(), lit(" "))
                            .otherwise(col('salesforce_id')))

            merge_exceptions_df = merge_exceptions_df.withColumn("merge_id", lit(self.merge_id))
            merge_exceptions_df = merge_exceptions_df.select(merge_exceptions_df_cols)

            self.print_w_ts("Sample of merge_exceptions_df:")
            # merge_exceptions_df.filter(col('id_old').isin('1126861','1011980')).show(10, False)
            merge_exceptions_df.show(2, False)

            self.output_df_to_rds(target_db=self.target_db,
                                  df=merge_exceptions_df,
                                  table=exceptions_table_name,
                                  mode="append")
            colors.suc_print(f"merge_exceptions_df for {self.table_name}"
                             f" written to RDS:{self.target_db}/{exceptions_table_name}")

            s3_loc_name = f"s3://{get_s3_bucket()}/CIRCE/data/merge_exceptions/{conf_date}"
            merge_exceptions_df.write.mode("append").parquet(s3_loc_name)
            colors.suc_print(f"merge_exceptions_df written to {s3_loc_name} for conf_date = {conf_date}", indent=3)
        else:
            colors.suc_print(f"No {self.source_system} merge exceptions due to non-existent valid entities exists\
                                     for conf_date = {conf_date}")

        self.print_w_ts("Filteration process on merge contents completed")

        return filtered_input_df

    #TODO: Merge this method with method in base class
    def update_persistence_id_for_prior_ended_dated_entities(self, entity_df, enriched_merge_df):
        """
        Logic to update persistence_ids of older entities that are chained to newly ended-dated entity

        :param entity_df: Cached entity table
        :param enriched_merge_df: Enriched merge rules
        :return: None

        Logic:
            Create old_pid_df with only invalids by extracting from enriched_merge_df
            Create old_pid_map_df by joining old_pid_df with entity table,
                this is to extract all the entities which use the invalid's pid
            Filter only prior ended-dated invalids in old_pid_map_df by using ended_at is not null,
                (current invalids are already end-dated in memory in enriched_merge_df)
            Create upd_delta_entity_df by joining old_pid_map_df with entity table,
                this is to extract subset of data which need to be updated
            Update entity table with the upd_delta_entity_df
        """
        self.print_w_ts("Persistence id chaining process started...")

        orig_entity_table_count = entity_df.count()

        enriched_merge_df = enriched_merge_df.withColumn('old_persistence_id', col('persistence_id'))
        self.print_w_ts("enriched_merge_df:")
        enriched_merge_df.orderBy(self.conf["TDS_ID"], self.conf["STAGING_ID"]).show(4, False)

        old_pid_df = enriched_merge_df.filter(enriched_merge_df[self.conf["STAGING_ID"]]=='false')

        # Takek only the columns needed since we are going to get repeated fields added
        # due to joining with entity table again:
        old_pid_df = old_pid_df.select(self.conf["TDS_ID"], 'sf_id', self.conf["STAGING_ID"], 'ended_at',\
                                       'entity_id', 'persistence_id', 'entity_type_id',\
                                       'new_persistence_id', 'old_persistence_id')

        old_pid_map_df = old_pid_df.join(entity_df, \
                                         (old_pid_df['entity_type_id']==entity_df['entity_type_id'])\
                                         & (old_pid_df['old_persistence_id']==entity_df['persistence_id']),\
                                         how='inner')\
                                    .drop(entity_df['salesvision_id'])\
                                    .drop(old_pid_df['entity_id'])\
                                    .drop(old_pid_df['entity_type_id'])\
                                    .drop(old_pid_df['persistence_id'])\
                                    .drop(old_pid_df['ended_at'])\
                                    .drop(old_pid_df[self.conf["TDS_ID"]])\
                                    .drop(old_pid_df[self.conf["STAGING_ID"]])\
                                    .drop(old_pid_df['sf_id'])

        self.print_w_ts("Sample of old_pid_map_df:")
        old_pid_map_df.show(10, False)

        # select only necessary columns to avoid dupe columns as a result of upcoming join operation:
        old_pid_map_df = old_pid_map_df.filter(trim(col('ended_at'))!='')\
                                        .select('entity_id', 'entity_type_id', 'persistence_id',\
                                                'new_persistence_id', 'ended_at')

        entity_df_cols = entity_df.columns

        upd_delta_entity_df = entity_df.join(old_pid_map_df, ['entity_id', 'entity_type_id', 'persistence_id'],\
                                                how='inner')\
                                        .drop(old_pid_map_df['ended_at'])\
                                        .drop('persistence_id')\
                                        .withColumnRenamed('new_persistence_id', 'persistence_id')\
                                        .select([c for c in entity_df_cols])

        self.print_w_ts("Sample of upd_delta_entity_df:")
        upd_delta_entity_df.show(10, False)

        self.print_w_ts(f"Updating df for {self.table_name} now...")

        unaffected_edf = entity_df.join(upd_delta_entity_df, ['entity_id', 'entity_type_id', 'salesforce_id'], how="left_anti")
        unaffected_edf = unaffected_edf.select([c for c in entity_df_cols])

        self.print_w_ts("unaffected_edf:")
        unaffected_edf.show(10, False)

        new_edf = unaffected_edf.union(upd_delta_entity_df)

        updated_entity_table_count = new_edf.count()
        upd_delta_entity_df_count = upd_delta_entity_df.count()
        unaffected_edf_count = unaffected_edf.count()

        self.print_w_ts(f"unaffected_edf_count = {unaffected_edf_count}")
        self.print_w_ts(f"upd_delta_entity_df_count = {upd_delta_entity_df_count}")

        self.print_w_ts(f"orig_entity_table_count = {orig_entity_table_count}")
        self.print_w_ts(f"updated_entity_table_count = {updated_entity_table_count}")

        if upd_delta_entity_df_count == 0 or orig_entity_table_count != updated_entity_table_count:
            self.print_w_ts("Either no entries exist for update OR there is a count mismatch. No update performed!!")
        else:
            self.print_w_ts(f"Updating {self.table_name} table now...")
            new_edf.write.jdbc(url=cm_cxn_jdbc['url'], table=self.table_name, mode='overwrite',
                                                   properties=cm_cxn_jdbc['properties'])
            self.print_w_ts(f"Data overwritten in {self.table_name} table with {upd_delta_entity_df_count} entities updated in it")

    def process(self):
        files_processed = []
        batch_count = 0
        for key in sorted(self.conf_files_dict.keys()):
            if batch_count > self.sf_conf_batch_size-1:
                    colors.out_print(f"Max batch size of {batch_count} reached. Quitting...")
                    break
            self.input_df = None
            self.joined_df = None
            self.diff_df = None
            self.parquet_append_mode = False

            s3_conf_file_without_path = self.conf_files_dict[key]
            s3_conf_file_with_path = self.conf_path + s3_conf_file_without_path

            self.print_w_ts(f"Currently processing {s3_conf_file_with_path}...")
            self.conf = load_conf(s3_conf_file_with_path)

            self.print_w_ts(f"Moving {s3_conf_file_without_path} from incoming to active")
            new_conf_loc = move_conf_along(s3_conf_file_with_path, currentstep="incoming", nextstep="active")

            self.sf_load_file_loc = self.conf["input_location"]["emr"]
            self.print_w_ts(f"sf_load_file_loc={self.sf_load_file_loc}")

            self.input_df = self.get_input_df(self.sf_load_file_loc)

            if self.input_df == None or self.input_df.take(1) == []:
                self.print_w_ts(f"Merge file either has no data or has an issue. Skipping this conf file...")
                continue

            self.print_w_ts(f"rowcount defined in conf file={self.conf['rowcount']}")
            self.print_w_ts(f"Actual rowcount in the merge file ={self.input_df.count()}")

            self.print_w_ts("Sample entries in input_df:")
            self.input_df.show(10, False)


            # self.get_joined_records()
            # print("self.joined_df=", self.joined_df.show(self.joined_df.count(), False))
            # self.get_diff_df()

            self.raw_table_name = 'entity' # unprefixed
            self.source_system = 'salesforce'
            self.source_system_prefix = 'sf'

            if self.table_prefix != '':
                self.table_name = self.table_prefix + "_" + self.raw_table_name
            else:
                self.table_name = self.raw_table_name

            self.clean_up_merge_tables(conf_date=str(key))

            self.entity_df = self.load_df_from_rds(target_db=self.src_db, table=self.table_name)
            if self.entity_df == None or self.entity_df.take(1) == []:
                raise RuntimeError(f"Either {self.table_name} doesn't exist or has no data in it. Aborting job...")

            entity_df = self.entity_df.cache()

            self.input_df = self.filter_input_exceptions(self.input_df, entity_df, conf_date=key)

            joined_df, out_df = self.create_tds_df(self.input_df, str(key))
            # joined_df columns: parent_id not present [sf_id, tds_id, submitted_at, entity_id, created_at, tds_master, etl_source]
            # out_df columns:  tds_master not present
            '''
             [employee_id, nullability_error, ai_investor_id, persistence_id, job_desc, fishtank_id,
             lei, etl_source, salesvision_id, updated_at, do_not_contact, salesforce_id, typecast_error,
             err_msg, created_at, parent_id, ended_at, client_type_id, crd, crm_id, entity_type_id,
             error, fca_id, asic_license_number, entity_id, enriched_at, entity_name, group_id, iard,
             ai_subinvestor_id, psn]
            '''

            enriched_merge_df = joined_df.cache()
            self.update_persistence_id_for_prior_ended_dated_entities(entity_df, enriched_merge_df)

            self.print_w_ts(f"Readng {self.table_name} again...")
            self.entity_df = self.load_df_from_rds(target_db=self.src_db, table=self.table_name)
            if self.entity_df == None or self.entity_df.take(1) == []:
                raise RuntimeError(f"Either {self.table_name} doesn't exist or has no data in it. Aborting job...")

            entity_df = self.entity_df.cache()

            # Take out entities that switch parents:
            joined_df = self.find_parent_change(df=joined_df)
            # print('AFTER parent_change: joined_df=', joined_df.show(2, False))
            ## out_df = self.find_parent_change(df=out_df)

            # joined_df.filter((col('salesforce_id') == '124982') | (col('salesforce_id') == '79197')).show(2, False)

            parent_change_y_df = joined_df.filter(joined_df['parent_change'] == 'y')
            parent_change_n_df = joined_df.filter(joined_df['parent_change'] == 'n')

            # self.print_w_ts("parent_change_y_df:")
            # parent_change_y_df.filter((col('salesforce_id') == '124982') | (col('salesforce_id') == '79197')).show(10, False)

            # self.print_w_ts("parent_change_n_df:")
            # parent_change_n_df.filter((col('salesforce_id') == '124982') | (col('salesforce_id') == '79197')).show(10, False)

            self.print_w_ts(f"Processing parent_change_n_df...")
            self.diff_df = self.get_diff_df(parent_change_n_df.drop('parent_change'), 'entity')
            self.get_cascade(str(key))
            # self.get_cascade_old(self.diff_df)

            circe_post_df1 = parent_change_n_df.drop('parent_change', 'tds_id', 'tds_master', 'submitted_at')
            circe_post_df1 = circe_post_df1.withColumn('persistence_id',
                                                    when(circe_post_df1['sf_id'] == circe_post_df1['id_old'],
                                                         circe_post_df1['new_persistence_id']).otherwise(col('persistence_id'))
                                                    )
            # circe_post_df1.filter((col('salesforce_id') == '124982') | (col('salesforce_id') == '79197')).show(10, False)
            # print("circe_post_df1:")
            # circe_post_df1.show(10,False)

            circe_post_df1 = circe_post_df1.drop('sf_id', 'new_persistence_id', 'id_old', 'id_new')

            self.print_w_ts("Writing circe_post_df1(parent_change=N) and its diff_df to RDS...")
            self.save_dfs(self.diff_df, circe_post_df1)

            # print("B4 diff2: joined_df=", joined_df.show(joined_df.count(),False))
            self.print_w_ts(f"Processing parent_change_y_df...")
            self.diff_df = self.get_diff_df(parent_change_y_df.drop('parent_change'), 'entity')
            self.get_cascade(str(key))
                        
            circe_post_df2 = parent_change_y_df.drop('parent_change', 'tds_id', 'tds_master', 'submitted_at')
            circe_post_df2 = circe_post_df2.withColumn('persistence_id',
                                                    when(circe_post_df2['sf_id'] == circe_post_df2['id_old'],
                                                         circe_post_df2['new_persistence_id']).otherwise(col('persistence_id'))
                                                    )
            # circe_post_df2.filter((col('salesforce_id') == '124982') | (col('salesforce_id') == '79197')).show(10, False)
            # print("circe_post_df2:")
            # circe_post_df2.show(10,False)

            circe_post_df2 = circe_post_df2.drop('sf_id', 'new_persistence_id', 'id_old', 'id_new')

            self.print_w_ts("Writing circe_post_df2(parent_change=Y) and its diff_df to RDS...")
            self.save_dfs(self.diff_df, circe_post_df2, mode='append')

            self.print_w_ts("Starting upsert..")
            df_full = self.load_df_from_rds(target_db=self.src_db, table=self.table_name)
            df_delta = self.load_df_from_rds(target_db=self.src_db,
                                             table=f"{self.table_name}_circe_sf_merge_post")
            upsert_cols = ['persistence_id', 'ended_at']
            self.load_cascade_upsert_new(df_full, df_delta, "entity_id", upsert_cols, self.table_name)

            # self.update_null_salesforce_ids(self.input_df)
            self.write_merge_exceptions(self.input_df, self.entity_df, key)
            self.update_survivor_with_max_ts()
            self.write_to_audit_log(conf_date = str(key))

            self.print_w_ts(f"Moving {new_conf_loc} from active to done")
            move_conf_along(new_conf_loc, currentstep="active", nextstep="done")
            files_processed.append(s3_conf_file_without_path)
            batch_count = batch_count + 1
            self.print_w_ts(f"Processed following files:{files_processed}")

        colors.out_print(f"Stopping spark session...")
        self.spark.stop()

        colors.out_print(f"Sleeping for 6 mins for GC in EMR to finish...")
        time.sleep(360)
        self.print_w_ts("SV MERGE PRCOESS FINISHED!")


def start_process(conf_location, table_prefix, src_db_name, target_db_name, \
                                            sf_mastered_output_dir, sf_conf_output_dir, sf_conf_batch_size):
    colors.suc_print(f"Initializing SFMergeManipulator...")
    try:
            processor = SFMergeManipulator(conf_location, table_prefix, src_db_name, target_db_name,\
                                                sf_mastered_output_dir, sf_conf_output_dir, sf_conf_batch_size)
            processor.process()
    except Exception as ex:
        logging.exception("Exception raised in SFMergeManipulator!")

