import os
from datetime import datetime, timedelta
from pyspark.sql.functions import lit, udf, col, concat_ws, md5
from pyspark.sql.types import StructType, StringType, StructField
import logging
import json

import pyspark.sql.functions as f

from circe.manipulator_base import GeneralManipulator
from cm_commons import colors
from cm_commons.util.boto_functions import put_file_in_s3
from spark_functions.scripts.sql_advanced import *
from cm_commons.util.safe_count import safe_count, SC_CONST


# Talend dates are in an awful format - this just parses them to a regular datetime
def parse_talend_date(date_str):
    if date_str == 'null':
        return 'None'
    days_since_1970 = int(date_str)
    return datetime(1970, 1, 1, 0, 0) + timedelta(days_since_1970)


def format_date_columns(raw_df):
    raw_df = raw_df.withColumn("date_effective", f.lit(datetime.now().strftime("%Y-%m-%d")))

    # parse_date_udf = udf(lambda my_date: parse_talend_date(my_date), StringType())
    # raw_df = raw_df.withColumn("parsed_created_at", parse_date_udf('created_at'))
    # raw_df = raw_df.withColumn("parsed_updated_at", parse_date_udf('updated_at'))
    # raw_df = raw_df.withColumn("parsed_enriched_at", parse_date_udf('enriched_at'))
    if 'created_at' in raw_df.schema.names:
        raw_df = raw_df.withColumn("parsed_created_at", raw_df.created_at)
        raw_df = raw_df.drop('created_at').withColumnRenamed('parsed_created_at', 'created_at')
    else:
        raw_df = raw_df.withColumn("created_at", f.lit(None))
    if 'updated_at' in raw_df.schema.names:
        raw_df = raw_df.withColumn("parsed_updated_at", raw_df.updated_at)
        raw_df = raw_df.drop('updated_at').withColumnRenamed('parsed_updated_at', 'updated_at')
    else:
        raw_df = raw_df.withColumn("updated_at", f.lit(None))

    if 'enriched_at' in raw_df.schema.names:
        raw_df = raw_df.withColumn("parsed_enriched_at", raw_df.enriched_at)
        raw_df = raw_df.drop('enriched_at').withColumnRenamed('parsed_enriched_at', 'enriched_at')
    else:
        raw_df = raw_df.withColumn("enriched_at", f.lit(None))

    return raw_df


# This was for testing when we were using csv files. It would just delete the old output before starting a new process
def delete_old_records(output_dir):
    output_subdirs = ["diff", "mastered"]
    for subdir in output_subdirs:
        for file in os.listdir(f"{output_dir}/{subdir}"):
            os.unlink(f"{output_dir}/{subdir}/{file}")


"""
The stewardship manipulator is used to pre-process all merge and update information, whether it's coming from 
SalesVision, the TalendDataStewardship portal, or any other source. For each relevant table, we are asssuming that 
we'll get two kinds of records. 
1) We will be observing record groups (deduplication) and we'll compare the input records with the mastered record to 
    obtain a diff df. If any of the original records existed in client master, we'll write these changes to an audit
    table. If any of these changes are flagged as "persist change = true", we'll create a rule to automatically 
    correct incoming records to reflect the mastered record. In addition to the audit and rule output, we will write the
    mastered records to the post-etl database so that they can pass through our data mastering process on the next run.
2) We will be observing resolved records. These require much less processing and will just be written to the post-etl
    database so that they can pass through our data mastering process on the next run.
"""


class StewardshipManipulator(GeneralManipulator):

    def __init__(self, circe_conf_dict, table_prefix, src_db_name, target_db_name, ds_mastered_output_dir,
                 ds_conf_output_dir):
        super(StewardshipManipulator, self).__init__(circe_conf_dict, table_prefix, src_db_name, target_db_name,
                                                     ds_mastered_output_dir, ds_conf_output_dir)

        self.raw_dedupe_df = None
        self.raw_resolution_df = None

        self.mastered_df = None

        self.diff_columns = None
        self.diff_df = None
        self.cascade_df = None

        self.table_name = None

        self.mastered_output_dir = ds_mastered_output_dir
        self.output_date = datetime.today().strftime('%m-%d-%Y')
        self.conf_output_dir = ds_conf_output_dir
        self.parquet_append_mode = False

        self.fields_to_ignore_in_parquet = ['source_name', 'stewardship_type']

    def load_ds_output_rds(self):

        self.raw_dedupe_df = self.load_df_from_rds(target_db=self.src_db,
                                                   table=f"{self.table_name}_deduplication")

        # Add the submitted at time
        if self.raw_dedupe_df is None:
            colors.war_print("NO DEDUPE TABLE FOUND", indent=1)
        else:
            self.raw_dedupe_df = self.raw_dedupe_df.withColumn("submitted_at",
                                                               f.lit(datetime.now().strftime("%Y-%m-%d")))
        return self.raw_dedupe_df
        # TODO: First check if table exist
        """
        self.raw_resolution_df = self.load_df_from_rds(target_db=self.src_db,
                                                       table=f"{self.table_name}_resolution")
                        

        self.raw_resolution_df = self.raw_resolution_df.withColumn("submitted_at",
                                                                   lit(datetime.now().strftime("%Y-%m-%d")))
        if self.table_name == 'agreement_entity_xref':
            self.raw_resolution_df = self.raw_resolution_df.withColumn("ended_at", lit("None"))

        print(f"Formatting {self.table_name} raw_dedupe date columns")
        self.raw_dedupe_df = format_date_columns(self.raw_dedupe_df)

        print(f"Formatting {self.table_name} raw_resolution date columns")
        self.raw_resolution_df = format_date_columns(self.raw_resolution_df)
        """

    def query_cascade_records(self, cascade_table_prefix, cascade_table_name, fk_col_name, cascade_map_df,
                              target_db=None):
        if not target_db:
            target_db = self.src_db

        if cascade_table_prefix == '':
            cascade_full_name = cascade_table_name
        else:
            cascade_full_name = cascade_table_prefix + "_" + cascade_table_name

        colors.out_print(f"Querying cascade_records for {cascade_full_name}", indent=4)

        raw_cascade_df_full = self.load_df_from_rds(target_db=target_db, table=cascade_full_name)

        if raw_cascade_df_full is None:
            return None, None
        raw_cascade_df = raw_cascade_df_full

        # print("NAV-DEBUG raw_cascade_df=", raw_cascade_df.show(truncate=False))
        # print("NAV-DEBUG raw_cascade_df=", raw_cascade_df.filter(raw_cascade_df.parent_id.isin(['49e3b10282f162eebb69735de9092f2f'])).show(truncate=False))
        # id_col = cascade_table_name+"_id"   # <<< instead should be fk_col_name('entity_id')

        # TODO: Check & handle conditions if invalid_value is null
        cascade_raw_df = raw_cascade_df.join(cascade_map_df,
                                             raw_cascade_df[fk_col_name] == cascade_map_df.invalid_value)

        colors.suc_print(f"{safe_count(raw_cascade_df_full)} records found for FULL", indent=5)
        colors.suc_print(f"{safe_count(cascade_raw_df)} records found for INVALID", indent=5)
        # print("NAV-DEBUG cascade_df=", cascade_df.show(cascade_df.count(), False))
        # print("NAV-DEBUG raw_cascade_df=", cascade_raw_df.filter(cascade_raw_df.entity_id.isin(['3980cb99d3991f7e3bc307741bd1059d'])).show(truncate=False))
        return cascade_raw_df, raw_cascade_df_full

    def get_mastered_records(self):
        print(f"Getting {self.table_name} mastered records")
        dupe_masters_df = self.raw_dedupe_df.where(self.raw_dedupe_df[self.conf["STAGING_ID"]] == self.conf["MASTER"])

        """
        dupe_masters_df = dupe_masters_df.drop(dupe_masters_df["TDS_SCORE"])
        dupe_masters_df = dupe_masters_df.drop(dupe_masters_df["TDS_MASTER"])
        dupe_masters_df = dupe_masters_df.drop(dupe_masters_df["TDS_SOURCE"])
        """

        # TODO: nav_uncomment self.mastered_df = dupe_masters_df.union(self.raw_resolution_df)
        self.mastered_df = dupe_masters_df

    def get_diff_df(self, input_df, actual_table_name, indent=0):
        # print(f"Caching input_df for table {actual_table_name}...")
        input_df.cache()

        colors.out_print(f"Generating {actual_table_name} diff df", indent=indent + 1)

        pre_melt = {}
        stmt = []
        for c in input_df.columns:
            if c not in ["tds_id", "staging_id", "stewardship_type", \
                         "create_rule", "etl_error", "etl_source", "error_message", "updated_at", \
                         "group_count", "tds_master", "tds_match_yn"]:
                input_df = input_df.withColumn(c + "_COLUMN", lit(c))
                pre_melt[c + '_key'] = [c, c + "_COLUMN"]
                stmt.append((c, col(c)))
        colors.out_print(f"Melting {actual_table_name} diff_df", indent=indent + 2)
        # colors.bug_print(f"pre_melt: {str(pre_melt)}", indent=indent+3)
        # pprint(pre_melt)

        post_melt = {'target': ['invalid', 'column_name']}
        # colors.bug_print(f"post_melt: {str(post_melt)} ", indent=indent+3)
        # pprint(post_melt)

        # print("pre_melt of input_df=", input_df.limit(5).show(truncate=False))
        # print("pre_melt=", pre_melt)
        # print("stmt=", stmt)

        df_melt_out = melt(input_df.filter(input_df.tds_master == 'false'), pre_melt, post_melt)
        # print("df_melt_out=", df_melt_out.limit(5).show(truncate=False))

        # Join the melt to to the valid entry for the tds_id
        df_joined = df_melt_out.select('tds_id', 'invalid', 'column_name',
                                       f.col('entity_id').alias('old_entity_id')) \
            .join(input_df.filter(input_df.tds_master == 'true'), 'tds_id')
        # input_df.drop('entity_id').filter(input_df.tds_master == 'true'), 'tds_id')

        # If  f.col(column_name) = <column_name>, set valid = columnt_name
        colors.out_print(f"Switch Casing to map Column Name to Column Value: ", indent=indent + 2)
        # colors.bug_print(f"switch_case statement: {str(stmt)}", indent=indent+3)
        # pprint(stmt)
        sc_df = switch_case_3(df_joined, in_col='column_name', out_col='valid', statement=stmt, default='error')

        # diff_df is all records where invalid and valid are diffierent
        colors.out_print("Finding diffs", indent=indent + 2)
        diff_df = sc_df.filter((sc_df.invalid != sc_df.valid) \
                               | (col('invalid').isNull() & col('valid').isNotNull()) \
                               | (col('invalid').isNotNull() & col('valid').isNull()))

        # print("diff_df=")
        # diff_df.show(5, False)

        # Special case for sv merge, to get the old entity_id from tds_master=False:
        diff_df = diff_df.drop('entity_id').withColumnRenamed('old_entity_id', 'entity_id')

        # add extra columns
        diff_df = diff_df.withColumn(f"original_record_{actual_table_name}_id", col(f"{self.raw_table_name}_id"))
        diff_df = diff_df.withColumn("stewardship_type", lit("Correction"))
        diff_df = diff_df.withColumn("create_rule", lit("false"))
        diff_df = diff_df.withColumn("updated_at", col("created_at"))
        diff_df = diff_df.withColumn("cascade", lit("False"))

        diff_schema = StructType([
            StructField(self.conf["TDS_ID"], StringType(), True),
            # StructField("entity_type_id", StringType(), True),
            StructField("etl_source", StringType(), True),
            StructField(f"original_record_{actual_table_name}_id", StringType(), True),
            StructField("column_name", StringType(), True),
            StructField("invalid_value", StringType(), True),
            StructField("valid_value", StringType(), True),
            StructField("stewardship_type", StringType(), True),
            StructField("create_rule", StringType(), True),
            StructField("created_at", StringType(), True),
            StructField("updated_at", StringType(), True),
            StructField("submitted_at", StringType(), True),
            StructField("cascade", StringType(), True)
        ])
        diff_df_final = self.spark.createDataFrame([], diff_schema)

        diff_df = diff_df.select(self.conf["TDS_ID"],
                                 # "entity_type_id",
                                 self.conf["ETL_SOURCE"],
                                 # "entity_id", # for debug
                                 f"{self.raw_table_name}_id",
                                 "column_name",
                                 "invalid",
                                 "valid",
                                 self.conf["STEWARDSHIP_TYPE"],
                                 "create_rule",
                                 "created_at",
                                 "updated_at",
                                 "submitted_at",
                                 "cascade")

        diff_df_final = diff_df_final.union(diff_df)
        diff_df_final_count = safe_count(diff_df_final)

        if diff_df_final_count == SC_CONST:
            colors.saf_print("Did not count records with diff", indent=indent + 3)
        elif diff_df_final_count > 0:
            delta_cols = [ii.column_name for ii in diff_df_final.select('column_name').distinct().collect()]
            colors.suc_print(f"Found {diff_df_final_count} records with diffs in {actual_table_name}",
                             indent=indent + 3)
            colors.suc_print(f"List of Columns which had diffs {delta_cols}", indent=indent + 2)
        else:
            colors.war_print(f"Found {diff_df_final_count} records with diffs in {actual_table_name}",
                             indent=indent + 3)

        return diff_df_final

    def get_cascade(self):
        """Get the cascaded records based on the primary table + conf"""

        colors.out_print(f"Getting pkey cascades for {self.table_name}", indent=1)

        if self.raw_table_name in self.conf['PKEY_FKEY_MAPPINGS'].keys():
            # find all tables with a foreign key relationship to the current table
            for fk_table, fk_column in self.conf['PKEY_FKEY_MAPPINGS'][self.raw_table_name].items():
                colors.out_print(f"Cascading in progress for column={fk_column} for table={fk_table}", indent=2)

                diff_count = safe_count(self.diff_df, True)
                if diff_count > 0:
                    colors.suc_print("Writing rules before cascading", indent=2)
                    # self.write_rules(self.diff_df, fk_table, ind=2)

                source_key = self.raw_table_name + "_id"

                # cascade_map_df = self.diff_df.where(self.diff_df['column_name'] == f"{source_key}")
                colors.out_print(f"Find diffs for {source_key} for table={self.raw_table_name}", indent=3)
                cascade_map_df = self.diff_df.where(self.diff_df['column_name'] == f"{source_key}")

                if cascade_map_df.take(1) != []:
                    # print("NAV_DEBUG: ", cascade_map_rdd.take(1))
                    # id_col = "original_record_" + fk_table + "_id"
                    id_col = fk_column
                    # cascade_dict = cascade_map_rdd.map(lambda x: (x[id_col], (x["invalid_value"], x["valid_value"])) ).collectAsMap()
                    cascade_map_df = cascade_map_df.select("invalid_value", "valid_value").distinct()
                    # colors.bug_print("cascade_map_df=", indent=3)
                    cascade_map_df.select("invalid_value", "valid_value").distinct().limit(2).show(truncate=False)
                    # print("NAV-DEBUG cascade_map_df=",cascade_map_df.filter(cascade_map_df.invalid_value == '49e3b10282f162eebb69735de9092f2f')\
                    #                                             .show(truncate=False))
                else:
                    colors.war_print(f"No data to cascade for column={fk_column} for table={fk_table}", indent=2)
                    continue

                # Getting cascaded records
                cascade_raw_df, cascade_raw_full_df = self.query_cascade_records(cascade_table_prefix=self.table_prefix,
                                                                                 cascade_table_name=fk_table,
                                                                                 fk_col_name=fk_column,
                                                                                 cascade_map_df=cascade_map_df)

                if cascade_raw_df is None:
                    colors.err_print(f"cascade_raw_df is None, continuingg to next table")
                    continue
                else:
                    count_cascade = safe_count(cascade_raw_df)
                    if count_cascade == SC_CONST:
                        colors.saf_print(f"Casacade record count ignoreed for {fk_table}.{fk_column}", indent=3)
                    elif count_cascade > 0:
                        colors.suc_print(f"Found {count_cascade} records to be cascaded in {fk_table}.{fk_column}",
                                         indent=3)
                    else:
                        colors.war_print(f"No data found with invalid_value in {self.table_name} table. Skipping...",
                                         indent=3)
                        continue
                colors.out_print(f"Adding static columns to {fk_table}", indent=3)
                # print("NAV-DEBUG - cascade_raw_df count = ", cascade_raw_df.count())
                # cascade_raw_df = cascade_raw_df.withColumn(self.conf["STAGING_ID"], lit(None))
                cascade_raw_df = cascade_raw_df.withColumn(self.conf["STAGING_ID"], lit(None))
                # cascade_raw_df = cascade_raw_df.withColumn('tds_match_yn', lit('n'))
                # print(f">>cascade_raw_df={cascade_raw_df.show(truncate=False)}")

                if fk_table.endswith('_xref') and fk_table.startswith('entity'):
                    fk_id = fk_table[:-5] + "_id"
                    colors.war_print(f"Assuming primary key {fk_id} for {fk_table}", indent=4)

                else:
                    fk_id = fk_table + "_id"
                    colors.suc_print(f"Assuming primary key {fk_id} for {fk_table}", indent=4)

                cascade_raw_df = cascade_raw_df.withColumn(self.conf["TDS_ID"], f.lit(cascade_raw_df[fk_id]))
                cascade_raw_df = cascade_raw_df.withColumn('stewardship_type', f.lit("Update"))
                cascade_raw_df = cascade_raw_df.withColumn('create_rule', f.lit("false"))
                # cascade_raw_df = cascade_raw_df.withColumn('source_name', lit("fir"))
                cascade_raw_df = cascade_raw_df.withColumn("submitted_at",
                                                           f.lit(datetime.now().strftime("%Y-%m-%d")))

                # Dropping this for now as it's not part of the diff schema:
                colors.war_print(f" Dropping error column", indent=4)
                cascade_raw_df = cascade_raw_df.drop("error")
                cascade_raw_df = format_date_columns(cascade_raw_df)

                # print(f"cascade_raw_df={cascade_raw_df.show(truncate=False)}")

                id_col = f"{self.raw_table_name}_id"
                if id_col != fk_column:
                    id_col = fk_column

                # colors.bug_print(f"{cascade_raw_df.count()}", indent=0)
                # TODO: Check filter condition handling for null values
                colors.out_print(f"Determing master record with {id_col}", indent=3)
                # cascade_mastered_df is ONLY mastered records
                cascade_mastered_df = cascade_raw_df.filter(cascade_raw_df[id_col] == cascade_raw_df.invalid_value) \
                    .drop(id_col) \
                    .withColumn(id_col, cascade_raw_df.valid_value)

                cascade_mastered_df_count = safe_count(cascade_mastered_df)
                cm_ind = 4

                if cascade_mastered_df_count == SC_CONST:
                    colors.saf_print(f"Ignoring count for remastered records for {self.raw_table_name}.{id_col}",
                                     indent=cm_ind)
                elif cascade_mastered_df_count > 0:
                    colors.suc_print(
                        f"{cascade_mastered_df_count} records remastered with valid {self.raw_table_name}.{id_col}",
                        indent=cm_ind)
                else:
                    colors.war_print(f"{cascade_mastered_df_count} records found for remastering", indent=cm_ind)

                # colors.bug_print(f"{cascade_mastered_df.count()}", indent=0)

                colors.out_print("Preparing RAW df", indent=4)
                cascade_raw_df = cascade_raw_df.drop("invalid_value")
                cascade_raw_df = cascade_raw_df.drop("valid_value")
                cascade_raw_df = cascade_raw_df.withColumn(self.conf["STAGING_ID"],
                                                           f.lit('false'))

                c_raw_count = safe_count(cascade_raw_df)
                colors.out_print(f"{c_raw_count} records in RAW", indent=5)
                # colors.bug_print("#####")
                # colors.bug_print("cascade_raw_df")
                # cascade_raw_df.orderBy("TDS_ID").show(2, truncate=False)
                # colors.bug_print("#####")
                # colors.bug_print("#####")

                colors.out_print("Preparing MASTERED df", indent=4)
                # cascade_mastered_df['staging_id'] = self.conf['MASTER']
                cascade_mastered_df = cascade_mastered_df.drop("invalid_value")
                cascade_mastered_df = cascade_mastered_df.drop("valid_value")
                cascade_mastered_df = cascade_mastered_df.drop(self.conf["STAGING_ID"])
                cascade_mastered_df = cascade_mastered_df.withColumn(self.conf["STAGING_ID"],
                                                                     f.lit(self.conf['MASTER']))
                cascade_mastered_df = cascade_mastered_df.select([col for col in cascade_raw_df.columns])

                colors.out_print(f"{safe_count(cascade_mastered_df, dummy_str=True)} records in MASTER", indent=5)
                # colors.bug_print("#####")
                # colors.bug_print("cascade_mastered_df")
                # cascade_mastered_df.orderBy("TDS_ID").show(2, truncate=False)
                # colors.bug_print("#####")
                # colors.bug_print("#####")

                colors.out_print("Unioning RAW and MASTERED", indent=4)
                cascade_df = cascade_raw_df.union(cascade_mastered_df)
                colors.out_print(f"{safe_count(cascade_df, dummy_str=True)} records in UNION", indent=5)
                # print("NAV-DEBUG - cascade_df(raw+mastered)=", cascade_df.show())

                # print(f"cascade_df={cascade_df.show(truncate=False)}")
                # colors.bug_print("#####")
                # colors.bug_print("cascade_df")
                # cascade_df.orderBy("TDS_ID").show(2, truncate=False)
                # colors.bug_print("#####")
                # colors.bug_print("#####")

                colors.out_print(f"Getting diff for cascaded table {fk_table}", indent=3)

                # We used to write only the found diffs to persist_df, we now do all in the beginning
                # cascade_diff_df = self.get_diff_df(cascade_df, fk_table, indent=4)
                # cascade_df_count = cascade_diff_df.count()
                # cascade_diff_df = cascade_diff_df.drop("cascade").withColumn("cascade", lit("True"))

                # Adding missing columns to match the self.mastered_df columns:
                # if 'error' not in cascade_mastered_df.columns:
                #    cascade_mastered_df = cascade_mastered_df.withColumn('error', lit(''))

                if 'record_id' not in cascade_mastered_df.columns:
                    cascade_mastered_df = cascade_mastered_df.withColumn('record_id', lit(''))

                if 'ds_ingested_at' not in cascade_mastered_df.columns:
                    cascade_mastered_df = cascade_mastered_df.withColumn('ds_ingested_at', lit(''))

                cascade_mastered_df = cascade_mastered_df.drop('etl_source').withColumn('etl_source',
                                                                                        lit('circe_cascade'))
                cascade_mastered_df = cascade_mastered_df.drop(self.conf['STAGING_ID'])

                # cascade_mastered_df = cascade_mastered_df.select([col for col in self.mastered_df.columns])

                # print("NAV-DEBUG cascade_mastered_df=", cascade_mastered_df.limit(2).show())

                if self.raw_table_name == fk_table:
                    table_name = self.table_name
                else:
                    table_name = self.table_prefix + "_" + fk_table

                """
                # Not needed for now
                self.output_df_to_rds(target_db=self.target_db,
                                      df=cascade_mastered_df,
                                      table=f"{table_name}_mastered",
                                      mode="append")
                colors.suc_print(f"cascade_mastered_df for {table_name} written to RDS:{self.target_db}/{table_name}_mastered")
                """

                # print("cascade_mastered_df count = ", cascade_mastered_df.count())
                if cascade_mastered_df != None and cascade_mastered_df.take(1) != []:

                    colors.out_print(f"Writing {fk_table} mastered to parquet", indent=2)
                    s3_loc_name = self.mastered_output_dir + fk_table + '/' + self.output_date + '.parquet'
                    cascade_mastered_df = cascade_mastered_df.select(
                        [col_name for col_name in cascade_mastered_df.columns if
                         col_name not in self.fields_to_ignore_in_parquet])
                    cascade_mastered_df.write.mode("overwrite").parquet(s3_loc_name)
                    colors.suc_print(f"cascade_mastered_df written to {s3_loc_name}", indent=3)

                    push_table_name = f"{table_name}"

                    # colors.out_print(f"Writing {fk_table} to push table {push_table_name}", indent=2)

                    # colors.suc_print(f"cascade_mastered_df written to {push_table_name}", indent=3)

                    push_table_name = f"{table_name}"
                    if push_table_name == f"{table_name}":
                        colors.war_print(f"Overwriting {fk_table} to push table {push_table_name}", indent=2)

                    cascade_full_df = self.load_df_from_rds(target_db=self.src_db,
                                                            table=f"{table_name}")

                    # cascade_mastered_df: just the mastered records
                    # cascade_full_df
                    self.load_cascade_upsert(df_full=cascade_full_df, df_delta=cascade_mastered_df,
                                             primary_key=fk_id, upsert_col=id_col, table_name=push_table_name)

                    if self.raw_table_name == fk_table:
                        self.parquet_append_mode = True
                else:
                    print(f"No data available to write as parquet for {fk_table}")

                """
                # Not needed for now
                # Writing to persist_rules table instead
                self.output_df_to_rds(target_db=self.target_db,
                                          df=cascade_diff_df,
                                          table=f"{table_name}_diff",
                                          mode="append")

                colors.suc_print(f"cascade_diff_df for {table_name} written to RDS:{self.target_db}/{table_name}_diff")
                """

                self.write_conf(fk_table)

                # self.write_rules(cascade_diff_df, fk_table)

        else:
            print(f"No FK relations found for {self.table_name} table")

    def load_cascade_upsert(self, df_full, df_delta, primary_key, upsert_col, table_name):
        """Upsert df_delta into df_full and loads to table_name"""

        colors.out_print(f"Upserting mastered table for {table_name}", indent=2)
        colors.out_print(f"Primary Key: {primary_key}", indent=3)  # entity_id, agreement_entity_xref_id, etc.
        colors.out_print(f"Upsert Column: {upsert_col}", indent=3)  # parent_id, entity_id, etc.

        # taking the delta and renaming the column to upsert_col and join criteria on it's own
        df_delta = df_delta.withColumnRenamed(f"{upsert_col}", f"{upsert_col}_master").select(
            f"{primary_key}", f"{upsert_col}_master")

        colors.bug_print(f"{safe_count(df_full, dummy_str=True)} FULL records before", indent=3)
        colors.bug_print(f"{safe_count(df_delta, dummy_str=True)} DELTA records before", indent=3)

        pre_full_count = df_full.count()
        out_df = df_full.join(df_delta,
                              f"{primary_key}",
                              "left_outer").withColumn(f"{upsert_col}",
                                                       f.when(
                                                           f.col(f"{upsert_col}_master").isNotNull(),
                                                           f.col(f"{upsert_col}_master")
                                                       ).otherwise(f.col(f"{upsert_col}"))
                                                       ).drop(f"{upsert_col}_master")

        colors.bug_print(f"{safe_count(out_df, dummy_str=False)} TOTAL records after", indent=3)

        num_upserts = safe_count(out_df.filter(f.col(f"{upsert_col}_master").isNotNull()))

        if num_upserts == SC_CONST:
            colors.saf_print(f"ignoring counts for upserts")
        elif num_upserts > 0:
            colors.suc_print(f"{num_upserts} upserts found in {table_name}", indent=3)
        else:
            colors.war_print(f"{num_upserts} upserts found in {table_name}", indent=3)

        out_df_count = out_df.count()
        # out_df.show()
        if out_df_count == pre_full_count:

            out_df.write.jdbc(url=self.cxn['url'],
                              table=table_name + '_circe',
                              mode="overwrite",
                              properties=self.cxn['properties'])

            # MANUALLY COPY TABLE name to overwrite other table
            from cm_commons.db.cm_conn import cm_cxn

            colors.bug_print("DELETING TABLE")

            self.copy_table(src=table_name + '_circe', trg=table_name,
                            cxn=cm_cxn, overwrite=True,
                            delete_src=False,
                            prv_src=False, prv_trg=False)

            # THIS THING DOESN'T WORK!

            # out_df.write.jdbc(url=self.cxn['url'],
            #                  table=table_name,
            #                  mode="overwrite",
            #                  properties=self.cxn['properties'])

            colors.suc_print(f"Wrote {table_name} successfully with {out_df_count} records", indent=3)
            # out_df.show()
        else:
            colors.err_print(f"{table_name} previously had {pre_full_count} records but now has {out_df_count}",
                             indent=3)

        return self

    def save_dfs(self):

        # Not needed for now:
        """
        # TODO: Check RDS write which is failing currently
        print(f"Outputting dfs for {self.table_name} to RDS")

        self.output_df_to_rds(target_db=self.target_db,
                              df=self.mastered_df,
                              table=f"{self.table_name}_mastered",
                              mode="append")

        colors.suc_print(f"mastered_df for {self.table_name} written to RDS:{self.target_db}/{self.table_name}_mastered")

        s3_mode="overwrite"
        if self.parquet_append_mode:
            s3_mode = "append"
        print("S3 write mode = ", s3_mode)
        s3_loc_name=self.mastered_output_dir + self.raw_table_name + '/' + self.output_date + '.parquet'
        self.mastered_df=self.mastered_df.select([col_name for col_name in self.mastered_df.columns if col_name not in self.fields_to_ignore_in_parquet])
        self.mastered_df.limit(2).write.mode(s3_mode).parquet(s3_loc_name)
        colors.suc_print(f"mastered_df written to {s3_loc_name}")


        self.output_df_to_rds(target_db=self.target_db,
                              df=self.diff_df,
                              table=f"{self.table_name}_diff",
                              mode="append")
        colors.suc_print(f"diff_df for {self.table_name} written to RDS:{self.target_db}/{self.table_name}_diff")
        """

        self.write_rules(self.diff_df, self.raw_table_name)

    def write_conf(self, table_name):
        colors.out_print(f"Creating conf for {table_name}...", indent=1)

        conf = { \
            "etl_name": "Circe Job", \
            "packages": [], \
            "prefix": "circe_", \
            "file_extension": "none", \
            "source_type": "none", \
            "file_date": f"{self.output_date}", \
            "input_location": { \
                "emr": "None" \
                }, \
            "output_location": { \
                "emr": f"{self.mastered_output_dir}" \
                }, \
            "source_name": "circe", \
            "schema_name": f"{table_name.upper()}", \
            "destinations": ["parquet"], \
            "source_schema_name": "null_schema", \
            "target_schema_name": f"{table_name.upper()}", \
            "transformer": "None" \
            }

        conf_filename = f"{table_name}_{self.output_date}.conf"
        put_file_in_s3(conf_filename, self.conf_output_dir, json.dumps(conf, indent=4))
        colors.suc_print(f"Finished writing {conf_filename} to {self.conf_output_dir}", indent=2)

    def write_rules(self, diff_df, actual_table_name, ind=0, schema=None):

        # Remove excess baggage:
        diff_df = diff_df.filter(~col('column_name').isin(self.fields_to_omit_in_persist_rules))
        diff_df = diff_df.filter(~col('invalid_value').isin(self.values_to_omit_in_persist_rules))
        diff_df = diff_df.filter(~col('valid_value').isin(self.values_to_omit_in_persist_rules))

        # TODO: Change to True later if needed
        rules_df = diff_df.where(diff_df.create_rule == lit(False))

        original_record_pkey = f"original_record_{actual_table_name}_id"
        if actual_table_name.startswith('entity_'):
            original_record_pkey = f"original_record_{actual_table_name[:-5]}_id"
        colors.out_print(f"Using  {original_record_pkey} as key name")

        col_groups = ["column_name", original_record_pkey, "etl_source"]

        rules_df = rules_df.withColumn("rule_id", md5(concat_ws("_", *col_groups)))

        #TODO: stop-gap; fill in the entity_type_id when creating diff_df:
        rules_df = rules_df.withColumn('entity_type_id', lit(''))

        rules_df = rules_df.withColumn('created_by', lit('circe_ds'))
        rules_df = rules_df.withColumn('created_at', f.current_timestamp())
        rules_df = rules_df.select('rule_id', original_record_pkey,'entity_type_id', 'column_name', 'invalid_value', \
                                   'valid_value', 'stewardship_type', 'created_by', 'created_at')
        # rules_df.show(rules_df.count(), False)

        # print(f"Rules count for {actual_table_name} = {rules_df.count()}")

        # rules_database = 'cm_enrichment'
        rules_database = self.target_db
        rules_table_name = f"{self.table_prefix}_persist_rules_{actual_table_name}"

        self.output_df_to_rds(target_db=rules_database,
                              df=rules_df,
                              table=rules_table_name,
                              mode="append")
        colors.suc_print(
            f"rules_df written to RDS:{rules_database}/{rules_table_name}",
            indent=ind + 1)

    def process_file(self):
        colors.out_print(f"Starting process_files for {self.table_name}", indent=0)
        if self.conf['load_src'] == 'csv':
            self.load_ds_output_csv()
        elif self.conf['load_src'] == 'rds':
            self.load_ds_output_rds()
        else:
            colors.err_print("Invalid load_src!", indent=1)
            exit(1)

        if self.raw_dedupe_df:
            self.get_mastered_records()
            colors.suc_print("Obtained mastered records.", indent=1)

            self.diff_df = self.get_diff_df(self.raw_dedupe_df, self.raw_table_name)

            self.get_cascade()
            self.save_dfs()
            self.write_conf(self.raw_table_name)
        else:
            colors.err_print(f"No deduplication table, skipping {self.table_name}", indent=1)

    def process_all_files(self):
        for table_name in self.conf["TABLES_LIST"]:
            #
            # if table_name != nav_debug:"entity":  continue

            colors.suc_print(f"Processing {table_name} table ...")

            self.raw_table_name = table_name  # unprefixed

            if self.table_prefix != '':
                self.table_name = self.table_prefix + "_" + table_name
            else:
                self.table_name = table_name

            self.diff_columns = [self.conf["TDS_ID"],
                                 # "source_name",
                                 "etl_source",
                                 f"original_record_{table_name}_id",
                                 "column_name",
                                 "invalid_value",
                                 "valid_value",
                                 "stewardship_type",
                                 "create_rule",
                                 "created_at",
                                 "updated_at",
                                 "submitted_at",
                                 "cascade"]
            self.process_file()


def start_process(circe_conf_dict, table_prefix, src_db_name, target_db_name, ds_mastered_output_dir,
                  ds_conf_output_dir):
    try:
        colors.suc_print("Initializing StewardshipManipulator...")
        # circe_conf_loc = "s3://lazard-emr-test-data/conf/source-files/DS/process_ds_conf.json"
        processor = StewardshipManipulator(circe_conf_dict, table_prefix, src_db_name, target_db_name, \
                                           ds_mastered_output_dir, ds_conf_output_dir)
        processor.process_all_files()
    except Exception as ex:
        logging.exception("Exception raised in StewardshipManipulator!")
