import json, os, time, calendar
import psycopg2, hashlib
from datetime import datetime
import re

from pyspark.sql.types import StructType, StringType, StructField
from pyspark.sql.functions import lit, udf, col, concat_ws, md5, monotonically_increasing_id, when, current_timestamp, trim, coalesce

from cm_commons import colors
from cm_commons.db.cm_conn import cm_cxn_jdbc, cm_cxn
from cm_commons.spark import build_session
from cm_commons.util.boto_functions import put_file_in_s3, file_exists, read_json, \
    get_files_from_s3_folder, get_s3_bucket
from spark_functions.scripts.sql_advanced import *


# Load the configuration file from S3
def load_conf(conf_loc):
    if not file_exists(conf_loc):
        colors.err_print(f"{conf_loc} does NOT exist!")
        raise RuntimeError("Aborting job...")
    return read_json(conf_loc)


# Check if we're passing in a connection, and if not use the information in the cm_cxn_jdbc from cm_commons
def check_cxn(url, properties):
    if url is None:
        url = cm_cxn_jdbc['url']
    if properties is None:
        properties = cm_cxn_jdbc['properties']

    return url, properties


def format_date_columns(raw_df):
    raw_df = raw_df.withColumn("date_effective", lit(datetime.now().strftime("%m-%d-%Y")))

    # parse_date_udf = udf(lambda my_date: parse_talend_date(my_date), StringType())
    # raw_df = raw_df.withColumn("parsed_created_at", parse_date_udf('created_at'))
    # raw_df = raw_df.withColumn("parsed_updated_at", parse_date_udf('updated_at'))
    # raw_df = raw_df.withColumn("parsed_enriched_at", parse_date_udf('enriched_at'))

    raw_df = raw_df.withColumn("parsed_created_at", raw_df.created_at)
    raw_df = raw_df.withColumn("parsed_updated_at", raw_df.updated_at)
    raw_df = raw_df.withColumn("parsed_enriched_at", raw_df.enriched_at)

    raw_df = raw_df.drop('created_at').withColumnRenamed('parsed_created_at', 'created_at')
    raw_df = raw_df.drop('updated_at').withColumnRenamed('parsed_updated_at', 'updated_at')
    raw_df = raw_df.drop('enriched_at').withColumnRenamed('parsed_enriched_at', 'enriched_at')

    return raw_df

class GeneralManipulator:
    def __init__(self, conf_loc_or_dict, table_prefix, src_db_name, target_db_name, mastered_output_dir,
                 conf_output_dir):
        print("Building spark session")
        self.spark = build_session("Process_DS")

        if isinstance(conf_loc_or_dict, str):
            print(f"Looking up list of files from SV conf from {conf_loc_or_dict}")
            # self.conf = load_conf(conf_loc_or_dict)
            self.conf_path = conf_loc_or_dict
            self.conf_files_dict = self.get_conf_files_dict()
        else:
            print("Loading DS conf dictionary...")
            self.conf = conf_loc_or_dict
            # print(f"self.conf=", self.conf)

        self.src_db = src_db_name
        self.target_db = target_db_name

        self.mastered_df = None

        self.mastered_output_dir = mastered_output_dir
        self.conf_output_dir = conf_output_dir
        self.output_date = datetime.today().strftime('%m-%d-%Y')

        print("Getting cxn details")
        self.cxn = cm_cxn_jdbc

        if table_prefix == '':
            self.table_prefix = 'stg_' + self.look_up_staging_switch()
            colors.out_print(f"Setting table prefix to {self.table_prefix}")
        else:
            self.table_prefix = table_prefix

        self.diff_schema = None
        self.fields_to_ignore_in_parquet = ['source_name', 'stewardship_type']
        self.fields_to_omit_in_persist_rules = ['created_by', 'created_at', 'crm_id', 'enrichment_error', 'error',
                                                'new_persistence_id', 'record_id',
                                                'salesvision_id_new', 'salesvision_id_old',
                                                'ect_channel_id', 'ect_entity_id', 'ect_team_id', 'enriched_at']
        self.values_to_omit_in_persist_rules = ['none', 'null', 'edm-881', 'edm-494', 'edm-1030', 'edm-1090', 'edm_exempt']

        self.pid = str(os.getpid())
        self.run_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        md5_param = f"{str(self.pid)}_{str(self.run_date)}"
        # self.merge_id = hashlib.md5(str(md5_param).encode('utf-8')).hexdigest()
        self.merge_id = str(calendar.timegm(time.gmtime()))
        colors.out_print(f"PID= {self.pid}, run_date={self.run_date}, merge_id={self.merge_id}")

    def get_conf_files_dict(self):
        # TODO: Iterate through the files from incoming folder and process them. Currently picking only one file
        files_list = get_files_from_s3_folder(self.conf_path)

        files_dict = {}
        if len(files_list) > 0:
            for f in files_list:
                # Assuming file format: TEST_salesvision_merge_profile_06_11_2019.csv.gz_1564687618127
                match = re.search(r'\d{2}_\d{2}_\d{4}', f) or re.search(r'\d{2}-\d{2}-\d{4}', f)
                date_str = match.group()

                # key = int(yyyymmdd)
                key = int(date_str[6:] + date_str[0:2] + date_str[3:5])
                files_dict[key] = f
        else:
            print(f"No conf file found for merge in the s3 folder - {conf_location}")
            raise RuntimeError

        print(f"Total merge files to be processed={len(files_list)}")
        return files_dict

    # TODO: Standardize this method in cm_commons.colors later for use by all modules
    def print_w_ts(self, mesg):
        """
        Print with timestamp.
        :param mesg: Message to be printed
        :return: None
        """
        log_prefix = datetime.strftime(datetime.now(), '%d/%m/%Y %H:%M:%S') + ' [merge]'
        print(f"{log_prefix} {mesg}")

    def load_df_from_rds(self, url=None, target_db=None, table=None, properties=None):
        self.cxn['url'], self.cxn['properties'] = check_cxn(url, properties)
        self.cxn['url'] = self.cxn['url'][:self.cxn['url'].rindex("/") + 1] + target_db

        # print("self.cxn=",self.cxn)
        # print("cm_cxn=", cm_cxn)
        conn = psycopg2.connect(dbname=target_db,
                                user=self.cxn['properties']['user'],
                                host=cm_cxn['location'],  # TODO: self.cxn['url'],
                                password=self.cxn['properties']['password'])
        cur = conn.cursor()
        cur.execute("select * from information_schema.tables where table_name=%s", (table,))

        if bool(cur.rowcount):
            print(f"Loading from RDS:{target_db}/{table}")
            df = self.spark.read.jdbc(url=self.cxn['url'],
                                      table=table,
                                      properties=self.cxn['properties'])
        else:
            colors.err_print(f"Could not find {table} in {target_db}", indent=1)
            df = None
        return df

    def load_file_from_s3(self, file_loc):
        print(f"Loading Salesvision merge file from {file_loc}")
        df = self.spark.read.csv(file_loc, header=True)
        return df

    def output_df_to_rds(self, df, url=None, target_db=None, table=None, mode='overwrite', properties=None):
        self.cxn['url'], self.cxn['properties'] = check_cxn(url, properties)
        self.cxn['url'] = self.cxn['url'][:self.cxn['url'].rindex("/") + 1] + target_db

        print(f"Writing to RDS:{target_db}/{table}, mode={mode}")
        df.write.jdbc(url=self.cxn['url'],
                      table=table,
                      properties=self.cxn['properties'],
                      mode=mode)

    def invoke_db_sql_stmt(self, table_name, sql_stmt, url=None, target_db=None, table=None, properties=None):

        if target_db is None:
            target_db = self.target_db
        self.cxn['url'], self.cxn['properties'] = check_cxn(url, properties)
        self.cxn['url'] = self.cxn['url'][:self.cxn['url'].rindex("/") + 1] + target_db

        conn = psycopg2.connect(dbname=target_db,
                                user=self.cxn['properties']['user'],
                                host=cm_cxn['location'],  # TODO: self.cxn['url'],
                                password=self.cxn['properties']['password'])
        cur = conn.cursor()
        cur.execute("select * from information_schema.tables where table_name=%s", (table_name,))
        if  bool(cur.rowcount):
            cur.execute(sql_stmt)
            row_count = cur.rowcount
            print("Nbr of rows affected=", row_count)
            cur.execute("COMMIT;")
            print("Sql stmt execution completed!")
        else:
            colors.err_print(f"{table_name} does not exist in {target_db}, skipping...", indent=1)

    def look_up_staging_switch(self):
        df = self.load_df_from_rds(target_db=self.src_db, table="edm_params")
        if df != None and df.count() >= 1:
            return str(df.filter(df.key == 'active_mdm_stage').collect()[0].asDict()['value1'])
        else:
            colors.err_print(f"staging_switch table does NOT exist!")
            raise RuntimeError("Aborting job...")

    def get_diff_df(self, input_df, actual_table_name, indent=0):
        print(f"Caching input_df for table {actual_table_name} inside get_diff_df()...")
        input_df.cache()

        colors.out_print(f"Generating {actual_table_name} diff df", indent=indent + 1)

        pre_melt = {}
        stmt = []
        for c in input_df.columns:
            # Ignore these columns from diff process:
            if c in ["tds_id", "staging_id", "stewardship_type", \
                     "create_rule", "etl_error", "etl_source", "error_message", "updated_at", \
                     "group_count", "tds_master", "tds_match_yn"]:
                continue
            input_df = input_df.withColumn(c + "_COLUMN", lit(c))
            pre_melt[c + '_key'] = [c, c + "_COLUMN"]
            stmt.append((c, col(c)))

        # print("pre_melt of input_df=", input_df.limit(5).show(truncate=False))
        # print("pre_melt=", pre_melt)
        # print("stmt=", stmt)

        post_melt = {'target': ['invalid', 'column_name']}

        df_melt_out = melt(input_df.filter(input_df.tds_master == 'false'), pre_melt, post_melt)

        # print("df_melt_out=", df_melt_out.limit(5).show(truncate=False))

        # df_joined = df_melt_out.select('tds_id', 'invalid', 'column_name').join(
        #   input_df.filter(input_df.tds_master == 'true'), 'tds_id')

        df_joined = df_melt_out.select('tds_id', 'invalid', 'column_name', \
                                       col('entity_id').alias('old_entity_id')) \
            .join(input_df.filter(input_df.tds_master == 'true'), 'tds_id')
        # input_df.drop('entity_id').filter(input_df.tds_master == 'true'), 'tds_id')

        '''
        df_joined = df_melt_out.select('tds_id', 'invalid', 'column_name', 'entity_id').join(
            input_df.filter(input_df.tds_master == 'true'), 'tds_id')
            #input_df.drop('entity_id').filter(input_df.tds_master == 'true'), 'tds_id')
        '''

        # print("Inside get_diff_df, df_joined:")
        # df_joined.show(df_joined.count(), False)

        sc_df = switch_case_3(df_joined, in_col='column_name', out_col='valid', statement=stmt, default='error')
        diff_df = sc_df.filter((sc_df.invalid != sc_df.valid) \
                               | (col('invalid').isNull() & col('valid').isNotNull()) \
                               | (col('invalid').isNotNull() & col('valid').isNull()))

        # print("diff_df=")
        # diff_df.show(5, False)

        # Special case for sv merge, to get the old entity_id from tds_master=False:
        diff_df = diff_df.drop('entity_id').withColumnRenamed('old_entity_id', 'entity_id')

        # print("Inside get_diff_df, diff_df:")
        # diff_df.show(diff_df.count(), False)
        # colors.out_print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")

        # print("diff_df=", diff_df.show(diff_df.count(), truncate=False))

        original_record_pkey = f"original_record_{actual_table_name}_id"
        if actual_table_name.startswith('entity_'):
            original_record_pkey = f"original_record_{actual_table_name[:-5]}_id"
        colors.out_print(f"Using  {original_record_pkey} as key name")

        diff_df = diff_df.withColumn(original_record_pkey, col(f"{self.raw_table_name}_id"))
        diff_df = diff_df.withColumn("stewardship_type", lit("Correction"))
        diff_df = diff_df.withColumn("create_rule", lit("false"))
        diff_df = diff_df.withColumn("updated_at", col("created_at"))
        diff_df = diff_df.withColumn("cascade", lit("False"))

        if actual_table_name == 'entity':
            diff_schema = StructType([
                StructField(self.conf["TDS_ID"], StringType(), True),
                StructField("entity_type_id", StringType(), True),
                StructField("etl_source", StringType(), True),
                StructField(original_record_pkey, StringType(), True),
                StructField("column_name", StringType(), True),
                StructField("invalid_value", StringType(), True),
                StructField("valid_value", StringType(), True),
                StructField("stewardship_type", StringType(), True),
                StructField("create_rule", StringType(), True),
                StructField("created_at", StringType(), True),
                StructField("updated_at", StringType(), True),
                StructField("submitted_at", StringType(), True),
                StructField("cascade", StringType(), True)
            ])
            diff_df_final = self.spark.createDataFrame([], diff_schema)

            diff_df = diff_df.filter(diff_df[original_record_pkey].isNotNull())\
                            .select(self.conf["TDS_ID"],
                                                  "entity_type_id",
                                                  "etl_source",
                                                  # "entity_id", # for debug
                                                  f"{self.raw_table_name}_id",
                                                  "column_name",
                                                  "invalid",
                                                  "valid",
                                                  self.conf["STEWARDSHIP_TYPE"],
                                                  "create_rule",
                                                  "created_at",
                                                  "updated_at",
                                                  "submitted_at",
                                                  "cascade")

            diff_df_final = diff_df_final.union(diff_df)
        else:
            #For tables other than entity:
            diff_schema = StructType([
                StructField(self.conf["TDS_ID"], StringType(), True),
                # StructField("entity_type_id", StringType(), True),
                StructField("etl_source", StringType(), True),
                StructField(original_record_pkey, StringType(), True),
                StructField("column_name", StringType(), True),
                StructField("invalid_value", StringType(), True),
                StructField("valid_value", StringType(), True),
                StructField("stewardship_type", StringType(), True),
                StructField("create_rule", StringType(), True),
                StructField("created_at", StringType(), True),
                StructField("updated_at", StringType(), True),
                StructField("submitted_at", StringType(), True),
                StructField("cascade", StringType(), True)
            ])
            diff_df_final = self.spark.createDataFrame([], diff_schema)

            diff_df = diff_df.filter(diff_df[original_record_pkey].isNotNull()) \
                .select(self.conf["TDS_ID"],
                        # "entity_type_id",
                        "etl_source",
                        # "entity_id", # for debug
                        f"{self.raw_table_name}_id",
                        "column_name",
                        "invalid",
                        "valid",
                        self.conf["STEWARDSHIP_TYPE"],
                        "create_rule",
                        "created_at",
                        "updated_at",
                        "submitted_at",
                        "cascade")

            diff_df_final = diff_df_final.union(diff_df)

        # print("diff_df_final=", diff_df_final.limit(10).show(truncate=False))
        print("List of Columns which had diffs =")
        diff_df_final.select('column_name').distinct().show(diff_df_final.count(), truncate=False)

        print(f"Returning diff_df for {actual_table_name} table")
        return diff_df_final.distinct()

    def query_cascade_records(self, cascade_table_prefix, cascade_table_name, fk_col_name, cascade_map_df,
                              target_db=None):
        if not target_db:
            target_db = self.src_db

        if cascade_table_prefix == '':
            cascade_full_name = cascade_table_name
        else:
            cascade_full_name = cascade_table_prefix + "_" + cascade_table_name

        colors.out_print(f"Querying cascade_records for {cascade_full_name}", indent=4)

        raw_cascade_df_full = self.load_df_from_rds(target_db=target_db, table=cascade_full_name)
        if raw_cascade_df_full is None:
            return None, None

        raw_cascade_df = raw_cascade_df_full

        # TODO: Check & handle conditions if invalid_value is null
        colors.out_print(
            f"Extracting rows from full dataset of {cascade_full_name} using {fk_col_name} column having invalid values...")
        cascade_raw_invalid_df = raw_cascade_df.join(cascade_map_df,
                                                     raw_cascade_df[fk_col_name] == cascade_map_df.invalid_value)

        colors.suc_print(f"{raw_cascade_df_full.count()} records found in  FULL dataset", indent=5)
        colors.suc_print(f"{cascade_raw_invalid_df.count()} records found in INVALID dataset", indent=5)

        return cascade_raw_invalid_df, raw_cascade_df_full


    def query_cascade_records_old(self, cascade_table_prefix, cascade_table_name, fk_col_name, cascade_map_df, target_db=None):
        if not target_db:
            target_db = self.src_db

        if cascade_table_prefix == '':
            cascade_full_name = cascade_table_name
        else:
            cascade_full_name = cascade_table_prefix + "_" + cascade_table_name

        raw_cascade_df = self.load_df_from_rds(target_db=target_db, table=cascade_full_name)

        id_col = fk_col_name

        if raw_cascade_df is not None:
            # TODO: Check & handle conditions if invalid_value is null
            cascade_raw_df = raw_cascade_df.join(cascade_map_df, raw_cascade_df[fk_col_name] == cascade_map_df.invalid_value)
        else:
            cascade_raw_df = None

        return cascade_raw_df


    def get_cascade(self, yyyymmdd_str_key):
        """Get the cascaded records based on the primary table + conf"""

        conf_date_stamp = yyyymmdd_str_key[0:4] + "-" + yyyymmdd_str_key[4:6] + "-" + yyyymmdd_str_key[6:]

        colors.out_print(f"Getting pkey cascades for {self.table_name}", indent=1)

        if self.raw_table_name in self.conf['PKEY_FKEY_MAPPINGS'].keys():
            # find all tables with a foreign key relationship to the current table
            for fk_table, fk_column in self.conf['PKEY_FKEY_MAPPINGS'][self.raw_table_name].items():
                colors.out_print(f"Cascading in progress for column={fk_column} for table={fk_table}", indent=2)

                source_key = self.raw_table_name + "_id"

                # cascade_map_df = self.diff_df.where(self.diff_df['column_name'] == f"{source_key}")
                colors.out_print(f"Find diffs for {source_key} for table={self.raw_table_name}", indent=3)
                cascade_map_df = self.diff_df.where(self.diff_df['column_name'] == f"{source_key}")

                if cascade_map_df.take(1) != []:
                    # print("NAV_DEBUG: ", cascade_map_rdd.take(1))
                    # id_col = "original_record_" + fk_table + "_id"
                    id_col = fk_column
                    # cascade_dict = cascade_map_rdd.map(lambda x: (x[id_col], (x["invalid_value"], x["valid_value"])) ).collectAsMap()
                    cascade_map_df = cascade_map_df.select("invalid_value", "valid_value").distinct()
                    colors.bug_print("cascade_map_df=", indent=3)
                    cascade_map_df.select("invalid_value", "valid_value").distinct().limit(2).show(truncate=False)
                    # print("NAV-DEBUG cascade_map_df=",cascade_map_df.filter(cascade_map_df.invalid_value == '49e3b10282f162eebb69735de9092f2f')\
                    #                                             .show(truncate=False))
                else:
                    colors.war_print(f"No data to cascade for column={fk_column} for table={fk_table}", indent=2)
                    continue

                # Getting cascaded records
                cascade_raw_invalid_df, cascade_raw_full_df = self.query_cascade_records(
                    cascade_table_prefix=self.table_prefix,
                    cascade_table_name=fk_table, fk_col_name=fk_column,
                    cascade_map_df=cascade_map_df)

                if cascade_raw_invalid_df is None:
                    colors.err_print(f"cascade_raw_invalid_df is None for {fk_table} table. Skipping...")
                    continue
                else:
                    count_cascade = cascade_raw_invalid_df.count()
                    if count_cascade > 0:
                        colors.suc_print(f"Found {count_cascade} records to be cascaded in {fk_table}.{fk_column}",
                                         indent=3)
                    else:
                        colors.war_print(f"No data found with invalid_value in {fk_table} table. Skipping...", indent=3)
                        continue

                colors.out_print(f"Adding static columns to {fk_table}", indent=3)

                cascade_raw_invalid_df = cascade_raw_invalid_df.withColumn(self.conf["STAGING_ID"], lit(None))

                if fk_table.endswith('_xref') and fk_table.startswith('entity'):
                    fk_id = fk_table[:-5] + "_id"
                    colors.war_print(f"Assuming primary key {fk_id} for {fk_table}", indent=4)

                else:
                    fk_id = fk_table + "_id"
                    colors.suc_print(f"Assuming primary key {fk_id} for {fk_table}", indent=4)

                cascade_raw_invalid_df = cascade_raw_invalid_df.withColumn(self.conf["TDS_ID"],
                                                                           f.lit(cascade_raw_invalid_df[fk_id]))
                cascade_raw_invalid_df = cascade_raw_invalid_df.withColumn('stewardship_type', f.lit("Update"))
                cascade_raw_invalid_df = cascade_raw_invalid_df.withColumn('create_rule', f.lit("false"))
                cascade_raw_invalid_df = cascade_raw_invalid_df.withColumn("submitted_at",
                                                                           f.lit(datetime.now().strftime("%Y-%m-%d")))

                # Dropping this for now as it's not part of the diff schema:
                colors.war_print(f" Dropping error column", indent=4)
                cascade_raw_invalid_df = cascade_raw_invalid_df.drop("error")
                cascade_raw_invalid_df = format_date_columns(cascade_raw_invalid_df)

                id_col = f"{self.raw_table_name}_id"
                if id_col != fk_column:
                    id_col = fk_column

                # TODO: Check filter condition handling for null values
                colors.out_print(f"Determing master record with {id_col}", indent=3)
                # cascade_mastered_df is ONLY mastered records
                cascade_mastered_df = cascade_raw_invalid_df.filter(
                    cascade_raw_invalid_df[id_col] == cascade_raw_invalid_df.invalid_value) \
                    .drop(id_col) \
                    .withColumn(id_col, cascade_raw_invalid_df.valid_value)

                cascade_mastered_df_count = cascade_mastered_df.count()

                if cascade_mastered_df_count > 0:
                    colors.suc_print(
                        f"{cascade_mastered_df_count} records remastered with valid {self.raw_table_name}.{id_col}",
                        indent=4)
                else:
                    colors.war_print(f"{cascade_mastered_df_count} records found for remastering", indent=4)

                # colors.bug_print(f"{cascade_mastered_df.count()}", indent=0)

                colors.out_print("Preparing RAW df", indent=4)
                cascade_raw_df = cascade_raw_invalid_df.drop("invalid_value")
                cascade_raw_df = cascade_raw_df.drop("valid_value")
                cascade_raw_df = cascade_raw_df.withColumn(self.conf["STAGING_ID"],
                                                           f.lit('false'))

                #TODO: should this to be driven by conf file. upsert columns list in addition to fk join column in conf file
                if fk_table.endswith('_xref') and fk_table.startswith(self.raw_table_name) and 'ended_at' in cascade_mastered_df.columns:
                    id_col = 'ended_at'
                    cascade_mastered_df = cascade_mastered_df.withColumn(id_col, lit(conf_date_stamp))

                colors.out_print("Preparing MASTERED df", indent=4)
                # cascade_mastered_df['staging_id'] = self.conf['MASTER']
                cascade_mastered_df = cascade_mastered_df.drop("invalid_value")
                cascade_mastered_df = cascade_mastered_df.drop("valid_value")
                cascade_mastered_df = cascade_mastered_df.drop(self.conf["STAGING_ID"])
                cascade_mastered_df = cascade_mastered_df.withColumn(self.conf["STAGING_ID"],
                                                                     f.lit(self.conf['MASTER']))
                cascade_mastered_df = cascade_mastered_df.select([col for col in cascade_raw_df.columns])
                colors.out_print(f"{cascade_mastered_df.count()} records in MASTER", indent=5)
                # colors.bug_print("#####")
                # colors.bug_print("cascade_mastered_df")
                # cascade_mastered_df.orderBy("TDS_ID").show(2, truncate=False)
                # colors.bug_print("#####")
                # colors.bug_print("#####")

                colors.out_print("Unioning RAW and MASTERED", indent=4)
                cascade_df = cascade_raw_df.union(cascade_mastered_df)
                colors.out_print(f"{cascade_df.count()} records in UNION", indent=5)
                # print("NAV-DEBUG - cascade_df(raw+mastered)=", cascade_df.show())

                # print(f"cascade_df={cascade_df.show(truncate=False)}")
                # colors.bug_print("#####")
                # colors.bug_print("cascade_df")
                # cascade_df.orderBy("TDS_ID").show(2, truncate=False)
                # colors.bug_print("#####")
                # colors.bug_print("#####")

                colors.out_print(f"Getting diff for cascaded table {fk_table}", indent=3)
                cascade_diff_df = self.get_diff_df(cascade_df, fk_table, indent=4)
                cascade_df_count = cascade_diff_df.count()
                cascade_diff_df = cascade_diff_df.drop("cascade").withColumn("cascade", lit("True"))

                # Adding missing columns to match the self.mastered_df columns:
                if 'error' not in cascade_mastered_df.columns:
                    cascade_mastered_df = cascade_mastered_df.withColumn('error', lit(''))

                if 'record_id' not in cascade_mastered_df.columns:
                    cascade_mastered_df = cascade_mastered_df.withColumn('record_id', lit(''))

                if 'ds_ingested_at' not in cascade_mastered_df.columns:
                    cascade_mastered_df = cascade_mastered_df.withColumn('ds_ingested_at', lit(''))

                cascade_mastered_df = cascade_mastered_df.drop('etl_source').withColumn('etl_source',
                                                                                        lit('circe_cascade'))
                cascade_mastered_df = cascade_mastered_df.drop(self.conf['STAGING_ID'])

                # cascade_mastered_df = cascade_mastered_df.select([col for col in self.mastered_df.columns])

                # print("NAV-DEBUG cascade_mastered_df=", cascade_mastered_df.limit(2).show())

                if self.raw_table_name == fk_table:
                    table_name = self.table_name
                else:
                    table_name = self.table_prefix + "_" + fk_table

                """
                # Not needed for now
                self.output_df_to_rds(target_db=self.target_db,
                                      df=cascade_mastered_df,
                                      table=f"{table_name}_mastered",
                                      mode="append")
                colors.suc_print(f"cascade_mastered_df for {table_name} written to RDS:{self.target_db}/{table_name}_mastered")
                """

                # print("cascade_mastered_df count = ", cascade_mastered_df.count())
                if cascade_mastered_df != None and cascade_mastered_df.take(1) != []:

                    colors.out_print(f"Writing {fk_table} mastered to parquet", indent=2)
                    s3_loc_name = self.mastered_output_dir + fk_table + '/' + self.output_date + '.parquet'
                    cascade_mastered_df = cascade_mastered_df.select(
                        [col_name for col_name in cascade_mastered_df.columns if
                         col_name not in self.fields_to_ignore_in_parquet])
                    cascade_mastered_df.write.mode("overwrite").parquet(s3_loc_name)
                    colors.suc_print(f"cascade_mastered_df written to {s3_loc_name}", indent=3)

                    push_table_name = f"{table_name}"

                    # colors.out_print(f"Writing {fk_table} to push table {push_table_name}", indent=2)

                    # colors.suc_print(f"cascade_mastered_df written to {push_table_name}", indent=3)

                    push_table_name = f"{table_name}"
                    if push_table_name == f"{table_name}":
                        colors.war_print(f"Overwriting {fk_table} to push table {push_table_name}", indent=2)

                    cascade_full_df = self.load_df_from_rds(target_db=self.src_db,
                                                            table=f"{table_name}")

                    # cascade_mastered_df: just the mastered records
                    # cascade_full_df
                    self.load_cascade_upsert(df_full=cascade_full_df, df_delta=cascade_mastered_df,
                                             primary_key=fk_id, upsert_col=id_col, table_name=push_table_name)

                    if self.raw_table_name == fk_table:
                        self.parquet_append_mode = True
                else:
                    print(f"No data available to write as parquet for {fk_table}")

                """
                # Not needed for now
                # Writing to persist_rules table instead
                self.output_df_to_rds(target_db=self.target_db,
                                          df=cascade_diff_df,
                                          table=f"{table_name}_diff",
                                          mode="append")

                colors.suc_print(f"cascade_diff_df for {table_name} written to RDS:{self.target_db}/{table_name}_diff")
                """

                self.write_conf(fk_table)

                self.write_rules(cascade_diff_df, fk_table)

        else:
            print(f"No FK relations found for {self.table_name} table")

    def load_cascade_upsert_new(self, df_full, df_delta, primary_key, upsert_cols, table_name):
        """Upsert df_delta into df_full and loads to table_name"""

        colors.out_print(f"Upserting mastered table for {table_name}", indent=2)
        colors.out_print(f"Primary Key: {primary_key}", indent=3)  # entity_id, agreement_entity_xref_id, etc.
        colors.out_print(f"Upsert Column: {upsert_cols}", indent=3)  # parent_id, entity_id, etc.

        # taking the delta and renaming the column to upsert_cols and join criteria on it's own
        cols = []
        for c in upsert_cols:
            df_delta = df_delta.withColumnRenamed(f"{c}", f"{c}_master")
            cols.append(f"{c}_master")

        select_list = [primary_key]
        select_list.extend(cols)

        if 'ended_at_master' in select_list:
            df_delta = df_delta.select(select_list).distinct().filter(col('ended_at_master').isNotNull())
        else:
            df_delta = df_delta.select(select_list)

        pre_full_count = df_full.count()

        colors.bug_print(f"{pre_full_count} FULL records before", indent=3)
        colors.bug_print(f"{df_delta.count()} DELTA records before", indent=3)

        colors.out_print("Sample df_delta records: ")
        df_delta.show(20, False)

        out_df = df_full.join(df_delta,
                              f"{primary_key}",
                              "left_outer")
        for c in upsert_cols:
            out_df = out_df.withColumn(f"{c}", when(
                col(f"{c}_master").isNotNull(),
                col(f"{c}_master")
            ).otherwise(col(f"{c}"))
                                       ).drop(f"{c}_master")

        out_df_count = out_df.count()
        colors.bug_print(f"{out_df_count} TOTAL records after", indent=3)

        '''
        num_upserts = out_df.filter(col(f"{upsert_col}_master").isNotNull()).count()
        if num_upserts > 0:
            colors.suc_print(f"{num_upserts} upserts found in {table_name}", indent=3)
        else:
            colors.war_print(f"{num_upserts} upserts found in {table_name}", indent=3)
        '''

        colors.out_print(f"Sample out_df records written to {table_name}:")
        out_df.show(5, False)
        if out_df_count == pre_full_count:
            tmp_table_name = f"{table_name}_circe_merge_post_tmp"
            out_df.write.jdbc(url=self.cxn['url'],
                              table=tmp_table_name,
                              mode="overwrite",
                              properties=self.cxn['properties'])

            # MANUALLY COPY TABLE name to overwrite other table
            # from cm_commons.db.cm_conn import cm_cxn

            colors.bug_print("DELETING TABLE")

            self.copy_table(src=tmp_table_name, trg=table_name,
                            cxn=cm_cxn, overwrite=True,
                            delete_src=False,
                            prv_src=False, prv_trg=False)

            # THIS THING DOESN'T WORK!

            # out_df.write.jdbc(url=self.cxn['url'],
            #                  table=table_name,
            #                  mode="overwrite",
            #                  properties=self.cxn['properties'])

            colors.suc_print(f"Wrote {table_name} successfully with {out_df_count} records", indent=3)
            colors.out_print(f"Sample out_df records written to {table_name}:")
            # out_df.show(5, False)
        else:
            colors.err_print(f"{table_name} previously had {pre_full_count} records but now has {out_df_count}",
                             indent=3)

        return self

    def load_cascade_upsert(self, df_full, df_delta, primary_key, upsert_col, table_name):
        """Upsert df_delta into df_full and loads to table_name"""

        colors.out_print(f"Upserting mastered table for {table_name}", indent=2)
        colors.out_print(f"Primary Key: {primary_key}", indent=3)  # entity_id, agreement_entity_xref_id, etc.
        colors.out_print(f"Upsert Column: {upsert_col}", indent=3)  # parent_id, entity_id, etc.

        # taking the delta and renaming the column to upsert_col and join criteria on it's own
        df_delta = df_delta.withColumnRenamed(f"{upsert_col}", f"{upsert_col}_master").select(
            f"{primary_key}", f"{upsert_col}_master")

        pre_full_count = df_full.count()
        colors.bug_print(f"{pre_full_count} FULL records before", indent=3)
        colors.bug_print(f"{df_delta.count()} DELTA records before", indent=3)

        colors.out_print("Sample df_delta records: ")
        df_delta.show(5, False)

        out_df = df_full.join(df_delta,
                              f"{primary_key}",
                              "left_outer").withColumn(f"{upsert_col}",
                                                       f.when(
                                                           f.col(f"{upsert_col}_master").isNotNull(),
                                                           f.col(f"{upsert_col}_master")
                                                       ).otherwise(f.col(f"{upsert_col}"))
                                                       ).drop(f"{upsert_col}_master")

        out_df_count = out_df.count()
        colors.bug_print(f"{out_df_count} TOTAL records after", indent=3)

        num_upserts = out_df.filter(f.col(f"{upsert_col}_master").isNotNull()).count()

        if num_upserts > 0:
            colors.suc_print(f"{num_upserts} upserts found in {table_name}", indent=3)
        else:
            colors.war_print(f"{num_upserts} upserts found in {table_name}", indent=3)

        colors.out_print(f"Sample out_df records written to {table_name}:")
        out_df.show(5, False)
        if out_df_count == pre_full_count:

            out_df.write.jdbc(url=self.cxn['url'],
                              table=table_name + '_circe',
                              mode="overwrite",
                              properties=self.cxn['properties'])

            # MANUALLY COPY TABLE name to overwrite other table
            # from cm_commons.db.cm_conn import cm_cxn

            colors.bug_print("DELETING TABLE")

            self.copy_table(src=table_name + '_circe', trg=table_name,
                            cxn=cm_cxn, overwrite=True,
                            delete_src=False,
                            prv_src=False, prv_trg=False)

            # THIS THING DOESN'T WORK!

            # out_df.write.jdbc(url=self.cxn['url'],
            #                  table=table_name,
            #                  mode="overwrite",
            #                  properties=self.cxn['properties'])

            colors.suc_print(f"Wrote {table_name} successfully with {out_df_count} records", indent=3)
            # out_df.show()
        else:
            colors.err_print(f"{table_name} previously had {pre_full_count} records but now has {out_df_count}",
                             indent=3)

        return self

    @staticmethod
    def copy_table(src, trg, cxn, overwrite=False, delete_src=False, prv_src=False, prv_trg=False):

        colors.out_print(f"Copying table {src} to {trg}", indent=3)

        import psycopg2
        conn = psycopg2.connect(dbname=cm_cxn['db_name'],
                                user=cm_cxn['user'],
                                host=cm_cxn['location'],
                                password=cm_cxn['password'])
        cur = conn.cursor()
        cur.execute(f"select * from information_schema.tables where table_name='{src}'")
        src_exists = bool(cur.rowcount)
        cur.execute(f"select * from information_schema.tables where table_name='{trg}'")
        trg_exists = bool(cur.rowcount)

        if src_exists:
            if trg_exists and overwrite == True:
                colors.out_print(f"Dropping {trg}", indent=3)
                cur.execute(f"drop table {trg}")
                colors.bug_print("Checking if table was really deleted")
                cur.execute(f"select * from information_schema.tables where table_name='{trg}'")
                colors.bug_print(f"{trg} exists: {str(bool(cur.rowcount))}")
                conn.commit()

            colors.out_print(f"Copying {src} to {trg}", indent=3)
            cur.execute(f"create table {trg} as SELECT * FROM {src}")
            conn.commit()

            colors.bug_print("Checking if table was really recreated")
            cur.execute(f"select * from information_schema.tables where table_name='{trg}'")
            colors.bug_print(f"{trg} exists: {str(bool(cur.rowcount))}")
        else:
            colors.err_print(f"{src} doesn't exist", indent=3)

    def write_conf(self, table_name):
        print(f"Creating conf for {table_name}...")

        conf = { \
            "etl_name": "Circe Job", \
            "packages": [], \
            "prefix": "circe_", \
            "file_extension": "none", \
            "source_type": "none", \
            "file_date": f"{self.output_date}", \
            "input_location": { \
                "emr": "None" \
                }, \
            "output_location": { \
                "emr": f"{self.mastered_output_dir}" \
                }, \
            "source_name": "circe", \
            "schema_name": f"{table_name.upper()}", \
            "destinations": ["parquet"], \
            "source_schema_name": "null_schema", \
            "target_schema_name": f"{table_name.upper()}", \
            "transformer": "None" \
            }

        conf_filename = f"{table_name}_{self.output_date}.conf"
        put_file_in_s3(conf_filename, self.conf_output_dir, json.dumps(conf, indent=4))
        colors.suc_print(f"Finished writing {conf_filename} to {self.conf_output_dir}")

    def write_rules(self, diff_df, actual_table_name):

        self.print_w_ts(f"Writing rules from diff_df for {actual_table_name}...")

        # Remove excess baggage:
        diff_df = diff_df.filter(~col('column_name').isin(self.fields_to_omit_in_persist_rules))

        # Updating null salesforce_ids in valid entities:
        diff_df = diff_df.withColumn('valid_value', when((col('column_name') == lit('salesforce_id'))
                                                            & (col('invalid_value').isNotNull())
                                                            & (col('valid_value').isNull()),col('invalid_value'))
                                                    .otherwise(col('valid_value')))

        diff_df = diff_df.filter(~col('invalid_value').isin(self.values_to_omit_in_persist_rules))
        diff_df = diff_df.filter(~col('valid_value').isin(self.values_to_omit_in_persist_rules))

        # TODO: Change to True later if needed
        rules_df = diff_df.where(diff_df.create_rule == lit(False))

        original_record_pkey = f"original_record_{actual_table_name}_id"
        if actual_table_name.startswith('entity_'):
            original_record_pkey = f"original_record_{actual_table_name[:-5]}_id"

        """ Replacing with merge_id:
        col_groups = ["column_name", original_record_pkey, "etl_source"]
        rules_df = rules_df.withColumn("rule_id", md5(concat_ws("_", *col_groups)))
        """

        rules_df = rules_df.withColumn("rule_id", lit(self.merge_id))

        rules_df = rules_df.withColumn('created_by', lit(f'circe_{self.source_system_prefix}_merge'))
        rules_df = rules_df.withColumn('created_at', current_timestamp())

        if actual_table_name == 'entity':
            rules_df = rules_df.select('rule_id', original_record_pkey, 'entity_type_id', 'column_name',
                                       'invalid_value', 'valid_value', 'stewardship_type', 'created_by', 'created_at')
        else:
            rules_df = rules_df.select('rule_id', original_record_pkey, 'column_name',
                                       'invalid_value', 'valid_value', 'stewardship_type', 'created_by', 'created_at')

        # rules_df.show(rules_df.count(), False)

        # print(f"Rules count for {actual_table_name} = {rules_df.count()}")

        # rules_database = 'cm_enrichment'
        rules_database = self.target_db
        rules_table_name = f"{self.table_prefix}_persist_rules_{actual_table_name}"

        if rules_df.take(1) != []:
            self.output_df_to_rds(target_db=rules_database,
                                  df=rules_df,
                                  table=rules_table_name,
                                  mode="append")
            colors.suc_print(
                f"rules_df written to RDS:{rules_database}/{rules_table_name}")
        else:
            colors.suc_print("No persist rules exist")

        if actual_table_name == 'entity':
            merge_database = self.target_db  # 'cm_merge'
            merge_rules_table_name = f"{self.table_prefix}_merge_rules"

            merges_p_df = diff_df.where(diff_df.column_name == lit('persistence_id'))
            merges_sf_df = diff_df.where(diff_df.column_name == lit('salesforce_id'))\
                .withColumnRenamed('invalid_value', 'sf_invalid') \
                .withColumnRenamed('valid_value', 'sf_valid') \
                .select('original_record_entity_id', 'sf_invalid', 'sf_valid')
            merges_sv_df = diff_df.where(diff_df.column_name == lit('salesvision_id')) \
                .withColumnRenamed('invalid_value', 'sv_invalid') \
                .withColumnRenamed('valid_value', 'sv_valid') \
                .select('original_record_entity_id', 'sv_invalid', 'sv_valid')

            merges_df = merges_p_df.join(merges_sf_df, 'original_record_entity_id', 'left_outer')
            merges_df = merges_df.join(merges_sv_df, 'original_record_entity_id', 'left_outer')

            # TODO: Duplication/Cartesian occurs due to Many:1 merge situation,
            #  where the valid sf_id occurs more than once.
            # Need a better way to handle this scenario while generating tds_id in create_tds_df()
            merges_df = merges_df.distinct()
            merges_df = merges_df.withColumn("merge_id", lit(self.merge_id))

            print("Sample of merges_df entries to be written to merge_rules table:")
            merges_df.show(5, False)

            merges_df = merges_df.select('merge_id', 'entity_type_id', 'invalid_value', 'valid_value',
                                         'sf_invalid', 'sf_valid', 'sv_invalid', 'sv_valid')
            merges_df = merges_df.withColumn('conf_date', lit(self.conf['file_date']))
            merges_df = merges_df.withColumn('created_by', lit(f'circe_{self.source_system_prefix}_merge'))
            merges_df = merges_df.withColumn('created_at', current_timestamp())


            if merges_df.take(1) != []:
                self.output_df_to_rds(target_db=merge_database,
                                      df=merges_df,
                                      table=merge_rules_table_name,
                                      mode="append")
                colors.suc_print(
                    f"merges_df for {self.table_name} written to RDS:{merge_database}/{merge_rules_table_name}")
            else:
                colors.suc_print("No merge rules exist")


    def write_merge_exceptions(self, input_merge_df, entity_df, conf_date):
        print(f"Looking up {self.source_system}_IDs that did NOT merge...")

        if self.source_system == 'salesvision':
            exceptions_df = input_merge_df.join(entity_df,
                                                (input_merge_df.salesvision_id_old == entity_df.salesvision_id) & \
                                                (when(input_merge_df.entity_char == 'P', '1')
                                                 .when(input_merge_df.entity_char == 'O', '2')
                                                 .otherwise('3') == entity_df['entity_type_id'].substr(1, 1)),
                                                how='inner') \
                .filter(col('ended_at').isNull() | (trim(col('ended_at'))==''))\
                .select('salesvision_id_old', 'salesvision_id_new', 'entity_id', 'persistence_id',
                        'entity_type_id', 'salesforce_id')
        elif self.source_system == 'salesforce':
            
            #TODO: This method needs clean up when Schema of exceptions table is changed.
            merge_df_cols = input_merge_df.columns
            input_merge_df = input_merge_df.join(entity_df,
                                            (col('id_old') == col('salesforce_id')) &
                                                (when(col('entity_char') == 'P', '1')
                                                .when(col('entity_char') == 'O', '2')
                                                .otherwise('3') == col('entity_type_id').substr(1, 1)),
                                                how='left_outer') \
                                    .withColumn('salesvision_id_old', coalesce(col('sv_from_id'), col('salesvision_id'))) \
                                    .select(merge_df_cols + ['salesvision_id_old'])
        
            input_merge_df = input_merge_df.join(entity_df,
                                            (col('id_new') == col('salesforce_id')) &
                                                (when(col('entity_char') == 'P', '1')
                                                .when(col('entity_char') == 'O', '2')
                                                .otherwise('3') == col('entity_type_id').substr(1, 1)),
                                                how='left_outer') \
                                .withColumn('salesvision_id_new', coalesce(col('sv_to_id'), col('salesvision_id'),lit('UNKNOWN'))) \
                                    .select(merge_df_cols + ['salesvision_id_old','salesvision_id_new'])

            exceptions_df = input_merge_df.join(entity_df,
                                                (input_merge_df.id_old == entity_df.salesforce_id) & \
                                                (when(input_merge_df.entity_char == 'P', '1')
                                                 .when(input_merge_df.entity_char == 'O', '2')
                                                 .otherwise('3') == entity_df['entity_type_id'].substr(1, 1)),
                                                how='inner') \
                .filter(col('ended_at').isNull() | (trim(col('ended_at'))==''))\
                .select('salesvision_id_old', 'salesvision_id_new', 'entity_id', 'persistence_id',
                        'entity_type_id', 'salesforce_id')
        else:
            # TODO: Check on id_old, id_new:
            exceptions_df = input_merge_df.join(entity_df,
                                                input_merge_df.id_old == entity_df.salesforce_id, how='inner') \
                                            .filter(col('ended_at').isNull() | (trim(col('ended_at'))==''))\
                                            .select('id_old', 'id_new',
                                                      'entity_id', 'persistence_id', 'entity_type_id', 'salesforce_id')

        if exceptions_df.take(1) != []:
            self.print_w_ts("Sample of exceptions_df:")
            exceptions_df.show(2, False)

            exceptions_table_name = f"{self.table_prefix}_merge_exceptions"

            exceptions_df = exceptions_df.withColumn('conf_date', lit(conf_date))\
                                .withColumn('created_at', current_timestamp())\
                                .withColumn('created_by', lit(f'circe_{self.source_system_prefix}_merge'))\
                                .withColumn('reason', lit('invalid is not end-dated, pls check'))\
                                .withColumn('salesforce_id',
                                            when(col('salesforce_id').isNull(), lit(" "))
                                            .otherwise(col('salesforce_id')))

            exceptions_df = exceptions_df.withColumn("merge_id", lit(self.merge_id))
            self.output_df_to_rds(target_db=self.target_db,
                                  df=exceptions_df,
                                  table=exceptions_table_name,
                                  mode="append")
            colors.suc_print(f"exceptions_df for {self.table_name}"
                             f" written to RDS:{self.target_db}/{exceptions_table_name}")

            s3_loc_name = f"s3://{get_s3_bucket()}/CIRCE/data/merge_exceptions/{conf_date}"
            exceptions_df.write.mode("append").parquet(s3_loc_name)
            colors.suc_print(f"exceptions_df written to {s3_loc_name} for conf_date = {conf_date}", indent=3)
        else:
            colors.suc_print(f"No {self.source_system} merge exceptions exists for conf_date = {conf_date}")


    def update_null_salesforce_ids(self, input_df):
        """
        Update new entities which have no salesforce ids with that from old entities
        :param input_df: The merge file contents
        :return:
        """
        self.print_w_ts("Salesforce id update process started...")

        edf = self.load_df_from_rds(target_db=self.src_db, table=self.table_name)

        if edf == None or edf.take(1) == []:
            raise RuntimeError(f"Either {self.table_name} doesn't exist or has no data in it. Aborting job...")

        edf = edf.cache()
        orig_entity_table_count = edf.count()
        self.print_w_ts(f"Row count in {self.table_name}={orig_entity_table_count}")

        # Preserve edf columns:
        entity_cols = []
        for c in edf.columns:
            entity_cols.append(c)

        merge_df = input_df.dropDuplicates(['salesvision_id_new'])

        self.print_w_ts("Sample merge_df entries from input merge file:")
        merge_df.show(5, False)

        invalid_edf = merge_df.join(edf, (merge_df.salesvision_id_old == edf.salesvision_id) & \
                                    (
                                            when(merge_df.entity_char == 'P', '1') \
                                            .when(merge_df.entity_char == 'O', '2') \
                                            .otherwise('3') == edf['entity_type_id'].substr(1, 1) \
                                        ), \
                                    how='inner')

        invalid_edf = invalid_edf.select('persistence_id', 'entity_type_id', col('ended_at').alias('inv_ended_at'),
                                         col('salesforce_id').alias('inv_sf_id'))

        valid_edf = merge_df.join(edf, (merge_df.salesvision_id_new == edf.salesvision_id) & \
                                  (
                                          when(merge_df.entity_char == 'P', '1') \
                                          .when(merge_df.entity_char == 'O', '2') \
                                          .otherwise('3') == edf['entity_type_id'].substr(1, 1) \
                                      ), \
                                  how='inner')

        # valid_edf = valid_edf.select('persistence_id', 'entity_type_id', 'ended_at', 'salesforce_id')
        # valid_edf = valid_edf.select(c for c in entity_cols)

        # self.print_w_ts(f"Count of invalid_edf={invalid_edf.count()}")
        # self.print_w_ts(f"Count of valid_edf={valid_edf.count()}")

        updated_valid_edf = valid_edf.join(invalid_edf, ['persistence_id', 'entity_type_id'], how='inner')
        # updated_valid_edf.show(10, False)

        if updated_valid_edf.take(1) == []:
            self.print_w_ts("No entries available for the update process. No Update performed, SKIPPING...")
            return

        updated_valid_edf = updated_valid_edf.withColumn('salesforce_id', when(
            (col('inv_ended_at').isNotNull() & \
             (col('ended_at').isNull() | (trim(col('ended_at'))=='')) & \
             col('inv_sf_id').isNotNull() & \
             (col('salesforce_id').isNull() | (trim(col('salesforce_id'))==''))),
            col('inv_sf_id')).otherwise(col('salesforce_id')))

        updated_valid_edf = updated_valid_edf.select([c for c in entity_cols])
        # updated_valid_edf.select('persistence_id', 'entity_type_id', 'ended_at', 'salesforce_id').show(20, False)
        updated_valid_edf = updated_valid_edf.withColumnRenamed('salesforce_id', 'upd_sf_id')
        updated_valid_edf = updated_valid_edf.filter(col('upd_sf_id').isNotNull()).dropDuplicates(['persistence_id'])

        uv_edf = updated_valid_edf.select('entity_id', 'entity_type_id', 'persistence_id', 'ended_at', 'upd_sf_id')
        print("Sample of valid entities that will be updated with salesforce_id:")
        uv_edf.show(10, False)

        unaffected_edf = edf.join(uv_edf, (edf.persistence_id == uv_edf.persistence_id) &
                                  (edf.entity_type_id == uv_edf.entity_type_id) &
                                  (edf.ended_at.isNull() | (trim(edf.ended_at)=='')),
                                  how="left_anti")
        new_edf = unaffected_edf.union(updated_valid_edf)

        updated_entity_table_count = new_edf.count()
        updated_valid_edf_count = updated_valid_edf.count()
        unaffected_edf_count = unaffected_edf.count()

        self.print_w_ts(f"unaffected_edf_count = {unaffected_edf_count}")
        self.print_w_ts(f"updated_valid_edf_count = {updated_valid_edf_count}")

        self.print_w_ts(f"orig_entity_table_count = {orig_entity_table_count}")
        self.print_w_ts(f"updated_entity_table_count = {updated_entity_table_count}")

        if updated_valid_edf_count == 0 or orig_entity_table_count != updated_entity_table_count:
            self.print_w_ts("Either no entries exist for update OR there is a count mismatch. No update performed!!")
            return
        else:
            print(f"Updating {self.table_name} table now...")
            new_edf.write.jdbc(url=cm_cxn_jdbc['url'], table=self.table_name, mode='overwrite',
                               properties=cm_cxn_jdbc['properties'])
            self.print_w_ts(f"Data overwritten in {self.table_name} table with updated sf ids for {updated_valid_edf_count} entities")

        self.print_w_ts("Salesforce id update process completed")

    def sv_filter_input(self, merge_df, entity_df, conf_date):
        """
            Identify the valid entities which do not have entries in entity table
            Write the corresponding invalid entities into merge_exceptions table
            Filter off these invalid-valid pair(s) from going ahead with the merge process
            (As as result, the invalid entities will not get end-dated and can be tracked)
        """
        self.print_w_ts("Filteration process on merge contents started...")

        merge_df = merge_df.filter(~(col('salesvision_id_old')==col('salesvision_id_new')))

        exceptions_table_name = f"{self.table_prefix}_merge_exceptions"

        self.print_w_ts("Looking to filter-off one-to-many merges of invalid entities...")
        multi_merge_df = merge_df.groupBy('entity_char', 'salesvision_id_old').count()\
                                    .filter(col('count') > 1)\
                                    .select('entity_char', 'salesvision_id_old')

        merge_df = merge_df.join(multi_merge_df,
                                 (merge_df['entity_char'] == multi_merge_df['entity_char']) &
                                 (merge_df['salesvision_id_old'] == multi_merge_df['salesvision_id_old']),
                                 how='left_anti')

        if multi_merge_df != None and multi_merge_df.take(1) != []:
            merge_exceptions_df = multi_merge_df.join(entity_df, (col('salesvision_id_old') == col('salesvision_id')) &
                                                      (when(col('entity_char') == 'P', '1')
                                                       .when(col('entity_char') == 'O', '2')
                                                       .otherwise('3') == col('entity_type_id').substr(1, 1)),
                                                      how='inner')

            merge_exceptions_df = merge_exceptions_df.select('salesvision_id_old', 'entity_id', 'persistence_id',
                                                             'entity_type_id', 'salesforce_id')\
                                                        .withColumn('salesvision_id_new', lit('MULTIPLE'))\
                                                        .withColumn('conf_date', lit(conf_date))\
                                                        .withColumn('created_by', lit(f'circe_{self.source_system_prefix}_merge'))\
                                                        .withColumn('created_at', current_timestamp())\
                                                        .withColumn('reason',
                                                                    lit('invalid merges with more than one valid')) \
                                                        .withColumn('salesforce_id',
                                                                    when(col('salesforce_id').isNull(), lit(" "))
                                                                    .otherwise(col('salesforce_id')))

            merge_exceptions_df = merge_exceptions_df.withColumn("merge_id", lit(self.merge_id))

            self.print_w_ts("Sample of merge_exceptions_df:")
            merge_exceptions_df.show(2, False)
            merge_exceptions_df.write.jdbc(url=cm_cxn_jdbc['url'], table=exceptions_table_name,
                                           properties=cm_cxn_jdbc['properties'], mode='append')
            self.print_w_ts(f"merge_exceptions_df written to RDS:{exceptions_table_name}")

            s3_loc_name = f"s3://{get_s3_bucket()}/CIRCE/data/merge_exceptions/{conf_date}"
            self.print_w_ts(f"Writing merge_exceptions_df to {s3_loc_name}")
            merge_exceptions_df.write.mode("append").parquet(s3_loc_name)
            self.print_w_ts(f"merge_exceptions_df written to {s3_loc_name} for conf_date = {conf_date}")
        else:
            self.print_w_ts(f"No {self.source_system} merge exceptions due to one-to-many merges of invalid entities exists\
                                                                for conf_date = {conf_date}")



        self.print_w_ts("Looking for non-existent invalid entities...")
        no_invalid_df = merge_df.join(entity_df, (col('salesvision_id_old')==col('salesvision_id')) &
                                        (when(col('entity_char') == 'P', '1')
                                         .when(col('entity_char') == 'O', '2')
                                         .otherwise('3') == col('entity_type_id').substr(1,1)),
                                    how='left_outer')\
                                .filter(col('entity_id').isNull())

        if no_invalid_df != None and no_invalid_df.take(1) != []:
            no_invalid_df = no_invalid_df.select('entity_char', 'salesvision_id_old', 'salesvision_id_new')\
                                    .withColumn('entity_id', lit('UNKNOWN'))\
                                    .withColumn('persistence_id', lit('UNKNOWN')) \
                                    .withColumn('entity_type_id',
                                                when(col('entity_char') == 'P', '101')
                                                .when(col('entity_char') == 'O', '201')
                                                .otherwise('301'))\
                                    .withColumn('salesforce_id', lit('UNKNOWN'))

            merge_exceptions_df = no_invalid_df.select('salesvision_id_old', 'salesvision_id_new', 'entity_id',\
                                                        'persistence_id','entity_type_id', 'salesforce_id') \
                                                        .withColumn('conf_date', lit(conf_date)) \
                                                        .withColumn('created_by', lit(f'circe_{self.source_system_prefix}_merge')) \
                                                        .withColumn('created_at', current_timestamp()) \
                                                        .withColumn('reason', lit('invalid does not exist in cm'))

            merge_exceptions_df = merge_exceptions_df.withColumn("merge_id", lit(self.merge_id))

            self.print_w_ts("Sample of merge_exceptions_df:")
            merge_exceptions_df.show(2, False)

            self.output_df_to_rds(target_db=self.target_db,
                                  df=merge_exceptions_df,
                                  table=exceptions_table_name,
                                  mode="append")
            colors.suc_print(f"merge_exceptions_df for {self.table_name}"
                             f" written to RDS:{self.target_db}/{exceptions_table_name}")

            s3_loc_name = f"s3://{get_s3_bucket()}/CIRCE/data/merge_exceptions/{conf_date}"
            merge_exceptions_df.write.mode("append").parquet(s3_loc_name)
            colors.suc_print(f"merge_exceptions_df written to {s3_loc_name} for conf_date = {conf_date}", indent=3)
        else:
            colors.suc_print(f"No {self.source_system} merge exceptions due to non-existent invalid entities exists\
                                    for conf_date = {conf_date}")



        self.print_w_ts("Looking for invalid entities with non-existent valid entities...")

        merge_df_cols = merge_df.columns

        joined_df = merge_df.join(entity_df, (col('salesvision_id_new')==col('salesvision_id')) &
                                        (when(col('entity_char') == 'P', '1')
                                         .when(col('entity_char') == 'O', '2')
                                         .otherwise('3') == col('entity_type_id').substr(1,1)) &
                                  (col('ended_at').isNull() | (trim(col('ended_at')) == '')),
                                    how='left_outer')

        merge_exceptions_df = joined_df.filter(col('entity_id').isNull()\
                                               | (col('ended_at').isNotNull() & (trim(col('ended_at'))!='')))\
                                        .select(merge_df_cols)

        merge_exceptions_df = merge_exceptions_df.join(entity_df, (col('salesvision_id_old')==col('salesvision_id')) &
                                                            (when(col('entity_char') == 'P', '1')
                                                                .when(col('entity_char') == 'O', '2')
                                                                .otherwise('3') == col('entity_type_id').substr(1,1)) &
                                                       (col('ended_at').isNull() | (trim(col('ended_at')) == '')),
                                                        how='inner')\
                                        .select('salesvision_id_old', 'salesvision_id_new',
                                                      'entity_id', 'persistence_id', 'entity_type_id', 'salesforce_id')\
                                        .distinct()

        filtered_input_df = joined_df.filter(col('entity_id').isNotNull()\
                                             & ((col('ended_at').isNull()) | (trim(col('ended_at'))=='')) )\
                                .select(merge_df_cols)

        self.print_w_ts("Sample filtered_input_df entries that will be used by merge process:")
        # filtered_input_df.filter(col('salesvision_id_old').isin('1126861','1011980')).show(10, False)
        filtered_input_df.show(2, False)

        if merge_exceptions_df != None and merge_exceptions_df.take(1) != []:
            merge_exceptions_df = merge_exceptions_df \
                .withColumn('conf_date', lit(conf_date))\
                .withColumn('created_by', lit(f'circe_{self.source_system_prefix}_merge')) \
                .withColumn('created_at', current_timestamp()) \
                .withColumn('reason', lit('valid is either end-dated or does not exist in cm')) \
                .withColumn('salesforce_id',
                            when(col('salesforce_id').isNull(), lit(" "))
                            .otherwise(col('salesforce_id')))

            merge_exceptions_df = merge_exceptions_df.withColumn("merge_id", lit(self.merge_id))

            self.print_w_ts("Sample of merge_exceptions_df:")
            # merge_exceptions_df.filter(col('salesvision_id_old').isin('1126861','1011980')).show(10, False)
            merge_exceptions_df.show(2, False)

            self.output_df_to_rds(target_db=self.target_db,
                                  df=merge_exceptions_df,
                                  table=exceptions_table_name,
                                  mode="append")
            colors.suc_print(f"merge_exceptions_df for {self.table_name}"
                             f" written to RDS:{self.target_db}/{exceptions_table_name}")

            s3_loc_name = f"s3://{get_s3_bucket()}/CIRCE/data/merge_exceptions/{conf_date}"
            merge_exceptions_df.write.mode("append").parquet(s3_loc_name)
            colors.suc_print(f"merge_exceptions_df written to {s3_loc_name} for conf_date = {conf_date}", indent=3)
        else:
            colors.suc_print(f"No {self.source_system} merge exceptions due to non-existent valid entities exists\
                                     for conf_date = {conf_date}")

        self.print_w_ts("Filteration process on merge contents completed")

        return filtered_input_df

    def update_persistence_id_for_prior_ended_dated_entities(self, entity_df, enriched_merge_df):
        """
        Logic to update persistence_ids of older entities that are chained to newly ended-dated entity

        :param entity_df: Cached entity table
        :param enriched_merge_df: Enriched merge rules
        :return: None

        Logic:
            Create old_pid_df with only invalids by extracting from enriched_merge_df
            Create old_pid_map_df by joining old_pid_df with entity table,
                this is to extract all the entities which use the invalid's pid
            Filter only prior ended-dated invalids in old_pid_map_df by using ended_at is not null,
                (current invalids are already end-dated in memory in enriched_merge_df)
            Create upd_delta_entity_df by joining old_pid_map_df with entity table,
                this is to extract subset of data which need to be updated
            Update entity table with the upd_delta_entity_df
        """
        self.print_w_ts("Persistence id chaining process started...")

        orig_entity_table_count = entity_df.count()

        enriched_merge_df = enriched_merge_df.withColumn('old_persistence_id', col('persistence_id'))
        self.print_w_ts("enriched_merge_df:")
        enriched_merge_df.orderBy(self.conf["TDS_ID"], self.conf["STAGING_ID"]).show(4, False)

        old_pid_df = enriched_merge_df.filter(enriched_merge_df[self.conf["STAGING_ID"]]=='false')

        # Takek only the columns needed since we are going to get repeated fields added
        # due to joining with entity table again:
        old_pid_df = old_pid_df.select(self.conf["TDS_ID"], 'sv_id', self.conf["STAGING_ID"], 'ended_at',\
                                       'entity_id', 'persistence_id', 'entity_type_id',\
                                       'salesvision_id_old', 'salesvision_id_new', 'new_persistence_id',\
                                       'old_persistence_id')

        old_pid_map_df = old_pid_df.join(entity_df, \
                                         (old_pid_df['entity_type_id']==entity_df['entity_type_id'])\
                                         & (old_pid_df['old_persistence_id']==entity_df['persistence_id']),\
                                         how='inner')\
                                    .drop(entity_df['salesvision_id'])\
                                    .drop(old_pid_df['entity_id'])\
                                    .drop(old_pid_df['entity_type_id'])\
                                    .drop(old_pid_df['persistence_id'])\
                                    .drop(old_pid_df['ended_at'])\
                                    .drop(old_pid_df[self.conf["TDS_ID"]])\
                                    .drop(old_pid_df[self.conf["STAGING_ID"]])\
                                    .drop(old_pid_df['sv_id'])

        self.print_w_ts("Sample of old_pid_map_df:")
        old_pid_map_df.show(10, False)

        # select only necessary columns to avoid dupe columns as a result of upcoming join operation:
        old_pid_map_df = old_pid_map_df.filter(trim(col('ended_at'))!='')\
                                        .select('entity_id', 'entity_type_id', 'persistence_id',\
                                                'new_persistence_id', 'ended_at')

        entity_df_cols = entity_df.columns

        upd_delta_entity_df = entity_df.join(old_pid_map_df, ['entity_id', 'entity_type_id', 'persistence_id'],\
                                                how='inner')\
                                        .drop(old_pid_map_df['ended_at'])\
                                        .drop('persistence_id')\
                                        .withColumnRenamed('new_persistence_id', 'persistence_id')\
                                        .select([c for c in entity_df_cols])

        self.print_w_ts("Sample of upd_delta_entity_df:")
        upd_delta_entity_df.show(10, False)

        self.print_w_ts(f"Updating df for {self.table_name} now...")

        unaffected_edf = entity_df.join(upd_delta_entity_df, ['entity_id', 'entity_type_id', 'salesvision_id'], how="left_anti")
        unaffected_edf = unaffected_edf.select([c for c in entity_df_cols])

        self.print_w_ts("unaffected_edf:")
        unaffected_edf.show(10, False)

        new_edf = unaffected_edf.union(upd_delta_entity_df)

        updated_entity_table_count = new_edf.count()
        upd_delta_entity_df_count = upd_delta_entity_df.count()
        unaffected_edf_count = unaffected_edf.count()

        self.print_w_ts(f"unaffected_edf_count = {unaffected_edf_count}")
        self.print_w_ts(f"upd_delta_entity_df_count = {upd_delta_entity_df_count}")

        self.print_w_ts(f"orig_entity_table_count = {orig_entity_table_count}")
        self.print_w_ts(f"updated_entity_table_count = {updated_entity_table_count}")

        if upd_delta_entity_df_count == 0 or orig_entity_table_count != updated_entity_table_count:
            self.print_w_ts("Either no entries exist for update OR there is a count mismatch. No update performed!!")
        else:
            self.print_w_ts(f"Updating {self.table_name} table now...")
            new_edf.write.jdbc(url=cm_cxn_jdbc['url'], table=self.table_name, mode='overwrite',
                                                   properties=cm_cxn_jdbc['properties'])
            self.print_w_ts(f"Data overwritten in {self.table_name} table with {upd_delta_entity_df_count} entities updated in it")

    def write_to_audit_log(self, conf_date):
        self.print_w_ts("Processing for audit log...")

        merge_rules_table_name = f"{self.table_prefix}_merge_rules"
        merge_rules_df = self.load_df_from_rds(target_db=self.src_db, table=merge_rules_table_name)
        merge_rules_df = merge_rules_df.filter(col('merge_id')==self.merge_id)

        entity_df = self.load_df_from_rds(target_db=self.src_db, table=self.table_name)
        if entity_df == None or entity_df.take(1) == []:
            raise RuntimeError(f"Either {self.table_name} doesn't exist or has no data in it. Aborting job...")

        m = conf_date[4:6]
        d = conf_date[6:]
        y = conf_date[0:4]
        conf_date_ymd = f"{y}-{m}-{d}"

        self.print_w_ts(f"Using conf_date={conf_date} as  conf_date_ymd={conf_date_ymd} and merge_id={self.merge_id} to look up...")
        audit_log_df = entity_df.join(merge_rules_df, (entity_df.persistence_id == merge_rules_df.valid_value) &
                                      (entity_df.entity_type_id == merge_rules_df.entity_type_id) &
                                      (merge_rules_df.merge_id == self.merge_id) &
                                      ((entity_df.ended_at.isNull()) | (entity_df.ended_at ==  lit(conf_date_ymd))),
                                      how="inner")\
            .drop(merge_rules_df['entity_type_id'])\
            .drop(merge_rules_df['created_at'])

        audit_log_df = audit_log_df.drop('invalid_value', 'valid_value', 'sf_invalid', 'sf_valid',
                                         'sv_invalid', 'sv_valid', 'conf_date', 'created_by')

        audit_log_df = audit_log_df.withColumn('sv_event_code', lit('X'))\
                                    .withColumnRenamed('merge_id', 'audit_log_id')

        audit_log_table_name = f"{self.table_name}_audit_log"

        self.print_w_ts(f"Count of entries for audit log = {audit_log_df.count()}")

        if audit_log_df.take(1) != []:
            self.output_df_to_rds(target_db=self.target_db,
                                  df=audit_log_df,
                                  table= audit_log_table_name,
                                  mode="append")
            colors.suc_print(f"audit_log_df written to RDS:{self.target_db}/{audit_log_table_name}")
        else:
            colors.suc_print("No audit log records exist")

        self.print_w_ts("audit log processing completed")

    def clean_up_merge_tables(self, conf_date=None):
        self.print_w_ts("Calling clean_up_merge_tables...")

        exceptions_table_name = f"{self.table_prefix}_merge_exceptions"
        merge_rules_table_name = f"{self.table_prefix}_merge_rules"
        created_by = f"circe_{self.source_system_prefix}_merge"

        sql_stmt = f"DELETE FROM {exceptions_table_name} WHERE conf_date='{conf_date}' AND created_by = '{created_by}';"
        self.print_w_ts(f"Deleting older records in {exceptions_table_name} for {conf_date} and '{created_by}'...")
        self.invoke_db_sql_stmt(exceptions_table_name, sql_stmt)

        m = conf_date[5:6] if conf_date[4] == '0' else conf_date[4:6]
        d = conf_date[7:] if conf_date[6] == '0' else conf_date[6:]
        y = conf_date[0:4]
        conf_date_mdy = f"{m}-{d}-{y}"
        sql_stmt = f"DELETE FROM {merge_rules_table_name} WHERE conf_date = '{conf_date_mdy}' AND created_by = '{created_by}';"
        self.print_w_ts(f"Deleting older records in {merge_rules_table_name} for {conf_date_mdy} and '{created_by}'...")
        self.invoke_db_sql_stmt(merge_rules_table_name, sql_stmt)

    def update_survivor_with_max_ts(self):
        """
        Stamp updated_at field of survivor with max TS if its updated_at is less than its non-survivor
        This way SF will not reject the survivor
        """
        self.print_w_ts("Calling update_survivor_with_max_ts...")

        entity_table_name = f"{self.table_prefix}_entity"

        sql_stmt = f"update {entity_table_name} e3 set updated_at = pu.max_updated_at from \
        (select e.persistence_id, e.entity_type_id, max(e.updated_at) max_updated_at \
        from {entity_table_name} e \
        where e.persistence_id in (select ee.persistence_id from {entity_table_name} ee where ee.ended_at is not null) \
        group by e.persistence_id, e.entity_type_id ) pu \
        where e3.persistence_id = pu.persistence_id \
        and substring(e3.entity_type_id, 1, 1) = substring(pu.entity_type_id, 1, 1) \
        and (e3.ended_at is null or trim(e3.ended_at)='') \
        and e3.updated_at < pu.max_updated_at;"

        self.print_w_ts(f"Updating {entity_table_name}...")
        self.invoke_db_sql_stmt(entity_table_name, sql_stmt)