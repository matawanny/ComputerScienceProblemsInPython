import gzip, sys
import sys
import pandas as pd
import shutil
from common.envconfig import *
from common.database import PostgreSQL, db_connection_factory
from pandas import DataFrame
import numpy as np

"""
Usage:
python merge_runbook.py <fop_type> <stg_switch>
where fop_type = F|O|P
Steps:
su into ProdFM box and do these:
$ cd /home/edmfilemgr/backup-prod-LQE/FOP_all
$ python merge_runbook.py F sv_init_10 #for firm
$ python merge_runbook.py O sv_init_10 #for office
$ python merge_runbook.py P sv_init_10 #for person
"""

merge_files_list = ['salesvision_merge_profile_09_25_2019.gz', 'salesvision_merge_profile_09_26_2019.gz', 'salesvision_merge_profile_10_02_2019.csv.gz', 'salesvision_merge_profile_10_03_2019.csv.gz', 'salesvision_merge_profile_10_04_2019.gz', 'salesvision_merge_profile_11_13_2019.gz', 'salesvision_merge_profile_11_14_2019.gz', 'salesvision_merge_profile_11_15_2019.csv.gz', 'salesvision_merge_profile_11_18_2019.gz', 'salesvision_merge_profile_11_19_2019.gz', 'salesvision_merge_profile_11_20_2019.gz', 'salesvision_merge_profile_11_21_2019.gz', 'salesvision_merge_profile_11_22_2019.gz', 'salesvision_merge_profile_11_25_2019.gz', 'salesvision_merge_profile_11_26_2019.gz', 'salesvision_merge_profile_11_27_2019.gz', 'salesvision_merge_profile_11_29_2019.gz', 'salesvision_merge_profile_12_02_2019.gz', 'salesvision_merge_profile_12_03_2019.gz', 'salesvision_merge_profile_12_04_2019.gz', 'salesvision_merge_profile_12_12_2019.gz', 'salesvision_merge_profile_01_06_2020.gz', 'salesvision_merge_profile_01_13_2020.gz', 'salesvision_merge_profile_01_14_2020.gz', 'salesvision_merge_profile_01_22_2020.gz', 'salesvision_merge_profile_01_29_2020.gz', 'salesvision_merge_profile_02_05_2020.gz', 'salesvision_merge_profile_02_12_2020.gz', 'salesvision_merge_profile_02_20_2020.gz', 'salesvision_merge_profile_02_26_2020.gz', 'salesvision_merge_profile_03_04_2020.gz', 'salesvision_merge_profile_03_12_2020.gz', 'salesvision_merge_profile_03_19_2020.gz', 'salesvision_merge_profile_03_20_2020.gz', 'salesvision_merge_profile_03_27_2020.gz', 'salesvision_merge_profile_04_03_2020.gz', 'salesvision_merge_profile_04_17_2020.gz', 'salesvision_merge_profile_04_20_2020.gz', 'salesvision_merge_profile_04_23_2020.gz', 'salesvision_merge_profile_04_29_2020.gz', 'salesvision_merge_profile_05_06_2020.gz', 'salesvision_merge_profile_05_11_2020.gz', 'salesvision_merge_profile_05_21_2020.gz', 'salesvision_merge_profile_05_28_2020.gz', 'salesvision_merge_profile_06_03_2020.gz', 'salesvision_merge_profile_06_10_2020.gz', 'salesvision_merge_profile_06_19_2020.gz', 'salesvision_merge_profile_06_26_2020.gz', 'salesvision_merge_profile_06_29_2020.gz', 'salesvision_merge_profile_07_17_2020.gz', 'salesvision_merge_profile_07_24_2020.gz', 'salesvision_merge_profile_08_05_2020.gz', 'salesvision_merge_profile_08_11_2020.gz', 'salesvision_merge_profile_08_26_2020.gz', 'salesvision_merge_profile_09_02_2020.gz', 'salesvision_merge_profile_09_08_2020.gz', , 'salesvision_merge_profile_09_18_2020.gz', 'salesvision_merge_profile_10_19_2020.gz', 'salesvision_merge_profile_11_13_2020.gz', 'salesvision_merge_profile_11_20_2020.gz']


# UNIT-TEST:
# input_id_list = ['1465539','193213','808397', '159888', '1482093', '1471779']
# ['1465539','193213','193955','664150','703660','882285','961223','808397', '1079819', '159888']
# 1465539 -> 159888 -> 1482093
# 1471779 -> 808397 -> 1475698

# firms:
# input_id_list = ['79715', '100493', '10134', '96880', '129329', '130855', '131743', '18996']

#offices:


#persons:
# non-survivor:

input_id_list = ['193213', '193955', '664150', '703660', '882285', '961223', '1079819', '1144103', '1159394', '1305799', '1393458', '1416702', '1459733', '1464714', '2942', '16120', '95640', '162174', '191513', '571548', '799895', '972106', '1012451', '1136031', '1143041', '1230103', '1263866', '1297100', '1301811', '1318205', '1335295', '1382995', '1394630', '1404103', '55743', '118872', '198906', '334184', '569844', '636162', '688232', '703002', '894038', '1071321', '1074315', '1092614', '1094550', '1109449', '1137913', '1199600', '1200418', '1205152', '1230228', '1320421', '1355334', '1431454', '1471317', '203971', '332784', '590813', '766029', '817418', '881399', '926917', '1003393', '1075877', '1100712', '1187701', '1203554', '1223686', '1225948', '1261105', '1276125', '1324297', '1358319', '1393858', '1432390', '1463727', '1470267', '302398', '559389', '694727', '808397', '929772', '991796', '1144550', '1222663', '1274169', '1293605', '1354143', '1383189', '1466668', '194575', '208340', '287967', '542103', '774728', '808260', '879395', '891465', '970604', '988482', '996550', '1011458', '1027170', '1090417', '1126701', '1133069', '1141589', '1144455', '1146441', '1153683', '1186449', '1203660', '1203872', '1220837', '1281596', '1297365', '1425161', '1461795', '1463488', '1471651', '1283205', '1328969', '1382737', '1412647', '1414646', '1420477', '1463617', '188748', '627907', '752907', '813777', '818282', '1060989', '1064263', '1091097', '1096256', '1106091', '1136889', '1141063', '1141127', '1155486', '1210400', '1275974', '94356', '168142', '396086', '572129', '574779', '639894', '739714', '774750', '810493', '893200', '951571', '1004393', '1152475', '1179305', '1196509', '1201469', '1206689', '1232533', '1274193', '1303993', '1310760', '1317515', '1325786', '1404771', '1420595', '1422555', '1463926', '1465096', '167937', '466895', '551033', '668109', '1016153', '1057338', '1100669', '1137532', '1207173', '159888', '202322', '571627', '821605', '879529', '895058', '929674', '949241', '999969', '1092477', '1157979', '1162169', '1169475', '1264925', '1303912', '1331238', '1339940', '1394344', '9453', '186735', '253545', '464487', '660350', '698245', '725676', '730735', '828519', '856887', '903469', '975117', '992690', '1023982', '1118124', '1157118', '1288617', '1319398', '1351818', '1356917', '1382778', '1463372', '203652', '565382', '570044', '763960', '889283', '960917', '967921', '1015846', '1100548', '1135477', '1140549', '1200671', '1320959', '1338771', '1393280', '1412437', '1445273', '1461678', '640179', '967960', '1178727', '1387607', '843974', '1084819', '1137611', '1142499', '1270413', '1288205', '1463854', '73035', '1042262', '1068835', '1236473', '1251024', '1359358', '689375', '740859', '1060696', '1070433', '1092666', '1132784', '1135969', '1227722', '1275921', '1327860', '1379770', '175587', '197143', '206846', '688221', '743060', '750992', '836538', '868389', '968560', '1099880', '1142707', '1233519', '1470345', '895538', '897881', '989953', '1033895', '1092188', '1137899', '1156955', '1161479', '1161655', '1170832', '1178135', '1307590', '1342052', '1379577', '1383332', '1418446', '1481181', '94380', '115206', '123009', '185462', '187074', '194961', '195615', '209291', '309589', '479081', '620054', '637782', '659146', '697696', '746462', '751506', '784453', '825178', '860269', '892881', '1242700', '1281333', '1282255', '1283029', '1283674', '1287328', '1416917', '438093', '480684', '639907', '909960', '957984', '1006861', '1023626', '1069596', '1093334', '1194100', '1268617', '1304974', '1322877', '1406651', '1424312', '1461566', '1469497', '1475129', '1485584', '158195', '176078', '628947', '660754', '739262', '922587', '1175049', '1247911', '1343171', '1345335', '1013316', '1135402', '7164', '348087', '365900', '685231', '769821', '794980', '909753', '1051171', '1082722', '1086155', '1098393', '1099017', '1114250', '1136284', '1181888', '1188046', '1195253', '1221106', '1256391', '1281933', '1307155', '1316016', '1318243', '1338066', '1386939', '1390325', '1401317', '1412668', '1414225', '1463902', '184483', '307576', '571641', '729661', '772728', '979614', '1091975', '1271721', '1281084', '1325316', '1345340', '1374971', '1414574', '1414578', '1464735', '1019307', '328619', '818139', '865868', '989073', '1149101', '1317417', '1435038', '821131', '113140', '1388009', '672104', '891016', '190541', '1103592', '965322', '881658', '917057', '1219158', '185718', '901397', '908657', '919718', '1461937', '953565', '1016112', '1040730', '1088341', '1446945', '1446964', '1446970']



#--------------------------------------------------------------------


def query_rds(query, col_list):
        edf = None
        connection = db_connection_factory("prod", "RDS")
        with connection as cursor:
                        cursor.execute(query)
                        edf = DataFrame(cursor.fetchall())
        edf.columns = col_list
        edf.fillna('', inplace=True)
        return edf


def create_merge_graph(input_id_list, merge_files_list, curr_graph_list):
        for input_id in input_id_list:
                #debug print()
                #debug print(f"Looking up input_id={input_id}...")
                tmp_graph_list = list()
                active_sub_list = list()

                #debug print(f"START curr_graph_list = {curr_graph_list}")
                if curr_graph_list != []:
                        for x in range(len(curr_graph_list)):
                                #print(x)
                                tmp_list = curr_graph_list.pop(-1)
                                # print(type(tmp_list))
                                # print(tmp_list)
                                if not input_id in tmp_list:
                                        tmp_graph_list.append(tmp_list)
                                else:
                                        active_sub_list = tmp_list
                        """
                        if active_sub_list == []:
                                curr_graph_list = tmp_graph_list
                                continue
                        """
                for gzip_merge_file in merge_files_list:
                        merge_file_name = f"/home/edmfilemgr/backup-prod-LQE/FOP_all/{gzip_merge_file}"
                        # print(f"Opening {merge_file_name}...")
                        with gzip.open(merge_file_name, 'rt') as merge_file:
                                for line in merge_file:
                                        fields = line.split('|')
                                        if fields[0] == fop_type:
                                                if fields[1] == input_id:
                                                        #debug print(f"{input_id} present as INVALID in {merge_file_name}")
                                                        # print(f"active_sub_list type is {type(active_sub_list)} and has {active_sub_list}")
                                                        if input_id not in active_sub_list:
                                                                if tmp_graph_list != [] and any(fields[2] in sub_list for sub_list in tmp_graph_list):
                                                                        # Find the survivor sub-list and put non-survivor before the surivivor in that sub-list
                                                                        #debug print(f"Searching in tmp_graph_list={tmp_graph_list}")
                                                                        new_tmp_graph_list = list()
                                                                        for x in range(len(tmp_graph_list)):
                                                                                #print(x)
                                                                                tmp_list = tmp_graph_list.pop(-1)
                                                                                # print(type(tmp_list))
                                                                                # print(tmp_list)
                                                                                if not input_id in tmp_list:
                                                                                        new_tmp_graph_list.append(tmp_list)
                                                                                        if fields[2] in tmp_list:
                                                                                                active_sub_list = tmp_list
                                                                                else:
                                                                                        active_sub_list = tmp_list      #found the sub-list!
                                                                        tmp_graph_list = new_tmp_graph_list
                                                                        # Find survivor index and insert non-survivor before the survivor in this sub-list:
                                                                        #debug print(f"b4 index search: active_sub_list: {active_sub_list}")
                                                                        survivor_index = active_sub_list.index(fields[2])
                                                                        active_sub_list.insert(survivor_index, input_id)
                                                                else:
                                                                        # create a new sub-list:
                                                                        active_sub_list.append(input_id)
                                                                        # print(f"active_sub_list={active_sub_list}")
                                                                        active_sub_list.append(fields[2])
                                                        elif len(active_sub_list) > 0 and active_sub_list[-1] == input_id:
                                                                active_sub_list.append(fields[2])
                                                        else:
                                                                pass #already in the list with a successor
                                                elif fields[2] == input_id:
                                                        #debug print(f"{input_id} present as VALID in {merge_file_name}")
                                                        if input_id not in active_sub_list:
                                                                active_sub_list.append(input_id)
                                                        elif len(active_sub_list) > 0 and active_sub_list[-1] == input_id:
                                                                pass #exists already as last elem in the list as a successor
                                                        else:
                                                                pass #already in the list with a successor

                if active_sub_list != []:
                        tmp_graph_list.append(active_sub_list)
                curr_graph_list = tmp_graph_list
                # print(f"Inside curr_graph_list = {curr_graph_list}")
                # print()

        # print(f"Before depth-search, curr_graph_list:")
        # print(curr_graph_list)

        print()

        print("Finding the next survivor of surivivor who becomes a non-survivor...")
        depth_count = 0
        for depth in range(10):
                depth_count = depth_count + 1
                for sub_list in curr_graph_list:
                        last_survivor = sub_list[-1] if len(sub_list) > 1 else None
                        for gzip_merge_file in merge_files_list:
                                merge_file_name = f"/home/edmfilemgr/backup-prod-LQE/FOP_all/{gzip_merge_file}"
                                # print(f"Opening {merge_file_name}...")
                                with gzip.open(merge_file_name, 'rt') as merge_file:
                                        for line in merge_file:
                                                fields = line.split('|')
                                                if fields[0] == fop_type and fields[1] == last_survivor and fields[2] not in sub_list:
                                                        sub_list.append(fields[2])

        # print(f"After depth count={depth_count}, curr_graph_list:")
        return curr_graph_list



def get_updated_graph_list(edf, orig_graph_list):
        last_survivor_list = []
        ent_not_in_db_list = []
        depth = 6
        graph_list = list(filter(None, orig_graph_list))

        for depth_level in range(1, depth):
                        print(f"At depth_level={depth_level}")
                        if ent_not_in_db_list == [] :
                                        for sub_list in graph_list:
                                                        if len(sub_list) > 1:
                                                                last_survivor_list.append(sub_list[-depth_level])

                                        #print(f"last_survivor_list= {last_survivor_list}")

                                        ent_not_in_db_ndarray = np.setdiff1d(last_survivor_list,edf.values.tolist())
                                        ent_not_in_db_list = [ i for i in ent_not_in_db_ndarray ]
                                        print(f"At depth_level={depth_level} ent_not_in_db_list: {ent_not_in_db_list}")
                                        if ent_not_in_db_list == []:
                                                        break
                        else:
                                        next_surv_not_found = False
                                        print("Repeating search with next available survivor...")
                                        for sub_list in graph_list:
                                                        for entity in ent_not_in_db_list:
                                                                        # print(f"Looking for next survivor for {entity}...")
                                                                        if len(sub_list) > 1 and entity in sub_list and (len(sub_list)-depth_level)>0:
                                                                                        print(f"len(sub_list)={len(sub_list)}, sub_list={sub_list}, depth_level={depth_level}")
                                                                                        print(f"Replacing {entity} with next survivor {sub_list[len(sub_list)-depth_level]}")
                                                                                        if entity in last_survivor_list:
                                                                                                last_survivor_list.remove(entity)
                                                                                        sub_list.remove(entity)
                                                                                        # last_survivor_list.append(sub_list[len(sub_list)-depth_level])
                                                                                        if len(sub_list) > 1:
                                                                                                        last_survivor_list.append(sub_list[-1])
                                        if next_surv_not_found:
                                                        print("Next survivor not available")
                                                        break
                                        ent_not_in_db_ndarray = np.setdiff1d(last_survivor_list,edf.values.tolist())
                                        ent_not_in_db_list = [ i for i in ent_not_in_db_ndarray ]
                                        print(f"At depth_level={depth_level} ent_not_in_db_list: {ent_not_in_db_list}")
                                        if ent_not_in_db_list == []:
                                                        break

        print()
        # print(f"last_survivor_list={last_survivor_list}")
        print()
        # print(f"graph_list={graph_list}")
        return graph_list



#--------------------------MAIN-----------------------------

print()
print("PROCESS STARTED")
print()

fop_type = sys.argv[1]   # F/O/P
DB_SWITCH = sys.argv[2]  #db switch

print(f"Using fop_type={fop_type} and DB_SWITCH={DB_SWITCH}")


curr_graph_list = []
sf_query = ''
entity_query = ''

if fop_type == "F":
        sf_query = """
        select
        e.salesvision_id
        from stg_%s_entity e
        where (e.ingested_at is null or e.entity_id = md5(e.salesforce_id) )
        and (e.ended_at is null or e.ended_at = '')
        and e.entity_type_id like '3%%'
        and e.salesvision_id is not null and e.salesvision_id != ''
        """ % (DB_SWITCH)
        entity_query = """
        select salesvision_id
        from stg_%s_entity e
        where
        e.entity_type_id like '3%%'
        and e.salesvision_id is not null
        """ % (DB_SWITCH)

elif fop_type == "O":
        sf_query = """
        select
        e.salesvision_id
        from stg_%s_entity e
        where (e.ingested_at is null or e.entity_id = md5(e.salesforce_id) )
        and (e.ended_at is null or e.ended_at = '')
        and e.entity_type_id like '2%%'
        and e.salesvision_id is not null and e.salesvision_id != ''
        """ % (DB_SWITCH)
        entity_query = """
        select salesvision_id
        from stg_%s_entity e
        where
        e.entity_type_id like '2%%'
        and e.salesvision_id is not null
        """ % (DB_SWITCH)
else:
        sf_query = """
        select
        e.salesvision_id
        from stg_%s_entity e
        where (e.ingested_at is null or e.entity_id = md5(e.salesforce_id) )
        and (e.ended_at is null or e.ended_at = '')
        and e.entity_type_id like '1%%'
        and e.salesvision_id is not null and e.salesvision_id != ''
        """ % (DB_SWITCH)
        entity_query = """
        select salesvision_id
        from stg_%s_entity e
        where
        e.entity_type_id like '1%%'
        and e.salesvision_id is not null
        """ % (DB_SWITCH)


col_list = ['salesvision_id']
sv_ids_df = query_rds(sf_query, col_list)
print(f"Count of entities which need to be merged away ={len(sv_ids_df.values.tolist())}")
sv_ids_list = [ ent[0] for ent in sv_ids_df.values.tolist() ]
# print(f"sv_ids_list={sv_ids_list}")

graph_list = create_merge_graph(sv_ids_list, merge_files_list, curr_graph_list)
graph_list = [list(i) for i in set(map(tuple, graph_list))]
print(f"After create_merge_graph: {graph_list}")



col_list = ['salesvision_id']
edf = query_rds(entity_query, col_list)

revised_graph_list = get_updated_graph_list(edf, graph_list)





print()
print("Generating merge rules...")
end_date_list = []
merge_candidates_list = []
non_merge_candidates_list = [] # Not in any merge rules
ctr = 0
print("------------------------------------")
print("H|2020-07-21 00:00:00|2020-07-21 13:10:00")

for sv_id in sv_ids_list:
        for sub_list in revised_graph_list:
                        if sv_id in sub_list:
                                if len(sub_list) == 1:
                                                end_date_list.append(sv_id)
                                else:
                                                merge_candidates_list.append(sv_id)
                                                print(f"{fop_type}|{sv_id}|{sub_list[-1]}||")
                                                ctr = ctr + 1
                                break
        if sv_id not in end_date_list and sv_id not in merge_candidates_list:
                non_merge_candidates_list.append(sv_id)


print(f"T|{ctr}")
print("------------------------------------")
print()


print("Entities to be end-dated:")
print(end_date_list)
print()

print("Entities not in any merge rules:")
print(non_merge_candidates_list)

print()
print("PROCESS COMPLETED")
print()
