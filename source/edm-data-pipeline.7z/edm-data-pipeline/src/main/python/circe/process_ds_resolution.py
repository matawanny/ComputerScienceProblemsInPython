import os

from datetime import datetime, timedelta
import time
from pyspark.sql.functions import lit, udf, col, concat_ws, md5
from pyspark.sql.types import StructType, StringType, StructField

from circe.manipulator_base import GeneralManipulator
import logging
from cm_commons import colors
from cm_commons.util.boto_functions import put_file_in_s3
import json
from pprint import pprint
from spark_functions.scripts.sql_advanced import *
import pyspark.sql.functions as f


class StewardshipResolutionManipulator(GeneralManipulator):

    def __init__(self, circe_conf_dict, table_prefix, src_db_name, target_db_name, ds_mastered_output_dir, ds_conf_output_dir):
        super(StewardshipResolutionManipulator, self).__init__(circe_conf_dict, table_prefix, src_db_name, target_db_name, ds_mastered_output_dir, ds_conf_output_dir)

        self.table_name = None

        self.output_date = datetime.today().strftime('%m-%d-%Y')
        self.conf_output_dir = ds_conf_output_dir
        self.job_id = str(int(round(time.time() * 1000)))
        self.ds_mastered_output_dir = ds_mastered_output_dir
        self.conf_output_dir = ds_conf_output_dir
        self.table_sufix = "_resolution_ds"


    def load_ds_output_from_rds(self):

        raw_resolution_df = self.load_df_from_rds(target_db=self.src_db, table=self.table_name)

        # Add the submitted at time
        if raw_resolution_df is None:
            colors.war_print("NO DEDUPE TABLE FOUND", indent=1)
        else:
            raw_resolution_df = raw_resolution_df.withColumn("submitted_at",
                                                               f.lit(datetime.now().strftime("%Y-%m-%d")))
        return raw_resolution_df


    def save_dfs(self, df):
        s3_mode="overwrite"
        print("S3 write mode = ", s3_mode)
        s3_loc_name=self.mastered_output_dir + self.raw_table_name.replace('_resolution', '') \
                                + '/' + self.output_date \
                                + '/' + f"{self.job_id}.parquet"
        df.write.mode(s3_mode).parquet(s3_loc_name)
        colors.suc_print(f"parquet for {self.raw_table_name} written to {s3_loc_name}")

    def write_conf(self, job_id):
        colors.out_print(f"Creating resolution conf for job-id:{job_id}...", indent=1)

        conf= {\
                "job-id": f"ds_resolution_{job_id}",
                "etl_name": "ds_resolution_circe", \
                "prefix": "ds_resolution", \
                "file_date": f"{self.output_date}", \
                "packages": [], \
                "source_type": "db", \
                "file_extension": "None",\
                "input_location": {\
                "emr":"None"\
                },\
                "output_location": {\
                "emr": f"{self.mastered_output_dir}"\
                },\
                "source_name": "ds_res_circe",\
                "schema_name": "MDM_schema",\
                "destinations": ["postgres", "parquet"],\
                "source_schema_name": "null_schema",\
                "target_schema_name": "MDM_schema",\
                "transformer": "None"\
                }

        conf_filename = f"ds_resolution_{self.output_date}.conf"
        put_file_in_s3(conf_filename, self.conf_output_dir, json.dumps(conf, indent=4))
        colors.suc_print(f"Finished writing {conf_filename} to {self.conf_output_dir}", indent=2)


    def process_file(self):
        colors.suc_print(f"Processing {self.table_name} table ...")
        raw_resolution_df = self.load_ds_output_from_rds()

        if raw_resolution_df:
            self.save_dfs(raw_resolution_df)
        else:
            colors.war_print(f"No resolution table found, skipping {self.table_name}", indent=1)


    def process_all_files(self):
        for table_name in ['entity', 'entity_address_xref', 'entity_email_xref', 'entity_phone_xref',\
                           'entity_team_xref',\
                           'agreement', 'agreement_entity_xref', 'sub_agreement',\
                           'aum', 'sales_owner_agreement_xref',\
                           'trade']:

            self.raw_table_name = table_name + self.table_sufix  # unprefixed

            if self.table_prefix != '':
                self.table_name = self.table_prefix + "_" + table_name + self.table_sufix
            else:
                self.table_name = table_name + self.table_sufix

            self.process_file()
        self.write_conf(self.job_id)


def start_process(circe_conf_dict, table_prefix, src_db_name, target_db_name, ds_mastered_output_dir, ds_conf_output_dir):
    try:
        colors.suc_print("Initializing StewardshipResolutionManipulator...")
        # circe_conf_loc = "s3://lazard-emr-test-data/conf/source-files/DS/process_ds_conf.json"

        # ds_conf_output_dir = s3://{bucket}/MDM/conf/DS/incoming/
        # ds_mastered_output_dir = f"s3://<bucket_name>/etl-output/DS_Resolution/{table_name}/{date}/{job-id}.parquet"
        # circe_conf_dict = {}
        processor = StewardshipResolutionManipulator(circe_conf_dict, table_prefix, src_db_name, target_db_name,\
                                                                ds_mastered_output_dir, ds_conf_output_dir)
        processor.process_all_files()
    except Exception as ex:
        logging.exception("Exception raised in StewardshipManipulator!")

