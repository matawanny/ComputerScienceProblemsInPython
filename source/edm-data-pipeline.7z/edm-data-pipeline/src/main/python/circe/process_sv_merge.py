from datetime import datetime
import logging
import time

from pyspark.sql.functions import lit, col, monotonically_increasing_id, when, lower, collect_set, size, col, split
from pyspark.sql.types import StructType, StringType, StructField

from circe.manipulator_base import GeneralManipulator, load_conf
from cm_commons.util.boto_functions import move_conf_along, get_files_from_s3_folder
from cm_commons import colors



class SVMergeManipulator(GeneralManipulator):
    def __init__(self, conf_loc, table_prefix, src_db_name, target_db_name,\
                                            sv_mastered_output_dir, sv_conf_output_dir, sv_conf_batch_size):
        super(SVMergeManipulator, self).__init__(conf_loc, table_prefix, src_db_name, target_db_name, \
                                                                sv_mastered_output_dir, sv_conf_output_dir)
        self.input_df = None
        self.joined_df = None
        self.diff_df = None
        self.sv_conf_batch_size = int(sv_conf_batch_size)
        self.parquet_append_mode = False

    def clean_input_df(self, raw_df):
        """
        raw_df: Merge file contents
        Returns in this format:
        |entity_char|salesvision_id_old|salesvision_id_new| crm_id_old| crm_id_new|
        +-----------+------------------+------------------+-----------+-----------+
        |          F|            119985|             89048|AEQA-B4A83F|       \"\"|
        """
        if len(raw_df.columns) == 1:
            self.print_w_ts("Parsing input which has header and trailer...")
            raw_df = raw_df.withColumn('entity_char', split(col('_c0'), '\|').getItem(0))\
                            .withColumn('salesvision_id_old', split(col('_c0'),'\|').getItem(1))\
                            .withColumn('salesvision_id_new', split(col('_c0'),'\|').getItem(2))\
                            .withColumn('crm_id_old', split(col('_c0'), '\|').getItem(3))\
                            .withColumn('crm_id_new', split(col('_c0'), '\|').getItem(4))\
                            .drop('_c0')\
                            .filter(~col('entity_char').isin(['H', 'T'])) #.show(20, False)
        else:
            if 'merge_type' not in raw_df.columns:
                self.print_w_ts("Parsing input which has meta-column names...")
                raw_df = raw_df.withColumnRenamed('_c0', 'entity_char')
                raw_df = raw_df.withColumnRenamed('_c1', 'salesvision_id_old')
                raw_df = raw_df.withColumnRenamed('_c2', 'salesvision_id_new')
                raw_df = raw_df.withColumnRenamed('_c3', 'crm_id_old')
                raw_df = raw_df.withColumnRenamed('_c4', 'crm_id_new')
            elif 'merge_type' in raw_df.columns:
                null_check = str(raw_df.select('sv_from_id').limit(1).collect()[0].asDict()['sv_from_id'])
                self.print_w_ts(f"null_check = {null_check}")
                if null_check == 'None':
                    self.print_w_ts("Parsing piped-delimited data all contained in first column - merge_type...")
                    raw_df = raw_df.filter(raw_df.merge_type.rlike('|')).select('merge_type')\
                        .withColumn('entity_char', split(col('merge_type'), '\|').getItem(0))\
                        .withColumn('salesvision_id_old', split(col('merge_type'), '\|').getItem(1))\
                        .withColumn('salesvision_id_new', split(col('merge_type'), '\|').getItem(2))\
                        .withColumn('crm_id_old', split(col('merge_type'), '\|').getItem(3))\
                        .withColumn('crm_id_new', split(col('merge_type'), '\|').getItem(4))\
                        .drop('merge_type') # .show(20, False)
                else:
                    self.print_w_ts("Parsing input which has pre-defined column names...")
                    raw_df = raw_df.withColumnRenamed('merge_type', 'entity_char')
                    raw_df = raw_df.withColumnRenamed('sv_from_id', 'salesvision_id_old')
                    raw_df = raw_df.withColumnRenamed('sv_to_id', 'salesvision_id_new')
                    raw_df = raw_df.withColumnRenamed('crm_from_id', 'crm_id_old')
                    raw_df = raw_df.withColumnRenamed('crm_to_id', 'crm_id_new')

        return raw_df

    def get_input_df(self, file_loc):
        raw_df = self.load_file_from_s3(file_loc)

        self.print_w_ts("Sample entries in raw merge file:")
        raw_df.show(10, False)

        raw_df = self.clean_input_df(raw_df)
        return raw_df

    # Method not used currently:
    def get_joined_records(self):
        # Note: Method not used currently
        original_recs = self.load_df_from_rds(target_db=self.src_db,
                                              table=self.table_name)["entity_id", "crm_id", "salesvision_id"]

        original_recs = original_recs.alias("o_recs")

        self.joined_df = self.input_df.join(original_recs,
                                       self.input_df.salesvision_id_old == original_recs.salesvision_id,
                                       how='left')

                                        # & self.input_df.crm_id_old == original_recs.crm_id,

        self.joined_df = self.joined_df.drop('salesvision_id').drop('crm_id')

    def save_dfs(self, diff_df, circe_sv_merge_post_df, mode='overwrite'):

        self.write_rules(diff_df, self.raw_table_name)

        circe_sv_merge_post_df = circe_sv_merge_post_df.distinct()

        table_name = f"{self.table_name}_circe_sv_merge_post"
        self.output_df_to_rds(target_db=self.target_db,
                              df=circe_sv_merge_post_df,
                              table=table_name,
                              mode=mode)
        self.print_w_ts(f"circe_sv_merge_post_df written to RDS:{self.target_db}/{table_name}")

    def create_tds_df(self, df, entity_df, yyyymmdd_str_key):
        df = df.drop('crm_id_old').drop('crm_id_new')

        current_time_str = datetime.now().strftime("%Y-%m-%d")
        conf_date_stamp = yyyymmdd_str_key[0:4] + "-" + yyyymmdd_str_key[4:6] + "-" + yyyymmdd_str_key[6:]

        #Naming cols in df to avoid colliding with some columns from entity table
        sv_merge_prefix = 'sv_merge_'

        df = df.withColumn(sv_merge_prefix + self.conf["TDS_ID"], monotonically_increasing_id())
        df = df.withColumn("submitted_at", lit(current_time_str))

        master_n_df = df.select(sv_merge_prefix + self.conf["TDS_ID"],\
                                'submitted_at',\
                                col('entity_char').alias(sv_merge_prefix + "entity_char"),\
                                col('salesvision_id_old').alias('sv_id'))\
                                .withColumn(sv_merge_prefix + self.conf["STAGING_ID"],lit('false'))
        master_y_df = df.select(sv_merge_prefix + self.conf["TDS_ID"],\
                                'submitted_at',\
                                col('entity_char').alias(sv_merge_prefix + "entity_char"),\
                                col('salesvision_id_new').alias('sv_id'))\
                                .withColumn(sv_merge_prefix + self.conf["STAGING_ID"],lit('true'))

        master_y_n_df = master_y_df.union(master_n_df)

        # print('master_y_n_df=', master_y_n_df.columns)

        # Drop tds_master column since it exists in the subsequent join:
        if self.conf["STAGING_ID"] in entity_df.columns:
            entity_df = entity_df.drop(self.conf["STAGING_ID"])

        joined_df1 = master_y_n_df.join(entity_df,\
                                       (master_y_n_df.sv_id == entity_df.salesvision_id) &\
                                       (
                                               when(master_y_n_df[sv_merge_prefix + "entity_char"] == 'P', '1')\
                                                .when(master_y_n_df[sv_merge_prefix + "entity_char"] == 'O', '2')\
                                                .otherwise('3') == entity_df['entity_type_id'].substr(1,1)\
                                       ) &\
                                       (entity_df['ended_at'].isNull() | (entity_df['ended_at'] == '')),\
                                       how='left')

        # master_y_n_df = master_y_n_df.drop(sv_merge_prefix + "entity_char")

        dead = entity_df
        alive = entity_df

        for c in alive.columns:
            alive = alive.withColumn('alive_' + c, col(c)).drop(c)

        include_prend_edf = dead.join(alive, ((dead['salesvision_id'] == alive['alive_salesvision_id']) & (
                    dead['entity_type_id'].substr(1, 1) == alive['alive_entity_type_id'].substr(1, 1)) & (
                                                  alive['alive_ended_at'].isNull())), how='left_outer').filter(
            col('ended_at').isNotNull() & col('alive_entity_id').isNull())

        drop_cols = []
        for c in include_prend_edf.columns:
            if c.startswith('alive_'):
                drop_cols.append(c)
        self.print_w_ts(f"drop_cols={drop_cols}")
        include_prend_edf = include_prend_edf.drop(*drop_cols)

        joined_df2 = master_y_n_df.join(include_prend_edf, \
                                        (master_y_n_df.sv_id == include_prend_edf.salesvision_id) & \
                                        (
                                                when(master_y_n_df[sv_merge_prefix + "entity_char"] == 'P', '1') \
                                                .when(master_y_n_df[sv_merge_prefix + "entity_char"] == 'O', '2') \
                                                .otherwise('3') == include_prend_edf['entity_type_id'].substr(1, 1) \
                                            ), \
                                        how='inner')

        joined_df = joined_df1.union(joined_df2)
        self.print_w_ts("After union joined_df:")
        joined_df.orderBy(sv_merge_prefix + self.conf["TDS_ID"], sv_merge_prefix + self.conf["STAGING_ID"]).show(10, False)

        persistence_map_df = df.join(joined_df,\
                                     (df['salesvision_id_new'] == joined_df['sv_id']) &\
                                        (
                                             when(df["entity_char"] == 'P', '1') \
                                             .when(df["entity_char"] == 'O', '2') \
                                             .otherwise('3') == joined_df['entity_type_id'].substr(1, 1) \
                                        )
                                     )

        persistence_map_df = persistence_map_df.select('salesvision_id_old', 'salesvision_id_new',\
                                                       col('persistence_id').alias('new_persistence_id'), \
                                                       col('entity_type_id').alias('p_entity_type_id'))
        joined_df = joined_df.join(persistence_map_df,\
                                   (joined_df.sv_id == persistence_map_df['salesvision_id_old']) &\
                                   (joined_df['entity_type_id'] == persistence_map_df['p_entity_type_id']),\
                                   how='left')\
                                .drop('p_entity_type_id')

        # print("NAV_DEBUG joined_df:")
        # joined_df.filter(col('sv_id').isin(['815293','507399','1464931'])).show(10, False)

        joined_df = joined_df.withColumn('ended_at',
                                                when(joined_df[sv_merge_prefix + self.conf["STAGING_ID"]] == lit('false'),
                                                                   lit(conf_date_stamp)).otherwise(col('ended_at'))
                                                )
        '''
                                    .withColumn('persistence_id',
                                                when(joined_df['sv_id'] == joined_df['salesvision_id_new'],
                                                     ## joined_df['old_persistence_id']).otherwise(col('persistence_id'))
                                                     joined_df['persistence_id']).otherwise(col('persistence_id'))
                                                )
        '''

        ##joined_df = joined_df.drop('old_persistence_id', 'salesvision_id_old', 'salesvision_id_new')
        out_df = joined_df

        # print("out_df", out_df.show(3, truncate=False))

        #Remove recs with null entity_id because of the earlier left join:
        out_df = out_df.select(entity_df.columns)\
                        .filter(out_df['entity_id'].isNotNull())\
                        .drop(sv_merge_prefix + "entity_char")

        columns_list = joined_df.schema.names
        for cid in columns_list:
            joined_df = joined_df.withColumn(cid, when(
                lower(col(cid)).isin(['none', 'edm_exempt', 'exempt', 'edm-881', 'edm-494', 'edm-1030', 'edm-1090']),
                lit(None)).otherwise(col(cid)))
        # out_df = out_df.select(columns_list)

        joined_df_cols = master_y_n_df.columns + ['entity_id']

        #joined_df = joined_df.select(joined_df_cols)\
        joined_df = joined_df.withColumnRenamed(sv_merge_prefix + self.conf["STAGING_ID"], self.conf["STAGING_ID"])\
                            .withColumnRenamed(sv_merge_prefix + self.conf["TDS_ID"], self.conf["TDS_ID"])
        joined_df = joined_df.withColumn('created_at', lit(current_time_str))
        joined_df = joined_df.withColumn('etl_source', lit('salesvision'))

        #joined_df cols = ['tds_id',  'submitted_at', 'sv_id', 'tds_master', 'entity_id', 'salesvision_id', 'ended_at']
        # print('self.joined_df=',joined_df.columns)

        joined_df = joined_df.filter(joined_df['entity_id'].isNotNull())\
                                .drop(sv_merge_prefix + "entity_char")\
                                .dropDuplicates()

        joined_df.orderBy(sv_merge_prefix + self.conf["TDS_ID"], sv_merge_prefix + self.conf["STAGING_ID"]).show(10, False)
        return joined_df, out_df

    def find_parent_change(self, df):
        gdf = df.groupBy(self.conf["TDS_ID"]).agg(collect_set('parent_id')).withColumnRenamed('collect_set(parent_id)', 'parent_id_set')
        gdf = gdf.withColumn('parent_id_length', size(gdf['parent_id_set'])).drop('parent_id_set')
        gdf = gdf.withColumnRenamed(self.conf["TDS_ID"], 'gdf_'+self.conf["TDS_ID"])
        df = df.join(gdf, df[self.conf["TDS_ID"]] == gdf['gdf_'+self.conf["TDS_ID"]], how='left' )
        df = df.withColumn('parent_change', when(df['parent_id_length']>1,\
                                            lit('y')).otherwise(lit('n')) )\
                .drop('parent_id_length').drop('gdf_'+self.conf["TDS_ID"])
        # print('df=', df.show(3,truncate=False))
        return df

    def call_upsert(self):
        self.print_w_ts("Calling upsert...")

        sql_stmt = "WITH upsert AS (update cm_agreement_entity_xref trg \
                       set \
                            agreement_entity_xref_id = src.agreement_entity_xref_id, \
                            agreement_id = src.agreement_id, \
                            entity_id = src.entity_id, \
                            relationship_type_id = src.relationship_type_id, \
                            primary_relationship = src.primary_relationship, \
                            ended_at = src.ended_at, \
                            created_at = src.created_at, \
                            updated_at = src.updated_at, \
                            etl_source = src.etl_source, \
                            enriched_at = src.enriched_at, \
                            error = src.error, \
                            nullability_error = src.nullability_error, \
                            typecast_error = src.typecast_error \
                           from cm_agreement_entity_xref_circe_push src \
                              where  trg.agreement_entity_xref_id = src.agreement_entity_xref_id \
                       RETURNING *) \
                  insert into cm_agreement_entity_xref \
                               select 'agreement_entity_xref_id', 'agreement_id', \
                               'entity_id', 'relationship_type_id', 'primary_relationship', \
                               'ended_at', 'created_at', 'updated_at', 'etl_source', \
                               'enriched_at', 'error', 'nullability_error', 'typecast_error' \
                                from cm_agreement_entity_xref_circe_push  WHERE NOT EXISTS (SELECT * FROM upsert);"

        self.invoke_db_sql_stmt(sql_stmt)

    def clean_up_merge_tables(self, conf_date=None):
        self.print_w_ts("Calling clean_up_merge_tables...")

        exceptions_table_name = f"{self.table_prefix}_merge_exceptions"
        merge_rules_table_name = f"{self.table_prefix}_merge_rules"

        sql_stmt = f"DELETE FROM {exceptions_table_name} WHERE conf_date='{conf_date}';"
        self.print_w_ts(f"Deleting older records in {exceptions_table_name} for {conf_date}...")
        self.invoke_db_sql_stmt(exceptions_table_name, sql_stmt)

        m = conf_date[5:6] if conf_date[4] == '0' else conf_date[4:6]
        d = conf_date[7:] if conf_date[6] == '0' else conf_date[6:]
        y = conf_date[0:4]
        conf_date_mdy = f"{m}-{d}-{y}"
        sql_stmt = f"DELETE FROM {merge_rules_table_name} WHERE conf_date = '{conf_date_mdy}';"
        self.print_w_ts(f"Deleting older records in {merge_rules_table_name} for {conf_date_mdy}...")
        self.invoke_db_sql_stmt(merge_rules_table_name, sql_stmt)

    def update_survivor_with_max_ts(self):
        """
        Stamp updated_at field of survivor with max TS if its updated_at is less than its non-survivor
        This way SF will not reject the survivor
        """
        self.print_w_ts("Calling update_survivor_with_max_ts...")

        entity_table_name = f"{self.table_prefix}_entity"

        sql_stmt = f"update {entity_table_name} e3 set updated_at = pu.max_updated_at from \
        (select e.persistence_id, e.entity_type_id, max(e.updated_at) max_updated_at \
        from {entity_table_name} e \
        where e.persistence_id in (select ee.persistence_id from {entity_table_name} ee where ee.ended_at is not null) \
        group by e.persistence_id, e.entity_type_id ) pu \
        where e3.persistence_id = pu.persistence_id \
        and substring(e3.entity_type_id, 1, 1) = substring(pu.entity_type_id, 1, 1) \
        and (e3.ended_at is null or trim(e3.ended_at)='') \
        and e3.updated_at < pu.max_updated_at;"

        self.print_w_ts(f"Updating {entity_table_name}...")
        self.invoke_db_sql_stmt(entity_table_name, sql_stmt)


    def process(self):
        files_processed = []
        batch_count = 0
        for yyyymmdd_int_key in sorted(self.conf_files_dict.keys()):
            if batch_count > self.sv_conf_batch_size-1:
                    colors.out_print(f"Max batch size of {batch_count} reached. Quitting...")
                    break
            self.input_df = None
            self.joined_df = None
            self.diff_df = None
            self.parquet_append_mode = False

            s3_conf_file_without_path = self.conf_files_dict[yyyymmdd_int_key]
            s3_conf_file_with_path = self.conf_path + s3_conf_file_without_path

            self.print_w_ts(f"Currently processing {s3_conf_file_with_path}...")
            self.conf = load_conf(s3_conf_file_with_path)

            self.print_w_ts(f"Moving {s3_conf_file_without_path} from incoming to active")
            new_conf_loc = move_conf_along(s3_conf_file_with_path, currentstep="incoming", nextstep="active")

            self.sv_load_file_loc = self.conf["input_location"]["emr"]
            self.print_w_ts(f"sv_load_file_loc={self.sv_load_file_loc}")

            self.input_df = self.get_input_df(self.sv_load_file_loc)

            if self.input_df == None or self.input_df.take(1) == []:
                self.print_w_ts(f"Merge file either has no data or has an issue. Skipping this conf file...")
                continue

            self.print_w_ts(f"rowcount defined in conf file={self.conf['rowcount']}")
            self.print_w_ts(f"Actual rowcount in the merge file ={self.input_df.count()}")

            # self.get_joined_records()
            # print("self.joined_df=", self.joined_df.show(self.joined_df.count(), False))
            # self.get_diff_df()

            self.raw_table_name = 'entity' # unprefixed
            self.source_system = 'salesvision'
            self.source_system_prefix = 'sv'

            if self.table_prefix != '':
                self.table_name = self.table_prefix + "_" + self.raw_table_name
            else:
                self.table_name = self.raw_table_name

            self.clean_up_merge_tables(conf_date=str(yyyymmdd_int_key))

            self.entity_df = self.load_df_from_rds(target_db=self.src_db, table=self.table_name)
            if self.entity_df == None or self.entity_df.take(1) == []:
                raise RuntimeError(f"Either {self.table_name} doesn't exist or has no data in it. Aborting job...")

            entity_df = self.entity_df.cache()

            self.input_df = self.sv_filter_input(self.input_df, entity_df, conf_date=yyyymmdd_int_key)
            self.print_w_ts(f"After filtering, rowcount in the merge file ={self.input_df.count()}")

            self.print_w_ts("Sample entries in input_df:")
            self.input_df.show(10, False)



            joined_df, out_df = self.create_tds_df(self.input_df, entity_df, str(yyyymmdd_int_key))
            # joined_df columns: parent_id not present [sv_id, tds_id, submitted_at, entity_id, created_at, tds_master, etl_source]
            # out_df columns:  tds_master not present
            '''
             [employee_id, nullability_error, ai_investor_id, persistence_id, job_desc, fishtank_id,
             lei, etl_source, salesvision_id, updated_at, do_not_contact, salesforce_id, typecast_error,
             err_msg, created_at, parent_id, ended_at, client_type_id, crd, crm_id, entity_type_id,
             error, fca_id, asic_license_number, entity_id, enriched_at, entity_name, group_id, iard,
             ai_subinvestor_id, psn]
            '''

            enriched_merge_df = joined_df.cache()
            self.update_persistence_id_for_prior_ended_dated_entities(entity_df, enriched_merge_df)

            self.print_w_ts(f"Readng {self.table_name} again...")
            self.entity_df = self.load_df_from_rds(target_db=self.src_db, table=self.table_name)
            if self.entity_df == None or self.entity_df.take(1) == []:
                raise RuntimeError(f"Either {self.table_name} doesn't exist or has no data in it. Aborting job...")

            entity_df = self.entity_df.cache()

            # Take out entities that switch parents:
            joined_df = self.find_parent_change(df=joined_df)
            # print('AFTER parent_change: joined_df=', joined_df.show(2, False))
            ## out_df = self.find_parent_change(df=out_df)

            # joined_df.filter((col('salesvision_id') == '124982') | (col('salesvision_id') == '79197')).show(2, False)

            parent_change_y_df = joined_df.filter(joined_df['parent_change'] == 'y')
            parent_change_n_df = joined_df.filter(joined_df['parent_change'] == 'n')

            # self.print_w_ts("parent_change_y_df:")
            # parent_change_y_df.filter((col('salesvision_id') == '124982') | (col('salesvision_id') == '79197')).show(10, False)

            # self.print_w_ts("parent_change_n_df:")
            # parent_change_n_df.filter((col('salesvision_id') == '124982') | (col('salesvision_id') == '79197')).show(10, False)

            self.print_w_ts(f"Processing parent_change_n_df...")
            self.diff_df = self.get_diff_df(parent_change_n_df.drop('parent_change'), 'entity')

            # self.print_w_ts("diff_df in parent_change=N:")
            # self.diff_df.filter(col('invalid_value')=='072243ab0a791550c5350e3f4ad83df9').show(200, False)

            self.get_cascade(str(yyyymmdd_int_key))
            # self.get_cascade_old(self.diff_df)

            circe_post_df1 = parent_change_n_df.drop('parent_change', 'tds_id', 'tds_master', 'submitted_at')
            circe_post_df1 = circe_post_df1.withColumn('persistence_id',
                                                    when(circe_post_df1['sv_id'] == circe_post_df1['salesvision_id_old'],
                                                         circe_post_df1['new_persistence_id']).otherwise(col('persistence_id'))
                                                    )
            # circe_post_df1.filter((col('salesvision_id') == '124982') | (col('salesvision_id') == '79197')).show(10, False)
            # print("circe_post_df1:")
            # circe_post_df1.show(10,False)

            circe_post_df1 = circe_post_df1.drop('sv_id', 'new_persistence_id', 'salesvision_id_old', 'salesvision_id_new')

            self.print_w_ts("Writing circe_post_df1(parent_change=N) and its diff_df to RDS...")
            self.save_dfs(self.diff_df, circe_post_df1)

            # print("B4 diff2: joined_df=", joined_df.show(joined_df.count(),False))
            self.print_w_ts(f"Processing parent_change_y_df...")
            self.diff_df = self.get_diff_df(parent_change_y_df.drop('parent_change'), 'entity')

            # self.print_w_ts("diff_df in parent_change=Y:")
            # self.diff_df.filter(col('invalid_value')=='072243ab0a791550c5350e3f4ad83df9').show(200, False)

            self.get_cascade(str(yyyymmdd_int_key))  # Turn it off for now, might need it later

            circe_post_df2 = parent_change_y_df.drop('parent_change', 'tds_id', 'tds_master', 'submitted_at')
            circe_post_df2 = circe_post_df2.withColumn('persistence_id',
                                                    when(circe_post_df2['sv_id'] == circe_post_df2['salesvision_id_old'],
                                                         circe_post_df2['new_persistence_id']).otherwise(col('persistence_id'))
                                                    )
            # circe_post_df2.filter((col('salesvision_id') == '124982') | (col('salesvision_id') == '79197')).show(10, False)
            # print("circe_post_df2:")
            # circe_post_df2.show(10,False)

            circe_post_df2 = circe_post_df2.drop('sv_id', 'new_persistence_id',
                                                 'salesvision_id_old', 'salesvision_id_new')

            self.print_w_ts("Writing circe_post_df2(parent_change=Y) and its diff_df to RDS...")
            self.save_dfs(self.diff_df, circe_post_df2, mode='append')

            self.print_w_ts("Starting upsert..")
            df_full = self.load_df_from_rds(target_db=self.src_db, table=self.table_name)
            df_delta = self.load_df_from_rds(target_db=self.src_db,
                                             table=f"{self.table_name}_circe_sv_merge_post")
            upsert_cols = ['persistence_id', 'ended_at']
            self.load_cascade_upsert_new(df_full, df_delta.distinct(), "entity_id", upsert_cols, self.table_name)

            self.update_null_salesforce_ids(self.input_df)
            self.write_merge_exceptions(self.input_df, entity_df, yyyymmdd_int_key)
            self.update_survivor_with_max_ts()
            self.write_to_audit_log(conf_date = str(yyyymmdd_int_key))

            self.print_w_ts(f"Moving {new_conf_loc} from active to done")
            move_conf_along(new_conf_loc, currentstep="active", nextstep="done")
            files_processed.append(s3_conf_file_without_path)
            batch_count = batch_count + 1
            self.print_w_ts(f"Processed following files:{files_processed}")

        colors.out_print(f"Stopping spark session...")
        self.spark.stop()

        colors.out_print(f"Sleeping for 6 mins for GC in EMR to finish...")
        time.sleep(360)
        self.print_w_ts("SV MERGE PRCOESS FINISHED!")


def start_process(conf_location, table_prefix, src_db_name, target_db_name, \
                                            sv_mastered_output_dir, sv_conf_output_dir, sv_conf_batch_size):
    colors.suc_print(f"Initializing SVMergeManipulator...")
    try:
            processor = SVMergeManipulator(conf_location, table_prefix, src_db_name, target_db_name,\
                                                sv_mastered_output_dir, sv_conf_output_dir, sv_conf_batch_size)
            processor.process()
    except Exception as ex:
        logging.exception("Exception raised in SVMergeManipulator!")

