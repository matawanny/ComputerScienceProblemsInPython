# import conf
# import models
# import colors
# import util.system

# package list for commons module
PACKAGES = [
    "sqlalchemy",
    "psycopg2",
    "pytest",
    "cx_oracle",
    "oracle-instantclient",
    "sqlalchemy_sqlany"
]
