import pytest
import sys
import unittest
import logging
from test.postgregsql_pool import *

env = 'test'
logger = logging.getLogger()
logger.level = logging.INFO
stream_handler = logging.StreamHandler(sys.stdout)
logger.addHandler(stream_handler)


class TestPostgreSQLPool(unittest.TestCase):
    def setUp(self):
        DatabasePool.initialize_by_data_source(env=f"{env}", data_source="RDS", init_size="1", max_size="5")

    @pytest.mark.aws
    def test_insert_into_db(self):
        with CursorFromConnectionPool() as cursor:
            cursor.execute("insert into edm_export_params (mdm_stage, send_to_sv_date, send_to_sf_date) "
                           "values ('stg_nav_edm2681_sf_upd_del', '2020-01-02 00:00:00', null)")

    @pytest.mark.aws
    def test_load_from_db(self):
        with CursorFromConnectionPool() as cursor:
            cursor.execute("select * from edm_export_params")
            rows = cursor.fetchall()
            self.assertIsNotNone(rows)
            for row in rows:
                print(row)


if __name__ == '__main__':
    unittest.main()
