import os

def gzipFile(filename):
    f, file_extension = os.path.splitext(filename)
    if file_extension != ".gz":
        os.system("gzip -f '" + filename + "'")
        filename = filename + ".gz"
    return filename