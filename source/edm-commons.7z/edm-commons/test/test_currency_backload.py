import pytest
import sys
import unittest
import csv
from datetime import datetime
from common.security import *
from common.database import  db_connection_factory
from common.utils import datetime_range
from test.business_model import FXRateElement
from test.utilities import *
from common.aws import S3

env = 'test'
logger = logging.getLogger()
logger.level = logging.INFO
stream_handler = logging.StreamHandler(sys.stdout)
logger.addHandler(stream_handler)


class TestCurrencyBackload(unittest.TestCase):
    def setUp(self):
        self.source = 'FXRATE'
        self.bucketname = ENVS[env]['aws']['s3_bucket']
        if self.bucketname.startswith('s3://'):
            self.bucketname = self.bucketname[5:]
        self.keyid = ENVS[env]['keyid']

    def test_currency_table_backload(self):
        TARGET_CURRENCIES = ['AUD', 'CAD', 'CHF', 'DKK', 'EUR', 'GBP', 'HKD', 'JPY', 'KRW', 'NOK', 'NZD', 'SGD', 'SEK',
                             'AED', 'USD']
        # define dates
        start_date = datetime(2020, 1, 1)
        end_date = datetime.today()
        # create string version of date range
        dates = list(datetime_range(start=start_date, end=end_date))
        dates = [d.strftime('%m/%d/%Y') for d in dates]
        date_range = ', '.join(f"'{k}'" for k in dates)
        currs = ', '.join(f"'{k}'" for k in TARGET_CURRENCIES)

        todaysdate = datetime.today().strftime('%Y-%m-%d')
        csv_file = "fx_rate_conversion_" + todaysdate + ".csv"
        connection = db_connection_factory(env, self.source)
        with connection as cursor, open(f'{csv_file}', 'w', newline='') as f:
            result = FXRateElement.table_load_from_db(cursor, date_range, currs)
            writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            # Add the header/column names
            header = ['fx_rate_id','current_symbol', 'current_rate', 'target_symbol', 'target_rate',
                      'fx_rate', 'rate_date', 'end_date']
            writer.writerow(header)
            for row in result:
                # print(fx_rate)
                writer.writerow(row)
        # localGzipFile = gzipFile(csv_file)

    @pytest.mark.aws
    def test_s3_send_get(self):
        todaysdate = datetime.today().strftime('%Y-%m-%d')
        current_dir = os.getcwd()
        cvsFileName = current_dir + f"/fx_rate_conversion_{todaysdate}.csv"
        gzipFileWithPath = gzipFile(cvsFileName)

        s3BucketName = self.bucketname
        destpath = f"/ETL/data/ReferenceData/FXRate/fx_rate_conversion_{todaysdate}.csv.gz"
        try:
            with S3('test') as s3:
                logger.info("Uploading " + gzipFileWithPath + " to " + s3BucketName + destpath)
                s3.send_file(gzipFileWithPath, self.bucketname, destpath)
        except Exception as e:
            logger.error(str(e))


if __name__ == '__main__':
    unittest.main()
