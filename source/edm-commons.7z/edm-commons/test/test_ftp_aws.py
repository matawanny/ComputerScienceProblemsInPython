import sys
import unittest
import pytest
from common.aws import S3
from common.ftp import *
from common.security import *
from test.utilities import *

env = 'test'
logger = logging.getLogger()
logger.level = logging.INFO
stream_handler = logging.StreamHandler(sys.stdout)
logger.addHandler(stream_handler)


class TestFtoAndAws(unittest.TestCase):
    def setUp(self):
        env = 'test'
        self.bucketname = ENVS[env]['aws']['s3_bucket']
        if self.bucketname.startswith('s3://'):
            self.bucketname = self.bucketname[5:]
        self.source = "sftp-uploader"
        self.sftp_server = ENVS[env]['cm-sftp']['server']
        self.sftp_user = ENVS[env]['cm-sftp']['secret']


    @pytest.mark.aws
    def test_au_platform_files_sftp(self):
        files = "/registreetFTP/incoming/au_platform_until_2019-12-31.csv".split(",")
        destcomponent = "ETL"
        destpath = "data/au_platform/"

        try:
            with SFTP(self.sftp_server, self.sftp_user, "") as sftp, S3('test') as s3:
                for fn in files:
                    filepath, fn = os.path.split(fn)
                    logger.info("Retrieving " + fn + " from SFTP dir")
                    sftp.get_file(filepath, fn, self.source)

                    localPathOfFileIncludingFilename ='sftp-uploader/' + fn
                    s3pathOfFileIncludingFilename ='/ETL/data/sftp-uploader/'+fn
                    localGzipFile = gzipFile(localPathOfFileIncludingFilename)

                    logger.info("Uploading " + localGzipFile + " to s3://" + s3pathOfFileIncludingFilename )
                    s3.send_file(localGzipFile, self.bucketname, s3pathOfFileIncludingFilename)
        except Exception as e:
            logger.error(str(e))


if __name__ == '__main__':
    unittest.main()
