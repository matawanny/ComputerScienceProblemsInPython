from psycopg2 import pool
from common.envconfig import ENVS
from common.security import get_secret, assume_role


class DatabasePool:
    __connection_pool = None

    @staticmethod
    def initialize(**kwargs):
        DatabasePool.__connection_pool = pool.SimpleConnectionPool(1, 10, **kwargs)

    @staticmethod
    def initialize_by_data_source(env, data_source, init_size, max_size):
        assumerole = ENVS[env]['assumerole']
        assume_role(assumerole)
        secret = ENVS[env][data_source]["secret"]
        cm_cxn = get_secret(secret, env)
        user = cm_cxn['username']
        database = cm_cxn['dbname']
        server = cm_cxn['host']
        password = cm_cxn['password']
        port = cm_cxn['port']
        DatabasePool.__connection_pool = pool.SimpleConnectionPool(init_size, max_size, user=f"{user}", password=f"{password}",
                                                                   host=f"{server}", port=f"{port}", database=f"{database}")

    @staticmethod
    def get_connection():
        return DatabasePool.__connection_pool.getconn()

    @staticmethod
    def return_connection(connection):
        DatabasePool.__connection_pool.putconn(connection)

    @staticmethod
    def close_all_connections():
        DatabasePool.__connection_pool.closeall()


class CursorFromConnectionPool:
    def __init__(self):
        self.conn = None
        self.cursor = None

    def __enter__(self):
        self.conn = DatabasePool.get_connection()
        self.cursor = self.conn.cursor()
        return self.cursor

    def __exit__(self, exception_type, exception_value, exception_traceback):
        if exception_value:  # This is equivalent to `if exception_value is not None`
            self.conn.rollback()
        else:
            self.cursor.close()
            self.conn.commit()
        DatabasePool.return_connection(self.conn)
