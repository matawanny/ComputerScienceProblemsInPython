import csv
import pytest
import sys
import traceback
import unittest
import logging
import os
from datetime import datetime
from common.database import db_connection_factory
from common.envconfig import ENVS
from common.security import *

from test.utilities import gzipFile

env = 'test'
logger = logging.getLogger()
logger.level = logging.INFO
stream_handler = logging.StreamHandler(sys.stdout)
logger.addHandler(stream_handler)


class TestDatabaseAndAws(unittest.TestCase):
    def setUp(self):
        self.source = 'AMG'
        self.assumerole = ENVS[env]['assumerole']
        self.bucketname = ENVS[env]['aws']['s3_bucket']
        if self.bucketname.startswith('s3://'):
            self.bucketname = self.bucketname[5:]
        self.keyid = ENVS[env]['keyid']

    @pytest.mark.aws
    def test_amg_file_manager(self):
        ##############################################
        # HEADER WHICH GETS PREPENDED TO THE FILE    #
        ##############################################
        header = """MUTUAL_FUND_INDICATOR_CODE,portfolio_no,portfolio_no_char,ACCOUNT_LEGAL_NAME1,ACCOUNT_LEGAL_NAME2,ACCOUNT_LEGAL_NAME3,ACCOUNT_SHORT_NAME,PMF_T07_ID,CLIENT_BUSINESS_CODE,SERVICING_TYPE,CRM_RELATIONSHIP_ID,ACCOUNT_ADDR_LINE1,ACCOUNT_ADDR_LINE2,ACCOUNT_CITY,ACCOUNT_STATE_CODE,ACCOUNT_COUNTRY_CODE,ACCOUNT_ZIP_CODE,entity_code,DUMMY_YN,SEED_ACCOUNT_YN,ACCOUNT_LOST_DATE,CURRENCY,INCEPTION_DATE,lazard_id
        """
        ##################################################################################
        # IMPORTANT: IF QUERY FIELD CHANGES, BE SURE TO CHANGE THE HEADER VARIABLE ABOVE #
        ##################################################################################
        sql = """select
            distinct
            AM_PORTFOLIO2.MUTUAL_FUND_INDICATOR_CODE,
            AM_PORTFOLIO.portfolio_no,
            AM_PORTFOLIO.portfolio_no_char,
            AM_PORTFOLIO.ACCOUNT_LEGAL_NAME1,
            AM_PORTFOLIO.ACCOUNT_LEGAL_NAME2,
            AM_PORTFOLIO.ACCOUNT_LEGAL_NAME3,
            AM_PORTFOLIO.ACCOUNT_SHORT_NAME,
            PORTIA_PMF_T07_PRODUCT.PMF_T07_ID,
            AM_PORTFOLIO2.CLIENT_BUSINESS_CODE,
            AM_PORTFOLIO2.SERVICING_TYPE,
            AM_PORTFOLIO2.CRM_RELATIONSHIP_ID,
            AM_PORTFOLIO2.ACCOUNT_ADDR_LINE1,
            AM_PORTFOLIO2.ACCOUNT_ADDR_LINE2,
            AM_PORTFOLIO2.ACCOUNT_CITY,
            AM_PORTFOLIO2.ACCOUNT_STATE_CODE,
            AM_PORTFOLIO2.ACCOUNT_COUNTRY_CODE,
            AM_PORTFOLIO2.ACCOUNT_ZIP_CODE,
            AM_PORTFOLIO2.entity_code,
            case AM_PORTFOLIO.portfolio_no when 13292 then 'N' when 17727 then 'N' else AM_PORTFOLIO2.DUMMY_YN end as DUMMY_YN,  -- Hardcodes dummy_yn='N' for portfolios 13292 and 17727
            AM_PORTFOLIO2.SEED_ACCOUNT_YN,
            AM_PORTFOLIO2.ACCOUNT_LOST_DATE,
            PORTIA_PMF_NEW.CURRENCY,
            PORTIA_PMF_NEW.INCEPTION_DATE,
            employee_master.lazard_id
        FROM AM_PORTFOLIO
        LEFT JOIN (SELECT CONTACT_TYPE_CODE, ACCOUNT_NO, CONTACT_NO FROM AM_ACCOUNT_CONTACT_XREF WHERE CONTACT_TYPE_CODE IN ('BROKER','CLICON','CONSUL','CUADMN','CUASST','CUCORP','CUSCON','CUSDOM','CUSFX1','CUSFX2','CUSGLB','CUSMST','CUSSEN','CUSSUB','CUSTLE','CUSTOD','CUSTRD','CUSTTE','MAILCL','PRICLI')) cct_x ON AM_PORTFOLIO.account_no = cct_x.ACCOUNT_NO
        LEFT JOIN AM_CONTACT ON cct_x.CONTACT_NO = AM_CONTACT.CONTACT_NO
        LEFT JOIN AM_ADDRESSES on AM_ADDRESSES.ADDRESS_CODE = AM_CONTACT.ADDRESS_CODE
        LEFT JOIN AM_PORTFOLIO2  ON AM_PORTFOLIO.account_no = AM_PORTFOLIO2.ACCOUNT_NO
        LEFT JOIN portia_pmf_new  on (AM_PORTFOLIO.portfolio_no_char = portia_pmf_new.symbol)
        LEFT JOIN portia_pmf_t07_product on (portia_pmf_t07_product.pmf_t07_udt_table_name = portia_pmf_new.product)
        left join am_internal_contact on (am_internal_contact.account_no=am_portfolio.account_no and am_internal_contact.internal_contact_type='CLNT_SVC_REP' )
        left join employee_master on (am_internal_contact.employee_id=employee_master.employee_id)
        WHERE (AM_PORTFOLIO2.ACCOUNT_LOST_DATE > to_date('2018-12-31', 'YYYY-MM-DD') or AM_PORTFOLIO2.ACCOUNT_LOST_DATE is null) 
            and (AM_PORTFOLIO2.MUTUAL_FUND_INDICATOR_CODE != 'MF-ONLY' or AM_PORTFOLIO2.MUTUAL_FUND_INDICATOR_CODE is null) --exclude the portfolios which only hold funds (for now... this should be included before AUM reporting can be complete)
            and (AM_PORTFOLIO2.entity_code != 'FUNDS'   or (AM_PORTFOLIO2.ENTITY_CODE='FUNDS' and AM_PORTFOLIO2.vehicle_code='SUB-ADVISED')) --exclude the portfolios which are LAM funds
            and (AM_PORTFOLIO2.CLIENT_BUSINESS_CODE != 'EMPLOY' or AM_PORTFOLIO2.CLIENT_BUSINESS_CODE is null)
        """
        todaysdate = datetime.today().strftime('%Y-%m-%d')
        fn = "amg_data_" + todaysdate + ".csv"

        if not os.path.isdir("./amg"):
            logger.info("Making local amg path")
            os.mkdir("./amg")
        file_name_with_folder = "amg/amg_data_" + todaysdate + ".csv"
        connection = db_connection_factory(env, "AMG")
        with connection as cursor, open(file_name_with_folder, 'w') as outputfile:
            logger.info(sql)
            cursor.execute(sql)
            logger.info("Executed Query to DB")
            outputfile.write(header)
            output = csv.writer(outputfile, lineterminator='\n')
            onerow = cursor.fetchone()
            self.assertIsNotNone(onerow)
            for row in cursor:
                output.writerow(row)

if __name__ == '__main__':
    unittest.main()
