import logging
import sys
import unittest
import pytest
from common.security import get_secret

logger = logging.getLogger()
logger.level = logging.INFO
stream_handler = logging.StreamHandler(sys.stdout)
logger.addHandler(stream_handler)


class TestSecurity(unittest.TestCase):

    @pytest.mark.aws
    def test_get_secret(self):
        ret_val = get_secret("edmcm_salesvision", 'test')
        logger.info("secret = {}".format(ret_val))
        print("secret = {}".format(ret_val))
        self.assertEqual(ret_val['pwd'], 'zard10l$')

if __name__ == '__main__':
    unittest.main()
