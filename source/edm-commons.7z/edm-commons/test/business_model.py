class FXRateElement:
    TARGET_CURRENCY_QUERY = """
select  cur_b.currency_symbol currency_symbol_b, 
        hfx_b.xrate xrate_b,
        cur_f.currency_symbol currency_symbol_f, 
        hfx_f.xrate xrate_f,
        hfx_f.xrate/hfx_b.xrate xrate_b_f,
        convert(char(20), hfx_b.rate_date, 20),
        convert(char(20), hfx_b.end_date, 20)
from    apoprod.cur cur_b,
        apoprod.hfx hfx_b, 
        apoprod.cur cur_f, 
        apoprod.hfx hfx_f  
where   hfx_b.rate_date in ({0}) 
and     hfx_b.end_Date >= hfx_b.rate_date
and     hfx_f.rate_date = hfx_b.rate_date
and     hfx_f.end_date >= hfx_f.rate_date
and     hfx_b.rate_type = 1 and hfx_b.source = 1
and     hfx_f.rate_type = 1 and hfx_f.source = 1
and     hfx_b.xrate > 0 and hfx_f.xrate > 0
and     cur_b.currency_symbol in ('AUD', 'CAD', 'CHF', 'DKK', 'EUR', 'GBP', 'HKD', 'JPY', 'KRW', 'NOK', 'NZD', 'SGD', 'SEK', 'AED')
and     cur_f.currency_symbol in ('AUD', 'CAD', 'CHF', 'DKK', 'EUR', 'GBP', 'HKD', 'JPY', 'KRW', 'NOK', 'NZD', 'SGD', 'SEK', 'AED')
and     hfx_b.currency = cur_b.id
and     hfx_f.currency = cur_f.id
--order by hfx_b.rate_date, cur_b.currency_symbol, cur_f.currency_symbol  
UNION  
select  'USD' currency_symbol_b, 
        1 xrate_b,
        cur_f.currency_symbol currency_symbol_f, 
        hfx_f.xrate xrate_f,
        hfx_f.xrate xrate_b_f,
        convert(char(20), hfx_f.rate_date, 20),
        convert(char(20), hfx_f.end_date, 20)
from    apoprod.cur cur_f, 
        apoprod.hfx hfx_f  
where   hfx_f.rate_date in ({0}) 
and     hfx_f.end_Date >= hfx_f.rate_date
and     hfx_f.rate_type = 1 and hfx_f.source = 1
and     hfx_f.xrate > 0
and     cur_f.currency_symbol in ({1})
and     hfx_f.currency = cur_f.id
--order by hfx_f.rate_date, cur_f.currency_symbol, cur_f.currency_symbol  
UNION  
select  cur_b.currency_symbol currency_symbol_b, 
        hfx_b.xrate xrate_b,
        'USD' currency_symbol_f, 
        1 xrate_f,
        1 / hfx_b.xrate xrate_b_f,
        convert(char(20), hfx_b.rate_date, 20),
        convert(char(20), hfx_b.end_date, 20)
from    apoprod.cur cur_b, 
        apoprod.hfx hfx_b  
where   hfx_b.rate_date in ({0}) 
and     hfx_b.end_Date >= hfx_b.rate_date
and     hfx_b.rate_type = 1 and hfx_b.source = 1
and     hfx_b.xrate > 0
and     cur_b.currency_symbol in ({1})
and     hfx_b.currency = cur_b.id
--order by hfx_b.rate_date, cur_b.currency_symbol, cur_b.currency_symbol  
UNION  
-- Add a rows for USD to USD for completeness.
select  'USD' currency_symbol_b, 
        1 xrate_b,
        'USD' currency_symbol_f, 
        1 xrate_f,
        1 xrate_b_f,
        convert(char(20), hfx_b.rate_date, 20),
        convert(char(20), hfx_b.end_date, 20)
from    apoprod.cur cur_b, 
        apoprod.hfx hfx_b  
where   hfx_b.rate_date in ({0}) 
and     hfx_b.end_Date >= hfx_b.rate_date
and     hfx_b.rate_type = 1 and hfx_b.source = 1
and     hfx_b.xrate > 0
and     cur_b.currency_symbol in ('EUR')
and     hfx_b.currency = cur_b.id
    """

    def __init__(self, current_symbol, current_rate, target_symbol, target_rate,
                 fx_rate, rate_date, end_date, fx_rate_id=None, created_at=None, updated_at=None):
        self.current_symbol = current_symbol
        self.current_rate = current_rate
        self.target_symbol = target_symbol
        self.target_rate = target_rate
        self.fx_rate = fx_rate
        self.rate_date = rate_date
        self.end_date = end_date
        self.fx_rate_id = fx_rate_id
        self.created_at = created_at
        self.updated_at = updated_at

    def __repr__(self):
        return iter([self.fx_rate_id, self.current_symbol, self.current_rate, self.target_symbol, self.target_rate,
                     self.fx_rate, self.rate_date, self.end_date])

    @classmethod
    def object_load_from_db(cls, cursor, date_range, target_currencies):
        target_query = cls.TARGET_CURRENCY_QUERY.format(date_range, target_currencies)
        fxrates = []
        cursor.execute(target_query)
        results = cursor.fetchall()
        for i, res in enumerate(results):
            fxrate = FXRateElement(
                fx_rate_id=i,
                current_symbol=res[0],
                current_rate=res[1],
                target_symbol=res[2],
                target_rate=res[3],
                fx_rate=res[4],
                rate_date=res[5].strip(),
                end_date=res[6].strip()
            )
            fxrates.append(fxrate.__repr__())
        return fxrates

    @classmethod
    def table_load_from_db(cls, cursor, date_range, target_currencies):
        target_query = cls.TARGET_CURRENCY_QUERY.format(date_range, target_currencies)
        rates = []
        cursor.execute(target_query)
        results = cursor.fetchall()
        return results
