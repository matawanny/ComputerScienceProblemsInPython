import sys
import unittest
import pytest
from common.aws import S3
from common.security import *

env = 'test'
logger = logging.getLogger()
logger.level = logging.DEBUG
stream_handler = logging.StreamHandler(sys.stdout)
logger.addHandler(stream_handler)


class TestAws(unittest.TestCase):
    def setUp(self):
        self.source = "sftp-uploader"
        self.bucketname = ENVS[env]['aws']['s3_bucket']



    @pytest.mark.aws
    def test_s3_send_get(self):
        current_dir = os.getcwd()
        localPathOfFileIncludingFilename = current_dir +"/bak/TEST_salesvision_firm_profile_07_21_2020.gz"
        localIncomingFile = current_dir + "/incoming/TEST_salesvision_firm_profile_07_21_2020.gz"
        s3BucketName = self.bucketname
        destpath = "/ETL/data/salesvision/TEST_salesvision_firm_profile_07_21_2020.gz"
        try:
            with S3('test') as s3:
                logger.info("Uploading " + localPathOfFileIncludingFilename + " to " + s3BucketName + destpath)
                s3.send_file(localPathOfFileIncludingFilename, self.bucketname,  destpath)
                logger.info("Downloading " + localIncomingFile + " from " + s3BucketName + destpath)
                s3.get_file(localIncomingFile, self.bucketname, destpath)
        except Exception as e:
            logger.error(str(e))


if __name__ == '__main__':
    unittest.main()
