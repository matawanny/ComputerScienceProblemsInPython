import os
import sys
import logging
import unittest
import pytest
from datetime import datetime
from common.envconfig import ENVS
from common.ftp import SFTP
from common.security import get_secret,assume_role


env = 'test'
logger = logging.getLogger()
logger.level = logging.INFO
stream_handler = logging.StreamHandler(sys.stdout)
logger.addHandler(stream_handler)


class TestFtoAndAws(unittest.TestCase):
    def setUp(self):
        self.assumerole = ENVS[env]['assumerole']
        self.sftp_server = ENVS[env]['SalesVision']['server']
        self.sftp_user = ENVS[env]['SalesVision']['user']
        self.sftp_secret = ENVS[env]['SalesVision']['secret']
        self.sftp_port = int(ENVS[env]['SalesVision']['port'])
        self.sftp_root_dir = '/' + ENVS[env]['SalesVision']['root-dir']
        assume_role(self.assumerole)
        self.sftp_password = get_secret(self.sftp_secret, env)
        print(self.sftp_password)
        print(self.sftp_password['pwd'])


    @pytest.mark.aws
    def test_salesvision_list_files(self):
        substring = datetime.today().strftime('profile_%m_%d_%Y')
        with SFTP(self.sftp_server, self.sftp_user, self.sftp_password['pwd'], self.sftp_port) as sftp:
            file_list = sftp.list_files(self.sftp_root_dir)
            for file_name in file_list:
                if file_name.find(substring) !=-1:
                    print(f"{file_name}")


if __name__ == '__main__':
    unittest.main()
