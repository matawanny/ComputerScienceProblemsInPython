import os
import sys
import logging
import unittest
import pytest
from common.envconfig import ENVS
from common.ftp import SFTP
from common.security import get_secret,assume_role

env = 'test'
logger = logging.getLogger()
logger.level = logging.INFO
stream_handler = logging.StreamHandler(sys.stdout)
logger.addHandler(stream_handler)


class TestFtoAndAws(unittest.TestCase):
    def setUp(self):
        self.assumerole = ENVS[env]['assumerole']
        self.sftp_server = ENVS[env]['SalesVision']['server']
        self.sftp_user = ENVS[env]['SalesVision']['user']
        self.sftp_secret = ENVS[env]['SalesVision']['secret']
        self.sftp_port = int(ENVS[env]['SalesVision']['port'])
        self.sftp_root_dir = '/' + ENVS[env]['SalesVision']['root-dir']
        assume_role(self.assumerole)
        self.sftp_password = get_secret(self.sftp_secret, env)
        print(self.sftp_password)
        print(self.sftp_password['pwd'])


    @pytest.mark.aws
    def test_salesvision_export_files_sftp(self):
        gz_file_path = '/home/edmfilemgr/data/sent/SalesVision/crm_firm_profile_06-09-2020.csv.gz'
        with SFTP(self.sftp_server, self.sftp_user, self.sftp_password['pwd'], self.sftp_port) as sftp:
            filepath, fn = os.path.split(gz_file_path)
            print(f'sourcePath={gz_file_path}, destFileName={fn}, destDir={self.sftp_root_dir}')
            sftp.put_file(gz_file_path, fn, self.sftp_root_dir)

if __name__ == '__main__':
    unittest.main()
