import csv
import pytest
import sys
import traceback
import unittest
import logging
import os
from datetime import datetime
from common.database import Oracle
from common.envconfig import ENVS
from common.security import *
from common.database import *
from test.utilities import gzipFile

env = 'test'
logger = logging.getLogger()
logger.level = logging.INFO
stream_handler = logging.StreamHandler(sys.stdout)
logger.addHandler(stream_handler)


class TestDatabaseAndAws(unittest.TestCase):
    def setUp(self):
        self.source = 'AMG'
        self.assumerole = ENVS[env]['assumerole']
        self.bucketname = ENVS[env]['aws']['s3_bucket']
        if self.bucketname.startswith('s3://'):
            self.bucketname = self.bucketname[5:]
        self.keyid = ENVS[env]['keyid']

    @pytest.mark.aws
    def test_oracle_count(self):
        sql = f"select count(*) from amv_mktg_share_class_detailed"
        connection = db_connection_factory(env, "AMG")
        with connection as cursor:
            logger.info(sql)
            cursor.execute(sql)
            row = cursor.fetchone()
            self.assertIsNotNone(row)
            print(f'count = {row[0]}')

if __name__ == '__main__':
    unittest.main()
