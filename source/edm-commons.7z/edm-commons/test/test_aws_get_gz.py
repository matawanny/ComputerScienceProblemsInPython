import sys
import unittest
import pytest
from common.aws import S3
from common.security import *

env = 'test'
logger = logging.getLogger()
logger.level = logging.DEBUG
stream_handler = logging.StreamHandler(sys.stdout)
logger.addHandler(stream_handler)


class TestAws(unittest.TestCase):
    def setUp(self):
        self.source = "sftp-uploader"
        self.bucketname = ENVS[env]['aws']['s3_bucket']



    @pytest.mark.aws
    def test_s3_get(self):
        current_dir = os.getcwd()
        localIncomingFile = current_dir + "/TEST_salesvision_person_profile_11_24_2020.gz"
        s3BucketName = self.bucketname
        destpath = "/ETL/data/salesvision/TEST_salesvision_person_profile_11_24_2020.gz"
        try:
            with S3('test') as s3:
                logger.info("Downloading " + localIncomingFile + " from " + s3BucketName + destpath)
                s3.get_file(localIncomingFile, self.bucketname, destpath)
        except Exception as e:
            logger.error(str(e))


if __name__ == '__main__':
    unittest.main()
