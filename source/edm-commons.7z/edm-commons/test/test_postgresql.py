import pytest
import sys
import traceback
import unittest
import logging
from datetime import datetime
from common.envconfig import ENVS
from common.database import *
from common.security import get_secret, assume_role

env = 'test'
logger = logging.getLogger()
logger.level = logging.INFO
stream_handler = logging.StreamHandler(sys.stdout)
logger.addHandler(stream_handler)


class TestPostgreSQL(unittest.TestCase):
    def setUp(self):
        region_name = ENVS[env]['aws']['region']
        secret = ENVS[env]['RDS']['secret']
        cm_cxn = get_secret(secret, env)

        logger.info(f"dbname = {cm_cxn['dbname']}")
        logger.info(f"user = {cm_cxn['username']}")
        logger.info(f"password = {cm_cxn['password']}")
        logger.info(f"host = {cm_cxn['host']}")
        logger.info(f"port = {cm_cxn['port']}")

    @pytest.mark.aws
    def test_cursor_query(self):
        connection = db_connection_factory(env, "RDS")
        with connection as cursor:
            cursor.execute("select count(*) from share_class_enum")
            row = cursor.fetchone()
            self.assertIsNotNone(row)
            print(f"The total counts in table share_class_enum is {row[0]}")

    @pytest.mark.aws
    def test_table_exists_query(self):
        connection = db_connection_factory(env, "RDS")
        with connection as cursor:
            assert not is_table_exists(cursor, 'stg_sv_init_24_agreement_entity_xref_circe')
            assert is_table_exists(cursor, 'stg_ops_agreement')


if __name__ == '__main__':
    unittest.main()
