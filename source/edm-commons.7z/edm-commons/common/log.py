import logging

'''import boto3
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key '''

# Required for ANSI colors to work on windows
import os, sys
if sys.platform.lower() == "win32":
    os.system('color')

class ColorFormatter(logging.Formatter):
    """Custom formatter for colorizing log messages"""
    BLACK = '\033[0;30m'
    RED = '\033[0;31m'
    GREEN = '\033[0;32m'
    BROWN = '\033[0;33m'
    BLUE = '\033[0;34m'
    PURPLE = '\033[0;35m'
    CYAN = '\033[0;36m'
    GREY = '\033[0;37m'

    DARK_GREY = '\033[1;30m'
    LIGHT_RED = '\033[1;31m'
    LIGHT_GREEN = '\033[1;32m'
    YELLOW = '\033[1;33m'
    LIGHT_BLUE = '\033[1;34m'
    LIGHT_PURPLE = '\033[1;35m'
    LIGHT_CYAN = '\033[1;36m'
    WHITE = '\033[1;37m'

    RESET = "\033[0m"
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

    def __init__(self, *args, **kwargs):
        self._colors = {logging.DEBUG: self.DARK_GREY,
                        logging.INFO: self.RESET,
                        logging.WARNING: self.BROWN,
                        logging.ERROR: self.RED,
                        logging.CRITICAL: self.LIGHT_RED}
        super(ColorFormatter, self).__init__(*args, **kwargs)

    def format(self, record):
        """Applies the color formats"""
        record.msg = self._colors[record.levelno] + record.msg + self.RESET
        return logging.Formatter.format(self, record)

    def setLevelColor(self, logging_level, escaped_ansi_code):
        self._colors[logging_level] = escaped_ansi_code

logger = logging.getLogger(__name__)

# Create formatter and handler for writing to console
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.WARNING)
logger.addHandler(console_handler)
console_formatter = ColorFormatter('%(levelname)s| %(filename)s.line%(lineno)d    %(message)s', datefmt='%m-%d-%y %H:%M:%S')
console_handler.setFormatter(console_formatter)

# Create formatter and handler for writing to files
file_handler = logging.FileHandler('file.log')
file_handler.setLevel(logging.ERROR)
logger.addHandler(file_handler)
file_formatter = ColorFormatter('%(asctime)s %(levelname)s| %(filename)s.%(lineno)d    %(message)s', datefmt='%m-%d-%y %H:%M:%S')
file_handler.setFormatter(file_formatter)


################################### USEFUL LOG FUNCTIONS ###################################

def get_func_args_helper(func, *func_args, **func_kwargs):
    """Return a string of the function name followed by its arguments."""
    arg_names = func.func_code.co_varnames[:func.func_code.co_argcount]
    args = func_args[:len(arg_names)]
    defaults = func.func_defaults or ()
    args = args + defaults[len(defaults) - (func.func_code.co_argcount - len(args)):]
    params = zip(arg_names, args)
    args = func_args[len(arg_names):]
    if args: params.append(('args', args))
    if func_kwargs: params.append(('kwargs', func_kwargs))
    return func.func_name + '(' + ', '.join('%s = %r' % p for p in params) + ')'

def log_function(func):
    """Decorator to print function call details - parameters names and effective values."""
    def wrapper(*func_args, **func_kwargs):
        logger.debug( get_func_args_helper(func, *func_args, **func_kwargs)+'    START')
        result = func(*func_args, **func_kwargs)
        logger.debug(func.func_name + ')    END')
        return result

    return wrapper

def log_exception(func):
    """Decorator to print function call details - parameters names and effective values."""
    def wrapper(*func_args, **func_kwargs):
        try:
            result = func(*func_args, **func_kwargs)
        except:
            # TBD-glp 1/6/20: print function, args and exception
            logger.error()
        return result

    return wrapper


class CapturableHandler(logging.StreamHandler):

    @property
    def stream(self):
        return sys.stdout

    @stream.setter
    def stream(self, value):
        pass

