import enum


class JobStatus(enum.Enum):
    SUCCESS = "success"
    FAILED = "failed"
    STARTED = "started"


class JobStatusLabels(enum.Enum):
    COB = "cob"
    JOB_STATUS = "job_status"
    JOB_LOG = 'job_log'
    CONTENTS = "contents"
    LOADED = 'LoadedRecordCount'
    FILTERED = 'FilteredRecordCount'
    ERRORED = 'ErroredRecordCount'


class JobsParameter(enum.Enum):
    STATS_TABLE_LIST = 'stats_table_list'
    STATS_QUERIES_DICT = 'stats_queries_dict'

class FeedDefDynamoFields(enum.Enum):
    PARAMETERS ='parameters'


class DatabaseParamsLabels(enum.Enum):
    SECRET = "secret"
    SERVER = "server"
    USER = "user"
    PASSWORD = "password"
    PORT = "port"
    #Remove the underscore from the values
    ASSUME_ROLE = "assumerole"
    DATABASE_TYPE = "db_type"
    DB_INSTANCE = "db_instance"

class DatabaseTypesLabels(enum.Enum):
    ORAClE = "oracle"
    SYBASE = "sybase"
    POSTGRES = "postgres"


class DataFlowFoldersName(enum.Enum):
    RECEIVED = "received"
    SENT = "sent"
    PROCESSED = "processed"
    UNZIPPED = "unzipped"


class OpsWiseParametersNames(enum.Enum):
    DATASOURCE = "DataSource"
    FEEDNAME = "FeedName"