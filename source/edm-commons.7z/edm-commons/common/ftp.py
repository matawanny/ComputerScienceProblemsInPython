import logging
import os
import pexpect


class SFTP:

    def __init__(self, host, username, password=None, port=22):
        self.host = host
        self.username = username
        self.lastdir = ""
        self.password = password
        self.port = port
        self.sftpdir = ""
        self.localdir = ""
        self.transferring = 0
        self.deleting = False
        self.filename = None

    def __enter__(self):
        logging.info("Starting SFTP host:" + self.host + " User:" + self.username + " Port:" + str(self.port))
        self.child = pexpect.spawn(f'sftp -P {str(self.port)} {self.username}@{self.host}', timeout=600)
        i = self.child.expect(['.*continue connecting.*', '.*password:.*', 'sftp>.*'])
        if i == 0:
            self.child.sendline('yes')
            logging.info("sent yes to host conf")
        #		self.handle_sftp_prompt()
        elif i == 1:
            self.child.sendline(self.password)
            j = self.child.expect(['.*Permission denied.*', 'sftp>.*'])
            logging.info("sending password")
            if j == 0:
                logging.error("Wrong password sent to " + self.host)
                exit(1)
            elif j == 1:
                logging.info("connected")
        elif i == 2:
            logging.info("connected")
        return self

    def close(self):
        logging.info("Closing SFTP")
        self.child.sendline("exit")

    def set_ftp_compat(self):
        logging.info("Turning on FTP Compatibility")
        self.child.sendline("set compatibility-mode=ftp")
        self.handle_sftp_prompt()

    def get_file(self, srcpath, destdir="."):
        if not os.path.isdir(destdir):
            logging.info(f"Making dir: {destdir}")
            os.mkdir(destdir)
        prevLocalDir = self.lpwd()
        if prevLocalDir != destdir:
            self.change_local_dir(destdir)
        else:
            prevLocalDir = None

        srcdir = None
        if srcpath.find('/') != -1:
            filename = srcpath[srcpath.rindex('/')+1:]
            srcdir = srcpath[:srcpath.rindex('/')]
        else:
            filename = srcpath
        if srcdir: self.change_dir(srcdir)
        self.child.sendline("get " + filename)
        self.handle_sftp_prompt(srcpath)

        if prevLocalDir: self.change_local_dir(prevLocalDir)

    def get_files(self, srcdir, filelist, destdir="./"):
        for file in filelist:
            self.get_file(srcdir, file, destdir)

    # Call sftp.change_dir first to set remote dest path
    def put_file_d(self, srcFileNameWithRelativePath, desFileName):
        print(f'put {srcFileNameWithRelativePath} {desFileName}')
        self.child.sendline("put " + srcFileNameWithRelativePath + " " + desFileName)
        self.filename = srcFileNameWithRelativePath
        self.handle_sftp_prompt()

    def put_file(self, srcFileNameWithAbsolutePath, desFileName, destdir=""):
        if destdir == "":
            destdir = self.lastdir
            logging.debug("destdir is : " + destdir)
        desFileWithAbsolutePath = destdir + '/' + desFileName
        print(f'put {srcFileNameWithAbsolutePath} {desFileWithAbsolutePath}')
        self.child.sendline("put " + srcFileNameWithAbsolutePath + " " + desFileWithAbsolutePath)
        self.filename = desFileName
        self.lastdir = destdir
        self.handle_sftp_prompt(self.filename)


    def put_files(self, srcdir, filelist, destdir=""):
        for f in filelist:
            self.put_file(srcdir, f, destdir)

    def move_file(self, fileName, currDir, destDir):
        self.child.sendline("cd {0}".format(currDir))
        self.handle_sftp_prompt()
        self.child.sendline("rename {0} {1}/{2}".format(fileName,destDir,fileName))
        self.handle_sftp_prompt()
        logging.info("file successfully moved {0} from {1} to {2}:".format(fileName, currDir, destDir))

    def list_files(self, dir):
        if dir:
            self.change_dir(dir)
        logging.info(f"listing files on {self.host} in {dir}")
        self.child.sendline("ls")
        self.handle_sftp_prompt()

        lines = (self.child.before).splitlines()
        file_list=None
        if len(lines)>1:
            lines.pop(0)    # Remove status info
            file_list = [line.strip().decode("UTF-8") for line in lines]
            logging.info("FILELIST:" + str(file_list))
        return file_list if file_list else None

    def pwd(self):
        result = self.child.sendline("pwd")
        self.handle_sftp_prompt()
        return result

    def lpwd(self):
        self.filename = "lpwd"
        self.child.sendline("lpwd")
        print(str(self.child.before))
        print(str(self.child.after))
        self.handle_sftp_prompt()

    def lls(self):
        self.filename = "lpwd"
        self.child.sendline("lls")
        print(str(self.child.before))
        print(str(self.child.after))
        self.handle_sftp_prompt()

    def change_local_dir(self, newdir):
        self.filename = newdir
        if self.localdir != newdir:
            self.child.sendline("lcd " + newdir)
            self.handle_sftp_prompt()
            self.localdir = newdir
            logging.info("Changed sftp local dir to " + newdir)

    def change_dir(self, newdir):
        if self.sftpdir != newdir:
            self.child.sendline("cd " + newdir)
            self.handle_sftp_prompt()
            self.sftpdir = newdir
            logging.info("Changed sftp dir to " + newdir)

    def handle_sftp_prompt(self, filename=None):
        i = self.child.expect(['.*not found.*', 'sftp>.*', '.*ETA.*', 'No such file or directory', 'Removing .*'])
        if i == 0: raise ValueError(f"File {filename} not found.")
        elif i == 1:
            if self.transferring == 1:
                print("DONE  ", end='\r')
                transferring = 0
                logging.info(f"Transferred {filename}")
                self.filename = ""
            else:
                logging.info('Success')
        elif i == 2:
            a = str(self.child.after)
            start = a.find("%") - 3
            print(a[start:-1], end='\r')
            self.transferring = 1
            self.handle_sftp_prompt()
        elif i == 3:
            if self.deleting == True:
                self.handle_sftp_prompt(filename)
            else:
                raise ValueError(f'Error Transferring file via SFTP. {filename} not found.')
        elif i == 4:
            logging.info('del')

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
