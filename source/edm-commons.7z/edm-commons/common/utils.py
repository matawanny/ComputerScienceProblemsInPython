from common.log import *
import importlib
import boto3
import datetime
import uuid
from urllib.parse import urlparse
import botocore
import sys
import re
import os
from common.envconfig import ENVS
import logging
from datetime import datetime, timedelta
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication


def call_function(func, parameter_list=None):
    # TODO : remove after verification if no longer being called

    if func[:func.find('.')] == 'edm-fm':
        print("call_function current sys.argv: {}".format(sys.argv))
        print("call_function incomming parameters: {}".format((parameter_list)))
        sys.argv.clear()
        sys.argv = []
        #remove this hack once the modules being called have explicit parameters
        #that can happen once ALL jobs calling those modules have been converted to use FeedAPI
        if parameter_list.get('start-date') and parameter_list.get('end-date'):
            sys.argv.append('EmptyParameter')
            sys.argv.append(parameter_list.get('start-date'))
            sys.argv.append(parameter_list.get('end-date'))
        print("call_function modified sys.argvs: {}".format(sys.argv))
        print("call_function importing: {}".format(func))
        importlib.import_module(func)
        return
      
    if parameter_list:
        if not isinstance(parameter_list, (list, tuple)) and len(parameter_list) < 1:
            raise ValueError("When parameters are passed to a function, they must be a list of more than zero parameters.")

    if isinstance(func, str):
        numDots=func.count('.')
        package = None
        if numDots == 0:
            raise ValueError(f"A full path to the function {func} must be specified.")
        elif numDots == 1:
            module = func[:func.rindex('.')]
        else:   #numDots >1
            package= func[:func.rindex('.')]
            module=package[package.rindex(".")+1:]
            package= package[:package.rindex('.')]
        function= func[func.rindex(".")+1:]
        importlib.invalidate_caches()
        module = importlib.import_module((package+"." if package else "") + module)
        print(f"Running module={str(module)} function={function} parameters={str(parameter_list)}")
        if parameter_list:
            if isinstance(parameter_list, dict):
                return getattr(module, function)(**parameter_list)
            else:
                return getattr(module, function)(*parameter_list)
        else:
            return getattr(module, function)()
    elif isinstance(func, dict):
        module= func["module"]
        clazz= func["class"]
        function= func["function"]
        # TBD-glp 3/25/20: Need to implement
    else:
        raise ValueError("Can only execute code when the func parameter, {}, is a dict or a str path".format(func))

#move to EMR
def get_emr_cluster_id(cluster_name):
    client = boto3.client("emr")
    response = client.list_clusters(
                ClusterStates=['RUNNING', 'WAITING']
    )
    for c in response['Clusters']:
        if c['Name'] == cluster_name:
            return c['Id']

#stays here
def getTime():
        return datetime.now().strftime('%Y%m%d %H:%M:%S')

#move to EMR class- non static
def copy_config_to_s3(etl_conf_str, env, source, jobID, alias):
        s3 = boto3.resource('s3')
        if alias:
            filename = "{}_{}.conf".format(re.sub('\s+', '_', alias.lower()).strip(), jobID)
        else:
            filename = "{}.conf".format(str(jobID))
        file_path = f"{ENVS[env]['mdmLocation']}/{source}/incoming/{filename}"
        logging.info(f"Copying file to S3:{str(file_path)}")
        s3.Object(ENVS[env]['aws']['s3_bucket'][5:], file_path).put(Body=etl_conf_str)
        logging.info("File successfully copied to S3")

#move to jobRunner
def gen_jobid():
       jobid = uuid.uuid1()
       return jobid.hex

#move to S3 class
def is_s3_file_present(s3_file):
        o = urlparse(s3_file, allow_fragments=False)
        bucket_name = o.netloc
        file_path = o.path[1:]
        s3 = boto3.client('s3')
        try:
            s3.head_object(Bucket=bucket_name, Key=file_path)
        except botocore.exceptions.ClientError as err:
            return False
        return True


def datetime_range(start=None, end=None):
    span = end - start
    for i in range(span.days + 1):
        yield start + timedelta(days=i)

def gzipFile(filename):
    f, file_extension = os.path.splitext(filename)
    if file_extension != ".gz":
        os.system("gzip -f '" + filename + "'")
        filename = filename + ".gz"
    return filename


def send_email(subject, message, from_email, to_email=[], attachment=[]):
    """
    :param subject: email subject
    :param message: Body content of the email (string), can be HTML/CSS or plain text
    :param from_email: Email address from where the email is sent
    :param to_email: List of email recipients, example: ["a@a.com", "b@b.com"]
    :param attachment: List of attachments, exmaple: ["file1.txt", "file2.txt"]
    """
    msg = MIMEMultipart()
    msg['Subject'] = subject
    msg['From'] = from_email
    msg['To'] = ", ".join(to_email)
    msg.attach(MIMEText(message, 'html'))

    for f in attachment:
        with open(f, 'rb') as a_file:
            basename = os.path.basename(f)
            part = MIMEApplication(a_file.read(), Name=basename)

        part['Content-Disposition'] = 'attachment; filename="%s"' % basename
        msg.attach(part)

    email = smtplib.SMTP('localhost')
    email.sendmail(from_email, to_email, msg.as_string())
