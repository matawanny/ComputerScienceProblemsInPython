import boto3
import json
import logging
import os
from common.envconfig import ENVS


def assume_role(assumerole):
    redirect = '/dev/null'
    if redirect in assumerole:
        ret_val = os.system(assumerole)
    else:
        ret_val = os.system(assumerole + " > /dev/null")
    if ret_val != 0:
        raise Exception("There is error to run script at " + assumerole)


def exit_role():
    exitrole = 'exit'
    ret_val = os.system(exitrole + " > /dev/null")


def get_secret(secret_name, env):
    """
    THE CALLER NEEDS TO CALL assumeRole WHEN RUNNING ON ON-PREMISES MACHINES SUCH AS FileManager
    """
    awsregion = ENVS[env]['aws']['region']

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=awsregion
    )
    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.

    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    # Decrypts secret using the associated KMS CMK.
    # Depending on whether the secret is a string or binary, one of these fields will be populated.
    if 'SecretString' in get_secret_value_response:
        secret = get_secret_value_response['SecretString']
        secret_json = json.loads(secret)
        return secret_json
    else:
        raise ValueError("Cannot get secrete")
