ENVS = {
    'test': {
        "aws"    : {
            "region"        : "us-east-2",
            "account"       : "430815409173",
            "role"          : "AWS_ROLE_4308-DATASCIENTIST",
            "s3_bucket"     : "s3://lazard-test-client-master",
            "s3_log_bucket" : "s3://aws-logs-430815409173-us-east-2",
            "region_for_java": "US_EAST_2"
        },
        "assumerole": "/usr/local/bin/aws-4308-role-LazardFileManagerRole.py",
        "keyid": "8af400cc-21f2-4f5b-bb22-da1bceb42fff",
        "poll_time_seconds" : "60",
        "waitOnJobStatus"   : False,
        "mdmLocation"       : "MDM/conf",
        "etl_cluster_name"  : "lazard-test-emr-etl",
        "mdm_cluster_name"  : "lazard-test-emr-mdm",
        "code_branch"       : "development",
        "cm-sftp"           : {             # TBD-glp 4/16/20: Not yet tested
            "secret"        : "edmsftp" ,
            "server"        : "nj1ux-edmsftp1"
        },
        "cm-interface-to-salesforce": {
            "secret"        : "edmcm_webtoken",
            "url"           : "http://cm-test-salesforce-api.awstst.lazard.com:9010"
        },
        "cm_salesforce_api":{
            "api_secret": "lazard-test-sf-api",
            "sf_grant_type": "refresh_token",
            "sf_redirect_url": "https://localhost",
            "sf_token_url": "https://test.salesforce.com/services/oauth2/token",
            "sf_base_url": "https://lazard--Full.my.salesforce.com/services/",
            "sf_entity_endpoint": "apexrest/dumbyapi",
            "sf_agreement_endpoint": "apexrest/cmag",
            "sf_agreement_delete_endpoint": "apexrest/deleteagreementapi",
            "sf_entity_merge_endpoint": "apexrest/cmmerge",
            "einstein_grant_type": "password",
            "einstein_base_url": "https://lazard--Full.my.salesforce.com/services/",
            "einstein_flow_endpoint": "data/v47.0/sobjects/InsightsExternalData"
        },
        "RDS"               : {
            "secret"        : "lazard-test-db-json",
            "db_type"       : "postgres"
        },
        "SalesVision_Import"       : {
            "secret"        : "edmcm_salesvision",
            "server"        : "clientxfer.adp-ics.com",
            "port"          : 10022,
            "user"          : "svlazard",
            "root-dir"      : "svlazard"
        },
        "AMG_Import"               : {
            "secret"        : "edmcm_amg",
            "user"          : "READONLY",
            "server"        : "10.56.25.148",
            "port"          : 1501,
            "db_instance"   : "ORPGEN01",
            "db_type"       : "oracle"
        },
         "Reference_Data_Import"               : {
            "secret"        : "edmcm_amg",
            "user"          : "READONLY",
            "server"        : "10.56.25.148",
            "port"          : 1501,
            "db_instance"   : "ORPGEN01",
            "db_type"       : "oracle"
        },
        "LDW": {  # Sybase db for flows. Use sqlanydb.connect
            "secret"        : "edmcm_ldw",
            "user"          : "edm_ro",
            "server"        : "nylux-iqldwprddb",
            "port"          : 2034,
            "db_type"       : "sybase"
        },
        "Fishtank_Import": {
            "server"        : "nj1ux-edmpsftp",
            "port"          : 22,
            "user"          : "edmsftp"
        },
        "AU_Platfrom_Import": {
            "server"        : "nj1ux-edmpsftp",
            "port"          : 22,
            "user"          : "edmsftp"
        },
        "AU_Registreet_Import": {
            "server"        : "nj1ux-edmpsftp",
            "port"          : 22,
            "user"          : "edmsftp"
        },
        "FXRATE": {  # Sybase db for fx_rate. Use sqlanydb.connect
            "secret"        : "edmcm_ldw",
            "user"          : "edm_ro",
            "server"        : "nylux-iqldwprddb",
            "port"          : 2034,
            "db_instance"   : "IQPAST01",
            "db_type"       : "sybase"
        },
        "Salesforce_Import": {
            "server"        : "nj1ux-edmpsftp",
            "port"          : 22,
            "user"          : "edmsftp"
        }
    },
    'prod': {
        "aws"               : {
            "region"        : "us-east-1",
            "account"       : "617264982758",
            "role"          : "AWS-ROLE-6172-LazardCMReadonlyRole",
            "s3_bucket"     : "s3://lazard-prod-client-master",
            "s3_log_bucket" : "s3://aws-logs-617264982758-us-east-1",
            "region_for_java": "US_EAST_1"
        },
        "assumerole"        : "/usr/local/bin/aws-6172-role-LazardFileManagerRole.py",
        "keyid"             : "827813db-6a6b-45b6-9e82-36094f1c949a",
        "poll_time_seconds" : "60",
        "waitOnJobStatus"   : False,
        "mdmLocation"       : "MDM/conf",
        "etl_cluster_name"  : "lazard-prod-emr-etl",
        "mdm_cluster_name"  : "lazard-prod-emr-mdm",
        "code_branch"       : "master",
        "cm-sftp"           : {
            "secret"        : "edmsftp",
            "server"        : "nj1ux-edmpsftp"
        },
        "cm-interface-to-salesforce": {
            "secret"        : "edmcm_webtoken",
            "url"           : "http://cm-prod-salesforce-api.aws.lazard.com:9010"
        },
        "cm_salesforce_api":{
            "api_secret": "lazard-prod-sf-api",
            "sf_grant_type": "refresh_token",
            "sf_redirect_url": "https://localhost",
            "sf_token_url": "https://login.salesforce.com/services/oauth2/token",
            "sf_base_url": "https://lazard.my.salesforce.com/services/",
            "sf_entity_endpoint": "apexrest/dumbyapi",
            "sf_agreement_endpoint": "apexrest/cmag",
            "sf_agreement_delete_endpoint": "apexrest/deleteagreementapi",
            "sf_entity_merge_endpoint": "apexrest/cmmerge",
            "einstein_grant_type": "password",
            "einstein_base_url": "https://lazard.my.salesforce.com/services/",
            "einstein_flow_endpoint": "data/v47.0/sobjects/InsightsExternalData"
        },
        "RDS": {
            "secret"        : "lazard-prod-db-json",
            "db_type"       : "postgres"
        },
        "SalesVision_Import"       : {
            "secret"        : "edmcm_salesvision",
            "server"        : "clientxfer.adp-ics.com",
            "port"          : 10022,
            "user"          : "svlazard",
            "root-dir"      : "svlazard"
        },
        "AMG_Import"        : { #Oracle db
            "secret"        : "edmcm_amg",
            "user"          : "READONLY",
            "server"        : "10.56.25.148",
            "port"          : 1501,
            "db_instance"   : "ORPGEN01",
            "db_type"       : "oracle"
        },
        "Reference_Data_Import"        : { #Oracle db
            "secret"        : "edmcm_amg",
            "user"          : "READONLY",
            "server"        : "10.56.25.148",
            "port"          : 1501,
            "db_instance"   : "ORPGEN01",
            "db_type"       : "oracle"
        },
        "LDW"               : { #Sybase db for flows. Use sqlanydb.connect
            "secret"        : "edmcm_ldw",
            "user"          : "edm_ro",
            "server"        : "nylux-iqldwprddb",
            "port"          : 2034,
            "db_type"       : "sybase"
        },
        "Fishtank_Import": {
            "server"        : "nj1ux-edmpsftp",
            "port"          : 22,
            "user"          : "edmsftp"
        },
        "AU_Platfrom_Import": {
            "server"        : "nj1ux-edmpsftp",
            "port"          : 22,
            "user"          : "edmsftp"
        },
        "AU_Registreet_Import": {
            "server"        : "nj1ux-edmpsftp",
            "port"          : 22,
            "user"          : "edmsftp"
        },
        "FXRATE": {  # Sybase db for fx_rate. Use sqlanydb.connect
            "secret"        : "edmcm_ldw",
            "user"          : "edm_ro",
            "server"        : "nylux-iqldwprddb",
            "port"          : 2034,
            "db_instance"   : "IQPAST01",
            "db_type"      : "sybase"
        },
        "Salesforce_Import": {
            "server"        : "nj1ux-edmpsftp",
            "port"          : 22,
            "user"          : "edmsftp"
        }
    }
}