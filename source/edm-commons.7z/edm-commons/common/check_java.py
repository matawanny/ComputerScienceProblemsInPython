import fileinput


f = []
for line in fileinput.input():
    f.append(line)
g = ""
if len(f) > 2:
    for x in range(2, len(f)):
        g += f[x]
    print("Error when call aws encryption/decryption jar: " + g.strip())
    print(g.strip())
    exit(1)

