from boto3.dynamodb.conditions import Key, Attr
import boto3
import time as t
from common.security import *
import logging
from common.utils import get_emr_cluster_id, copy_config_to_s3, gen_jobid, is_s3_file_present
import time
from common.envconfig import ENVS
from jobsystem.build_config import *
from datetime import datetime
from io import BytesIO
import gzip
import os
import json

class S3:
    def __init__(self, env):
        if env is None or (env != 'test' and env != 'prod'):
            raise ValueError("Wrong value of env: {}".format(env))

        self.assumerole = ENVS[env]['assumerole']
        self.bucketname = ENVS[env]['aws']['s3_bucket']
        if self.bucketname.startswith('s3://'):
            self.bucketname = self.bucketname[5:]
        self.aws_region = ENVS[env]['aws']['region_for_java']
        self.keyid = ENVS[env]['keyid']
        self.start_time = None
        classpath = os.getenv('CLASSPATH')
        if ':' in classpath:
            self.classpath = classpath.split(':')[-1] + '/'
        else:
            self.classpath = classpath + '/'

        logging.info(f"assumerole={self.assumerole}, bucketname={self.bucketname}, aws_region={self.aws_region} "
                     f"keyid={self.keyid}, env={env} ")

    def __enter__(self):
        self.start_time = t.time()
        logging.info("Refreshing AWS Credentials")
        assume_role(self.assumerole)
        return self

    def __exit__(self, exception_type, exception_value, exception_traceback):
        self.start_time = None
        exit_role()

    def check_file(self, filename):
        if os.path.isfile(filename):
            logging.info("Found existing file : " + filename)
            return 0
        else:
            return -1

    def send_file(self, localPathOfFileIncludingFilename, s3BucketName, s3pathOfFileIncludingFilename, encrypt=True):
        # check to see if file exists
        result = self.check_file(localPathOfFileIncludingFilename)
        if result < 0:
            raise ValueError("Cannot find local file: " + localPathOfFileIncludingFilename)
        if s3BucketName.startswith('s3://'):
            s3BucketName = s3BucketName[5:]
        elapsed_time = t.time() - self.start_time
        if elapsed_time > 600:
            assume_role(self.assumerole)
            self.start_time = t.time()  # reset timer
            logging.info("Refreshing AWS Credentials")

        # Send file with jar
        print("localPathOfFileIncludingFilename = " + localPathOfFileIncludingFilename)
        print("s3BucketName = " + s3BucketName)
        print("s3pathOfFileIncludingFilename =" + s3pathOfFileIncludingFilename)

        local_file = localPathOfFileIncludingFilename.split('/')[-1]
        aws_file = s3pathOfFileIncludingFilename.split('/')[-1]
        aws_path = s3pathOfFileIncludingFilename[:len(s3pathOfFileIncludingFilename) - len(aws_file) - 1]
        if not aws_path.startswith('/'):
            aws_path = '/' + aws_path
        if encrypt:
            logging.info("java -classpath {classpath}aws-encryption-sdk-java-1.3.7-SNAPSHOT-jar-with-dependencies.jar "
                         "com.amazonaws.encryptionsdk.S3Ecopy \"{s3destbucket}\" \"{dest}\" {keyid} {region} \"{src}\" "
                         "| python {classpath}check_java.py".format(classpath=self.classpath,
                                                                    s3destbucket=s3BucketName + aws_path,
                                                                    dest=aws_file, region=self.aws_region, keyid=self.keyid,
                                                                    src=localPathOfFileIncludingFilename))
            print("java -classpath {classpath}aws-encryption-sdk-java-1.3.7-SNAPSHOT-jar-with-dependencies.jar "
                  "com.amazonaws.encryptionsdk.S3Ecopy \"{s3destbucket}\" \"{dest}\" {keyid} {region} \"{src}\" "
                  "| python {classpath}check_java.py".format(classpath=self.classpath, s3destbucket=s3BucketName + aws_path,
                                                             dest=aws_file, region=self.aws_region, keyid=self.keyid,
                                                             src=localPathOfFileIncludingFilename))
            code = os.system("java -classpath {classpath}aws-encryption-sdk-java-1.3.7-SNAPSHOT-jar-with-dependencies.jar "
                             "com.amazonaws.encryptionsdk.S3Ecopy \"{s3destbucket}\" \"{dest}\" {keyid} {region} \"{src}\" "
                             "| python {classpath}check_java.py".format(classpath=self.classpath,
                                                                        s3destbucket=s3BucketName + aws_path,
                                                                        dest=aws_file, region=self.aws_region,
                                                                        keyid=self.keyid,
                                                                        src=localPathOfFileIncludingFilename))

            print(f'code={code}')
            if code != 0:
                logging.error("Error uploading the file :" + local_file)
                print("Error uploading the file :" + local_file)
                raise ValueError("Error uploading the file : " + local_file)

            logging.info("Encrypted and sent : " + local_file)
            print("Encrypted and sent : " + local_file)

        else:
            if str(s3BucketName) in aws_path:
                # remove bucket name at beginning of the aws_path if its there
                print("removing bucket name in aws path...")
                aws_path_list = aws_path.split('/')
                aws_path_list.pop(0)
                aws_path = '/'.join(aws_path_list)
            if aws_path.startswith('/'):
                aws_path = aws_path.lstrip('/')
            if not aws_path.endswith('/'):
                aws_path = aws_path + '/'
            print("BucketName: " + s3BucketName)
            print("aws_file: " + aws_file)
            print("Local file: " + local_file)
            print("aws path: " + aws_path)
            with open(localPathOfFileIncludingFilename) as file:
                s3_client = boto3.client('s3')
                response = s3_client.upload_file(localPathOfFileIncludingFilename, s3BucketName,  aws_path + aws_file)
                print(response)
                print("File {} successfully uploaded to S3 bucket: {} Path: {}".format(localPathOfFileIncludingFilename, s3BucketName, aws_path))


    def get_file(self, localPathOfFileIncludingFilename, s3BucketName, s3pathOfFileIncludingFilename):

        elapsed_time = t.time() - self.start_time
        if elapsed_time > 600:
            assume_role(self.assumerole)
            self.start_time = t.time()  # reset timer
            logging.info("Refreshing AWS Credentials")

        if s3BucketName.startswith('s3://'):
            s3BucketName = s3BucketName[5:]

        # Send file with jar
        aws_file = s3pathOfFileIncludingFilename.split('/')[-1]
        aws_path = s3pathOfFileIncludingFilename[:len(s3pathOfFileIncludingFilename) - len(aws_file) - 1]
        if not aws_path.startswith('/'):
            aws_path = '/' + aws_path

        logging.info("java -classpath {classpath}aws-decryption.jar "
                     "com.amazonaws.encryptionsdk.S3Ecopy \"{aws_source_path}\" \"{srcfilename}\" {keyid} {awsregion} \"{destfilename}\" "
                     "| python {classpath}check_java.py".format(classpath=self.classpath,
                                                                aws_source_path=s3BucketName + aws_path,
                                                                srcfilename=aws_file, keyid=self.keyid,
                                                                awsregion=self.aws_region,
                                                                destfilename=localPathOfFileIncludingFilename))

        print("java -classpath {classpath}aws-decryption.jar "
              "com.amazonaws.encryptionsdk.S3Ecopy \"{aws_source_path}\" \"{srcfilename}\" {keyid} {awsregion} \"{destfilename}\" "
              "| python {classpath}check_java.py".format(classpath=self.classpath,
                                                         aws_source_path=s3BucketName + aws_path,
                                                         srcfilename=aws_file, keyid=self.keyid,
                                                         awsregion=self.aws_region,
                                                         destfilename=localPathOfFileIncludingFilename))
        code = os.system("java -classpath {classpath}aws-decryption.jar "
                         "com.amazonaws.encryptionsdk.S3Ecopy \"{aws_source_path}\" \"{srcfilename}\" {keyid} {awsregion} \"{destfilename}\" "
                         "| python {classpath}check_java.py".format(classpath=self.classpath,
                                                                    aws_source_path=s3BucketName + aws_path,
                                                                    srcfilename=aws_file, keyid=self.keyid,
                                                                    awsregion=self.aws_region,
                                                                    destfilename=localPathOfFileIncludingFilename))
        print(f'code={code}')
        if code != 0:
            logging.error("Error decrypting the file :" + s3pathOfFileIncludingFilename)
            raise ValueError("Error decrypting the file : " + s3pathOfFileIncludingFilename)


class DynamoDB:

    def __init__(self, env):
        if env is None or (env != 'test' and env != 'prod'):
            raise ValueError("Wrong value of env: {}".format(env))
        self.assumerole = ENVS[env]['assumerole']
        self.aws_region = ENVS[env]['aws']['region_for_java']
        self.keyid = ENVS[env]['keyid']
        self.start_time = None
        logging.info(f"assumerole={self.assumerole}, aws_region={self.aws_region} "
                     f"keyid={self.keyid}, env={env} ")

    def __enter__(self):
        self.start_time = t.time()
        logging.info("Refreshing AWS Credentials")
        assume_role(self.assumerole)
        return self

    def __exit__(self, exception_type, exception_value, exception_traceback):
        self.start_time = None
        exit_role()

    def upsert(self, tableName, data, insertIfNotFound=True):
        dynamo = boto3.resource('dynamodb')
        table = dynamo.Table(tableName)
        if not bool(insertIfNotFound):
            hash_key = data.pop('hash_key', None)
            range_key = data.pop('range_key', None)
            if not hash_key:
                raise ValueError("hash_key is required for update")
            if hash_key and range_key:
                response = table.query(
                    KeyConditionExpression=Key(hash_key).eq(data[hash_key]) & Key(range_key).eq(data[range_key])
                )
            else:
                response = table.query(
                    KeyConditionExpression=Key(hash_key).eq(data[hash_key])
                )
            items = response['Items']
            if len(items) == 0:
                raise ValueError("record with hash_value of {0} not found in collection".format(data[hash_key]))
            item = items[0]
            item.update(data)
            table.put_item(Item=item)
        else:
            data.pop('hash_key', None)
            data.pop('range_key', None)
            status = table.put_item(Item=data)

    def bulkInsert(self, table_name, items_list):
        dynamo = boto3.resource('dynamodb')
        table = dynamo.Table(table_name)
        with table.batch_writer() as batch:
            for item in items_list:
                batch.put_item(item)

    def query(self, tableName, data):
        dynamo = boto3.resource('dynamodb')
        table = dynamo.Table(tableName)

        hash_key = data.pop('hash_key', None)
        range_key = data.pop('range_key', None)

        if not hash_key:
            raise ValueError("hash_key is required for query")

        if data[hash_key].endswith("*"):
            fe = Attr(hash_key).contains(data[hash_key][:-1])
            response = table.scan(
                FilterExpression=fe
            )
        elif hash_key and range_key:
            response = table.query(
                KeyConditionExpression=Key(hash_key).eq(data[hash_key]) & Key(range_key).eq(data[range_key])
            )
        else:
            response = table.query(
                KeyConditionExpression=Key(hash_key).eq(data[hash_key])
            )
        item = response['Items']
        return item

    def delete(self, tableName, data):
        dynamo = boto3.resource('dynamodb')
        table = dynamo.Table(tableName)
        hash_key = data.pop('hash_key', None)
        range_key = data.pop('range_key', None)

        if not hash_key:
            raise ValueError("hash_key is required for delete")
        if hash_key and range_key:
            response = table.delete_item(
                Key={hash_key: data[hash_key], range_key: data[range_key]}
            )
        else:
            response = table.delete_item(
                Key={hash_key: data[hash_key]}
            )
        print(response)
        return True


class EMR:

    def __init__(self, codeToRun, alias, env, COB, targetMachine, inputs, outputs, parameters, dryRun, jobID):

        self.codeToRun = codeToRun
        self.alias = alias
        self.env = env
        self.COB = COB
        self.targetMachine = targetMachine
        self.inputs = inputs
        self.outputs = outputs
        self.jobID = jobID
        self.parameters = parameters
        self.dryRun = dryRun
        self.assumerole = ENVS[env]['assumerole']
        self.status = None
        self.emr_action = self.parameters.pop("emr_function")
        self.cluster_id = None
        self.step_id = None



    def __enter__(self):
        self.start_time = t.time()
        logging.info("Refreshing AWS Credentials")
        if not self.dryRun:
            assume_role(self.assumerole)
        return self

    def __exit__(self, exception_type, exception_value, exception_traceback):
        self.start_time = None
        exit_role()


    def get_etl_conf(self):
        etl_conf = self.parameters
        etl_conf["output_location"] = self.outputs
        etl_conf["input_location"] = self.inputs
        etl_conf["file_date"] = f"{datetime.now():%m-%d-%Y}"
        etl_conf["job-id"] = self.jobID
        return json.dumps(etl_conf)

    def run(self):

        """Expect a key, emr_function to be defined in parameters specifying whether
        to run: etl, mdm, dbsync, or circe"""
        if self.emr_action not in ("etl", "mdm", "dbsync", "circe"):
            raise ValueError(
                "A value for 'emr_function' must be specified in the parameters and \
                must be one of: etl, mdm, dbsync, circe")

        if not self.dryRun:
            self.cluster_id = get_emr_cluster_id(self.targetMachine)
            if self.cluster_id is None:
                raise ValueError("No running cluster with name of {}".format(self.targetMachine))


        branch = ENVS[self.env]['code_branch']

        l_mdm_driver = f"{ENVS[self.env]['aws']['s3_bucket']}{mdm_driver.format(branch)}"
        l_etl_driver = f"{ENVS[self.env]['aws']['s3_bucket']}{etl_driver.format(branch)}"
        l_circe_driver = f"{ENVS[self.env]['aws']['s3_bucket']}{circe_driver.format(branch)}"
        l_dbsync_driver = f"{ENVS[self.env]['aws']['s3_bucket']}{dbsync_driver.format(branch)}"

        step_args = ["/usr/bin/spark-submit",
                     "--jars", f"{ENVS[self.env]['aws']['s3_bucket']}{postgres_jar}",
                     "--master", "yarn",
                     "--conf", "spark.pyspark.python=/usr/bin/python3.6"
                     ]

        py_zips = f"{ENVS[self.env]['aws']['s3_bucket']}{commons_zip.format(branch)}," \
                  f"{ENVS[self.env]['aws']['s3_bucket']}{dpl_zip.format(branch)}"
        step_args.extend(["--py-files", py_zips.format(self.parameters.get("commons_branch", branch), \
                                                       self.parameters.get("dpl_branch", branch))])

        if self.emr_action == "mdm":
            mdm_conf_dir = self.inputs.get('mdm_conf_dir')
            mdm_prefix = self.inputs.get('mdm_prefix')
            add_args = ["--conf", "spark.driver.memory=16G",
                        "--conf", "spark.executor.memory=16G",
                        l_mdm_driver, "-s", mdm_conf_dir, "-m True", "-e", "-x", mdm_prefix, "-p", "stg_"
                        ]
            step_args.extend(add_args)
        elif self.emr_action == "dbsync":
            dbsync_param = None
            source = None
            if self.inputs:
                dbsync_param = self.inputs.get('dbsync_param')
                source = self.inputs.get('source')
            add_args = []
            add_args.extend(spark_driver_memory)
            add_args.extend(spark_executor_memory)
            add_args.extend([l_dbsync_driver, "-s", dbsync_param])
            if source: add_args.extend(("-p", source))
            if self.parameters and self.parameters.get("AdditionalParameters", None): add_args.extend(
                [self.parameters["AdditionalParameters"]])
        elif self.emr_action == "etl":
            etl_conf = self.parameters
            etl_conf["output_location"] = self.outputs
            etl_conf["input_location"] = self.inputs
            etl_conf["file_date"] = f"{datetime.now():%m-%d-%Y}"
            etl_conf["job-id"] = self.jobID
            etl_conf_str = self.get_etl_conf()
            logging.info("etl conf:" + str(etl_conf))
            add_args = [l_etl_driver, "-f", etl_conf_str, "-m False"]
            s3_conf_file = self.inputs['emr']
            if not self.dryRun:
                if not is_s3_file_present(s3_conf_file):
                    self.status = "FILE_NOT_FOUND"
                    raise ValueError("{} file not present in S3".format(s3_conf_file))
        elif self.emr_action == "circe":
            circe_conf_dir = self.inputs['circe_conf_dir']
            circe_prefix = self.inputs['circe_prefix']
            add_args = ["--conf", "spark.driver.memory=16G",
                        "--conf", "spark.executor.memory=16G",
                        l_circe_driver, "-c", circe_conf_dir, "-j", circe_prefix
                        ]
        else:
            raise ValueError("{} not supported".format(self.codeToRun))

        step_args.extend(add_args)
        logging.info(f"running {self.emr_action}")
        emr_conn = boto3.client("emr", region_name=ENVS[self.env]['aws']['region'])
        step = {"Name": f"{self.emr_action}_{self.alias.lower()}_{self.jobID}_{time.strftime('%Y%m%d-%H:%M')}",
                'ActionOnFailure': 'CONTINUE',
                'HadoopJarStep': {
                    'Jar': 's3://us-east-2.elasticmapreduce/libs/script-runner/script-runner.jar',
                    'Args': step_args
                }
                }

        if not self.dryRun:
            assume_role(self.assumerole)
            logging.info("Running EMR Step on " + self.cluster_id + ":" + str(step))
            action = emr_conn.add_job_flow_steps(JobFlowId=self.cluster_id, Steps=[step])
            step_id = action.get('StepIds', " ").pop()
            logging.info("EMR Command:" + " ".join(step['HadoopJarStep']['Args']))
            self.step_id = step_id

            job_details = {"cluster_id": self.get_cluster_id(),
                           "step_id": self.get_step_id()
                           }
            self.log_to_dynamodb({"job_details": job_details})

            self.blockUntilComplete(step_id)
            self.complete()
            print("*" * 200)
            print(self.getLog())
            print("*" * 200)
            if self.status == "FAILED":
                raise ValueError("EMR step failed! Check logs")
            return self.status


        # in dry mode return None
        return None

    def blockUntilComplete(self, step_id):
        if self.dryRun:
            return
        cluster_id = self.cluster_id
        emr_conn = boto3.client("emr", region_name=ENVS[self.env]['aws']['region'])
        while True:
            emr_steps = emr_conn.list_steps(ClusterId=cluster_id)['Steps']
            for step in emr_steps:
                if step_id == step['Id']:
                    step_status = step['Status']['State']
                    logging.info("step status:" + str(step_status))
                    if (step_status in ['COMPLETED', 'FAILED']):
                        # need to wait until logging.info file is accessible in s3
                        time.sleep(300)
                        assume_role(self.assumerole)
                        # self.log_contents = retrieveS3Log(cluster_id, step_id)
                        if step_status == "FAILED":
                            failureReason = step['Status']['FailureDetails']['Reason']
                            logging.info("FailureReason:" + str(failureReason))
                            self.status = step_status
                            return False
                        self.status = step_status
                        return True
            time.sleep(30)
            assume_role(self.assumerole)

    def complete(self):
        if self.dryRun:
            return
        if self.emr_action == "etl" and self.status == "COMPLETED":
            source = self.inputs['source']
            copy_config_to_s3(self.get_etl_conf(), self.env,  source, self.jobID, self.alias)

    def get_job_id(self):
        return self.jobID

    def get_step_id(self):
        return self.step_id

    def get_cluster_id(self):
        return self.cluster_id


    def get_status(self):
        if self.step_id:
            return self.status
        else:
            return "NOTRUN"

    def getLogPath(self):
        if self.step_id:
            key = f"elasticmapreduce/{self.cluster_id}/steps/{self.step_id}/stdout.gz"
            self.full_s3_path = f"{ENVS[self.env]['aws']['s3_log_bucket']}/{key}"
            return self.full_s3_path
        return None


    def getLog(self):

        if not self.step_id:
            raise ValueError(
                "No job has been launched. Please call run() method before calling getLog()")

        key = None

        stdout_key = f"elasticmapreduce/{self.cluster_id}/steps/{self.step_id}/stdout.gz"
        stderror_key = f"elasticmapreduce/{self.cluster_id}/steps/{self.step_id}/stderr.gz"

        full_file_stdout = "{0}/{1}".format(ENVS[self.env]['aws']['s3_log_bucket'], stdout_key)
        full_file_stderror = "{0}/{1}".format(ENVS[self.env]['aws']['s3_log_bucket'], stderror_key)

        if is_s3_file_present(full_file_stdout):
            key = stdout_key
        elif is_s3_file_present(full_file_stderror):
            key = stderror_key

        if not key:
            raise ValueError("No log found in S3 when calling getLog()")

        try:
            s3 = boto3.resource('s3')
            logBucket = ENVS[self.env]['aws']['s3_log_bucket']
            obj = s3.Object(logBucket[5:], key)
            n = obj.get()['Body'].read()
            gzipfile = BytesIO(n)
            gzipfile = gzip.GzipFile(fileobj=gzipfile)
            log_contents = gzipfile.read().decode('UTF-8')
            logging.info("S3 log output:" + log_contents)
            return log_contents
        except Exception as e:
            print(e)
            raise e

    def log_to_dynamodb(self, data_dict):
        res_dict = {}
        jobdata = {
            'jobid': self.jobID,
            'hash_key': 'jobid'
        }


        res_dict.update(jobdata)
        res_dict.update(data_dict)
        with DynamoDB(self.env) as dynamo:
            dynamo.upsert("OpswiseJobStatus", res_dict, False)

    @staticmethod
    def kill(env, cluster_id, step_id):
        '''Kill the job associated with the stepId'''
        emr_conn = boto3.client("emr", region_name=ENVS[env]['aws']['region'])
        response = emr_conn.cancel_steps(ClusterId=cluster_id, StepIds=[step_id])
        logging.info(response)
