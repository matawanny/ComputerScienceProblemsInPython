import csv

import cx_Oracle
import json
import psycopg2
import sqlanydb
from sqlanydb import DatabaseError

from common.envconfig import ENVS
from common.security import get_secret, assume_role
from common.enums import DatabaseParamsLabels, DatabaseTypesLabels


def checkDBparameters(function):
    def wrapper(class_instance, env, data_source):
        if not ENVS.get(env, None): raise ValueError("The env parameter must be passed in.")
        if not env.lower() in ("test", "prod"): raise ValueError("The env parameter must be either PROD or TEST.")
        if not ENVS[env].get(data_source, None):
            raise ValueError(f"The data_source parameter {data_source} must be a dict in the envconfig.py script.")
        function(class_instance, env, data_source)

    return wrapper


class DatabaseConnection:
    def __init__(self, **db_params):
        assume_role(db_params[DatabaseParamsLabels.ASSUME_ROLE.name])
        self.user = db_params[DatabaseParamsLabels.USER.name]
        self.password = db_params[DatabaseParamsLabels.PASSWORD.name]
        self.server = db_params[DatabaseParamsLabels.SERVER.name]
        self.port = db_params[DatabaseParamsLabels.PORT.name]
        self.db_instance = db_params.get(DatabaseParamsLabels.DB_INSTANCE.name, None)

    def __exit__(self, exception_type, exception_value, exception_traceback):
        if exception_value:  # This is equivalent to `if exception_value is not None`
            self.connection.rollback()
        else:
            self.cursor.close()
            self.connection.commit()
        self.connection.close()


class Oracle(DatabaseConnection):
    # @checkDBparameters
    def __init__(self, **db_params):
        secret = db_params[DatabaseParamsLabels.SECRET.name]
        password = secret["pwd"]
        db_params[DatabaseParamsLabels.PASSWORD.name] = password
        super().__init__(**db_params)

    def __enter__(self):
        connection_string = cx_Oracle.makedsn(self.server, self.port, self.db_instance)
        self.connection = cx_Oracle.connect(self.user, self.password, connection_string)
        self.cursor = self.connection.cursor()
        return self.cursor


class Sybase(DatabaseConnection):
    # @checkDBparameters
    def __init__(self, **db_params):
        secret = db_params[DatabaseParamsLabels.SECRET.name]

        if 'sybase_iq_pass' in secret:
            password = secret["sybase_iq_pass"]
        elif 'pwd' in secret:
            password = secret["pwd"]
        else:
            password = secret["password"]

        db_params[DatabaseParamsLabels.PASSWORD.name] = password
        super().__init__(**db_params)

    def __enter__(self):
        print(f'user={self.user}, password={self.password}, host={self.server}:{self.port}')
        self.connection = sqlanydb.connect(userid=self.user, password=self.password,
                                           host=f"{self.server}:{self.port}")
        self.cursor = self.connection.cursor()
        return self.cursor


class PostgreSQL(DatabaseConnection):
    # @checkDBparameters
    def __init__(self, **db_params):
        secret = db_params[DatabaseParamsLabels.SECRET.name]
        db_params[DatabaseParamsLabels.USER.name] = secret['username']
        db_params[DatabaseParamsLabels.DB_INSTANCE.name] = secret['dbname']
        db_params[DatabaseParamsLabels.SERVER.name] = secret['host']
        db_params[DatabaseParamsLabels.PASSWORD.name] = secret['password']
        db_params[DatabaseParamsLabels.PORT.name] = secret['port']
        super().__init__(**db_params)

    def __enter__(self):
        self.connection = psycopg2.connect(user=self.user, password=self.password, host=self.server, port=self.port,
                                           database=self.db_instance)
        self.cursor = self.connection.cursor()
        return self.cursor




db_connection_class = {
    DatabaseTypesLabels.ORAClE.value: Oracle,
    DatabaseTypesLabels.SYBASE.value: Sybase,
    DatabaseTypesLabels.POSTGRES.value: PostgreSQL
}


def db_connection_factory(env, db_params_dict_name):
    #TBD : Will have to change secret label in config
    db_params_dict = ENVS[env][db_params_dict_name].copy()
    db_type = db_params_dict[DatabaseParamsLabels.DATABASE_TYPE.value]

    secret = get_secret(db_params_dict[DatabaseParamsLabels.SECRET.value], env)
    assume_role_id = ENVS[env][DatabaseParamsLabels.ASSUME_ROLE.value]

    connection = db_connection_class.get(db_type)

    db_params = {DatabaseParamsLabels.ASSUME_ROLE.name: assume_role_id,
                 DatabaseParamsLabels.SECRET.name: secret}

    db_params_dict.pop(DatabaseParamsLabels.SECRET.value)

    for key, value in db_params_dict.items():
        db_params[DatabaseParamsLabels(key).name] = value



    return connection(**db_params)


def is_table_exists(cursor, table_name):
    cursor.execute("select exists( SELECT 1 AS result FROM information_schema.tables "
                   " WHERE   table_name='{}'".format(table_name))
    return cursor.fetchone()[0]


def load_from_db_into_csv(env, db_params_dict_name, header, sql_query, csv_file_name):
    connection = db_connection_factory(env, db_params_dict_name)
    with connection as cursor, open(csv_file_name, 'w') as outputfile:
        outputfile.write(header + '\n')
        csv_writer = csv.writer(outputfile, lineterminator='\n')
        cursor.execute(sql_query)
        rows = cursor.fetchall()
        csv_writer.writerows(rows)
    return len(rows)
