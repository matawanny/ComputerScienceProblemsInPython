from cm_commons.cron import retrieve_enum_file_path
from cm_commons.db import connect_to_cm_master, recreate_table
from cm_commons.models.sqlalchemy.client_master_models import *

# create CM connection
engine, session = connect_to_cm_master()


def _pre_process_enum(engine, model, enum_file):
    """
    Helper function to drop table by model, then pull file path for opening & reading
    :param engine:
    :param model:
    :param enum_file:
    :return:
    """
    # recreate currency table
    recreate_table(Base, engine, model.__tablename__)
    # logger.debug('recreated {}'.format(model.__tablename__))

    # process currency file
    # logger.info('running {} enum sync from ENUM file to CM'.format(model.__tablename__))
    return retrieve_enum_file_path(enum_file)


def process_address_type_file(engine, session):
    """
    Process Address Type ENUM file to supplied database
    :param engine:
    :param session:
    :return:
    """
    # drop table, get path for ENUM data
    path = _pre_process_enum(engine, AddressType, 'address_type_enum.csv')

    # open file, processing each line as a new record
    with open(path, 'rU') as f_in:
        # skip header
        f_in.readline()
        for line in f_in:
            line = line.strip().split(',')

            # create object using SQLA model
            addy_type = AddressType(
                address_type_id=int(line[0]),
                address_type_name=line[1],
            )
            session.add(addy_type)
    session.commit()


def process_aggregator_file(engine, session):
    """
    Process Aggregator ENUM file to supplied database
    :param engine:
    :param session:
    :return:
    """
    # drop table, get path for ENUM data
    path = _pre_process_enum(engine, Aggregator, 'aggregator_enum.csv')

    # open file, processing each line as a new record
    with open(path, 'rU') as f_in:
        # skip header
        f_in.readline()
        for line in f_in:
            line = line.strip().split(',')

            # create object using SQLA model
            aggregator = Aggregator(
                aggregator_id=int(line[0]),
                aggregator_name=line[1]
            )
            session.add(aggregator)
    session.commit()


def process_channel_file(engine, session):
    """
    Process Channel ENUM file to supplied database
    :param engine:
    :param session:
    :return:
    """
    # drop table, get path for ENUM data
    path = _pre_process_enum(engine, Channel, 'channel_enum.csv')

    # open file, processing each line as a new record
    with open(path, 'rU') as f_in:
        # skip header
        f_in.readline()
        for line in f_in:
            line = line.strip().split(',')

            # create object using SQLA model
            channel = Channel(
                channel_id=line[0],
                sf_channel_id=line[1],
                channel_name=line[2],
                parent_channel_id=line[3] if line[3] else None,
                parent_sf_channel_id=line[4] if line[4] else None
            )
            session.add(channel)
    session.commit()


def process_client_type_file(engine, session):
    """
    Process Channel ENUM file to supplied database
    :param engine:
    :param session:
    :return:
    """
    # drop table, get path for ENUM data
    path = _pre_process_enum(engine, ClientType, 'client_type_enum.csv')

    # open file, processing each line as a new record
    with open(path, 'rU') as f_in:
        # skip header
        f_in.readline()
        for line in f_in:
            line = line.strip().split(',')
            line = [l.strip() for l in line]

            # create object using SQLA model
            client_type = ClientType(
                client_type_id=line[0],
                client_type_name=line[1],
                parent_id=line[2] if line[2] else None,
            )
            session.add(client_type)
    session.commit()


def process_currency_file(engine, session):
    """
    Process Currency ENUM file to supplied database
    :param engine:
    :param session:
    :return:
    """
    # drop table, get path for ENUM data
    path = _pre_process_enum(engine, Currency, 'currency_enum.csv')

    # open file, processing each line as a new record
    with open(path, 'rU') as f_in:
        # skip header
        f_in.readline()
        for line in f_in:
            line = line.strip().split(',')

            # create object using SQLA model
            currency = Currency(
                currency_id=int(line[0]),
                currency_name=line[1],
                currency_iso3_code=line[2]
            )
            session.add(currency)
    session.commit()


def process_country_file(engine, session):
    """
    Process Country ENUM file to supplied database
    :param engine:
    :param session:
    :return:
    """
    # drop table, get path for ENUM data
    path = _pre_process_enum(engine, Country, 'country_enum.csv')

    # open file, processing each line as a new record
    with open(path, 'rU') as f_in:
        # skip header
        f_in.readline()
        for line in f_in:
            line = line.strip().split(',')

            # create object using SQLA model
            country = Country(
                country_id=int(line[0]),
                country_name=line[1],
                country_iso3_code=line[2]
            )
            session.add(country)
    session.commit()


def process_email_type_file(engine, session):
    """
    Process Email Type ENUM file to supplied database
    :param engine:
    :param session:
    :return:
    """
    # drop table, get path for ENUM data
    path = _pre_process_enum(engine, EmailType, 'email_type_enum.csv')

    # open file, processing each line as a new record
    with open(path, 'rU') as f_in:
        # skip header
        f_in.readline()
        for line in f_in:
            line = line.strip().split(',')

            # create object using SQLA model
            email_type = EmailType(
                email_type_id=int(line[0]),
                email_type_name=line[1],
                hierarchy=int(line[2])
            )
            session.add(email_type)
    session.commit()


def process_entity_type_file(engine, session):
    """
    Process Entity Type ENUM file to supplied database
    :param engine:
    :param session:
    :return:
    """
    # drop table, get path for ENUM data
    path = _pre_process_enum(engine, EntityType, 'entity_type_enum.csv')

    # open file, processing each line as a new record
    with open(path, 'rU') as f_in:
        # skip header
        f_in.readline()
        for line in f_in:
            line = line.strip().split(',')

            # create object using SQLA model
            entity_type = EntityType(
                entity_type_id=line[0],
                entity_type_name=line[1],
            )
            session.add(entity_type)
    session.commit()


def process_money_type_file(engine, session):
    """
    Process Money Type ENUM file to supplied database
    :param engine:
    :param session:
    :return:
    """
    # drop table, get path for ENUM data
    path = _pre_process_enum(engine, MoneyType, 'money_type_enum.csv')

    # open file, processing each line as a new record
    with open(path, 'rU') as f_in:
        # skip header
        f_in.readline()
        for line in f_in:
            line = line.strip().split(',')

            # create object using SQLA model
            money_type = MoneyType(
                money_type_id=line[0],
                money_type_desc=line[1]
            )
            session.add(money_type)
    session.commit()


def process_origin_file(engine, session):
    """
    Process Origin ENUM file to supplied database
    :param engine:
    :param session:
    :return:
    """
    # drop table, get path for ENUM data
    path = _pre_process_enum(engine, Origin, 'origin_enum.csv')

    # open file, processing each line as a new record
    with open(path, 'rU') as f_in:
        # skip header
        f_in.readline()
        for line in f_in:
            line = line.strip().split(',')

            # create object using SQLA model
            origin = Origin(
                origin_id=int(line[0]),
                origin_name=line[1]
            )
            session.add(origin)
    session.commit()


def process_phone_type_file(engine, session):
    """
    Process Phone Type ENUM file to supplied database
    :param engine:
    :param session:
    :return:
    """
    # drop table, get path for ENUM data
    path = _pre_process_enum(engine, PhoneType, 'phone_type_enum.csv')

    # open file, processing each line as a new record
    with open(path, 'rU') as f_in:
        # skip header
        f_in.readline()
        for line in f_in:
            line = line.strip().split(',')

            # create object using SQLA model
            phone_type = PhoneType(
                phone_type_id=int(line[0]),
                phone_type_name=line[1],
                hierarchy=int(line[2])
            )
            session.add(phone_type)
    session.commit()


def process_relationship_type_file(engine, session):
    """
    Process Relationship Type ENUM file to supplied database
    :param engine:
    :param session:
    :return:
    """
    # drop table, get path for ENUM data
    path = _pre_process_enum(engine, RelationshipType, 'relationship_type_enum.csv')

    # open file, processing each line as a new record
    with open(path, 'rU') as f_in:
        # skip header
        f_in.readline()
        for line in f_in:
            line = line.strip().split(',')

            # create object using SQLA model
            rel_type = RelationshipType(
                relationship_type_id=int(line[0]),
                relationship_type_desc=line[1],
                hierarchy=int(line[2])
            )
            session.add(rel_type)
    session.commit()


def process_territory_file(engine, session):
    """
    Process Territory ENUM file to supplied database
    :param engine:
    :param session:
    :return:
    """
    # drop table, get path for ENUM data
    path = _pre_process_enum(engine, Territory, 'territory_enum.csv')

    # open file, processing each line as a new record
    with open(path, 'rU') as f_in:
        # skip header
        f_in.readline()
        for line in f_in:
            line = line.strip().split(',')

            # create object using SQLA model
            territory = Territory(
                territory_id=int(line[0]),
                territory_name=line[1],
                channel_id=int(line[2])
            )
            session.add(territory)
    session.commit()


def process_territory_postal_xref_file(engine, session):
    """
    Process Territory ENUM file to supplied database
    :param engine:
    :param session:
    :return:
    """
    # drop table, get path for ENUM data
    path = _pre_process_enum(engine, ZipTerritory, 'territory_postal_xref_master.csv')

    # open file, processing each line as a new record
    batch = 0
    count = 0
    with open(path, 'rU') as f_in:
        # skip header
        f_in.readline()
        for line in f_in:
            line = line.strip().split(',')

            # create object using SQLA model
            zip_terr = ZipTerritory(
                country_id=int(line[0]),
                postal_code=line[1],
                territory_id=int(line[2])
            )
            session.add(zip_terr)
            count = count + 1
            if count % 1000 == 0:
                session.commit()
                count = 0
                batch = batch + 1
                # logger.info('batch {} persisted'.format(batch))
    session.commit()


if __name__ == '__main__':
    # process all files
    # process_address_type_file(engine, session)
    # process_aggregator_file(engine, session)
    process_channel_file(engine, session)
    # process_client_type_file(engine, session)
    # process_country_file(engine, session)
    # process_currency_file(engine, session)
    # process_email_type_file(engine, session)
    # process_entity_type_file(engine, session)
    # process_money_type_file(engine, session)
    # process_origin_file(engine, session)
    # process_phone_type_file(engine, session)
    # process_relationship_type_file(engine, session)
    # process_territory_file(engine, session)
    # process_territory_postal_xref_file(engine, session)
