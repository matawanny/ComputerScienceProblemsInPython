from botocore.exceptions import NoCredentialsError
from datetime import datetime
import os
import logging
import time

from cm_commons.db.cm_conn import create_cm_conn
from cm_commons.models.salesvision_model import FOPExport,MergeSummary
from cm_commons.models.sqlalchemy.client_master_models import Entity, EntityType
from cm_commons.cron.job_config import SECRET_NAME, REGION_NAME, CM_DB, CM_LOCATION, CM_PORT, CM_USER, CM_PWD, \
    FOLDER_TGT, FILE_PREFIX
from cm_commons.util.aws_secrets_manager import get_secret

try:
    from cm_commons.util.cloudwatch_util import *
except:
    print('not using cw logging, using default py logger')
    import logging

# connect to db using secrets manager or local credential file
try:
    secrets = get_secret(SECRET_NAME, REGION_NAME)
    engine, session = create_cm_conn(user=secrets['username'],
                                     pwd=secrets['password'],
                                     location=secrets['host'],
                                     port=secrets['port'],
                                     db=secrets['dbname'])
except NoCredentialsError:
    print('creating local connection to CM database')
    engine, session = create_cm_conn(user=CM_USER,
                                     pwd=CM_PWD,
                                     location=CM_LOCATION,
                                     port=CM_PORT,
                                     db=CM_DB)

# init logger
logger = logging.getLogger('salesvision_export')
logger.setLevel(logging.DEBUG)

# create time and dates for files
time_now = datetime.now()
file_date = time_now.strftime('%m_%d_%Y')
CREATE_USER = 'laz_cm_sv_api'

# blank file flag
BLANK_FILE_GEN = False


def _recurse_first_sv_parent(entity, parent_type):
    """
    Recursively find first Salesvision parent checking for SV ID and requested type
    :param entity:
    :param parent_type:
    :return:
    """
    # entity has
    if entity.parent_entity.salesvision_id and entity.parent_entity.entity_type_id == parent_type:
        return entity.parent_entity
    else:
        # end date on entity, find next alive parent
        return _recurse_first_sv_parent(entity.parent_entity, parent_type)


def generate_header_row(start_time, end_time):
    """
    Generate a header row for each SalesVision file
    Format: H|<date and time of the data>|<date and time data was sent>
    :param start_time:
    :param end_time:
    :return:
    """
    # TODO: what does date and time of data mean? what does time sent mean? (current time|completed time)?
    return 'H|{}|{}'.format(start_time, end_time)


def generate_trailer_row(record_count):
    """
    Generate a trailer row for each SalesVision file
    Format: T|<record count: contains the count of all records in the file, excluding the header/trailer records>
    :return:
    """
    return 'T|{}'.format(record_count)


def firm_data_extract():
    """
    Pull Firm level data from Client Master, then format into string properties
    :return:
    """
    if BLANK_FILE_GEN:
        return []

    # pull firm data from client master
    ent_type = session.query(EntityType).filter_by(entity_type_name='Firm').first()
    results = session.query(Entity).filter_by(entity_type_id=ent_type.entity_type_id).all()

    # create objects for data using SV FOP object
    firms = []
    # TODO: add validation
    for res in results:
        # populate data in object
        firm = FOPExport()
        firm.sv_firm_id = res.salesvision_id
        firm.firm_name = res.entity_name
        firm.address_line_1 = res.entity_address[0].street_address_1 if res.entity_address else None
        firm.address_line_2 = res.entity_address[0].street_address_2 if res.entity_address else None
        firm.address_city = res.entity_address[0].city if res.entity_address else None
        firm.address_state = res.entity_address[0].state if res.entity_address else None
        firm.address_zipcode = res.entity_address[0].postal_code if res.entity_address else None
        firm.address_country = res.entity_address[0].country if res.entity_address else None
        firm.crm_firm_id = str(res.persistence_id)
        firm.event_code = 'U'  # note: this will temporarily be hard coded to 'U'
        firm.crm_service_request_id = None
        firm.create_date = res.created_at if res.created_at else str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        firm.create_user = CREATE_USER
        firm.maintenance_date = res.updated_at if res.created_at else None
        firm.maintenance_user = None

        # convert object to str rep and append
        firms.append(firm.firm_format())
    return firms


def office_data_extract():
    """
    Pull Office level data from Client Master, then format into string properties
    :return:
    """
    if BLANK_FILE_GEN:
        return []

    # pull office data from client master
    ent_type = session.query(EntityType).filter_by(entity_type_name='Office').first()
    results = session.query(Entity).filter_by(entity_type_id=ent_type.entity_type_id).limit(10).all()

    # create objects for data using SV FOP object
    offices = []
    # TODO: add validation
    for res in results:
        try:
            # populate data in object
            office = FOPExport()

            # get current SV parent
            sv_parent_firm = _recurse_first_sv_parent(res, '301')

            office.sv_firm_id = sv_parent_firm.salesvision_id
            office.sv_office_id = res.salesvision_id if res.salesvision_id else None
            office.address_line_1 = res.entity_address[0].street_address_1
            office.address_line_2 = res.entity_address[0].street_address_2 if res.entity_address else None
            office.address_line_3 = None
            office.address_city = res.entity_address[0].city
            office.address_state = 'US-{}'.format(res.entity_address[0].state)
            office.address_zipcode = res.entity_address[0].postal_code
            office.address_country = res.entity_address[0].country
            office.crm_firm_id = sv_parent_firm.persistence_id
            office.crm_office_id = res.persistence_id
            office.event_code = 'U'  # note: this will temporarily be hard coded to 'U'
            office.crm_service_request_id = None
            office.create_date = res.created_at if res.created_at else str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            office.create_user = CREATE_USER
            office.maintenance_date = res.updated_at if res.created_at else None
            office.maintenance_user = None

            # convert object to str rep and append
            offices.append(office.office_format())
        except:
            print('error with office {}'.format(res.entity_id))
    return offices


def person_data_extract():
    """
    Pull Person level data from Client Master, then format into string properties
    :return:
    """
    if BLANK_FILE_GEN:
        return []

    # pull office data from client master
    ent_type = session.query(EntityType).filter_by(entity_type_name='Person').first()
    results = session.query(Entity).filter_by(entity_type_id=ent_type.entity_type_id).limit(5).all()

    # create objects for data using SV FOP object
    persons = []
    # TODO: add validation
    for res in results:
        try:
            # populate data in object
            person = FOPExport()

            # get current SV parents
            sv_parent_office = _recurse_first_sv_parent(res, '201')
            sv_parent_firm = _recurse_first_sv_parent(sv_parent_office, '301')

            person.sv_firm_id = sv_parent_firm.salesvision_id
            person.sv_office_id = sv_parent_office.salesvision_id
            person.sv_person_id = res.salesvision_id

            if ',' in res.entity_name:
                ent_name = res.entity_name.split(',')
                person.last_name = ent_name[0]
                person.first_name = ent_name[1]
                person.middle_name = ent_name[2] if len(ent_name) > 2 else None
            else:
                person.last_name = res.entity_name
                person.first_name = None
                person.middle_name = None
            person.broker_team = None  # TODO: will this be the team name that a person belongs to?
            person.crm_firm_id = sv_parent_firm.persistence_id
            person.crm_office_id = sv_parent_office.persistence_id
            person.crm_person_id = res.persistence_id
            person.event_code = 'U'  # note: this will temporarily be hard coded to 'U'
            person.crm_service_request_id = None
            person.person_status = 'C'  # TODO: this may need to be updated
            person.home_office_flag = None  # TODO: update this based on schema/spec
            person.phone_number = res.entity_phone[0].phone_number if res.entity_phone else None
            person.email_address = res.entity_email[0].email_address if res.entity_email else None
            person.crd_number = res.crd
            person.broker_rep_code = None
            person.create_date = res.created_at if res.created_at else str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            person.create_user = CREATE_USER
            person.maintenance_date = res.updated_at if res.created_at else None
            person.maintenance_user = None

            # convert object to str rep and append
            persons.append(person.person_format())
        except:
            print('error with person {}'.format(res.entity_id))
    return persons


def merge_data_extract():
    """
    Pull merge data from Client Master, then format into string properties
    :return:
    """
    if BLANK_FILE_GEN:
        return []

    # TODO: db call
    results = []

    merges = []
    for res in results:
        merge_record = MergeSummary()
        merge_record.merge_type = ''    # type of merge
        merge_record.sv_from_id = ''
        merge_record.sv_to_id = ''
        merge_record.crm_from_id = ''
        merge_record.crm_to_id = ''
        merge_record.crm_service_request_id = None

        merges.append(merge_record.merge_format())
    return merges


def write_to_file(file_name, start_time, record_count, data):
    """
    Write header, trailer, and data to file using start & end times and record count
    :param file_name:
    :param start_time:
    :param end_time:
    :param record_count:
    :param data:
    :return:
    """
    print('writing {} ...'.format(file_name))
    with open(file_name, 'w', encoding='utf-8') as f_out:
        header = generate_header_row(str(start_time), str(datetime.now()))
        trailer = generate_trailer_row(record_count)

        # write to file
        f_out.write(header + '\n')
        for row in data:
            f_out.write(row + '\n')
        f_out.write(trailer)


def process_firm():
    """
    Process entire firm file
    :return:
    """
    # pull data and process
    data = firm_data_extract()
    record_count = len(data)

    # write data to file
    write_to_file(FILE_PREFIX + 'firm_profile_{}'.format(file_date), time_now, record_count, data)


def process_office():
    """
    Process entire office file
    :return:
    """
    # pull data and process
    data = office_data_extract()
    record_count = len(data)

    # write data to file
    write_to_file(FILE_PREFIX + 'office_profile_{}'.format(file_date), time_now, record_count, data)


def process_person():
    """
    Process entire person file
    :return:
    """
    # pull data and process
    data = person_data_extract()
    record_count = len(data)

    # write data to file
    write_to_file(FILE_PREFIX + 'person_profile_{}'.format(file_date), time_now, record_count, data)


def process_merge_summary():
    """

    :return:
    """
    # TODO: determine how to pull merges
    data = []
    record_count = len(data)

    # write data to file
    write_to_file(FILE_PREFIX + 'merge_{}'.format(file_date), time_now, record_count, data)


def process_sales_person_profile():
    """
    :return:
    """
    # TODO: this
    data = []
    record_count = len(data)

    # write data to file
    write_to_file(FILE_PREFIX + 'sales_person_profile_{}'.format(file_date), time_now, record_count, data)


if __name__ == '__main__':
    """
    Generate files for salesvision export
    :return:
    """
    rel = os.path.abspath(os.path.join(os.getcwd(), FOLDER_TGT))
    if not os.path.exists(rel):
        os.mkdir(rel)

    # generate files
    # print('beginning processing for firm file')
    # process_firm()
    # print('beginning processing for office export file')
    # process_office()
    print('beginning processing for person export file')
    process_person()
    # process_merge_summary()
    # process_sales_person_profile()
