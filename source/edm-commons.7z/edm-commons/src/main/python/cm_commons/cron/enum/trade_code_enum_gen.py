# from botocore.exceptions import NoCredentialsError
import pandas as pd

from cm_commons.cron import retrieve_enum_file_path
from cm_commons.db import connect_to_cm_master

# create CM connection
engine, session = connect_to_cm_master()


SV_TRADE_CODE_MAPPING = """
drop table if exists sv_trade_code_enum;

create table sv_trade_code_enum 
as
    select 
        tc.trc_id as aggregator_trade_code, 
        tc.trc_trans_code_override, 
        tc.trc_trans_override_desc as trade_desc, 
        flow_type, 
        direction 
    from sv_tradecode_salesvision_trade_code_enum tc 
    left join sv_trans_code_to_flow df on tc.trc_trans_code_override = df.trans_code;
"""

TRADE_CODE_ENUM_MASTER = """
drop table if exists trade_code_enum;

create table trade_code_enum 
as
    SELECT 
        sv.aggregator_trade_code::varchar, sv.trade_desc, sv.flow_type, direction,
        (SELECT aggregator_id FROM aggregator where aggregator_name = 'SalesVision')::varchar as aggregator_id
    FROM sv_trade_code_enum sv
    UNION 
    SELECT 
        ldw.aggregator_trade_code, ldw.trade_desc, ldw.flow_type, '1' as direction,
        (SELECT aggregator_id FROM aggregator where aggregator_name = 'LDW')::varchar as aggregator_id
    FROM ldw_trade_code_enum ldw
    UNION
    SELECT 
        ai.aggregator_trade_code, ai.trade_desc, ai.flow_type, '1' as direction,
        (SELECT aggregator_id FROM aggregator where aggregator_name = 'Alternative Investments')::varchar as aggregator_id
    FROM ai_trade_code_enum ai
    UNION
    SELECT 
        ft.aggregator_trade_code, ft.trade_desc, ft.flow_type, '1' as direction,
        (SELECT aggregator_id FROM aggregator where aggregator_name = 'FishTank')::varchar as aggregator_id
    FROM ft_trade_code_enum ft
    UNION
    SELECT 
        rs.aggregator_trade_code::varchar, rs.trade_desc, rs.flow_type, '1' as direction,
        (SELECT aggregator_id FROM aggregator where aggregator_name = 'RegiStreet')::varchar as aggregator_id
    FROM registreet_active_trade_code_enum rs
"""


def load_enum_data_from_file(file_name, table_name):
    """
    Open ENUM file for loading into database
    :param file_name:
    :param table_name:
    :return:
    """
    with open(retrieve_enum_file_path(file_name), 'r') as f:
        data_df = pd.read_csv(f)
        data_df = data_df.applymap(str)
        data_df.to_sql(table_name, con=engine, index=False, index_label='id', if_exists='replace',
                       chunksize=100, method='multi')


if __name__ == '__main__':
    # # load trade code enums from source
    # load_enum_data_from_file('sv_trade_code_enum.csv', 'sv_tradecode_salesvision_trade_code_enum')
    # print('sv raw trade codes loaded')

    load_enum_data_from_file('sv_trans_code_to_flow.csv', 'sv_trans_code_to_flow')
    print('sv desc trade codes loaded')

    load_enum_data_from_file('ai_trade_code_enum.csv', 'ai_trade_code_enum')
    print('ai trade codes loaded')

    load_enum_data_from_file('ldw_trade_code_enum.csv', 'ldw_trade_code_enum')
    print('ldw trade codes loaded')

    load_enum_data_from_file('ft_trade_code_enum.csv', 'ft_trade_code_enum')
    print('ft trade codes loaded')

    load_enum_data_from_file('registreet_active_trade_code_enum.csv', 'registreet_active_trade_code_enum')
    print('registreet active trade codes loaded')

    # create sv trade code enum
    engine.execute(SV_TRADE_CODE_MAPPING)
    print('created sv trade code mapping as a view')

    # create trade code enum master
    engine.execute(TRADE_CODE_ENUM_MASTER)
    print('created trade code enum master')
