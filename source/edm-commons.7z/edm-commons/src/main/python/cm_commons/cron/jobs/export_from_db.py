import csv
from cm_commons.db import connect_to_cm_master
from cm_commons.models.sqlalchemy import sql_classes

# create CM connection
engine, session = connect_to_cm_master()


if __name__ == '__main__':
    all_tables = engine.execute('SELECT * FROM pg_catalog.pg_tables where schemaname = \'public\'')

    for tbl in all_tables:
        # get current table name
        curr_tbl = tbl[1]
        print('processing {}...'.format(curr_tbl))

        # query for columns
        cols = engine.execute('SELECT * FROM information_schema.columns '
                              'WHERE table_schema = \'public\'  AND table_name = \'{}\''.format(curr_tbl))
        cols_list = [x[3].strip() for x in cols]

        data = engine.execute('SELECT * FROM {}'.format(curr_tbl))

        # write columns and data to file
        outfile = open('{}.csv'.format(curr_tbl), 'w', newline='')
        outcsv = csv.writer(outfile)
        outcsv.writerow(cols_list)
        for x in data:
            row = [y for y in x]
            outcsv.writerow(row)
        outfile.close()
