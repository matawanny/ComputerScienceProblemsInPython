"""
Configuration file for the Salesvision Export process
"""
import os
import json

""" Export Config """
# paths & prefixes
FOLDER_TGT = 'sv_export'
FILE_PREFIX = FOLDER_TGT + '/TEST_crm_'

""" Connection Config """
# AWS secrets manager config
SECRET_NAME = 'edmcm_rds_api'
REGION_NAME = 'us-east-2'

# bucket config
BUCKET_NAME = 'lazard-emr-test-data'

# Client Master Local DB config
CM_DB = None
CM_LOCATION = None
CM_PORT = None
CM_USER = None
CM_PWD = None
AMG_PWD = None

LOCAL_CRED_STORE = os.path.dirname(os.path.abspath(__file__)) + '/cred.json'
if os.path.isfile(LOCAL_CRED_STORE):
    with open(os.path.dirname(os.path.abspath(__file__)) + '/cred.json', 'r') as f:
        creds = json.load(f)

    env = 'test'
    CM_DB = creds[env]['db']
    CM_LOCATION = creds[env]['location']
    CM_PORT = creds[env]['port']
    CM_USER = creds[env]['user']
    CM_PWD = creds[env]['pwd']
    AMG_PWD = creds['amg_pwd']
