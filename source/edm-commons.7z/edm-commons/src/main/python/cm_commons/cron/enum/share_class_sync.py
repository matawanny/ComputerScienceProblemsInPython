from botocore.exceptions import NoCredentialsError

from cm_commons.cron import BATCH_SIZE, SHARE_CLASS_QUERY
from cm_commons.cron.job_config import AMG_PWD
from cm_commons.db import connect_to_cm_master, recreate_table
from cm_commons.db.connectors.oracle_connector import connect_to_oracle
from cm_commons.models.sqlalchemy.base import Base
from cm_commons.models.sqlalchemy.client_master_models import ShareClass
from cm_commons.util.aws_secrets_manager import get_secret


# create CM connection
engine, session = connect_to_cm_master()

try:
    amg_secret = get_secret('edmcm_amg', 'us-east-2')
    amg_conn = connect_to_oracle('READONLY', amg_secret, '10.56.25.148', 1501, 'ORPGEN01')
except NoCredentialsError:
    amg_conn = connect_to_oracle('READONLY', AMG_PWD, '10.56.25.148', 1501, 'ORPGEN01')
    amg_cursor = amg_conn.cursor()


def share_class_sync():
    """
    Process that will sync PDB data with Client Master's Share Class object
    """
    # poll pdb for share class data
    results = amg_cursor.execute(SHARE_CLASS_QUERY).fetchall()

    # create ShareClass objects for each record
    for i, res in enumerate(results):
        sc = ShareClass(
            share_class_id=res[0],
            vehicle_type_id=res[1],
            product_id=res[2],
            vehicle_type_desc=res[3],
            product_name=res[4],
            share_class_name=res[5],
            status=res[6],
            currency=res[7],
            ISIN=res[8],
            CUSIP=res[9],
            ticker=res[10],
            APIR_code=res[11],
            SSALUR=res[12],
            PMF_ID=res[13],
            sub_strategy_id=res[14],
            category_id=res[15],
            category_desc=res[16],
        )
        session.add(sc)
        if (i + 1) % BATCH_SIZE == 0:
            # logger.info('persisting {} records to {} ...'.format(BATCH_SIZE, ShareClass.__tablename__))
            session.commit()
    session.commit()


if __name__ == '__main__':
    # recreate share class table
    recreate_table(Base, engine, ShareClass.__tablename__)
    # logger.debug('recreated {}'.format(ShareClass.__tablename__))

    # pull share classes from AMG
    # logger.info('running share class enum sync from AMG to CM')
    share_class_sync()
