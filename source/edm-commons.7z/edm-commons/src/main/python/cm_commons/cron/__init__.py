import boto3

from cm_commons.cron.job_config import BUCKET_NAME

# batch size for commits
BATCH_SIZE = 100

# query to sync share classes from AMG
SHARE_CLASS_QUERY = 'select SHARE_CLASS_ID, VEHICLE_TYPE_ID, PRODUCT_ID, VEHICLE_TYPE_DESC, PRODUCT_NAME, ' \
                    'SHARE_CLASS_NAME, STATUS, CURRENCY_ID, ISIN, CUSIP, TICKER, APIR_CODE, SSALUR, PMF_ID, ' \
                    'SUB_STRATEGY_ID, category_id, category_desc from amv_mktg_share_class_detailed'


def retrieve_enum_file_path(file_name):
    """
    Return path to file, depending which environment is currently being used
    :return:
    """
    try:
        # connect to S3, download file
        s3 = boto3.resource('s3')
        s3.Bucket('lazard-emr-test-data').download_file('cm-enum/' + file_name, '../tmp_enums/{}'.format(file_name))

        return '../tmp_enums/{}'.format(file_name)
    except Exception:
        return '../tmp_enums/{}'.format(file_name)
