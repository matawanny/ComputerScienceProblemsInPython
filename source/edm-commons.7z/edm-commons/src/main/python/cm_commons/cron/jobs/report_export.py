import csv
import os

from cm_commons.db import connect_to_cm_master

# create CM connection
engine, session = connect_to_cm_master()

stg_switch = 'stg_2166'

if __name__ == '__main__':
    # drop table if exists
    engine.execute(f'drop table if exists {stg_switch}_report;')

    # create report table
    print(f'creating {stg_switch} report table')
    report_sql = f"""
    CREATE TABLE {stg_switch}_report
    AS 
        SELECT aggregator_name, agreement_type, ent.salesforce_id AS asset_owner, agr.agreement_id, currency_iso3_code, amount::float, as_of_date, origin_id
        FROM {stg_switch}_entity ent
        JOIN {stg_switch}_agreement_entity_xref xref
            ON ent.entity_id = xref.entity_id
        JOIN (             (
                            select 'agreement' as agreement_type, agreement_id, agreement_name, account_number, channel_id, money_type_id, firm_type_id, benchmark_id, ta_number, external_identifier, external_identifier_type, erisa_plan, preferred_currency_id, unit_holder_code, ipo_flag, ocio_flag, inception_date, ended_at, origin_id, aggregator_id, created_at, updated_at, etl_source, enriched_at, error, nullability_error, typecast_error, null as parent_agreement_id --, external_agreement_id 
                            from {stg_switch}_agreement
                          )
                        UNION
                          (
                            select 'sub_agreement' as agreement_type, agreement_id, agreement_name, account_number, channel_id, money_type_id, null as firm_type_id, benchmark_id, ta_number, external_identifier, external_identifier_type, erisa_plan, preferred_currency_id, unit_holder_code, ipo_flag, ocio_flag, inception_date, ended_at, origin_id, aggregator_id, created_at, updated_at, etl_source, enriched_at, error, nullability_error, typecast_error, parent_agreement_id--, external_agreement_id
                            from {stg_switch}_sub_agreement
                          )) agr
            ON agr.agreement_id = xref.agreement_id
        JOIN (
                SELECT aum.* FROM {stg_switch}_aum aum
                JOIN 
                    ( SELECT agreement_id, max(as_of_date) max_date
                    FROM {stg_switch}_aum
                    GROUP BY agreement_id ) s
                ON s.agreement_id = aum.agreement_id 
                AND s.max_date = aum.as_of_date
            ) aum
            ON aum.agreement_id = agr.agreement_id
        JOIN aggregator agg
            ON agg.aggregator_id::text = agr.aggregator_id
        JOIN currency_enum cur
            ON cur.currency_id::text = aum.currency_id
        WHERE xref.relationship_type_id = '100';
    """
    engine.execute(report_sql)

    # get origin list
    origin_list = engine.execute(f'SELECT origin_id FROM {stg_switch}_report GROUP BY origin_id')

    # make report dump location
    report_dir = f'{stg_switch}_reports'
    if not os.path.exists(report_dir):
        os.makedirs(report_dir)

    for origin in origin_list:
        org = origin[0]
        sql = f"""
        SELECT *, o.origin_name
        FROM stg_2166_report rep
        JOIN origin o
            ON o.origin_id::text = rep.origin_id
        WHERE rep.origin_id in ('{org}')
        """

        data = engine.execute(sql)

        # write columns and data to file
        f_name = f'{stg_switch}_origin_{org}.csv'
        outfile = open(report_dir + '/' + f_name, 'w', newline='')
        outcsv = csv.writer(outfile)

        # dump column titles (optional)
        print(f'dumping {org}')
        outcsv.writerow(x[0] for x in data.cursor.description)
        # dump rows
        outcsv.writerows(data.fetchall())
        outfile.close()
