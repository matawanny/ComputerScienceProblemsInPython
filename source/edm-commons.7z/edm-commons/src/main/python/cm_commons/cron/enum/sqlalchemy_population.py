from cm_commons.db import connect_to_cm_master, recreate_table
from cm_commons.models.sqlalchemy.base import Base


# create CM connection
engine, session = connect_to_cm_master()


MODELS_TO_CREATE = [
    'agreement',
    'agreement_entity_xref',
    'agreement_pmf_xref',
    'aum',
    'entity',
    'entity_address_xref',
    'entity_email_xref',
    'entity_phone_xref',
    'entity_team_xref',
    'sales_owner_agreement_xref',
    'sub_agreement',
    'trade'
]

if __name__ == '__main__':
    # loop through models and create as necessary
    for model in Base.metadata.sorted_tables:
        if model.name in MODELS_TO_CREATE:
            recreate_table(Base, engine, model.name)
