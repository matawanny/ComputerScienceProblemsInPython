from datetime import datetime

from cm_commons.db import connect_to_cm_master, recreate_table
from cm_commons.models.sqlalchemy.misc_models import Base, FXRate
from cm_commons.util.currency_util import currency_date_conversion
from cm_commons.util.date_util import datetime_range

TARGET_CURRENCIES = ['AUD', 'CAD', 'CHF', 'DKK', 'EUR', 'GBP', 'HKD', 'JPY', 'KRW', 'NOK', 'NZD', 'SGD', 'SEK',
                     'AED', 'USD']

if __name__ == '__main__':
    # connect to CM
    engine, session = connect_to_cm_master()

    # recreate table upon load
    recreate_table(Base, engine, FXRate.__tablename__)

    # define dates
    start_date = datetime(2019, 1, 1)
    end_date = datetime.today()

    # create string version of date range
    dates = list(datetime_range(start=start_date, end=end_date))
    dates = [d.strftime('%m/%d/%Y') for d in dates]
    date_range = ', '.join(f"'{k}'" for k in dates)
    currs = ', '.join(f"'{k}'" for k in TARGET_CURRENCIES)

    # poll sybase to get conversions and save in CM
    print('capturing FX rates')
    fx_rates = currency_date_conversion(date_range, 'USD', currs)

    print('saving to CM...')
    session.add_all(fx_rates)
    session.commit()
    session.close()
