from cm_commons.util.system import env

if env != 'emr':
    def build_session(app_name):
        print("Dummy Spark Session")
    pass

else:
    from pyspark.sql import SparkSession

    def build_session(app_name):
        spark = SparkSession.builder \
            .appName(app_name) \
            .getOrCreate()

        ## Added these to shut SPARK UP
        logger = spark._jvm.org.apache.log4j
        logger.LogManager.getLogger("org").setLevel(logger.Level.ERROR)
        logger.LogManager.getLogger("akka").setLevel(logger.Level.ERROR)

        return spark

    # spark = SparkSession.builder \
    #     .appName("ETLSpark") \
    #     .getOrCreate()

    def get_spark(app_name='Pyspark'):
        return SparkSession.builder.appName(app_name).getOrCreate()
