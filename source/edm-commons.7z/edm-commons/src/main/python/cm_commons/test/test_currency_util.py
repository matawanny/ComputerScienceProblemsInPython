from datetime import datetime
import pytest

from cm_commons.util.currency_util import currency_date_conversion

# constants
RATE_DATE = '12/03/2018'
WEEKEND_RATE_DATE = '12/15/2018'
BAD_RATE_DATE = '2018/12/10'
CURRENT_CURRENCY = 'USD'
TARGET_CURRENCY = 'EUR'


def test_currency_conversion_with_weekday():
    """
    Use the currency conversion util to pull a conversion for a given day
    :return:
    """
    fx_rate = currency_date_conversion(RATE_DATE, CURRENT_CURRENCY, TARGET_CURRENCY)
    date_from_req = datetime.strptime(fx_rate[5], '%Y-%m-%d %H:%M:%S.%f').strftime('%m/%d/%Y')
    assert fx_rate[0] == TARGET_CURRENCY and \
           fx_rate[2] == CURRENT_CURRENCY and \
           date_from_req == RATE_DATE


def test_currency_conversion_with_weekday_and_persist():
    """
    Use the currency conversion util to pull a conversion for a given day
    :return:
    """
    fx_rate = currency_date_conversion(RATE_DATE, CURRENT_CURRENCY, TARGET_CURRENCY, persist=True)
    date_from_req = datetime.strptime(fx_rate[5], '%Y-%m-%d %H:%M:%S.%f').strftime('%m/%d/%Y')
    assert fx_rate[0] == TARGET_CURRENCY and \
           fx_rate[2] == CURRENT_CURRENCY and \
           date_from_req == RATE_DATE


def test_currency_conversion_with_weekend():
    """
    Use the currency conversion util to pull a conversion for a day that falls on the weekend; the database will not
    have 12/15, but the rate date should come back as 12/14
    :return:
    """
    fx_rate = currency_date_conversion(WEEKEND_RATE_DATE, CURRENT_CURRENCY, TARGET_CURRENCY)
    date_from_req = datetime.strptime(fx_rate[5], '%Y-%m-%d %H:%M:%S.%f').strftime('%m/%d/%Y')
    assert fx_rate[0] == TARGET_CURRENCY and \
           fx_rate[2] == CURRENT_CURRENCY and \
           date_from_req == '12/14/2018'


def test_currency_conversion_catch_bad_date():
    """
    Catch a bad date in the currency conversion
    :return:
    """
    with pytest.raises(ValueError):
        fx_rate = currency_date_conversion(BAD_RATE_DATE, CURRENT_CURRENCY, TARGET_CURRENCY)
        date_from_req = datetime.strptime(fx_rate[5], '%Y-%m-%d %H:%M:%S.%f').strftime('%m/%d/%Y')
        assert fx_rate[0] == TARGET_CURRENCY and \
               fx_rate[2] == CURRENT_CURRENCY and \
               date_from_req == RATE_DATE