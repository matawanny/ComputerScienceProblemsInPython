import pytest
from sqlalchemy.exc import IntegrityError

from cm_commons.models import Agreement, Entity
from cm_commons.test.models.default_test_values import *

"""
TODO:
Add tests for:
- incorrect field inputs/data validation on types
- double keys
- No parent/child
- 
"""


def test_insert_single_agreement_with_entity(db_session):
    """
    Create an Agreement with Entity present to demonstrate single agreement creation
    :param db_session:
    :return:
    """
    tmp_entity = Entity(
        entity_id=entity_id,
        entity_type_id=entity_type_id,
        entity_name=first_name + ' ' + last_name,
        aggregator_id=aggregator_id,
        fca_id=fca_id,
        client_type_id=client_type_id
    )

    tmp_agreement = Agreement(
        agreement_id=agreement_id,
        agreement_type=agreement_type,
        advisor_id=entity_id,
        channel_id=channel_id,
        platform_id=platform_id,
        ta_number=ta_number,
        dealer_number=dealer_number,
        money_type=money_type,
        external_identifier=external_identifier
    )

    db_session.add(tmp_entity)
    db_session.add(tmp_agreement)
    db_session.commit()
    db_session.flush()

    # assertions
    count = db_session.query(Agreement).count()
    db_item = db_session.query(Agreement).first()

    assert count == 1 and db_item.agreement_id == tmp_agreement.agreement_id


def test_insert_single_agreement_no_entity(db_session):
    """
    Insert a single Agreement into the database, will fail because entity does not exist
    :param db_session:
    :return:
    """
    tmp_agreement = Agreement(
        agreement_id=agreement_id,
        agreement_type=agreement_type,
        advisor_id=entity_id,
        channel_id=channel_id,
        platform_id=platform_id,
        ta_number=ta_number,
        dealer_number=dealer_number,
        money_type=money_type,
        external_identifier=external_identifier
    )

    with pytest.raises(IntegrityError):
        db_session.add(tmp_agreement)
        db_session.commit()
