import pytest
from sqlalchemy.exc import DataError, IntegrityError

from cm_commons.models import Agreement, Entity
from cm_commons.test.models.default_test_values import *

"""
TODO:
Add tests for:
- incorrect field inputs/data validation on types
- double keys
- No parent/child
- 
"""


def test_insert_single_entity(db_session):
    """
    Insert models Entity into database
    :param db_session:
    :return:
    """
    tmp_entity = Entity(
        entity_id=entity_id,
        entity_type_id=entity_type_id,
        entity_name=first_name + ' ' + last_name,
        aggregator_id=aggregator_id,
        fca_id=fca_id,
        client_type_id=client_type_id
    )
    db_session.add(tmp_entity)
    db_session.commit()
    db_session.flush()

    # assertions
    count = db_session.query(Entity).count()
    db_item = db_session.query(Entity).first()

    assert count == 1 and db_item.entity_id == tmp_entity.entity_id


def test_insert_entity_missing_non_null_data(db_session):
    """
    Attempt to create an entity without an ID and catch exception
    :param db_session:
    :return:
    """
    tmp_entity = Entity(
        entity_type_id=entity_type_id,
        entity_name=first_name + ' ' + last_name
    )

    with pytest.raises(IntegrityError):
        db_session.add(tmp_entity)
        db_session.commit()
        db_session.flush()


def test_insert_entity_with_wrong_data_type(db_session):
    """
    Cast the Entity Type ID to a string when it should be an INT
    :param db_session:
    :return:
    """
    tmp_entity = Entity(
        entity_id=entity_id,
        entity_type_id=entity_type_id,
        entity_name=first_name + ' ' + last_name,
        aggregator_id='aggregator_id',
        fca_id=fca_id,
        client_type_id=client_type_id
    )

    with pytest.raises(DataError):
        db_session.add(tmp_entity)
        db_session.commit()
        db_session.flush()


# TODO: why does this pass? How is this cast properly?
def test_insert_entity_with_data_type_cast(db_session):
    """
    Cast the Entity Type ID to a string when it should be an INT
    :param db_session:
    :return:
    """
    tmp_entity = Entity(
        entity_id=entity_id,
        entity_type_id=entity_type_id,
        entity_name=first_name + ' ' + last_name,
        aggregator_id=aggregator_id,
        fca_id=fca_id,
        client_type_id=client_type_id
    )
    db_session.add(tmp_entity)
    db_session.commit()
    db_session.flush()

    # assertions
    count = db_session.query(Entity).count()
    db_item = db_session.query(Entity).first()

    assert count == 1 and db_item.entity_type_id == entity_type_id


def test_insert_same_entity_twice(db_session):
    """
    Try to insert the same entity twice, will fail on primary key integrity error
    :param db_session:
    :return:
    """
    tmp_entity_1 = Entity(
        entity_id=entity_id,
        entity_type_id=entity_type_id,
        entity_name=first_name + ' ' + last_name,
        aggregator_id=aggregator_id,
        fca_id=fca_id,
        client_type_id=client_type_id
    )
    tmp_entity_2 = Entity(
        entity_id=entity_id,
        entity_type_id=entity_type_id,
        entity_name=first_name + ' ' + last_name,
        aggregator_id=aggregator_id,
        fca_id=fca_id,
        client_type_id=client_type_id
    )

    with pytest.raises(IntegrityError):
        db_session.add(tmp_entity_1)
        db_session.add(tmp_entity_2)
        db_session.commit()
        db_session.flush()


# todo: is this a bad models? should I be intentionally be avoiding the PK constraint
def test_insert_entity_with_agreement(db_session):
    """
    Insert database and related agreement
    :param db_session:
    :return:
    """
    tmp_entity = db_session.query(Entity).filter_by(entity_id=entity_id).first()
    if not tmp_entity:
        tmp_entity = Entity(
            entity_id=entity_id,
            entity_type_id=entity_type_id,
            entity_name=first_name + ' ' + last_name,
            aggregator_id=aggregator_id,
            fca_id=fca_id,
            client_type_id=client_type_id
        )
        db_session.add(tmp_entity)

    tmp_agreement = Agreement(
        agreement_id=agreement_id,
        agreement_type=agreement_type,
        advisor_id=entity_id,
        channel_id=channel_id,
        platform_id=platform_id,
        ta_number=ta_number,
        dealer_number=dealer_number,
        money_type=money_type,
        external_identifier=external_identifier
    )

    db_session.add(tmp_agreement)
    db_session.commit()
    db_session.flush()

    # assertions
    entity_count = db_session.query(Entity).count()
    agreement_count = db_session.query(Agreement).count()
    new_entity = db_session.query(Entity).first()

    assert entity_count == 1 and agreement_count == 1 and len(new_entity.agreements) == 1 \
           and new_entity.agreements[0].agreement_id == tmp_agreement.agreement_id
