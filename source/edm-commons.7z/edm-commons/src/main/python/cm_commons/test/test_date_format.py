from datetime import datetime


def date_formatter(date, pattern_in, pattern_out):
    """ Take given string date and pattern, convert to YYYY-mm-dd HH:MM:SS """
    return datetime.strptime(date, pattern_in).strftime(pattern_out)


def test_dt():
    d = date_formatter('10/11/2018', '%m/%d/%Y', '%Y-%m-%d %H:%M:%S')
    print(d)
