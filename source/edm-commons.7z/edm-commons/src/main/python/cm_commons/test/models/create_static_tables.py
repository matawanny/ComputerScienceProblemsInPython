from cm_commons.models import Aggregator, Channel, ClientType, Currency, EntityType, Group, Origin, ShareClass
from cm_commons.test.models.default_test_values import *


def populate_aggregator(session):
    """
    Populate System table with model data
    :param session:
    :return:
    """
    aggregator = Aggregator(
        aggregator_id=aggregator_id,
        aggregator_name=aggregator_name
    )
    session.add(aggregator)
    session.commit()
    session.flush()


def populate_channel(session):
    """
    Populate Channel tables with models data
    :param session:
    :return:
    """
    channel = Channel(
        channel_id=channel_id,
        channel_name=channel_name
    )
    session.add(channel)
    session.commit()
    session.flush()


def populate_client_type(session):
    """
    Populate Channel tables with models data
    :param session:
    :return:
    """
    client_type = ClientType(
        client_type_id=client_type_id,
        client_type_name=client_type_name
    )
    session.add(client_type)
    session.commit()
    session.flush()


def populate_currency(session):
    """
    Populate AUM Type Enum table with models data
    :param session:
    :return:
    """
    currency = Currency(
        currency_id=currency_id,
        currency_name=currency_name,
        currency_iso3_code=currency_iso3_name
    )
    session.add(currency)
    session.commit()
    session.flush()


def populate_entity_type_enum(session):
    """
    Populate Entity Type ENUM tables with models data
    :param session:
    :return:
    """
    entity_type = EntityType(
        entity_type_id=entity_type_id,
        entity_type_name=entity_type_name
    )
    session.add(entity_type)
    session.commit()
    session.flush()


def populate_group(session):
    """
    Populate Source table with model data
    :param session:
    :return:
    """
    group = Group(
        group_id=platform_id,
        group_name=platform_name
    )
    session.add(group)
    session.commit()
    session.flush()


def populate_origin(session):
    """
    Populate Source table with model data
    :param session:
    :return:
    """
    origin = Origin(
        origin_id=origin_id,
        origin_name=origin_name
    )
    session.add(origin)
    session.commit()
    session.flush()


def populate_share_class(session):
    """
    Populate Share Class Enum table with static data
    :param session:
    :return:
    """
    share_class = ShareClass(
        vehicle_type_id=vehicle_type_id,
        product_id=product_id,
        share_class_id=share_class_id,
        vehicle_type_desc=vehicle_type_desc,
        product_name=product_name,
        share_class_name=share_class_name,
        status=status,
        currency=currency_name,
        ISIN=ISIN,
        APIR_code=APIR_code,
        ticker=ticker,
        CUSIP=CUSIP
    )
    session.add(share_class)
    session.commit()
    session.flush()


def populate_all_static_tables(session):
    """
    Use helper functions above to populate static tables
    :return:
    """
    populate_aum_type(session)
    populate_aggregator(session)
    populate_channel(session)
    populate_client_type(session)
    populate_currency(session)
    populate_entity_type_enum(session)
    populate_platform(session)
    populate_origin(session)
    populate_share_class(session)
