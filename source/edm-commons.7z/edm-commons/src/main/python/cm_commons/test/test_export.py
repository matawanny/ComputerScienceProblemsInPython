from cm_commons.models.trg_files.xml_export import export_xml


def test_xml():
    tables = ['entity', 'agreement', 'portfolio', 'flow']
    xml = export_xml(tables)
