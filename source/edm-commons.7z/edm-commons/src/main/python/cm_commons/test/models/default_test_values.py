from datetime import datetime
"""
This file will be the central origin for model models values
"""

# entity values
entity_id = 123456
first_name = 'models'
last_name = 'name'
fca_id = 1234512

# agreement values
agreement_id = 1234561423
agreement_type = 'holdings'
ta_number = '6789'
dealer_number = 41658498
money_type = 'all cash baby'
external_identifier = 'external ID to somewhere probably the PDB'

# portfolio values
portfolio_id = 12345
external_type_id = 'some ID'

# aum values
aum_id = 1
aum = 100.41
as_of_date = datetime.now()

# flow values
flow_id = 1
inflow = 100.41
outflow = -10.8
start_date = datetime.now()
end_date = datetime.now()
transaction_code = 'TXN007'

# aggregator values
aggregator_id = 1
aggregator_name = 'models aggregator'

# origin values
origin_id = 1
origin_name = 'models origin'

# entity type values
entity_type_id = 1
entity_type_name = 'models entity'

# channel values
channel_id = 1
channel_name = 'models channel'

# aum type values
aum_type_id = 1
aum_type_name = 'a models aum type'

# currency values
currency_id = 1
currency_name = 'UNITED STATES DOLLAR'
currency_iso3_name = 'USD'

# share class enum values
vehicle_type_id = 1
product_id = 1
share_class_id = 1
vehicle_type_desc = 'vehicle desc'
product_name = 'a product name'
share_class_name = 'a share class name'
status = 'active'
ISIN = '001001'
CUSIP = 'LAMCUSIP13'
ticker = 'LAMX'
APIR_code = '100718B'

# platform values
platform_id = 1
firm_entity_id = 12345
platform_name = 'test_platform'

# group values
group_id = 1
group_name = 'test group'

# client type
client_type_id = 1
client_type_name = 'test client type'