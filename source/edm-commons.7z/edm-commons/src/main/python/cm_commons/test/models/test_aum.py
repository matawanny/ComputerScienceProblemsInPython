from cm_commons.models import Agreement, Entity, AUM
from cm_commons.test.models.default_test_values import *


def test_insert_single_aum_with_hierarchy(db_session):
    """
    Create an AUM record with a related Agreement, Portfolio, and Entity
    :param db_session:
    :return:
    """
    tmp_entity = Entity(
        entity_id=entity_id,
        entity_type_id=entity_type_id,
        entity_name=first_name + ' ' + last_name,
        aggregator_id=aggregator_id,
        fca_id=fca_id,
        client_type_id=client_type_id
    )

    tmp_agreement = Agreement(
        agreement_id=agreement_id,
        agreement_type=agreement_type,
        advisor_id=entity_id,
        channel_id=channel_id,
        platform_id=platform_id,
        ta_number=ta_number,
        dealer_number=dealer_number,
        money_type=money_type,
        external_identifier=external_identifier
    )

    tmp_aum = AUM(
        aum_id=aum_id,
        agreement_id=agreement_id,
        aum=aum,
        currency_id=currency_id,
        as_of_date=as_of_date,
        aum_type=aum_type_id,
        origin_id=origin_id,
        aggregator_id=aggregator_id
    )

    db_session.add(tmp_entity)
    db_session.add(tmp_agreement)
    db_session.add(tmp_aum)
    db_session.commit()
    db_session.flush()

    count = db_session.query(AUM).count()
    db_item = db_session.query(AUM).first()

    assert count == 1 and db_item.aum == aum
