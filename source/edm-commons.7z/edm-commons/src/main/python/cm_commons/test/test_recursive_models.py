import pytest
from sqlalchemy.orm import joinedload_all

from cm_commons.db.cm_conn import session
from cm_commons.models import Channel
from cm_commons.util.data_util import object_to_dict


# TODO: make these better tests


def test_channel_self_referential_by_parent_id():
    data = session.query(Channel).filter_by(channel_id=16).all()
    d = object_to_dict(data[0])
    print(data)


def test_channel_self_referential_by_child_id():
    data = session.query(Channel).filter_by(channel_name='Corporate 5').all()
    print(data)


def test_query_entire_tree_from_top():
    data = session.query(Channel).options(joinedload_all('related_channel')).\
        filter(Channel.channel_id == 3).first()
    print(data)


# def test_tree_traversal():
#     data = session.query(Channel).filter_by(channel_id=3).first()
#     d = full_tree_traversal(data)
#     print('data')
