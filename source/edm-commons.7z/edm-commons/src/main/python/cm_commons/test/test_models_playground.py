import pytest
import sqlalchemy

from cm_commons.db.cm_conn import session
from cm_commons.models import Agreement, Portfolio, Entity, Flow, Channel
from cm_commons.util.data_util import object_to_dict, unpack_objects

# todo: write better tests
# models variables (subject to change in db)
agreement_id = 5524390214248739400
portfolio_id = -6019716548998027333
entity_id = 'Off769655'
aum_port_id = -9220426164130345257


def test_linked_agreements():
    """
    Test to pull by agreement ID
    :return:
    """
    agreements = session.query(Agreement).filter_by(agreement_id=agreement_id).all()
    agg = object_to_dict(agreements[0])
    agreements = unpack_objects(agreements)

    assert len(agreements) == 1 and agreements[0]['agreement_id'] == agreement_id


def test_flow():
    data = session.query(Flow).filter_by(portfolio_id=portfolio_id).first()
    print(data)


def test_pagination_using_agreements():
    results = session.query(Agreement).limit(50)
    results.paginate(1, 20)
    print(results)


def test_sum_join_entity_to_flow():
    res = session.query(
        sqlalchemy.func.sum(sqlalchemy.cast(Flow.purchases, sqlalchemy.Float)),
        sqlalchemy.func.sum(Flow.redemptions)
    ).filter(
        Entity.entity_id == Agreement.advisor_id
    ).filter(
        Agreement.agreement_id == Portfolio.agreement_id
    ).filter(
        Portfolio.portfolio_id == Flow.portfolio_id
    ).filter(Entity.entity_id == 'Fir22990').first()

    print(res)
