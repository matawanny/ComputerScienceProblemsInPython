from cm_commons.models import Agreement, Entity, Flow
from cm_commons.test.models.default_test_values import *


def test_insert_single_positive_flow_with_hierarchy(db_session):
    """
    Create a Flow record with a related Agreement, Portfolio, and Entity
    :param db_session:
    :return:
    """
    tmp_entity = Entity(
        entity_id=entity_id,
        entity_type_id=entity_type_id,
        entity_name=first_name + ' ' + last_name,
        aggregator_id=aggregator_id,
        fca_id=fca_id,
        client_type_id=client_type_id
    )

    tmp_agreement = Agreement(
        agreement_id=agreement_id,
        agreement_type=agreement_type,
        advisor_id=entity_id,
        channel_id=channel_id,
        platform_id=platform_id,
        ta_number=ta_number,
        dealer_number=dealer_number
    )

    tmp_flow = Flow(
        flow_id=flow_id,
        agreement_id=agreement_id,
        inflow=inflow,
        start_date=start_date,
        end_date=end_date,
        aggregator_id=aggregator_id,
        origin_id=origin_id,
        transaction_code=transaction_code
    )

    db_session.add(tmp_entity)
    db_session.add(tmp_agreement)
    db_session.add(tmp_flow)
    db_session.commit()
    db_session.flush()

    count = db_session.query(Flow).count()
    db_item = db_session.query(Flow).first()

    assert count == 1 and db_item.inflow == inflow


def test_insert_single_negative_flow_with_hierarchy(db_session):
    """
    Create a Flow record with a related Agreement, Portfolio, and Entity
    :param db_session:
    :return:
    """
    tmp_entity = Entity(
        entity_id=entity_id,
        entity_type_id=entity_type_id,
        entity_name=first_name + ' ' + last_name,
        aggregator_id=aggregator_id,
        fca_id=fca_id,
        client_type_id=client_type_id
    )

    tmp_agreement = Agreement(
        agreement_id=agreement_id,
        agreement_type=agreement_type,
        advisor_id=entity_id,
        channel_id=channel_id,
        platform_id=platform_id,
        ta_number=ta_number,
        dealer_number=dealer_number
    )

    tmp_flow = Flow(
        flow_id=flow_id,
        agreement_id=agreement_id,
        outflow=outflow,
        start_date=start_date,
        end_date=end_date,
        aggregator_id=aggregator_id,
        origin_id=origin_id,
        transaction_code=transaction_code
    )

    db_session.add(tmp_entity)
    db_session.add(tmp_agreement)
    db_session.add(tmp_flow)
    db_session.commit()
    db_session.flush()

    count = db_session.query(Flow).count()
    db_item = db_session.query(Flow).first()

    assert count == 1 and db_item.inflow == inflow
