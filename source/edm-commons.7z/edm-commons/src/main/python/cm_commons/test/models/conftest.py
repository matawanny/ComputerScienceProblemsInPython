import pytest
from sqlalchemy.orm.session import sessionmaker


from cm_commons.db.cm_conn import create_cm_conn
from cm_commons.models import Base
from cm_commons.test.models.create_static_tables import populate_all_static_tables


@pytest.fixture(scope='session')
def connection():
    """
    Create models connection; drop and create all tables
    :return:
    """
    # connect to models database
    engine, session = create_cm_conn(db='edm_cm_test')
    Base.metadata.bind = engine
    conn = engine.connect()

    # drop tables and create new tables
    Base.metadata.drop_all()
    Base.metadata.create_all(engine)

    return conn


@pytest.fixture(scope='module')
def db_session(connection):
    """
    Create models session to pass around in
    :param connection:
    :return:
    """
    # create session bound to models connection
    Session = sessionmaker(bind=connection.engine)
    session = Session()

    # insert static table data
    populate_all_static_tables(session)

    # return session for use
    yield session

    # close session and teardown database
    session.close_all()
    Base.metadata.drop_all()
