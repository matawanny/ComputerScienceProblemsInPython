EDMCM_RDS = "edmcm_rds"
EDMCM_BUCKET  = "edmcm_bucket"
ENVIRONMENT = "Environment"
