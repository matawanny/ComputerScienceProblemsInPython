import time
import datetime
import boto3
from   boto3.dynamodb.conditions import Key

def gen_appid():
  jobid = int(round(time.time() * 1000))
  return str(jobid)

def logCmJob(dynamoDBTable="ClmasterJobStatus", **jobdata):
    dynamoDB = boto3.resource('dynamodb')
    table = dynamoDB.Table(dynamoDBTable)
    response = table.query(
        KeyConditionExpression=Key('jobid').eq(jobdata["jobid"])
    )
    items = response['Items']
    jobcount = len(items)
    #no existing job status entry. insert the record.
    if jobcount == 0:
        nowdate  =  datetime.datetime.now().strftime('%Y%m%d')
        jobdata["jobdate"] = nowdate
        table.put_item(
            Item=
                jobdata
        )
    # job exists, update with additional info
    else:
        item = items[0]
        item.update(jobdata)
        table.put_item(Item=item)

def getTime():
    return  datetime.datetime.now().strftime('%Y%m%d %H:%M:%S')
