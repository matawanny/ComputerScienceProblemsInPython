def object_to_dict(Model, unpack_all=True):
    """
    Takes a single SQLAlchemy Model and converts it to a dictionary
    `unpack_all` flag will convert and return any nested objects
    :param Model:
    :param unpack_all:
    :return:
    """
    # map a dictionary that will add column names and column values
    d = {c.name: getattr(Model, c.name, None) for c in Model.__table__.columns}

    if unpack_all:
        # get relationships from model mapping
        sql_relationships = Model.__mapper__.relationships

        # if relationships exist, convert sub objects
        if sql_relationships._data:
            # capture relationship name and use name to pull from current Model
            relationships = list(sql_relationships._data)
            for relation in relationships:
                children = getattr(Model, relation, None)

                # if no children exist for current relationship, continue
                if not children:
                    continue

                # if the children are not a list, convert to list to maintain JSON structure
                if not isinstance(children, list):
                    children = [children]

                # create a list of mapped dictionaries values for child objects
                child_vals = []
                for child in children:
                    child_d = {c.name: getattr(child, c.name, None) for c in child.__table__.columns}
                    child_vals.append(child_d)

                # add children to object
                d[relation] = child_vals

    return d


def unpack_objects(models, unpack_all=True):
    return [object_to_dict(m, unpack_all=unpack_all) for m in models]


# # todo: this
# # todo: https://stackoverflow.com/questions/4896104/creating-a-tree-from-self-referential-tables-in-sqlalchemy/4896292#4896292
# def full_tree_traversal(Model):
#     """
#     Takes a single SQLAlchemy Model and converts it to a dictionary
#     `unpack_all` flag will convert and return any nested objects
#     :param Model:
#     :param unpack_all:
#     :return:
#     """
#     # map a dictionary that will add column names and column values
#     d = {c.name: getattr(Model, c.name, None) for c in Model.__table__.columns}
#
#     # get relationships from model mapping
#     sql_relationships = Model.__mapper__.relationships
#
#     # if relationships exist, convert sub objects
#     if sql_relationships._data:
#         # capture relationship name and use name to pull from current Model
#         relationships = list(sql_relationships._data)
#
#         # grab parent and sub objects
#         parent_objects = [x for x in relationships if 'parent' in x]
#         sub_objects = [x for x in relationships if 'sub' in x]
#
#         # TODO: up the tree infinitely
#
#         # TODO: down the tree infinitely
#         for sub_obj in sub_objects:
#             # get current list of sub objects
#             related_objects = getattr(Model, sub_obj, None)
#
#             tmp = treeversal_helper(related_objects, sub_obj, [])
#             print(tmp)
#             # go through each sub object and check if there is a level below
#             # if yes: grab that sub_object and continue traversing
#             # else: continue
#             print(related_objects)
#         print(Model)
#
#     return d
#
#
# def treeversal_helper(objects, field_to_check, master):
#     # master = []
#     for obj in objects:
#         if getattr(obj, field_to_check, None):
#             treeversal_helper([obj], field_to_check, master)
#         else:
#             master.append({o.name: getattr(obj, o.name, None) for o in obj.__table__.columns})
#     return master
