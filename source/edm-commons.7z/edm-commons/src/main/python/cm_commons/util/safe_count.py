from cm_commons.colors import colors
SC_CONST = -1
def safe_count(df, count_bool=False, dummy_str=False):
    if count_bool:
        return df.count()
    else:
        if dummy_str:
            return "SAFE-COUNT"
        return SC_CONST

