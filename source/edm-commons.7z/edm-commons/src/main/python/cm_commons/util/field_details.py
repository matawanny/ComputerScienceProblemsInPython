"""
This file will maintain a list of nullability & any additional rules for our SQLAlchemy models.
These should map 1:1 for our models.
"""

# Encryption Definitions
IUO = {"encrypted": "Internal Use Only", 'skey': False}
RD = {"encrypted": "Restricted Data", 'skey': False}
CD = {"encrypted": "Confidential Data", 'skey': False}
IND = {"encrypted": "Index", 'skey': False}
NO = {"encrypted": "None", 'skey': False}
UND = {"encrypted": "None", 'skey': False}

# aggregator
aggregator_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
aggregator_name = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}

# agreement
agreement_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
agreement_type = {'required': ['none'], 'encrypted': 'Internal Use', 'skey': False}
agreement_name = {'required': ['amg'], 'encrypted': 'Internal Use', 'skey': False}
account_number = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
channel_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
money_type_id = {'required': ['sf'], 'encrypted': 'Internal Use Only', 'skey': False}
firm_type_id = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
benchmark_id = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
ta_number = {'required': ['sv_holding'], 'encrypted': 'Internal Use Only', 'skey': False}
external_identifier = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
external_identifier_type = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
account_salesforce_id = {'required': ['sf'], 'encrypted': 'Internal Use Only', 'skey': False}
erisa_plan = {'required': ['ai', 'ct'], 'encrypted': 'Internal Use Only', 'skey': False}
preferred_currency_id = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
unit_holder_code = {'required': ['registreet'], 'encrypted': 'Internal Use Only', 'skey': False}
ipo_flag = {'required': ['ai', 'ct'], 'encrypted': 'Internal Use Only', 'skey': False}
ocio_flag = {'required': ['sf'], 'encrypted': 'Internal Use Only', 'skey': False}
inception_date = {'required': ['amg',  'amgwm', 'ai', 'ct'], 'encrypted': 'Internal Use Only', 'skey': False}
origin_id = {'required': ['sv_firm', 'sv_office', 'sv_person', 'sv_holding'], 'encrypted': 'Internal Use Only', 'skey': False}
external_agreement_id = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}

# agreement_entity_xref
agreement_entity_xref_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
# sub_agreement_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey}: False
ae_entity_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False, 'fkey_of_pkey': True}
ae_agreement_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False,  'fkey_of_pkey': True}
relationship_type_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False, "default": 100}
primary_relationship = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
external_entity_id = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}

# agreement_pmf_xref
pmf_symbol = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
# fund_yn = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey}: False
fund_name = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
share_class_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
share_class_name = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}

# aum
aum_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
# sub_agreement_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey}: False
currency_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
amount = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
raw_amount = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
usd_amount = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
as_of_date = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}

# entity
entity_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'default': '0', 'skey': False}
persistence_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': True}
entity_type_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
entity_name = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
group_id = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
parent_id = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False, 'fkey_of_pkey': True}
crm_id = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
salesforce_id = {'required': ['sf'], 'encrypted': 'Internal Use Only', 'default': '003Xrsadfw34', 'skey': False}
salesvision_id = {'required': ['sv_firm', 'sv_office', 'sv_person'], 'encrypted': 'Internal Use Only', 'skey': False}
fishtank_id = {'required': ['ft'], 'encrypted': 'Internal Use Only', 'skey': False}
ai_investor_id = {'required': ['ai'], 'encrypted': 'Internal Use Only', 'skey': False}
ai_subinvestor_id = {'required': ['ai'], 'encrypted': 'Internal Use Only', 'skey': False}
fca_id = {'required': ['ft'], 'encrypted': 'Internal Use Only', 'skey': False}
employee_id = {'required': ['hr'], 'encrypted': 'Internal Use Only', 'skey': False}
lei = {'required': [], 'encrypted': 'Internal Use Only', 'skey': False}
crd = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
iard = {'required': [], 'encrypted': 'Internal Use Only', 'skey': False}
psn = {'required': ['dmi'], 'encrypted': 'Internal Use Only', 'skey': False}
asic_license_number = {'required': ['dmi'], 'encrypted': 'Internal Use Only', 'skey': False}
job_desc = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
client_type_id = {'required': ['sf'], 'encrypted': 'Internal Use Only', 'skey': False}
sv_event_code = {'required': ['sv_firm', 'sv_office', 'sv_person'], 'encrypted': 'Internal Use Only', 'skey': False}
do_not_contact = {'required': ['ct'], 'encrypted': 'Internal Use Only', 'skey': False}
err_msg = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
ect_channel_id = {'required': ['sf'], 'encrypted': 'Internal Use Only', 'skey': False}
ect_entity_id = {'required': ['sf'], 'encrypted': 'Internal Use Only', 'skey': False}
ect_team_id = {'required': ['sf'], 'encrypted': 'Internal Use Only', 'skey': False}
home_office_flag = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
broker_rep_code = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}

# entity_address_xref
entity_address_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
address_type_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
street_address_1 = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
street_address_2 = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
city = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
state = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
country = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
postal_code = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}

# entity_email_xref
entity_email_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
email_type_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
email_address = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}

# entity_phone_xref
entity_phone_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
phone_type_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
country_code = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
phone_number = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
extension = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}

# entity_team_xref
entity_team_id = {'required': ['sv_firm', 'sv_office', 'sv_person'], 'encrypted': 'Internal Use Only', 'skey': False}

# sales_owner_agreement_xref
sales_owner_xref_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
sales_owner_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
sales_owner_id_type = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
primary_owner_flag = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
percent_owned = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}

# sub_agreement (see agreement)
parent_agreement_id = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}

# trade
trade_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
aggregator_trade_code = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
start_date = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
end_date = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}

# territory_postal_xref
zip_territory_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
country_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}
territory_id = {'required': ['all'], 'encrypted': 'Internal Use Only', 'skey': False}

# utility
ended_at = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
ingested_at = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}

# valid line of business
employee_type = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
region_name = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
territory_name = {'required': ['none'], 'encrypted': 'Internal Use Only', 'skey': False}
