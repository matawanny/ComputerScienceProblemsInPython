import logging
from logging.handlers import RotatingFileHandler
import os
import sys

"""Logging Config"""
logging.basicConfig(level=logging.INFO)
log = logging.getLogger()
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# logging for stdout
default_console_handler = logging.StreamHandler(sys.stdout)
default_console_handler.setLevel(logging.DEBUG)
default_console_handler.setFormatter(formatter)


def generate_custom_log_handlers(log_file_name='cm_logger.log'):
    """
    Helper function to generate custom logging handlers
    :param log_file_name:
    :return:
    """
    # logging for stdout
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.DEBUG)
    console_handler.setFormatter(formatter)
    log.addHandler(console_handler)

    # logging for log file (will write to cwd)
    ROOT_DIR = os.getcwd()
    log_file_handler = logging.handlers.RotatingFileHandler('{}/{}'.format(ROOT_DIR, log_file_name),
                                                            maxBytes=(1048576 * 5), backupCount=5)
    log_file_handler.setLevel(logging.INFO)
    log_file_handler.setFormatter(formatter)
    log.addHandler(log_file_handler)
    return console_handler, log_file_handler
