import socket
ID_MAP = {}

class System:
    def __init__(self):
        self._ip = socket.gethostbyname(socket.gethostname())

    @property
    def ip(self):
        return self.ip

    @ip.getter
    def ip(self):

        print('\033[35m################################\033[0m')
        print('\033[35m################################\033[0m')
        if self._ip in ID_MAP.keys():
          #print("\033[35mOn system: \033[1m{}\033[21m...\033[0m".format(ID_MAP[self._ip]))
            out = ID_MAP[self._ip]
        else:
            #  print("\033[31mIP not registered, using \033[1m{}\033[21m...\033[0m".format(self._ip))
            out = None
        #print('\033[35m################################\033[0m')
        #print('\033[35m################################\033[0m')
        return out


# to import
system = System()

## https://lazard.atlassian.net/browse/EDM-1569
#TODO - cleaner way of determining bersion
import importlib
try:
    import pyspark
    import os.path

    print("On EMR")
    env='emr'


except:
    print("Not on EMR")
    env='not-emr'

