from boto3 import setup_default_session
from botocore.exceptions import NoCredentialsError
import watchtower
import logging

from cm_commons.util.boto_functions import get_region
# from config import REGION_NAME

# root logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger.handlers[0].setFormatter(formatter)

# initialize region for native watchtower setup
try:
    cli = setup_default_session(region_name=get_region())
    cloud_watch_handler = watchtower.CloudWatchLogHandler()

    # add handlers to root logger
    logger.addHandler(cloud_watch_handler)
except NoCredentialsError:
    logger.info('cannot connect to aws, not using cloud watch for logging')

