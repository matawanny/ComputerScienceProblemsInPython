from cm_commons import colors
import psycopg2


def psql_table_exists(cxn, table_name):
    conn = psycopg2.connect(dbname=cxn['db_name'],
                            user=cxn['user'],
                            host=cxn['location'],
                            password=cxn['password'])
    cur = conn.cursor()
    cur.execute(f"select * from information_schema.tables where table_name='{table_name}'")
    return bool(cur.rowcount)


def table_exists(cur, table_name):
    cur.execute(f"select * from information_schema.tables where table_name='{table_name}'")
    return bool(cur.rowcount)


def update_params_by_job(cur, job_type, timestamp, user='edm_user'):
    """
    Helper function to update `edm_params` to reflect job
    :return:
    """
    colors.out_print(f"Updating `edm_params` with runtime for {job_type}", indent=1)
    sql = f"""
        INSERT INTO edm_params VALUES ('{job_type}', '{timestamp}', '{user}', null)
        on conflict(key)
        do update set value1='{timestamp}', value2='{user}';
    """
    cur.execute(sql)
