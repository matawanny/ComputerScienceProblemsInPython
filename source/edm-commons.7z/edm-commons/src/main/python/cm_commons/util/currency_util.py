from cm_commons.db.sybase_currency_conn import sybase_iq_conn
from cm_commons.models.sqlalchemy.misc_models import FXRate

TARGET_CURRENCY_QUERY = """
    select cur_b.currency_symbol currency_symbol_b, hfx_b.xrate xrate_b, 
           cur_f.currency_symbol currency_symbol_f, hfx_f.xrate xrate_f, 
           hfx_f.xrate/hfx_b.xrate xrate_b_f, hfx_b.rate_date, hfx_b.end_date
    from apoprod.cur cur_b
    inner join apoprod.hfx hfx_b on (cur_b.id = hfx_b.currency)
    inner join apoprod.cur cur_f on (1=1)
    inner join apoprod.hfx hfx_f on (cur_f.id = hfx_f.currency and hfx_b.rate_date = hfx_f.rate_date)
    where hfx_b.rate_date in ({0}) and hfx_b.end_Date in ({0})
        and hfx_b.rate_type = 1 and hfx_b.source = 1
        and hfx_f.rate_type = 1 and hfx_f.source = 1
        and hfx_b.xrate > 0 and hfx_f.xrate > 0
        and cur_b.currency_symbol in ('{1}')
        and cur_f.currency_symbol in ({2})
    UNION
    SELECT DISTINCT 'USD', 1, cur.currency_symbol, hfx.xrate, hfx.xrate/1, hfx.rate_date, hfx.end_date
    FROM apoprod.cur
    inner join apoprod.hfx on (cur.id = hfx.currency)
    where hfx.rate_date in ({0}) and hfx.end_Date in ({0})
        and hfx.rate_type = 1 and hfx.source = 1 and hfx.xrate > 0 
        and cur.currency_symbol in ('{1}')
    UNION
    SELECT DISTINCT cur.currency_symbol, hfx.xrate, 'USD', 1, 1/hfx.xrate, hfx.rate_date, hfx.end_date
    FROM apoprod.cur
    inner join apoprod.hfx on (cur.id = hfx.currency)
    where hfx.rate_date in ({0}) and hfx.end_Date in ({0})
        and hfx.rate_type = 1 and hfx.source = 1 and hfx.xrate > 0 
        and cur.currency_symbol in ({2})
"""


def currency_date_conversion(date_range, current_currency, target_currencies):
    """
    Function takes a list of dates (as a string, wrapped in `'`)
    :param date_range:
    :param current_currency:
    :param target_currencies:
    :return:
    """
    # format query for target data
    target_query = TARGET_CURRENCY_QUERY.format(date_range, current_currency, target_currencies)

    # execute & process
    results = sybase_iq_conn.execute(target_query).fetchall()
    sybase_iq_conn.close()
    rates = []
    if results:
        for res in results:
            obj = FXRate(
                current_symbol=res[0],
                current_rate=res[1],
                target_symbol=res[2],
                target_rate=res[3],
                fx_rate=res[4],
                rate_date=res[5].replace('.000', ''),
                end_date=res[6].replace('.000', '')
            )
            rates.append(obj)
        return rates
