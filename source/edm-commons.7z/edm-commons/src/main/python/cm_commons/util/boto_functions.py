import boto3
from urllib.parse import urlparse
import json
import os
import requests
from cm_commons.util import awstags
from cm_commons import colors

def read_json(conf_loc):
    """Reads json from location into dict"""
    o = urlparse(conf_loc)
    s3 = boto3.resource('s3')
    bucket = o.netloc
    key = o.path[1:]
    obj = s3.Object(bucket, key)
    return json.loads(obj.get()['Body'].read().decode('utf-8'))



"""
source_location:s3://lazard-emr-test-data/conf/incoming/ai_aum_04-01-2019.conf
target_location:s3://lazard-emr-test-data/conf/active/ai_aum_04-01-2019.conf
"""
def s3_move_file(source_location, target_location, delete=True):
    #s3://lazard-emr-test-data/conf/incoming/ront.txt -> conf/incoming/ront.txt

    colors.out_print("source_location:"+source_location)
    colors.out_print("target_location:" + target_location)

    o = urlparse(source_location)
    source_bucket = o.netloc
    source = o.path[1:]
    (dirname, conf_file) = os.path.split(o[2])
    colors.out_print("conf_file="+conf_file)


    o = urlparse(target_location)
    destination = o.path[1:]

    s3 = boto3.resource('s3')
    copy_source = {'Bucket': source_bucket,'Key': source}
    colors.out_print("copy_source="+str(copy_source))
    colors.out_print("source_bucket=" + source_bucket)
    colors.out_print("destination="+destination)

    if delete:
        colors.out_print("moving file from {0} to {1}".format(source_location, target_location))
    else:
        destination += conf_file
        colors.out_print("destination="+destination)
        colors.out_print("copying file from {0} to {1}".format(source_location, target_location))
    s3.meta.client.copy(copy_source, source_bucket, destination)
    if delete:
        #delete the source file
        s3 = boto3.resource('s3')
        colors.out_print("deleting s3 object:{0}".format(source))
        s3.Object(source_bucket, source).delete()
        colors.out_print("s3 move file successful")
    return target_location

def move_conf_along(current_location, currentstep, nextstep):
    target_location = current_location.replace(currentstep, nextstep)
    return s3_move_file(current_location, target_location)

def get_instance_dict():
    r = requests.get("http://169.254.169.254/latest/dynamic/instance-identity/document")
    response_json = r.json()
    return response_json

def get_instance_id():
    instance_dict = get_instance_dict()
    instance_id = instance_dict['instanceId']
    return instance_id

def get_region():
    instance_dict = get_instance_dict()
    instance_id = instance_dict['region']
    return instance_id

def get_s3_bucket():
    ec2 = boto3.resource('ec2', region_name=get_region())
    ec2_instance = ec2.Instance(get_instance_id())
    for key_value in ec2_instance.tags:
        if key_value['Key'] == awstags.EDMCM_BUCKET:
            return key_value['Value']
    return None

def get_environment():
    ec2 = boto3.resource('ec2', region_name=get_region())
    ec2_instance = ec2.Instance(get_instance_id())
    for key_value in ec2_instance.tags:
        if key_value['Key'] == awstags.ENVIRONMENT:
            return key_value['Value']
    return None

def get_rds_config():
    ec2 = boto3.resource('ec2', region_name=get_region())
    ec2_instance = ec2.Instance(get_instance_id())
    for key_value in ec2_instance.tags:
        if key_value['Key'] == awstags.EDMCM_RDS:
            return key_value['Value']
    return None

def put_file_in_s3(filename, s3_folder_loc, string_content):
    """ Writes content into a s3 location """
    o = urlparse(s3_folder_loc)
    s3 = boto3.resource('s3')
    bucket = o.netloc
    key = o.path[1:]
    return s3.Object(bucket, key + filename).put(Body=string_content)

def file_exists(filename_with_s3_path):
    '''Check if file exists'''
    o = urlparse(filename_with_s3_path)
    s3 = boto3.resource('s3')
    bucket_name = o.netloc
    key = o.path[1:]
    bucket = s3.Bucket(bucket_name)
    obj = list(bucket.objects.filter(Prefix=key))
    return len(obj) > 0

def check_if_secret_exists(secret_name):
    """
    Check if a secret exists in current region
    :param secret_name:
    :return:
    """
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=get_region())
    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    return get_secret_value_response


def get_files_from_s3_folder(s3_folder_path):
    s3 = boto3.resource('s3')
    bucket_name = get_s3_bucket() # 'lazard-emr-test-data'
    bucket = s3.Bucket(bucket_name)

    s3_conf_loc = s3_folder_path # 's3://lazard-emr-test-data/MDM/nav_confs/incoming'
    conf_folder_prefix = s3_conf_loc[s3_conf_loc.rindex(bucket_name) + len(bucket_name) + 1:]

    # print(conf_folder_prefix)
    file_list = []
    for object_summary in bucket.objects.filter(Prefix=conf_folder_prefix):
        # print(object_summary.key) # MDM/nav_confs/incoming/salesforce_entity_1563050100.conf
        file = object_summary.key[object_summary.key.rindex('/') + 1:]
        file_list.append(file)

    if len(file_list) > 0:
        if file_list[0].strip() == '' and len(file_list) > 1:
            # Spotted in Dev: Exclude the directory which is the first item
            print(f"First item is empty. List of files in {conf_folder_prefix}  folder={file_list[1:]}")
            return file_list[1:]
        else:
            # Spotted in Test:
            print(f"List of files in {conf_folder_prefix}  folder={file_list}")
            return file_list

    #emtpy file list:
    return file_list

def delete_s3_folder(folder_location):
    o = urlparse(folder_location)
    bucket_name = o.netloc
    folder_name = o.path[1:]
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucket_name)

    colors.out_print(f"Deleting {bucket_name}/{folder_name} folder...")
    # for obj in bucket.objects.filter(Prefix="cache/07-22-2020/"):
    for obj in bucket.objects.filter(Prefix=folder_name):
        res = s3.Object(bucket.name, obj.key).delete()

    colors.out_print(f"Delete complete for {bucket_name}/{folder_name} folder")
    return
