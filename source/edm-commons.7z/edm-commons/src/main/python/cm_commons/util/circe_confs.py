entity = {
  "load_src": "rds",
  "TDS_ID": "TDS_ID",
  "STAGING_ID": "tds_master",
  "MASTER": "true",
  "SOURCE_NAME": "source_name",
  "ETL_SOURCE": "etl_source",
  "STEWARDSHIP_TYPE": "stewardship_type",
  "IGNORED_FIELD_LIST": [
    "staging_id",
    "stewardship_type",
    "create_rule",
    "etl_error",
    "etl_source",
    "error_message",
    "updated_at"
  ],
  "TABLES_LIST": [
    "agreement",
    "agreement_entity_xref",
    "aum",
    "entity",
    "trade"
  ],
  "INPUT_DIRECTORY": "../files/talend_ds_files",
  "OUTPUT_DIRECTORY": "../files/talend_ds_files",
  "PKEY_FKEY_MAPPINGS": {
    "entity": {
      "entity": "parent_id",
      "agreement_entity_xref": "entity_id",
      "entity_address_xref": "entity_id",
      "entity_email_xref": "entity_id",
      "entity_phone_xref": "entity_id"
    },
    "agreement": {
      "agreement_entity_xref": "agreement_id",
      "aum": "agreement_id",
      "trade": "agreement_id"
    }
  },
  "DIFF_COLUMNS": [
    "TDS_ID",
    "source_name",
    "etl_source",
    "original_record_",
    "column_name",
    "invalid_value",
    "valid_value",
    "stewardship_type",
    "create_rule",
    "created_at",
    "updated_at",
    "submitted_at",
    "cascade"
  ],
  "comment": "Pkey / fkey mappings is a dict where the keys are pkey table names and the values are dicts corresponding to the key / foreign key relationships."
}

agreement_entity_xref = {
  "load_src": "rds",
  "TDS_ID": "TDS_ID",
  "STAGING_ID": "tds_master",
  "MASTER": "true",
  "SOURCE_NAME": "source_name",
  "ETL_SOURCE": "etl_source",
  "STEWARDSHIP_TYPE": "stewardship_type",
  "IGNORED_FIELD_LIST": [
    "staging_id",
    "stewardship_type",
    "create_rule",
    "etl_error",
    "etl_source",
    "error_message",
    "updated_at"
  ],
  "TABLES_LIST": [
    "agreement",
    "agreement_entity_xref",
    "aum",
    "entity",
    "trade"
  ],
  "INPUT_DIRECTORY": "../files/talend_ds_files",
  "OUTPUT_DIRECTORY": "../files/talend_ds_files",
  "PKEY_FKEY_MAPPINGS": {
    "entity": {
      "entity": "parent_id",
      "agreement_entity_xref": "entity_id",
      "entity_address_xref": "entity_id",
      "entity_email_xref": "entity_id",
      "entity_phone_xref": "entity_id"
    },
    "agreement": {
      "agreement_entity_xref": "agreement_id",
      "aum": "agreement_id",
      "trade": "agreement_id"
    }
  },
  "DIFF_COLUMNS": [
    "TDS_ID",
    "source_name",
    "etl_source",
    "original_record_",
    "column_name",
    "invalid_value",
    "valid_value",
    "stewardship_type",
    "create_rule",
    "created_at",
    "updated_at",
    "submitted_at",
    "cascade"
  ],
  "comment": "Pkey / fkey mappings is a dict where the keys are pkey table names and the values are dicts corresponding to the key / foreign key relationships."
}