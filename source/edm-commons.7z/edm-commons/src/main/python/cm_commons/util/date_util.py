import calendar
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta


def last_business_day_in_month(date_in, pattern_in='%Y-%m-%d %H:%M:%S', num_months_back=0):
    """
    Utility method to get the last business day from a provided date, n months back
    For example, if passed in date is '2020-06-15', and num_months_back is 3, this will return the last business day 3
        months from the date passed in
    :param date_in:
    :param pattern_in:
    :param num_months_back:
    :return:
    """
    # convert current date string to datetime, then get current date - num months back
    curr_date = datetime.strptime(str(date_in), pattern_in)
    curr_date_minus_months = curr_date - relativedelta(months=num_months_back)

    # capture last business day in subtracted datetime
    last_biz_day_val = max(calendar.monthcalendar(int(curr_date_minus_months.year), int(curr_date_minus_months.month))[-1:][0][:5])

    # create new datetime and return as pattern in
    last_biz_date = datetime(curr_date_minus_months.year, curr_date_minus_months.month, last_biz_day_val)
    return last_biz_date.strftime(pattern_in)


def datetime_range(start=None, end=None):
    span = end - start
    for i in range(span.days + 1):
        yield start + timedelta(days=i)
