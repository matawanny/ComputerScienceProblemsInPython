from botocore.exceptions import NoCredentialsError
from sqlalchemy.schema import DropTable
from sqlalchemy.ext.compiler import compiles

from cm_commons.cron.job_config import SECRET_NAME, REGION_NAME, CM_DB, CM_USER, CM_PWD, CM_LOCATION, CM_PORT
from cm_commons.db.connectors.postgres_connector import connect_to_postgres
from cm_commons.util.aws_secrets_manager import get_secret


@compiles(DropTable, "postgresql")
def _compile_drop_table(element, compiler, **kwargs):
    return compiler.visit_drop_table(element) + " CASCADE"


def recreate_table(declarative_base, engine, table_name):
    """
    Drop and re-create target table
    :param declarative_base:
    :param engine:
    :param table_name:
    :return:
    """
    # drop table if exists
    print('recreating {}'.format(table_name))
    if engine.dialect.has_table(engine, table_name):
        declarative_base.metadata.tables[table_name].drop(bind=engine)
    declarative_base.metadata.tables[table_name].create(bind=engine)


def create_table_if_not_exists(declarative_base, engine, table_name):
    """
    Create table if not exists
    :param declarative_base:
    :param engine:
    :param table_name:
    :return:
    """
    if not engine.dialect.has_table(engine, table_name):
        declarative_base.metadata.tables[table_name].create(bind=engine)


def connect_to_cm_master():
    """
    Helper function to manage AWS/local connectivity to CM database
    :return:
    """
    try:
        secrets = get_secret(SECRET_NAME, REGION_NAME)
        return connect_to_postgres(secrets['username'],
                                              secrets['password'],
                                              secrets['host'],
                                              secrets['port'],
                                              secrets['dbname'])
    except NoCredentialsError:
        return connect_to_postgres(user=CM_USER,
                                              pwd=CM_PWD,
                                              location=CM_LOCATION,
                                              port=CM_PORT,
                                              db='edmcm')
