from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


def connect_to_postgres(user, pwd, location, port, db, autocommit=False):
    """
    Helper function to connect to Postgres database
    :param user:
    :param pwd:
    :param location:
    :param port:
    :param db:
    :param autocommit:
    :return:
    """
    # initialize connection to Client master
    engine = create_engine('postgresql://{}:{}@{}:{}/{}'.format(user, pwd, location, port, db), pool_size=10)
    Session = sessionmaker(bind=engine, autocommit=autocommit)
    return engine, Session()
