from sqlalchemy import create_engine
from sqlalchemy.dialects import registry

"""
Connection documentation in Windows:
1) Install SQL Anywhere 17 Driver
2) Create IQ connection in Windows ODBC Administrator Panel
    - Name of connection does not matter
    - In `Login` tab:
        - User & Pass to connect
        - Action: Connect to database in a cloud
        - Host: IP of server
        - Port: DB Port
        - Database Name: Actual database name, not loaded name (ex: `IQPAST01` is the db, not `ssims_load`
"""


def connect_to_sybase_iq(user, pwd, host, port, database):
    """
    Generic Sybase IQ Connection generator
    :param user:
    :param pwd:
    :param host:
    :param port:
    :param database:
    :return:
    """
    # registry.register('sqlalchemy_sqlany', 'sqlalchemy_sqlany.base', 'SQLAnyDialect')
    sybase_connection_string = "sqlalchemy_sqlany://{user}:{pwd}@{host}:{port}/{db}".\
        format(user=user, pwd=pwd, host=host, port=port, db=database)
    engine = create_engine(sybase_connection_string)
    return engine.connect()
