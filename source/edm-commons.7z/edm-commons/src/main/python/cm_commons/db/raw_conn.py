from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from cm_commons.dummy_ark.cm_cred import RAW_FILE_PG_URL

# create a connection to the table
engine = create_engine(RAW_FILE_PG_URL)

# create a configured "Session" class
Session = sessionmaker(bind=engine)

# create a Session
session = Session()
