import pyodbc

from cm_commons.conf import AI_SERVER_NAME, AI_DATABASE_NAME

# create MS SQL server connection using pyodbc
conn = pyodbc.connect("Driver={SQL Server Native Client 11.0};Server={%s};Database={%s};Trusted_Connection=yes;"
                      % (AI_SERVER_NAME, AI_DATABASE_NAME))
