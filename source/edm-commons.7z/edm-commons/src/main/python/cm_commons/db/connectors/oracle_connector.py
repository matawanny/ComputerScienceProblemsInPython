import cx_Oracle


def connect_to_oracle(user, pwd, host, port, sid):
    """
    Generic function to connect to oracle databases
    :param user:
    :param pwd:
    :param host:
    :param port:
    :param sid:
    :return:
    """
    dsn = cx_Oracle.makedsn(host, port, sid)
    return cx_Oracle.connect(user, pwd, dsn)
