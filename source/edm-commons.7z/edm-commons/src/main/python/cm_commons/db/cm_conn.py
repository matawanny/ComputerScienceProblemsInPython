from requests.exceptions import ConnectionError

from cm_commons.db.connectors.postgres_connector import connect_to_postgres
from cm_commons.util.aws_secrets_manager import get_secret
from cm_commons.util.boto_functions import get_region
from cm_commons.util.boto_functions import get_rds_config

try:
    cm_cxn = get_secret(get_rds_config(), get_region())
    cm_cxn['db_name'] = 'edmcm'

    cm_master_cxn = get_secret(get_rds_config(), get_region())
    cm_master_cxn['db_name'] = 'cm_master'

    if True:
        # TODO MOVE TO CONNECTORS
        cm_cxn_jdbc = {
            'url': 'jdbc:postgresql://{location}:{port}/{db_name}'.format(**cm_cxn),
            'properties': {
                "user": cm_cxn['user'],
                "password": cm_cxn['password'],
                "driver": "org.postgresql.Driver"
            }
        }

        cm_test_cxn_jdbc = {
            'url': 'jdbc:postgresql://{location}:{port}/edmcm_test'.format(**cm_cxn),
            'properties': {
                "user": cm_cxn['user'],
                "password": cm_cxn['password'],
                "driver": "org.postgresql.Driver"
            }
        }


except ConnectionError:
    print('cannot access secrets manager, please provide local credentials')
    cm_cxn = {
        'user': None,
        'password': None,
        'location': None,
        'port': None,
        'db_name': None
    }

    cm_master_cxn = {
        'user': None,
        'password': None,
        'location': None,
        'port': None,
        'db_name': None
    }

# This is the default JDBC connector. The DB name can be overridden by adding the "target_db" field to the conf file
# This update occurs in etl._configure(...)
def create_cm_conn(user=cm_cxn['user'], pwd=cm_cxn['password'], location=cm_cxn['location'], port=cm_cxn['port'],
                   db=cm_cxn['db_name']):
    """
    Helper function to generate Client Master PSQL connections in SQLAlchemy
    :param user:
    :param pwd:
    :param location:
    :param port:
    :param db:
    :return:
    """
    # initialize connection to Client master
    return connect_to_postgres(user, pwd, location, port, db)
