# TODO Get generic user here
# from conf import SYBASE_CURRENCY_USER, SYBASE_CURRENCY_PWD, SYBASE_CURRENCY_HOST, SYBASE_CURRENCY_PORT, \
#     SYBASE_CURRENCY_DATABASE
from cm_commons.db.connectors.sybase_iq_connector import connect_to_sybase_iq

# connect to Sybase IQ database for currency conversions/polling
sybase_iq_conn = connect_to_sybase_iq('ssims_load_ro',
                                      'XXXX',
                                      '10.56.12.22',
                                      '2009',
                                      'IQPAST01')
