import json, pprint

'''
Generates a conf dynamically similar to process_ds_conf.json 
'''

conf_fields = {}
conf_fields["load_src"] = "rds"
conf_fields["TDS_ID"] = "tds_id"
conf_fields["STAGING_ID"] = "tds_master"
conf_fields["MASTER"] = "true"
conf_fields["SOURCE_NAME"] = "source_name"
conf_fields["ETL_SOURCE"] = "etl_source"
conf_fields["STEWARDSHIP_TYPE"] = "stewardship_type"
conf_fields["INPUT_DIRECTORY"] = "../files/talend_ds_files"
conf_fields["OUTPUT_DIRECTORY"] = "../files/talend_ds_files"
conf_fields["comment"] = "Pkey / fkey mappings is a dict where the keys are pkey table names and the values are dicts corresponding to the key / foreign key relationships."


ignored_field_list = [
    "staging_id",
    "stewardship_type",
    "create_rule",
    "etl_error",
    "etl_source",
    "error_message",
    "updated_at"
]


tables_list = [
    "entity",
    "agreement_entity_xref",
    "agreement",
    "aum"
]


columns = [
    "TDS_ID",
    "source_name",
    "etl_source",
    "original_record_",
    "column_name",
    "invalid_value",
    "valid_value",
    "stewardship_type",
    "create_rule",
    "created_at",
    "updated_at",
    "submitted_at",
    "cascade"
]


pkey_fkey_mappings = {}

pkey_fkey_mappings["entity"] = {
    "entity": "parent_id",
    "agreement_entity_xref": "entity_id",
    "entity_email_xref": "entity_id",
    "entity_phone_xref": "entity_id",
    "entity_address_xref": "entity_id"
}

pkey_fkey_mappings["agreement"] = {
      "agreement_entity_xref": "agreement_id",
      "aum": "agreement_id",
      "trade": "agreement_id"
}



circe_conf = {}

for k, v in conf_fields.items():
    circe_conf[k] = v

circe_conf["ignored_field_list".upper()] = ignored_field_list
circe_conf["tables_list".upper()] = tables_list
circe_conf["columns".upper()] = columns
circe_conf["pkey_fkey_mappings".upper()] = pkey_fkey_mappings

# pprint.pprint(circe_conf)

# print("---------------------")
# circe_conf_json = json.dumps(circe_conf, indent=4)
# print(json_conf)

circe_conf = {
  "load_src": "rds",
  "TDS_ID": "tds_id",
  "STAGING_ID": "tds_master",
  "MASTER": "true",
  "SOURCE_NAME": "source_name",
  "ETL_SOURCE": "etl_source",
  "STEWARDSHIP_TYPE": "stewardship_type",
  "IGNORED_FIELD_LIST": [
    "staging_id",
    "stewardship_type",
    "create_rule",
    "etl_error",
    "etl_source",
    "error_message",
    "updated_at"
  ],
  "TABLES_LIST": [
    "entity"
  ],
  "INPUT_DIRECTORY": "../files/talend_ds_files",
  "OUTPUT_DIRECTORY": "../files/talend_ds_files",
  "PKEY_FKEY_MAPPINGS": {
    "entity": {
          "agreement_entity_xref": "entity_id",
          "entity": "parent_id",
          "entity_email_xref": "entity_id",
          "entity_phone_xref": "entity_id",
          "entity_address_xref": "entity_id"
      }
  },
  "COLUMNS": [
    "TDS_ID",
    "source_name",
    "etl_source",
    "original_record_",
    "column_name",
    "invalid_value",
    "valid_value",
    "stewardship_type",
    "create_rule",
    "created_at",
    "updated_at",
    "submitted_at",
    "cascade"
  ],
  "comment": "Pkey / fkey mappings is a dict where the keys are pkey table names and the values are dicts corresponding to the key / foreign key relationships."
}
