from cm_commons.models.sqlalchemy.base import *


class SalesVisionHolding(Base):
    __tablename__ = 'orig_holding'

    agreement_id = Column(String, primary_key=True, info=info.IUO)
    acp_id = Column(String, info=info.IUO)
    acp_ta = Column(String, info=info.IUO)
    acp_external_datasource = Column(String, info=info.IUO)
    acp_acc_id = Column(String, info=info.IUO)
    acp_act_id = Column(String, info=info.IUO)
    pro_cusip = Column(String, info=info.IUO)
    act_ta_code = Column(String, info=info.IUO)
    act_desc = Column(String, info=info.IUO)
    acp_pro_id = Column(String, info=info.IUO)
    acp_fir_id = Column(String, info=info.IUO)
    acp_ofl_id = Column(String, info=info.IUO)
    acp_per_id = Column(String, info=info.IUO)
    acp_create_date = Column(String, info=info.IUO)
    acp_create_userid = Column(String, info=info.IUO)
    acp_maint_date = Column(String, info=info.IUO)
    acp_maint_userid = Column(String, info=info.IUO)
    acp_tpa_dea_id = Column(String, info=info.IUO)
    clr_fir_id = Column(String, info=info.IUO)
    clr_fir_name = Column(String, info=info.IUO)
    tpa_fir_id = Column(String, info=info.IUO)
    tpa_fir_name = Column(String, info=info.IUO)
    acp_trust_dea_id = Column(String, info=info.IUO)
    trust_fir_id = Column(String, info=info.IUO)
    trust_fir_name = Column(String, info=info.IUO)
    acp_sponsor_dea_id = Column(String, info=info.IUO)
    spo_fir_id = Column(String, info=info.IUO)
    spo_fir_name = Column(String, info=info.IUO)
    acp_mcc_flg = Column(String, info=info.IUO)
    acp_cdr_flg = Column(String, info=info.IUO)
    acp_cdr_indicator = Column(String, info=info.IUO)
    acp_assigned_flg = Column(String, info=info.IUO)
    acp_network_level_ref_code = Column(String, info=info.IUO)
    acp_network_level_ref_desc = Column(String, info=info.IUO)
    acp_platform = Column(String, info=info.IUO)
    acp_external_account_number = Column(String, info=info.IUO)
    acc_ta_num = Column(String, info=info.IUO)
    acp_acc_name = Column(String, info=info.IUO)
    acp_acc_address_line_1 = Column(String, info=info.IUO)
    acp_acc_address_line_2 = Column(String, info=info.IUO)
    acp_acc_address_line_3 = Column(String, info=info.IUO)
    acp_acc_address_line_4 = Column(String, info=info.IUO)
    acp_acc_address_line_5 = Column(String, info=info.IUO)
    acp_acc_city = Column(String, info=info.IUO)
    acp_acc_region_ref_code = Column(String, info=info.IUO)
    acp_acc_postal_code = Column(String, info=info.IUO)
    acp_acc_country_ref_code = Column(String, info=info.IUO)
    aaa_id = Column(String, info=info.IUO)
    aaa_sah_id = Column(String, info=info.IUO)
    shd_lob = Column(String, info=info.IUO)
    shd_channel = Column(String, info=info.IUO)
    shd_region = Column(String, info=info.IUO)
    shd_territory = Column(String, info=info.IUO)
    holding_changed = Column(String, info=info.IUO)
    aaa_changed = Column(String, info=info.IUO)
    fir_type = Column(String, info=info.IUO)
    employee_id = Column(String, info=info.IUO)
    dealer_number = Column(String, info=info.IUO)


class SalesVisionAssetENUM(Base):
    __tablename__ = 'orig_asset'

    agreement_id = Column(String, primary_key=True, info=info.IUO)
    asp_acp_id = Column(String, primary_key=True, info=info.IUO)
    asp_asset_date = Column(String, primary_key=True, info=info.IUO)
    asp_nav = Column(String, primary_key=True, info=info.IUO)
    asp_nav_base = Column(String, primary_key=True, info=info.IUO)
    asp_asset_balance = Column(String, primary_key=True, info=info.IUO)
    asp_asset_balance_base = Column(String, primary_key=True, info=info.IUO)
    asp_valid_usd_flg = Column(String, primary_key=True, info=info.IUO)
    asp_asset_shares = Column(String, primary_key=True, info=info.IUO)
    asp_create_date = Column(String, primary_key=True, info=info.IUO)
    asp_create_userid = Column(String, primary_key=True, info=info.IUO)
    asp_maint_date = Column(String, primary_key=True, info=info.IUO)


class SalesVisionTradeENUM(Base):
    __tablename__ = 'orig_trade'

    trade_id = Column(String, primary_key=True, info=info.IUO)
    tca_id = Column(String, info=info.IUO)
    tca_ta = Column(String, info=info.IUO)
    tca_external_datasource = Column(String, info=info.IUO)
    tca_pro_id = Column(String, info=info.IUO)
    tca_trc_id = Column(String, info=info.IUO)
    tca_shares = Column(String, info=info.IUO)
    tca_amount = Column(String, info=info.IUO)
    tca_amount_base = Column(String, info=info.IUO)
    tca_fir_id = Column(String, info=info.IUO)
    tca_ofl_id = Column(String, info=info.IUO)
    tca_per_id = Column(String, info=info.IUO)
    tca_acc_id = Column(String, info=info.IUO)
    tca_acp_id = Column(String, info=info.IUO)
    tca_trade_date = Column(String, info=info.IUO)
    tca_settled_date = Column(String, info=info.IUO)
    tca_super_sheet_date = Column(String, info=info.IUO)
    tca_act_id = Column(String, info=info.IUO)
    act_ta_code = Column(String, info=info.IUO)
    act_desc = Column(String, info=info.IUO)
    tca_create_date = Column(String, info=info.IUO)
    tca_create_userid = Column(String, info=info.IUO)
    tca_maint_date = Column(String, info=info.IUO)
    tca_maint_userid = Column(String, info=info.IUO)
    tca_valid_usd_flg = Column(String, info=info.IUO)
    tca_assigned_flg = Column(String, info=info.IUO)
    tca_set_trans_flg = Column(String, info=info.IUO)
    tca_mcc_flg = Column(String, info=info.IUO)
    tca_cdr_flg = Column(String, info=info.IUO)
    tca_cdr_indicator = Column(String, info=info.IUO)
    tca_external_account_number = Column(String, info=info.IUO)
    tca_tpa_dea_id = Column(String, info=info.IUO)
    clr_fir_id = Column(String, info=info.IUO)
    clr_fir_name = Column(String, info=info.IUO)
    tpa_fir_id = Column(String, info=info.IUO)
    tpa_fir_name = Column(String, info=info.IUO)
    tca_trust_dea_id = Column(String, info=info.IUO)
    trust_fir_id = Column(String, info=info.IUO)
    trust_fir_name = Column(String, info=info.IUO)
    tca_sponsor_dea_id = Column(String, info=info.IUO)
    spo_fir_id = Column(String, info=info.IUO)
    spo_fir_name = Column(String, info=info.IUO)
    taa_id = Column(String, info=info.IUO)
    taa_sah_id = Column(String, info=info.IUO)
    shd_lob = Column(String, info=info.IUO)
    shd_channel = Column(String, info=info.IUO)
    shd_region = Column(String, info=info.IUO)
    shd_territory = Column(String, info=info.IUO)
    tca_changed = Column(String, info=info.IUO)
    taa_changed = Column(String, info=info.IUO)


class SalesVisionTradeCodeENUM(Base):
    __tablename__ = 'salesvision_trade_code_enum'

    trc_id = Column(String, primary_key=True, info=info.IUO)
    trc_trans_code = Column(String, primary_key=True, info=info.IUO)
    trc_trans_suffix = Column(String, primary_key=True, info=info.IUO)
    trc_trans_code_override = Column(String, primary_key=True, info=info.IUO)
    trc_trans_override_desc = Column(String, primary_key=True, info=info.IUO)
    trc_share_balance_indicator = Column(String, primary_key=True, info=info.IUO)
    trc_ta_transaction_desc = Column(String, primary_key=True, info=info.IUO)
    trc_file_indicator = Column(String, primary_key=True, info=info.IUO)
    trc_subcode = Column(String, primary_key=True, info=info.IUO)
    trc_create_date = Column(String, primary_key=True, info=info.IUO)
    trc_create_userid = Column(String, primary_key=True, info=info.IUO)
    trc_maint_date = Column(String, primary_key=True, info=info.IUO)
    trc_maint_userid = Column(String, primary_key=True, info=info.IUO)


class SalesVisionSalesPerson(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'sv_sales_person'

    sap_id = Column(String, primary_key=True, info=info.IUO)
    ssh_sah_id = Column(String, primary_key=True, info=info.IUO)
    sap_type = Column(String, info=info.IUO)
    sap_first_name = Column(String, info=info.IUO)
    sap_middle_name = Column(String, info=info.IUO)
    sap_last_name = Column(String, info=info.IUO)
    sap_end_date = Column(String, info=info.IUO)
    sap_employee_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] +
                                                'sales_owner_agreement_xref.sales_owner_id'), info=info.IUO)
    ssh_end_date = Column(String, info=info.IUO)
    sap_changed = Column(String, info=info.IUO)
    ssh_changed = Column(String, info=info.IUO)


class SalesVisionSalesHierachy(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'sv_sales_hierarchy'

    shd_sah_id = Column(String, primary_key=True, info=info.IUO)
    shd_lob = Column(String, primary_key=True, info=info.IUO)
    shd_channel = Column(String, info=info.IUO)
    shd_region = Column(String, info=info.IUO)
    shd_territory = Column(String, info=info.IUO)
    shd_sah_end_date = Column(String, info=info.IUO)
    shd_eligible_for_sales_supp = Column(String, info=info.IUO)


class SVExportPer(Base):
    __tablename__ = "sv_export_per"
    sv_firm_id = Column(String, primary_key=True)
    sv_office_id = Column(String)
    sv_person_id = Column(String)
    last_name = Column(String)
    middle_name = Column(String)
    first_name = Column(String)
    broker_team = Column(String)
    crm_firm_id = Column(String)
    crm_office_id = Column(String)
    crm_person_id = Column(String)
    event_code = Column(String)
    crm_service_request_id = Column(String)
    person_status = Column(String)
    home_office_flag = Column(String)
    phone_number = Column(String)
    email_address = Column(String)
    crd_number = Column(String)
    broker_rep_code = Column(String)
    create_date = Column(String)
    create_user = Column(String)
    maintenance_date = Column(String)
    maintenance_user = Column(String)


class SVExportOfl(Base):
    __tablename__ = "sv_export_ofl"
    sv_firm_id = Column(String, primary_key=True)
    sv_office_id = Column(String)
    address_line_1 = Column(String)
    address_line_2 = Column(String)
    address_line_3 = Column(String)
    address_city = Column(String)
    address_state = Column(String)
    address_zipcode = Column(String)
    address_country = Column(String)
    crm_firm_id = Column(String)
    crm_office_id = Column(String)
    event_code = Column(String)
    crm_service_request_id = Column(String)
    create_date = Column(String)
    create_user = Column(String)
    maintenance_date = Column(String)
    maintenance_user = Column(String)


class SVExportFir(Base):
    __tablename__ = "sv_export_fir"
    sv_firm_id = Column(String, primary_key=True)
    firm_name = Column(String)
    address_line_1 = Column(String)
    address_line_2 = Column(String)
    address_city = Column(String)
    address_state = Column(String)
    address_zipcode = Column(String)
    address_country = Column(String)
    crm_firm_id = Column(String)
    event_code = Column(String)
    crm_service_request_id = Column(String)
    create_date = Column(String)
    create_user = Column(String)
    maintenance_date = Column(String)
    maintenance_user = Column(String)

class EntityLinkedListSVAncestor(Base):

    __tablename__ = 'entity_linked_list_sv_anc'

    entity_id = Column(String, primary_key=True, autoincrement=True, info=info.IUO)
    parent_id = Column(String, nullable=False, info=info.IUO)
    salesvision_id = Column(Integer, nullable=False, info=info.IUO)
    entity_type_id = Column(String, nullable=False, info=info.IUO)
    id_path = Column(ARRAY(String), nullable=False, info=info.IUO)
    parent_path = Column(ARRAY(String), nullable=False, info=info.IUO)
    sv_path = Column(ARRAY(Integer), default=datetime.utcnow(), info=info.CD)
    type_path = Column(ARRAY(String), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)

class SVExportMrg(Base):
    __tablename__ = "sv_export_mrg"
    merge_type = Column(String)
    sv_from_id = Column(Integer, primary_key=True) # TODO: remove pkey
    sv_to_id = Column(Integer)
    crm_from_id = Column(String)
    crm_to_id = Column(String)

class SVSalesPerson(Base):
    __tablename__ = 'sv_sales_per_sv_sales_person'

    sap_id = Column(String, primary_key=True)
    ssh_sah_id = Column(String)
    sap_type = Column(String)
    sap_first_name = Column(String)
    sap_middle_name = Column(String)
    sap_last_name = Column(String)
    sap_end_date = Column(String)
    sap_employee_id = Column(String)
    ssh_end_date = Column(String)
    sap_changed = Column(String)
    ssh_changed = Column(String)


class SVSalesHier(Base):
    __tablename__ = 'sv_sales_hier_sv_sales_hierarchy'

    shd_sah_id = Column(String, primary_key=True)
    shd_lob = Column(String)
    shd_channel = Column(String)
    shd_region = Column(String)
    shd_territory = Column(String)
    shd_sah_end_date = Column(String)
    shd_eligible_for_sales_supp = Column(String)
