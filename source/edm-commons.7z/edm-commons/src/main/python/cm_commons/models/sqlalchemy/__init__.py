from cm_commons.models.sqlalchemy.au_models import *
from cm_commons.models.sqlalchemy.audit_models import *
from cm_commons.models.sqlalchemy.client_master_models import *
from cm_commons.models.sqlalchemy.fishtank_models import *
from cm_commons.models.sqlalchemy.misc_models import *
from cm_commons.models.sqlalchemy.rule_models import *
from cm_commons.models.sqlalchemy.salesvision_models import *
import types
"""
Below is a section of code that will dynamically create a list of instantiated SQLAlchemy objects that is used in a
process to export a JSON representation of our SQLAlchemy models
"""
# generate a list of model names as strings
clsmembers = [name for name, obj in inspect.getmembers(sys.modules[__name__], inspect.isclass)
              if 'cm_commons' in obj.__module__]

sql_classes = []

# This is varialble contains all models under sqlalchemy
current_module = sys.modules[__name__]

# for list of all models in this file, check if the current key is in the list of custom SQLAlchemy objects
# if so, instantiate an object and append to `sql_classes`
for key in dir(current_module):
    if key in clsmembers:
        _class = getattr(current_module, key)
        inst = _class()
        sql_classes.append(inst)
