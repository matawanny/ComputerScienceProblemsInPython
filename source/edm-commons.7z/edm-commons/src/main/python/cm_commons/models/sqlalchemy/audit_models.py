from cm_commons.models.sqlalchemy.base import *


class AgreementAudit(Base):
    __tablename__ = 'agreement_audit'

    audit_id = Column(Integer, primary_key=True, nullable=False, info=info.IUO)
    agreement_id = Column(String, nullable=False, info=info.IUO)
    source_name = Column(String, nullable=False, info=info.CD)
    column_name = Column(String, nullable=False, info=info.CD)
    original_agreement_id = Column(String, nullable=False, info=info.CD)
    invalid_value = Column(String, info=info.CD)
    valid_value = Column(String, info=info.CD)
    stewardship_type = Column(String, nullable=False, info=info.CD)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)
    submitted_at = Column(DateTime(), default=datetime.utcnow(), nullable=False, info=info.CD)


class AgreementEntityAudit(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'agreement_entity_xref_audit' + Base.metadata._sequences['main_postfix']

    audit_id = Column(Integer, primary_key=True, nullable=False, info=info.IUO)
    source_name = Column(String, nullable=False, info=info.CD)
    column_name = Column(String, nullable=False, info=info.CD)
    original_agreement_entity_xref_id = Column(String, nullable=False, info=info.CD)
    invalid_value = Column(String, info=info.CD)
    valid_value = Column(String, info=info.CD)
    stewardship_type = Column(String, nullable=False, info=info.CD)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)
    submitted_at = Column(DateTime(), default=datetime.utcnow(), nullable=False, info=info.CD)


class AUMAudit(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'aum_audit' + Base.metadata._sequences['main_postfix']

    audit_id = Column(Integer, primary_key=True, nullable=False, info=info.IUO)
    source_name = Column(String, nullable=False, info=info.CD)
    column_name = Column(String, nullable=False, info=info.CD)
    original_aum_id = Column(String, nullable=False, info=info.CD)
    invalid_value = Column(String, info=info.CD)
    valid_value = Column(String, info=info.CD)
    stewardship_type = Column(String, nullable=False, info=info.CD)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)
    submitted_at = Column(DateTime(), default=datetime.utcnow(), nullable=False, info=info.CD)


class EntityAudit(Base):
    __tablename__ = 'entity_audit'

    audit_id = Column(Integer, primary_key=True, nullable=False, info=info.IUO)
    source_name = Column(String, nullable=False, info=info.CD)
    column_name = Column(String, nullable=False, info=info.CD)
    original_entity_id = Column(Integer, nullable=False, info=info.CD)
    invalid_value = Column(String, info=info.CD)
    valid_value = Column(String, info=info.CD)
    stewardship_type = Column(String, nullable=False, info=info.CD)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)
    submitted_at = Column(DateTime(), default=datetime.utcnow(), nullable=False, info=info.CD)


class TradeAudit(Base):
    __tablename__ = 'trade_audit'

    audit_id = Column(Integer, primary_key=True, nullable=False, info=info.IUO)
    source_name = Column(String, nullable=False, info=info.CD)
    column_name = Column(String, nullable=False, info=info.CD)
    original_trade_id = Column(String, nullable=False, info=info.CD)
    invalid_value = Column(String, info=info.CD)
    valid_value = Column(String, info=info.CD)
    stewardship_type = Column(String, nullable=False, info=info.CD)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)
    submitted_at = Column(DateTime(), default=datetime.utcnow(), nullable=False, info=info.CD)
