from cm_commons.models.sqlalchemy.base import *


# adding Au Platforms (think DMIesc) as a seperate version of "sub agreement"
class AuPlatformSubAgreement(Base):
    # TODO: verify relationships with other fields
    __tablename__ = 'au_platform_sub_agreement'

    sub_agreement_id = Column(Integer, primary_key=True, nullable=False, info=info.IUO)
    #parent_agreement_id = Column(Integer, ForeignKey(temp_prefix + 'agreement' + temp_postfix + '.agreement_id'),
    #                            nullable=False, info=info.RD) #not required, as use xref below.
    account_number = Column(String, info=info.RD)
    channel_id = Column(Integer, ForeignKey('channel.channel_id'), nullable=False, info=info.IUO)
    money_type_id = Column(String, nullable=False, info=info.IUO)
    benchmark_id = Column(String, info=info.IUO)
    ta_number = Column(String, info=info.RD)
    external_identifier = Column(String, ForeignKey('agreement' + '.external_identifier'),
                                 nullable=False, info=info.CD)
    external_identifier_type = Column(String, info=info.CD)
    salesforce_id = Column(String, info=info.RD)
    erisa_plan = Column(String, info=info.RD)
    currency_id = Column(Integer, ForeignKey('currency_enum.currency_id'), nullable=False, info=info.RD)
    unit_holder_code = Column(String, info=info.CD)
    ipo_flag = Column(Boolean, info=info.CD)
    ocio_flag = Column(Boolean, info=info.CD)
    inception_date = Column(DateTime(), info=info.CD)
    origin_id = Column(String, ForeignKey('origin.origin_id'), nullable=False, info=info.IUO)
    aggregator_id = Column(String, ForeignKey('aggregator.aggregator_id'), nullable=False, info=info.IUO)
    ended_at = Column(DateTime(), info=info.IUO)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)


class AuPlatformSubAgreement_Agreement_XREF(Base):
    __tablename__ = 'au_platform_sub_agreement_agreement_xref'
    auplatformsubagreement_agreement_xref_id = Column(Integer, primary_key=True, nullable=False, info=info.IUO) #falls below 63 charcture limit so ok.
    sub_agreement_id = Column(Integer, nullable=False, info=info.IUO)
    parent_agreement_id = Column(Integer, ForeignKey('agreement' + '.agreement_id'),
                                 nullable=False, info=info.RD)
# end of adding AU Platform subclass.