ft_file_0 = {
  "source": True,
  "target": False,
  "mapping": {
    "Period": "period",
    "CRM ID": "crm_id",
    "ISIN": "isin",
    "Platform": "platform",
    "CRM Platform ID": "platform_crm_id",
    "Currency": "currency",
    " AUM ": "aum",
    "Organization Name": "organization_name",
    "Gross Sales": "gross_sales",
    "Gross Redemptions": "gross_redemptions",
    "Net Flow": "net_flow",
    "Channel Mapping": "channel_mapping",
    "Client Type": "client_type",
    "FT_ID": "ft_id",
    "CRM_Name": "employee_crm_name",
    "FCA_Number": "fca_number",
    "Office_Name": "office_name"
  }
}