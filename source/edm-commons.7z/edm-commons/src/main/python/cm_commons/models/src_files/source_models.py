import json
import os
from cm_commons.util.system import env
import boto3
from cm_commons.models.src_files import sv_models, amg_models, fishtank_models, ai_models, ldw_models, enum_models, conversion_models

old_dir = os.getcwd()
#os.chdir('../../..')


# s3 = boto3.resource('s3')
# content_object = s3.Object('test', 'lazard-client-master/src_sv_asset.json')
# file_content = content_object.get()['Body'].read().decode('utf-8')
# sv_asset_schema = json.loads(file_content)

sv_asset_schema = sv_models.sv_asset

sv_holding_schema = sv_models.sv_holding
sv_holding_2007 = sv_models.sv_2007
sv_trade_schema = sv_models.sv_trade
sv_tradecode_schema = sv_models.sv_tradecode
sv_sales_person_schema = sv_models.sv_sales_person

sv_entity_schema = sv_models.sv_firm_pipe

firm_lqe = sv_models.sv_firm
office_lqe = sv_models.sv_office
person_lqe = sv_models.sv_person

firm_lqe = sv_models.sv_firm
office_lqe = sv_models.sv_office
person_lqe = sv_models.sv_person


sv_firm_pipe = sv_models.sv_firm_pipe
sv_person_pipe = sv_models.sv_person_pipe
sv_office_pipe = sv_models.sv_office_pipe


fishtank_schema = fishtank_models.ft_file_0
amg_schema = amg_models.ent_agr
amg_wm_source = amg_models.wrap_models

ai_aum_schema = ai_models.ai_aum
ai_flow_schema = ai_models.ai_flow

ct_schema = None

ldw_trade_schema = ldw_models.ldw_trade
ldw_asset_schema = ldw_models.ldw_asset
dmi_schema = None
ldw_flow_schema = None
dmi_schema=None

null_schema = {"source": True,
               "target": False,
               "mapping": {},
               "flexible": {},
               "query": []
               }

SV_SALES_PER = sv_models.sv_sales_person
SV_SALES_HIER = sv_models.sv_sales_hier
SHARE_CLASS_ENUM = enum_models.share_class_enum_source_schema
FX_RATE_CONVERSION = conversion_models.fx_rate_conversion_source_schema
