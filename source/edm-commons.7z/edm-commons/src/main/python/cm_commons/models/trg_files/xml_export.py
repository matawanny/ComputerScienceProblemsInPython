import xml.dom.minidom
import xml.etree.cElementTree as ET

from cm_commons.models import sql_classes

SQL_TALEND_MAPPING ={
    'VARCHAR': 'string',
    'VARCHAR(25)': 'string',
    'VARCHAR(50)': 'string',
    'INTEGER': 'int',
    'FLOAT': 'float',
    'DATETIME': 'datetime'
}


def export_xml(tables):
    """
    Export SQLAlchemy models as XML
    :param tables:
    :return:
    """
    # create root object
    root = ET.Element('xsd:schema', attrib={'xmlns:xsd':'http://www.w3.org/2001/XMLSchema'})

    # create sub element with namespace
    ET.SubElement(root, 'xsd:import', namespace='http://www.w3.org/2001/XMLSchema')

    # create sub elements for each table in SQLAlchemy models
    for table in tables:
        obj = None
        for cls in sql_classes:
            if type(cls).__name__.lower() == table:
                obj = cls
                break

        # create element with table name
        elem = ET.SubElement(root, 'xsd:element', name=table.title(), type=table.lower() + '_type')
        uniq = ET.SubElement(elem, 'xsd:unique', name=table.title())

        # add primary keys to element mapping
        pks = obj.__table__.primary_key.columns
        for pk in pks:
            ET.SubElement(uniq, 'xsd:selector', xpath='.')
            ET.SubElement(uniq, 'xsd:field', xpath=pk.description)

        # add field names and values to <complexType> delcarations
        complex_type = ET.SubElement(root, 'xsd:complexType', name=table + '_type')
        _all = ET.SubElement(complex_type, 'xsd:all')
        fields = obj.__table__.c._all_columns
        for field in fields:
            # create field level mapping, handle primary key distinction
            if field.primary_key:
                inner_elem = ET.SubElement(_all, 'xsd:element', maxOccurs='1', minOccurs='1', name=field.name,
                                           type='xsd:' + SQL_TALEND_MAPPING.get(str(field.type)))
            else:
                inner_elem = ET.SubElement(_all, 'xsd:element', maxOccurs='1', minOccurs='0', name=field.name,
                                           type='xsd:' + SQL_TALEND_MAPPING.get(str(field.type)))

            # foreign key relationship mapping
            annotation = ET.SubElement(inner_elem, 'xsd:annotation')
            if field.foreign_keys:
                for fk in field.foreign_keys:
                    ET.SubElement(annotation, 'xsd:appinfo', source='X_ForeignKey')\
                        .text = table.title() + '/' + fk.column.description
                    ET.SubElement(annotation, 'xsd:appinfo', source='X_ForeignKey_NotSep').text = 'false'

    xmlstr = ET.tostring(root).decode('utf-8')
    parsed_xml = xml.dom.minidom.parseString(xmlstr)
    xml_formatted = parsed_xml.toprettyxml()

    f = open('sqlalchemy-mappings.xsd', 'w')
    f.write(xml_formatted)
