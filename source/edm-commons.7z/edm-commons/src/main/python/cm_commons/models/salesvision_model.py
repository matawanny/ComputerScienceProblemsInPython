class SVExport:
    """
    Base class for SV Expors
    """
    def __init__(self):
        pass

    def null_to_string(self):
        """
        Convert NoneTypes to empty strings
        :return:
        """
        fields = dir(self)
        for field in fields:
            if '__' in field:
                continue
            if getattr(self, field) is None:
                setattr(self, field, '')


class FOPExport(SVExport):
    """
    Generic Python model to meet Firm, Office, and Person structure requested by SalesVision
    """
    def __init__(self):
        super().__init__()

    sv_firm_id = None
    sv_office_id = None
    sv_person_id = None
    firm_name = None
    last_name = None
    first_name = None
    middle_name = None
    broker_team = None
    address_line_1 = None
    address_line_2 = None
    address_line_3 = None
    address_city = None
    address_state = None
    address_zipcode = None
    address_country = None
    crm_firm_id = None      # TODO: this is the salesforce id?
    crm_office_id = None    # TODO: this is the salesforce id?
    crm_person_id = None    # TODO: this is the salesforce id?
    event_code = None   # TODO: event code explains if it's a new record, updated, or deleted; how can we tell?
    home_office_flag = None
    crm_service_request_id = None
    # firm_status = None      # TODO: do we have status of firm?
    # office_status = None    # TODO: do we have status of office?
    person_status = None    # TODO: do we have status of person?
    phone_number = None
    email_address = None
    crd_number = None
    broker_rep_code = None
    # firm_type = None
    # parent_firm = None
    create_date = None
    create_user = None      # TODO: do we have this data?
    maintenance_date = None
    maintenance_user = None     # TODO: do we have this data?

    def firm_format(self):
        """
        Take data in object and format to proper Firm structure
        :return:
        """
        self.null_to_string()
        output = '|'.join([self.sv_firm_id, self.firm_name, self.address_line_1, self.address_line_2, self.address_city,
                           self.address_state, self.address_zipcode, self.address_country, self.crm_firm_id,
                           self.event_code, self.crm_service_request_id, self.create_date, self.create_user,
                           self.maintenance_date, self.maintenance_user])
        return output

    def office_format(self):
        """
        Take data in object and format to proper Office structure
        :return:
        """
        self.null_to_string()
        output = '|'.join([self.sv_firm_id, self.sv_office_id, self.address_line_1, self.address_line_2,
                           self.address_line_3, self.address_city, self.address_state, self.address_zipcode,
                           self.address_country, self.crm_firm_id, self.crm_office_id, self.event_code,
                           self.crm_service_request_id, self.create_date, self.create_user, self.maintenance_date,
                           self.maintenance_user])
        return output

    def person_format(self):
        """
        Take data in object and format to proper Person structure
        :return:
        """
        self.null_to_string()
        output = '|'.join([self.sv_firm_id, self.sv_office_id, self.sv_person_id, self.last_name, self.first_name,
                           self.middle_name, self.broker_team, self.crm_firm_id, self.crm_office_id, self.crm_person_id,
                           self.event_code, self.crm_service_request_id, self.person_status, self.home_office_flag,
                           self.phone_number, self.email_address, self.crd_number, self.broker_rep_code, self.create_date,
                           self.create_user, self.maintenance_date, self.maintenance_user])
        return output


class MergeSummary(SVExport):
    """
    Class to represent merge records sent back to SV
    """
    def __init__(self):
        super().__init__()

    merge_type = None
    sv_from_id = None
    sv_to_id = None
    crm_from_id = None
    crm_to_id = None
    crm_service_request_id = None

    def merge_format(self):
        """
        Take data in object and format to proper Person structure
        :return:
        """
        self.null_to_string()
        output = '|'.join([self.merge_type, self.sv_from_id, self.sv_to_id, self.crm_from_id, self.crm_to_id,
                           self.crm_service_request_id])
        return output
