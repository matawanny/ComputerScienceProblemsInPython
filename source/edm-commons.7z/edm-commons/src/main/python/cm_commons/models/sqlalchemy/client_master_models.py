from cm_commons.models.sqlalchemy.base import *


class AddressType(Base):
    __tablename__ = 'address_type_enum'

    address_type_id = Column(Integer, primary_key=True, nullable=False, info=info.IUO)
    address_type_name = Column(String, nullable=False, info=info.IUO)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)


class Aggregator(Base):
    __tablename__ = 'aggregator'

    aggregator_id = Column(Integer, primary_key=True, nullable=False, info=info.aggregator_id)
    aggregator_name = Column(String, nullable=False, info=info.aggregator_name)
    ended_at = Column(DateTime(), info=info.ended_at)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)


class Agreement(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'agreement' + Base.metadata._sequences['main_postfix']

    agreement_id = Column(String, primary_key=True, nullable=False, info=info.agreement_id)
    agreement_type = Column(String, info=info.agreement_type)
    agreement_name = Column(String, info=info.agreement_name)
    account_number = Column(String, info=info.account_number)
    channel_id = Column(Integer, ForeignKey('channel_enum.channel_id'), nullable=False, info=info.channel_id)
    money_type_id = Column(String, ForeignKey('money_type_enum.money_type_id'), nullable=False, info=info.money_type_id)
    firm_type_id = Column(String, info=info.firm_type_id)  # TODO: enum
    benchmark_id = Column(String, info=info.benchmark_id)
    ta_number = Column(String, info=info.ta_number)
    external_identifier = Column(String, nullable=False, info=info.external_identifier)
    external_identifier_type = Column(String, nullable=False, info=info.external_identifier_type)
    erisa_plan = Column(String, info=info.erisa_plan)
    preferred_currency_id = Column(String, ForeignKey('currency_enum.currency_id'), nullable=False,
                                   info=info.preferred_currency_id)
    unit_holder_code = Column(String, info=info.unit_holder_code)
    ipo_flag = Column(String, info=info.ipo_flag)
    ocio_flag = Column(String, info=info.ocio_flag)
    inception_date = Column(String, info=info.inception_date)
    origin_id = Column(Integer, ForeignKey('origin.origin_id'), nullable=False, info=info.origin_id)
    aggregator_id = Column(String, ForeignKey('aggregator.aggregator_id'), nullable=False, info=info.aggregator_id)
    external_agreement_id = Column(String, info=info.external_agreement_id)
    ended_at = Column(String, info=info.ended_at)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)

    # create necessary ORM relationships to properly link data
    agreement_pmf = relationship('AgreementPMF', lazy='joined')
    related_entities = relationship('AgreementEntity', lazy='joined')
    # aum = relationship('AUM', lazy='joined')
    trades = relationship('Trade')
    line_of_business = relationship('ValidLOB', lazy='joined')


class ValidAgreement(Base):
    __tablename__ = Base.metadata._sequences['valid_prefix'] + 'valid_agreements'

    agreement_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'agreement.agreement_id'), primary_key=True)
    aum_id = Column(String, primary_key=True, nullable=False, info=info.aum_id)
    raw_amount = Column(String, nullable=False, info=info.raw_amount)
    usd_amount = Column(String, nullable=False, info=info.usd_amount)
    currency_iso3_code = Column(String, nullable=False, info=info.currency_id)
    as_of_date = Column(String, nullable=False, info=info.as_of_date)

    agreement = relationship('Agreement', lazy='joined', uselist=False)


class ValidDeleteAgreement(Base):
    __tablename__ = Base.metadata._sequences['valid_prefix'] + 'valid_deleted_agreements'

    agreement_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'agreement.agreement_id'),
                          primary_key=True)

    agreement = relationship('Agreement', lazy='joined', uselist=False)


class AgreementEntity(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'agreement_entity_xref' + Base.metadata._sequences['main_postfix']

    agreement_entity_xref_id = Column(String, primary_key=True, info=info.agreement_entity_xref_id)
    agreement_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'agreement.agreement_id'),
                          nullable=False, info=info.ae_entity_id)
    entity_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'entity.entity_id'), nullable=False,
                       info=info.ae_entity_id)
    relationship_type_id = Column(Integer, ForeignKey('relationship_type_enum.relationship_type_id'),
                                  nullable=False, info=info.relationship_type_id)
    primary_relationship = Column(Boolean, info=info.primary_relationship)
    external_entity_id = Column(String, info=info.external_entity_id)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)

    entity = relationship('Entity', lazy='joined')
    agreements = relationship('Agreement', lazy='joined')
    relationship_type = relationship('RelationshipType', lazy='joined')


class AgreementPMF(Base):
    __tablename__ = Base.metadata._sequences['valid_prefix'] + 'valid_agreement_pmf_xref'

    agreement_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'agreement.agreement_id'),
                          primary_key=True, nullable=False, info=info.agreement_id)
    external_identifier = Column(String, primary_key=True, info=info.external_identifier)
    external_identifier_type = Column(String, info=info.external_identifier_type)
    # product_id = Column(Integer, info=info.pmf_symbol)
    # fund_yn = Column(Boolean, info=info.IUO)
    pmf_symbol = Column(String)
    fund_name = Column(String, info=info.fund_name)
    share_class_id = Column(String, info=info.share_class_id)
    # share_class_name = Column(String, info=info.share_class_name)
    sub_strategy_id = Column(Integer)


class AUM(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'aum' + Base.metadata._sequences['main_postfix']

    aum_id = Column(String, primary_key=True, nullable=False, info=info.aum_id)
    agreement_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'agreement.agreement_id'),
                          nullable=False,
                          info=info.agreement_id)
    amount = Column(String, nullable=False, info=info.amount)
    currency_id = Column(String, ForeignKey('currency_enum.currency_id'), nullable=False, info=info.currency_id)
    as_of_date = Column(String, nullable=False, info=info.as_of_date)
    aggregator_id = Column(Integer, ForeignKey('aggregator.aggregator_id'), nullable=False, info=info.aggregator_id)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)

    currency = relationship('Currency', lazy='joined')


class ClientType(Base):
    __tablename__ = 'client_type_enum'

    client_type_id = Column(String, primary_key=True, nullable=False, info=info.IUO)
    client_type_name = Column(String, nullable=False, info=info.IUO)
    parent_id = Column(String, ForeignKey(client_type_id), info=info.IUO)

    # create referential structure where `parent_client` holds level up & `sub_client_type` will hold level down
    parent_client = relationship('ClientType',
                                 backref='sub_client_type',
                                 remote_side=[client_type_id])


class Channel(Base):
    __tablename__ = 'channel_enum'

    channel_id = Column(String, primary_key=True, nullable=False, info=info.IUO)
    sf_channel_id = Column(String, nullable=False, info=info.IUO)
    channel_name = Column(String, nullable=False, info=info.CD)
    parent_channel_id = Column(String, ForeignKey(channel_id), info=info.IUO)  # establish FK relationship to self
    parent_sf_channel_id = Column(String, info=info.IUO)  # establish FK relationship to self
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)

    # create referential structure where `parent_channel` holds level up & `sub_channel` will hold level down
    parent_channel = relationship('Channel',
                                  backref='sub_channels',
                                  remote_side=[channel_id])


class Country(Base):
    __tablename__ = 'country_enum'

    country_id = Column(Integer, primary_key=True, nullable=False, info=info.IUO)
    country_name = Column(String, nullable=False, info=info.IUO)
    country_iso3_code = Column(String, nullable=False, info=info.IUO)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)


class Currency(Base):
    __tablename__ = 'currency_enum'

    currency_id = Column(Integer, primary_key=True, info=info.IUO)
    currency_name = Column(String, nullable=False, info=info.IUO)
    currency_iso3_code = Column(String, nullable=False, info=info.IUO)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)


class EmailType(Base):
    __tablename__ = 'email_type_enum'

    email_type_id = Column(String, primary_key=True, info=info.IUO)
    email_type_name = Column(String, nullable=False, info=info.IUO)
    hierarchy = Column(Integer, info=info.NO)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)


class Employee(Base):
    __tablename__ = 'employee_enum'

    employee_id = Column(Integer, primary_key=True, nullable=False, info=info.CD)
    curr_location_code = Column(Integer, nullable=False, info=info.RD)
    curr_location_city = Column(String, nullable=False, info=info.RD)
    opsysid = Column(String, info=info.RD)
    internet_name = Column(String, info=info.RD)
    supervisor_employee_id = Column(Integer, info=info.RD)
    hr_dept_id = Column(Integer, info=info.RD)
    hr_dept_id_desc = Column(String, info=info.RD)
    hr_business_unit_desc = Column(String, info=info.RD)
    gl_company_cd = Column(String, info=info.RD)
    gl_cost_center = Column(String, info=info.RD)
    gl_company_desc = Column(String, info=info.RD)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)


class Entity(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'entity' + Base.metadata._sequences['main_postfix']

    entity_id = Column(String, primary_key=True, nullable=False, info=info.entity_id)
    persistence_id = Column(String, info=info.persistence_id)
    entity_type_id = Column(String, ForeignKey('entity_type_enum.entity_type_id'), nullable=False,
                            info=info.entity_type_id)
    entity_name = Column(String, nullable=False, info=info.entity_name)
    group_id = Column(String, info=info.group_id)
    parent_id = Column(String, ForeignKey(entity_id), info=info.parent_id)  # self referential FK
    salesforce_id = Column(String, info=info.salesforce_id)
    crm_id = Column(String, info=info.crm_id)
    salesvision_id = Column(String, info=info.salesvision_id)
    fishtank_id = Column(String, info=info.fishtank_id)
    ai_investor_id = Column(String, info=info.ai_investor_id)
    ai_subinvestor_id = Column(String, info=info.ai_subinvestor_id)
    fca_id = Column(String, nullable=False, info=info.fca_id)
    employee_id = Column(String, info=info.employee_id)
    lei = Column(String, info=info.lei)
    crd = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'entity_team_xref.entity_crd'), info=info.crd)
    iard = Column(String, info=info.iard)
    psn = Column(String, info=info.psn)
    asic_license_number = Column(String, info=info.asic_license_number)
    job_desc = Column(String, info=info.job_desc)
    client_type_id = Column(String, ForeignKey('client_type_enum.client_type_id'), nullable=False,
                            info=info.client_type_id)
    sv_event_code = Column(String, info=info.sv_event_code)
    do_not_contact = Column(String, info=info.do_not_contact)
    err_msg = Column(String, info=info.err_msg)
    ect_channel_id = Column(String, info=info.ect_channel_id)
    ect_entity_id = Column(String, info=info.ect_entity_id)
    ect_team_id = Column(String, info=info.ect_team_id)
    ended_at = Column(String, info=info.ended_at)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)
    # EDM-2331
    ingested_at = Column(DateTime(), info=info.ingested_at)
    # EDM-2549
    home_office_flag = Column(String, info=info.home_office_flag)
    broker_rep_code = Column(String, info=info.broker_rep_code)
    # create relationship between entity & agreement_entity_xref
    related_agreements = relationship('AgreementEntity')

    # create referential structure where `parent_entity` holds level up & `sub_entity` will hold level down
    parent_entity = relationship('Entity',
                                 lazy='joined',
                                 backref='children_entities',
                                 join_depth=2,
                                 remote_side=[entity_id])

    # additional relationships for Entity
    entity_type_info = relationship('EntityType', lazy='joined')
    entity_address = relationship('EntityAddress', lazy='joined',
                                  order_by='desc(EntityAddress.updated_at)')
    entity_email = relationship('EntityEmail', lazy='joined',
                                order_by='desc(EntityEmail.updated_at)')
    entity_phone = relationship('EntityPhone', lazy='joined',
                                order_by='desc(EntityPhone.updated_at)')
    client_type_info = relationship('ClientType', lazy='joined')

    valid_entity = relationship('ValidEntityFull', lazy='joined', uselist=False)
    valid_team = relationship('ValidTeams', lazy='joined', uselist=False)


class ValidEntityFull(Base):
    __tablename__ = Base.metadata._sequences['valid_prefix'] + 'valid_entities_full'

    hierarchy = Column(String)
    persistence_id = Column(String)
    entity_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'entity.entity_id'),
                       primary_key=True)
    entity_type_id = Column(String)
    max_updated_at = Column(String)

    entity = relationship('Entity', lazy='joined', uselist=False,
                          primaryjoin='and_(Entity.entity_id == ValidEntityFull.entity_id, '
                                      'or_(Entity.updated_at == ValidEntityFull.max_updated_at, '
                                      'ValidEntityFull.max_updated_at == None))')


class ValidEntity(Base):
    __tablename__ = Base.metadata._sequences['valid_prefix'] + 'valid_entities'

    hierarchy = Column(String)
    persistence_id = Column(String)
    entity_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'entity.entity_id'),
                       primary_key=True)
    entity_type_id = Column(String)
    max_updated_at = Column(String)

    entity = relationship('Entity', lazy='joined', uselist=False,
                          primaryjoin='and_(Entity.entity_id == ValidEntity.entity_id, '
                                      'or_(Entity.updated_at == ValidEntity.max_updated_at, '
                                      'ValidEntity.max_updated_at == None))')


class EntityAddress(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'entity_address_xref' + Base.metadata._sequences['main_postfix']

    entity_address_id = Column(String, primary_key=True, nullable=False, info=info.entity_address_id)
    entity_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'entity.entity_id'), nullable=False, info=info.entity_id)
    address_type_id = Column(Integer, ForeignKey('address_type_enum.address_type_id'), nullable=False,
                             info=info.address_type_id)
    street_address_1 = Column(String, nullable=False, info=info.street_address_1)
    street_address_2 = Column(String, info=info.street_address_2)
    city = Column(String, nullable=False, info=info.city)
    state = Column(String, nullable=False, info=info.state)
    country = Column(String, nullable=False, info=info.country)
    postal_code = Column(String, nullable=False, info=info.postal_code)
    ended_at = Column(DateTime(), info=info.ended_at)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)
    ingested_at = Column(DateTime(), info=info.ingested_at)


class EntityEmail(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'entity_email_xref' + Base.metadata._sequences['main_postfix']

    entity_email_id = Column(String, primary_key=True, nullable=False, info=info.entity_email_id)
    entity_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'entity.entity_id'), nullable=False, info=info.entity_id)
    email_type_id = Column(String, ForeignKey('email_type_enum.email_type_id'), nullable=False, info=info.email_type_id)
    email_address = Column(String, info=info.email_address)
    ended_at = Column(DateTime(), info=info.ended_at)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)
    ingested_at = Column(DateTime(), info=info.ingested_at)

    # orm mapping to enum table
    email_type = relationship('EmailType', lazy='joined')


class EntityPhone(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'entity_phone_xref' + Base.metadata._sequences['main_postfix']

    entity_phone_id = Column(String, primary_key=True, nullable=False, info=info.entity_phone_id)
    entity_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'entity.entity_id'), primary_key=True, nullable=False,
                       info=info.entity_id)
    phone_type_id = Column(Integer, ForeignKey('phone_type_enum.phone_type_id'), nullable=False, info=info.phone_type_id)
    country_code = Column(String, info=info.country_code)
    phone_number = Column(String, info=info.phone_number)
    extension = Column(String, info=info.extension)
    ended_at = Column(DateTime(), info=info.ended_at)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)
    ingested_at = Column(DateTime(), info=info.ingested_at)

    # orm mapping to enum table
    phone_type = relationship('PhoneType', lazy='joined')


class EntityTeam(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'entity_team_xref' + Base.metadata._sequences['main_postfix']

    entity_team_id = Column(String, primary_key=True, info=info.entity_team_id)
    team_entity_id = Column(String, ForeignKey('valid_teams.team_entity_id'), info=info.CD)
    entity_crd = Column(String, info=info.CD)
    # entity_crd = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'entity.crd'), info=info.crd)
    ingested_at = Column(DateTime(), info=info.ingested_at)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)

    # relationship here will join back to entity on matching CRDs
    member = relationship('Entity',
                          lazy='joined',
                          primaryjoin='EntityTeam.entity_crd==Entity.crd',
                          uselist=False)


class ValidTeams(Base):
    __tablename__ = Base.metadata._sequences['valid_prefix'] + 'valid_teams'

    team_entity_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'entity.entity_id'), primary_key=True)
    valid_persons = Column(ARRAY(String))


class EntityType(Base):
    __tablename__ = 'entity_type_enum'

    entity_type_id = Column(String, primary_key=True, nullable=False, info=info.CD)
    entity_type_name = Column(String, nullable=False, info=info.CD)


class ValidLOB(Base):
    __tablename__ = Base.metadata._sequences['valid_prefix'] + 'valid_lob'

    agreement_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'agreement.agreement_id'),
                          primary_key=True, nullable=False, info=info.agreement_id)
    sales_owner_id = Column(String, nullable=False, info=info.sales_owner_id)
    sales_owner_id_type = Column(String, info=info.sales_owner_id_type)
    employee_id = Column(String, primary_key=True, info=info.employee_id)
    employee_type = Column(String, info=info.employee_type)
    channel_id = Column(Integer, ForeignKey('channel_enum.channel_id'), nullable=False, info=info.channel_id)
    sf_channel_id = Column(Integer, nullable=False, info=info.channel_id)
    region_name = Column(String, info=info.region_name)
    territory_name = Column(String, info=info.territory_name)

    channel = relationship('Channel', lazy='joined')


class MoneyType(Base):
    __tablename__ = 'money_type_enum'

    money_type_id = Column(String, primary_key=True, nullable=False, info=info.IUO)
    money_type_desc = Column(String, nullable=False, info=info.IUO)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)


class Origin(Base):
    __tablename__ = 'origin'

    origin_id = Column(Integer, primary_key=True, info=info.IUO)
    origin_name = Column(String, nullable=False, info=info.IUO)
    ended_at = Column(DateTime(), info=info.ended_at)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)


class PhoneType(Base):
    __tablename__ = 'phone_type_enum'

    phone_type_id = Column(String, primary_key=True, info=info.NO)
    phone_type_name = Column(String, nullable=False, info=info.NO)
    hierarchy = Column(Integer, info=info.NO)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)


class RelationshipType(Base):
    __tablename__ = 'relationship_type_enum'

    relationship_type_id = Column(Integer, primary_key=True, nullable=False, info=info.IUO)
    relationship_type_desc = Column(String, nullable=False, info=info.IUO)
    hierarchy = Column(Integer, info=info.NO)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)


class ValidEmployee(Base):
    __tablename__ = Base.metadata._sequences['valid_prefix'] + 'valid_employees'

    employee_id = Column(String, primary_key=True)
    employee_type = Column(String)
    sales_owner_id = Column(String)
    sales_owner_id_type = Column(String, primary_key=True)


class SalesOwner(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'sales_owner_agreement_xref' + Base.metadata._sequences['main_postfix']

    sales_owner_xref_id = Column(String, primary_key=True, nullable=False, info=info.sales_owner_xref_id)
    agreement_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'agreement.agreement_id'), nullable=False,
                          info=info.agreement_id)
    sales_owner_id = Column(String, nullable=False, info=info.sales_owner_id)
    sales_owner_id_type = Column(String, info=info.sales_owner_id_type)
    primary_owner_flag = Column(String, info=info.primary_owner_flag)
    percent_owned = Column(String, info=info.percent_owned)
    # ended_at = Column(DateTime(), info=info.ended_at)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)

    # define specific foreign key constraints for Trade -> TradeCode
    __table_args__ = (ForeignKeyConstraint([sales_owner_id, sales_owner_id_type],
                                           [ValidEmployee.employee_id, ValidEmployee.sales_owner_id_type]), {})
    valid_empl = relationship('ValidEmployee',
                              primaryjoin='and_(SalesOwner.sales_owner_id == ValidEmployee.employee_id,'
                                          'SalesOwner.sales_owner_id_type == ValidEmployee.sales_owner_id_type)',
                              uselist=False)


class ShareClass(Base):
    __tablename__ = 'share_class_enum'

    share_class_id = Column(Integer, primary_key=True, nullable=False, info=info.CD)
    vehicle_type_id = Column(Integer, nullable=False, info=info.CD)
    product_id = Column(Integer, nullable=False, info=info.CD)
    vehicle_type_desc = Column(String, nullable=False, info=info.CD)
    product_name = Column(String, nullable=False, info=info.CD)
    share_class_name = Column(String, info=info.CD)
    status = Column(String, info=info.CD)
    currency = Column(String, info=info.CD)
    isin = Column(String, info=info.CD)
    cusip = Column(String, info=info.CD)
    ticker = Column(String, info=info.CD)
    apir_code = Column(String, info=info.CD)
    ssalur = Column(String, info=info.CD)
    pmf_id = Column(String, info=info.CD)
    sub_strategy_id = Column(Integer, info=info.CD)
    category_id = Column(Integer, info=info.CD)
    category_desc = Column(String, info=info.CD)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)


class SubAgreement(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'sub_agreement' + Base.metadata._sequences['main_postfix']

    agreement_id = Column(String, primary_key=True, nullable=False, info=info.agreement_id)
    agreement_name = Column(String, info=info.agreement_name)
    parent_agreement_id = Column(String, nullable=False, info=info.parent_agreement_id)
    account_number = Column(String, info=info.account_number)
    channel_id = Column(Integer, ForeignKey('channel_enum.channel_id'), nullable=False, info=info.channel_id)
    money_type_id = Column(String, nullable=False, info=info.money_type_id)
    preferred_currency_id = Column(Integer, ForeignKey('currency_enum.currency_id'), nullable=False,
                                   info=info.preferred_currency_id)
    benchmark_id = Column(String, info=info.benchmark_id)
    ta_number = Column(String, info=info.ta_number)
    external_identifier = Column(String, nullable=False, info=info.external_identifier)
    external_identifier_type = Column(String, nullable=False, info=info.external_identifier_type)
    erisa_plan = Column(String, info=info.erisa_plan)
    unit_holder_code = Column(String, info=info.unit_holder_code)
    ipo_flag = Column(Boolean, info=info.ipo_flag)
    ocio_flag = Column(Boolean, info=info.ocio_flag)
    inception_date = Column(DateTime(), info=info.inception_date)
    origin_id = Column(Integer, ForeignKey('origin.origin_id'), nullable=False, info=info.origin_id)
    aggregator_id = Column(Integer, ForeignKey('aggregator.aggregator_id'), nullable=False, info=info.aggregator_id)
    external_agreement_id = Column(String, info=info.external_agreement_id)
    ended_at = Column(DateTime(), info=info.ended_at)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)


class ValidSubAgreement(Base):
    __tablename__ = Base.metadata._sequences['valid_prefix'] + 'valid_sub_agreements'

    agreement_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'agreement.agreement_id'),
                          primary_key=True)
    aum_id = Column(String, primary_key=True, nullable=False, info=info.aum_id)
    raw_amount = Column(String, nullable=False, info=info.raw_amount)
    usd_amount = Column(String, nullable=False, info=info.usd_amount)
    currency_iso3_code = Column(String, nullable=False, info=info.currency_id)
    as_of_date = Column(String, nullable=False, info=info.as_of_date)

    agreement = relationship('Agreement', lazy='joined', uselist=False)


class Territory(Base):
    __tablename__ = 'territory_enum'

    territory_id = Column(Integer, primary_key=True, info=info.IUO)
    territory_name = Column(String, nullable=False, info=info.IUO)
    channel_id = Column(Integer, ForeignKey('channel_enum.channel_id'), info=info.IUO)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)


class TradeCode(Base):
    __tablename__ = 'trade_code_enum'

    # two PKs here create a composite key for the view
    aggregator_trade_code = Column(String, primary_key=True, info=info.IUO)
    trade_desc = Column(String, info=info.IUO)
    flow_type = Column(String, info=info.IUO)
    aggregator_id = Column(Integer, primary_key=True, info=info.IUO)


class Trade(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'trade' + Base.metadata._sequences['main_postfix']

    trade_id = Column(String, primary_key=True, info=info.trade_id)
    aggregator_trade_code = Column(String, nullable=False, info=info.aggregator_trade_code)
    agreement_id = Column(String, ForeignKey(Base.metadata._sequences['main_prefix'] + 'agreement.agreement_id'),
                          nullable=False, info=info.aggregator_id)
    amount = Column(String, nullable=False, info=info.amount)
    currency_id = Column(String, ForeignKey('currency_enum.currency_id'), nullable=False, info=info.currency_id)
    start_date = Column(String, nullable=False, info=info.start_date)
    end_date = Column(String, nullable=False, info=info.end_date)
    aggregator_id = Column(Integer, ForeignKey('aggregator.aggregator_id'), nullable=False, info=info.aggregator_id)
    # ended_at = Column(DateTime(), info=info.ended_at)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)

    # define specific foreign key constraints for Trade -> TradeCode
    __table_args__ = (ForeignKeyConstraint([aggregator_trade_code, aggregator_id],
                                           [TradeCode.aggregator_trade_code, TradeCode.aggregator_id]), {})
    trade_code = relationship('TradeCode',
                              primaryjoin='and_(Trade.aggregator_trade_code == TradeCode.aggregator_trade_code,'
                                          'Trade.aggregator_id == TradeCode.aggregator_id)')


class ValidFlows(Base):
    __tablename__ = Base.metadata._sequences['valid_prefix'] + 'valid_flows'

    salesforce_id = Column(String, info=info.IUO)
    entity_id = Column(String, info=info.IUO)
    agreement_id = Column(String, info=info.IUO)
    flow_id = Column(String, primary_key=True, info=info.IUO)
    flow_type = Column(String, info=info.IUO)
    amount = Column(String, info=info.IUO)
    usd_amount = Column(String, info=info.IUO)
    currency_id = Column(String, info=info.IUO)
    share_class_id = Column(String, info=info.IUO)
    sub_strategy_id = Column(String, info=info.IUO)
    vehicle_type_id = Column(String, info=info.IUO)
    start_date = Column(String, info=info.IUO)
    end_date = Column(String, info=info.IUO)
    created_at = Column(String, info=info.IUO)
    updated_at = Column(String, info=info.IUO)
    aggregator_id = Column(String, info=info.IUO)


class ZipTerritory(Base):
    __tablename__ = 'territory_postal_xref'

    zip_territory_id = Column(Integer, primary_key=True, autoincrement=True, info=info.zip_territory_id)
    country_id = Column(Integer, ForeignKey('country_enum.country_id'), nullable=False, info=info.country_id)
    postal_code = Column(String, info=info.postal_code)
    territory_id = Column(Integer, ForeignKey('territory_enum.territory_id'), nullable=False, info=info.territory_id)
    ended_at = Column(DateTime(), info=info.ended_at)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)
