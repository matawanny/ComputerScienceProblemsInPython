from cm_commons.models.sqlalchemy import sql_classes


def export_pandas(obj):
    p_key = list(obj.__table__.primary_key)
    field_names = obj.__table__.c._data.keys()

    return {"fields":
        {k:
            {
                "type": obj.__table__.c._data[k].type,
                "nullable": obj.__table__.c._data[k].nullable,
                "encrypted": obj.__table__.c._data[k].info['encrypted'],
                "required": obj.__table__.c._data[k].info['required'] if 'required' in obj.__table__.c._data[k].info else []
            } for k in field_names
        },
        "primaryKey": [
            {
                'table': pk.table.name, 'field': pk.expression.name
            } for pk in obj.__table__.primary_key.columns
        ],
        "foreignKey": [
            {
                'source_table': obj.__table__.name,
                'source_field': fk.parent.name,
                'target_table': fk.target_fullname.split('.')[0],
                'target_field': fk.target_fullname.split('.')[1]
            } for fk in obj.__table__.foreign_keys if fk.column.primary_key
        ],
        "source": "sqlAlchemy"
    }


def export_model(class_name, stack="spark", dest="src"):
    """
        :param class_name:
        :param stack:
        :param dest:
        :return:
    """
    from cm_commons.colors import out_print, suc_print
    # out_print(class_name)
    for cls in sql_classes:
        # suc_print(cls.__tablename__)
        if cls.__tablename__ == class_name:
            return export_pandas(cls)


def build_schema(tables):
    schema = {}
    for tbl in tables:
        schema[tbl] = export_model(tbl)
    return schema


# Generic target schemas
dumb = build_schema(['entity']
                          )
MDM_schema = build_schema(['aum', 'agreement', 'sub_agreement', 'channel', 'entity', 'agreement_entity_xref',
                           'entity_address_xref', 'entity_email_xref', 'entity_phone_xref', 'trade', 'source', 'system',
                           'test_table', 'sales_owner_agreement_xref', 'entity_team_xref']
                          )

DB_sync_schema = build_schema(['aum', 'agreement', 'sub_agreement', 'channel', 'entity', 'agreement_entity_xref',
                           'entity_address_xref', 'entity_email_xref', 'entity_phone_xref', 'trade', 'source', 'system',
                           'test_table', 'sales_owner_agreement_xref', 'entity_team_xref', 'sv_sales_person',
                           'sv_sales_hierarchy'])

EAPF_schema = build_schema(['entity', 'agreement_entity_xref', 'agreement', 'trade'])
EAPA_schema = build_schema(['entity', 'agreement_entity_xref', 'agreement', 'aum'])
AUM = build_schema(['aum'])
AGREEMENT = build_schema(['agreement'])
TRADE = build_schema(['trade'])
AGREEMENT_ENTITY_XREF = build_schema(['agreement_entity_xref'])
TRADE_only = build_schema(['trade'])
ENTITY_PHONE_EMAIL = build_schema(['entity', 'entity_email_xref', 'entity_phone_xref', 'entity_team_xref'])
ENTITY_ADRRESS = build_schema(['entity', 'entity_address_xref'])

# Salesforce target schemas
sf_entity = build_schema(['entity', 'entity_address_xref', 'entity_phone_xref', 'entity_email_xref'])
SF_API_ENTITY = build_schema(["entity", "entity_address_xref", "entity_email_xref", "entity_phone_xref",
                              "entity_team_xref", "sv_sales_hierarchy", "sv_sales_person"])
SF_API_AGREEMENT = build_schema(['agreement', 'agreement_entity_xref', 'aum', 'trade', 'sales_owner_agreement_xref'])


# AMG target Schemas
AMG_Sprint9 = build_schema(['entity', 'agreement_entity_xref', 'agreement', 'sales_owner_agreement_xref'])
amg_wm_target = build_schema(['entity', 'agreement_entity_xref', 'agreement', 'aum', 'sales_owner_agreement_xref'])

# Salesvision target schemas
AUM_only = build_schema(['aum', 'orig_asset'])
FLOW_only = build_schema(['trade', 'orig_trade'])
SV_TRADE_CODE = build_schema(['salesvision_trade_code_enum'])
SV_SALES_PER = build_schema(['sv_sales_person'])
SV_SALES_HIER = build_schema(['sv_sales_hierarchy'])
SV_HOLDING_schema = build_schema(['agreement_entity_xref', 'agreement', 'sub_agreement',
                                  'sales_owner_agreement_xref', 'orig_holding'])
SV_SALESPERSON_schema = build_schema(['salesvision_sales_person'])

# Fishtank target schemas
FT_target_schema = build_schema(['entity', 'agreement_entity_xref', 'agreement', 'sub_agreement', 'aum', 'trade',
                                 'fishtank_enum', 'sales_owner_agreement_xref'])

# AU Target Schemas
datacleaner_agreement_schema = build_schema(['agreement_entity_xref', 'agreement', 'sales_owner_agreement_xref'])
datacleaner_entity_schema = build_schema(['entity'])
registreet_trade_schema = build_schema(['trade'])
registreet_aum_schema = build_schema(['aum'])
au_platform_subagreement_schema = build_schema(['sub_agreement', 'trade', 'aum', 'entity',
                                               'agreement_entity_xref', 'sales_owner_agreement_xref'])
AUS_agr = build_schema(['agreement_entity_xref', 'agreement'])
AUS_ent = build_schema(['entity'])

# share_class_enum Schemas
share_class_enum_schema = build_schema(['share_class_enum'])
fx_rate_conversion_schema = build_schema(['fx_rate_conversion'])

if __name__ == "__main__":
    from pprint import pprint
    pprint(MDM_schema)

    # null_set = {}
    # for fn in ff:
    #     for etl_source in ff[fn]['required']:
    #
    #         if etl_source not in null_set:
    #             null_set[etl_source] = [fn]
    #         else:
    #             null_set[etl_source].append(fn)
    # pprint(null_set)
