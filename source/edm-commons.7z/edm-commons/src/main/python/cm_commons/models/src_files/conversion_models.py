fx_rate_conversion_source_schema = {
    "source": True,
    "target": False,
    "mapping": {
        "FX_RATE_ID": "fx_rate_id",
        "CURRENT_SYMBOL": "current_symbol",
        "CURRENT_RATE": "current_rate",
        "TARGET_SYMBOL": "target_symbol",
        "TARGET_RATE": "target_rate",
        "FX_RATE": "fx_rate",
        "RATE_date": "rate_date"
    }
}