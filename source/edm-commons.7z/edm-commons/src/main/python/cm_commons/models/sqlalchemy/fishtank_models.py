from cm_commons.models.sqlalchemy.base import *


class FishtankENUM(Base):
    __tablename__ = 'fishtank_enum'
    agreement_id = Column(String, primary_key=True, info=info.IUO)
    crm_id = Column(String, info=info.IUO)
    salesforce_id = Column(String, info=info.salesforce_id)
    period = Column(String, info=info.IUO)
    isin = Column(String, info=info.IUO)
    platform = Column(String, info=info.IUO)
    platform_crm_id = Column(String, info=info.IUO)
    currency = Column(String, info=info.IUO)
    aum = Column(String, info=info.IUO)
    organization_name = Column(String, info=info.IUO)
    gross_sales = Column(String, info=info.IUO)
    gross_redemptions = Column(String, info=info.IUO)
    net_flow = Column(String, info=info.IUO)
    channel_mapping = Column(String, info=info.IUO)
    client_type = Column(String, info=info.IUO)
    ft_id = Column(String, info=info.IUO)
    employee_crm_name = Column(String, info=info.IUO)
    fca_number = Column(String, info=info.IUO)
    office_name = Column(String, info=info.IUO)
