import cm_commons.models.sqlalchemy as sqla

def sqla_to_sparkdf(sqla_table, num_rows=None, field_vals={}, spark=None, key_bool=False, x_cols={}):

    from pyspark.sql.types import StructType, StructField, StringType, BooleanType, FloatType, IntegerType, ArrayType

    if not num_rows:
        num_rows = len(field_vals[next(iter(field_vals))])

    type_map = {"varchar": StringType(),
                "boolean": BooleanType(),
                "integer": IntegerType(),
                "float": FloatType(),
                "datetime": StringType()
                }

    tbl_rel = getattr(sqla.current_module, sqla_table).__table__
    tbl = getattr(sqla.current_module, sqla_table).__table__.c._data

    # Get keys
    keys = {'pkey': [],
            'fkey': [],
            'skey': []}

    # pkey
    for pk in tbl_rel.primary_key.columns:
        keys['pkey'].append({'table': pk.table.name, 'field': pk.expression.name}
                            )
    # skey
    for fn, obj in tbl.items():
        if obj.info.get("skey", False):
            keys['skey'].append({'table': tbl_rel.name, 'field': fn})

    # fkey
    for fk in tbl_rel.foreign_keys:
        if tbl[fk.parent.name].info.get("fkey_of_pkey", False):
            keys['fkey'].append({
                            'source_table': tbl_rel.name,
                            'source_field': fk.parent.name,
                            'target_table': fk.target_fullname.split('.')[0],
                            'target_field': fk.target_fullname.split('.')[1]
                        }
                )

    # Get schema
    fields = []
    for fn, obj in tbl.items():
        if tbl[fn].type.python_type == list:
            inner_type = type_map[str(tbl['id_path'].type.item_type).lower()]
            fields.append(StructField(fn, ArrayType(inner_type), True))
        else:
            fields.append(StructField(fn, type_map[str(tbl[fn].type).lower()], True))

    for fn, type in x_cols.items():
        fields.append(StructField(fn, type_map[type.lower()], True))

    data_schema = StructType(fields=fields)

    # Get fields
    rows = [[] for ii in range(num_rows)]
    for row_n in range(0, num_rows):
        # Iterate over schema items
        for fn, obj in tbl.items():
            if fn in field_vals:
                rows[row_n].append(field_vals[fn][row_n])
            else:
                field_type = str(tbl[fn].type).lower()
                default_type_map = {"varchar": f"default_{fn}",
                                    "boolean": True,
                                    "integer": -1,
                                    "float": -1.0,
                                    "datetime": f"default_{fn}"}

                rows[row_n].append(obj.info.get("default", default_type_map[field_type]))
        # Iterate over x_col items
        for fn, type in x_cols.items():
            if fn in field_vals:
                rows[row_n].append(field_vals[fn][row_n])
            else:
                rows[row_n].append(f"default_{fn}")



    if spark == None:
        if key_bool:
            return data_schema, rows, keys
        else:
            return data_schema, rows
    else:
        if key_bool:
            return spark.createDataFrame(rows, schema=data_schema), keys
        else:
            return spark.createDataFrame(rows, schema=data_schema)




if __name__ == "__main__":
    NUM = 10000
    print(len([str(ii) for ii in range(NUM * 2)]))
    print(len(["001" + str(ii) for ii in range(NUM)] + (["None" for ii in range(NUM)])))
    in_dat = {"entity_id": [str(ii) for ii in range(NUM * 2)],
              "salesforce_id": ["001" + str(ii) for ii in range(NUM)] + ["None" for ii in range(NUM)],
              "salesvision_id": [str(ii) for ii in range(NUM)] + [str(ii) for ii in range(NUM)],
              "etl_source": ['cm' for ii in range(NUM)] + ['sv' for ii in range(NUM)]}
    in_df = sqla_to_sparkdf("Entity",
                                  num_rows=NUM * 2,
                                  field_vals=in_dat,
                                  key_bool=True,
                                  x_cols={'etl_source': 'varchar'})
