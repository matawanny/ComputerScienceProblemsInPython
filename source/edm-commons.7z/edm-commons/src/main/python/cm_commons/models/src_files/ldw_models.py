ldw_trade = {
    "source": True,
    "target": False,
    "mapping": {
        "pmf_symbol": "portfolio_symbol",
        "tran_trade_date": "tran_trade_date",
        "tran_type": "tran_type_remark",
        "port_cur_iso3": "currency",
        "flow_port_cur": "amount"
    },
    "flexible": {"InvestmentAmount": "flow"},
    "query": []
}

ldw_asset = {
    "source": True,
    "target": False,
    "mapping": {
        "as_of_date": "as_of_date",
        "portfolio_symbol": "portfolio_symbol",
        "portfolio_currency_symbol": "currency",
        "mv_port_cur": "amount"
    },
    "flexible": {"InvestmentAmount": "flow"},
    "query": []
}
