ai_aum = {
  "source": True,
  "target": False,
  "mapping": {
    "InvestorID": "investor_id",
    "Investor": "investor_name",
    "SubInvestorID": "sub_investor_id",
    "SubInvestor": "sub_investor_name",
    "InvestmentName": "investment_name",
    "NavDate": "as_of_date_raw",
    "MVLocal": "aum",
    "ClassID": "share_class_id",
    "ErisaType": "erisa_type"
  },
  "flexible": {"MVLocal": "aum"},
  "query": []
}


blank_ai_aum = {
  "source": True,
  "target": False,
  "mapping": {
    "_c0": "investor_id",
    "_c1": "sub_investor_id",
    "_c2": "investor_name",
    "_c3": "sub_investor_name",
    "_c4": "investment_name",
    "_c5": "share_class_id",
    "_c6": "aum",
    "_c7": "as_of_date_raw",
    "_c8": "erisa_type",
  },
  "flexible": {"InvestmentAmount": "flow"},
  "query": []
}


blank_ai_flow = {

  "source": True,
  "target": False,
  "mapping": {
    "_c0": "investor_id",
    "_c1": "sub_investor_id",
    "_c2": "investor_name",
    "_c3": "sub_investor_name",
    "_c4": "investment_name",
    "_c5": "share_class_id",
    "_c6": "transaction_code",
    "_c7": "start_date",
    "_c8": "amount",
    "_c9": "erisa_type"
  },
  "flexible": {"InvestmentAmount": "flow"},
  "query": []
}

ai_flow = {
  "source": True,
  "target": False,
  "mapping": {
    "InvestorID": "investor_id",
    "InvestorName": "investor_name",
    "SubInvestorID": "sub_investor_id",
    "SubInvestorName": "sub_investor_name",
    "InvestmentDate": "start_date",
    "InvestmentAmount": "amount",
    "ClassId": "share_class_id",
    "TransCode": "transaction_code",
    "erisatype": "erisa_type"
  },
  "flexible": {"InvestmentAmount": "flow"},
  "query": []
}