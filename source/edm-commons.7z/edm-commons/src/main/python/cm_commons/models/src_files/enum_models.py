share_class_enum_source_schema = {
    "source": True,
    "target": False,
    "mapping": {
        "SHARE_CLASS_ID": "share_class_id",
        "VEHICLE_TYPE_ID": "vehicle_type_id",
        "PRODUCT_ID": "product_id",
        "VEHICLE_TYPE_DESC": "vehicle_type_desc",
        "PRODUCT_NAME": "product_name",
        "SHARE_CLASS_NAME": "share_class_name",
        "STATUS": "status",
        "CURRENCY_ID": "currency",
        "ISIN": "isin",
        "CUSIP": "cusip",
        "TICKER": "ticker",
        "APIR_CODE": "apir_code",
        "SSALUR": "ssalur",
        "PMF_ID": "pmf_id",
        "SUB_STRATEGY_ID": "sub_strategy_id",
        "category_id": "category_id",
        "category_desc": "category_desc"
    }
}