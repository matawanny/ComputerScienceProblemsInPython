from cm_commons.models.sqlalchemy.base import *


class FXRate(Base):
    __tablename__ = 'fx_rate_conversion'

    fx_rate_id = Column(Integer, primary_key=True, autoincrement=True, info=info.IUO)
    current_symbol = Column(String, nullable=False, info=info.IUO)
    current_rate = Column(Float, nullable=False, info=info.IUO)
    target_symbol = Column(String, nullable=False, info=info.IUO)
    target_rate = Column(Float, nullable=False, info=info.IUO)
    fx_rate = Column(Float, nullable=False, info=info.IUO)
    rate_date = Column(String, nullable=False, info=info.IUO)
    end_date = Column(String, nullable=False, info=info.IUO)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)


class Group(Base):
    __tablename__ = 'group_enum'

    group_id = Column(Integer, primary_key=True, nullable=False, info=info.IUO)
    group_name = Column(String, nullable=False, info=info.IUO)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)


class TestTable(Base):
    __tablename__ = 'test_table'

    id = Column(Integer, primary_key=True, info=info.IUO)
    a = Column(String, nullable=False, info=info.IUO)
    b = Column(String, nullable=False, info=info.IUO)
    c = Column(String, nullable=False, info=info.IUO)
    d = Column(String, nullable=False, info=info.IUO)
