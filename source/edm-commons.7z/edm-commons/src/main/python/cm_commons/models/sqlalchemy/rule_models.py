from cm_commons.models.sqlalchemy.base import *




class AUMRule(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'persist_rules_aum' + Base.metadata._sequences['main_postfix']

    rule_id = Column(String, primary_key=True, nullable=False, info=info.IUO)
    original_record_aum_id = Column(String, nullable=False, info=info.IUO)
    source_name = Column(String, nullable=False, info=info.CD)
    column_name = Column(String, nullable=False, info=info.CD)
    invalid_value = Column(String, info=info.CD)
    valid_value = Column(String, info=info.CD)
    stewardship_type = Column(String, nullable=False, info=info.CD)
    submitted_at = Column(String, nullable=False, info=info.CD)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)

class AgreementPersistRules(Base):
    __tablename__ = 'persist_rules_agreement'

    rule_id = Column(String, primary_key=True, nullable=False, info=info.IUO)
    original_record_agreement_id = Column(String, nullable=False, info=info.IUO)
    source_name = Column(String, nullable=False, info=info.CD)
    column_name = Column(String, nullable=False, info=info.CD)
    invalid_value = Column(String, info=info.CD)
    valid_value = Column(String, info=info.CD)
    stewardship_type = Column(String, nullable=False, info=info.CD)
    submitted_at = Column(String, nullable=False, info=info.CD)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)

class AgreementEntityPersistRules(Base):
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'persist_rules_agreement_entity_xref' + Base.metadata._sequences['main_postfix']

    rule_id = Column(String, primary_key=True, nullable=False, info=info.IUO)
    original_record_agreement_entity_xref_id = Column(String, info=info.IUO)
    source_name = Column(String, nullable=False, info=info.CD)
    column_name = Column(String, nullable=False, info=info.CD)
    invalid_value = Column(String, info=info.CD)
    valid_value = Column(String, info=info.CD)
    stewardship_type = Column(String, nullable=False, info=info.CD)
    submitted_at = Column(String, nullable=False, info=info.CD)
    created_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)
    updated_at = Column(DateTime(), default=datetime.utcnow(), onupdate=datetime.utcnow(), info=info.CD)

class EntityPersistRules(Base):
    # TODO -  Table name may have `stg_` prefix pending EDM-1917
    __tablename__ = Base.metadata._sequences['main_prefix'] + 'persist_rules_entity'
    rule_id = Column(String, primary_key=True, nullable=False, info=info.IUO)
    original_record_entity_id = Column(String, nullable=False, info=info.IUO)
    entity_type_id = Column(String, info=info.CD)
    column_name = Column(String, nullable=False, info=info.CD)
    invalid_value = Column(String, info=info.CD)
    valid_value = Column(String, info=info.CD)
    stewardship_type = Column(String, nullable=False, info=info.CD)
    created_by = Column(String, nullable=False, info=info.CD)
    created_at = Column(DateTime(), default=datetime.utcnow(), nullable=False, info=info.CD)


class TradeRule(Base):
    __tablename__ = 'trade_rule'

    rule_id = Column(Integer, primary_key=True, nullable=False, info=info.IUO)
    original_record_trade_id = Column(String, nullable=False, info=info.IUO)
    source_name = Column(String, nullable=False, info=info.CD)
    column_name = Column(String, nullable=False, info=info.CD)
    invalid_value = Column(String, info=info.CD)
    valid_value = Column(String, info=info.CD)
    stewardship_type = Column(String, nullable=False, info=info.CD)
    submitted_at = Column(DateTime(), default=datetime.utcnow(), info=info.CD)

