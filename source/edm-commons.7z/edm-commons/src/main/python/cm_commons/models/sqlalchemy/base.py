from datetime import datetime
import inspect
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import ARRAY, Boolean, Column, DateTime, ForeignKey, Integer, String, Float, ForeignKeyConstraint
import sys

from cm_commons.util.system import env
import cm_commons.util.field_details as info


# declare model base for custom ORM objects
Base = declarative_base()
Base.metadata._sequences['main_prefix'] = 'cm_'
Base.metadata._sequences['valid_prefix'] = ''
Base.metadata._sequences['sv_salesperson'] = 'sv_salesperson_'
Base.metadata._sequences['main_postfix'] = ''

# flag for
if env == 'nj1ux-rhdev4' or env == 'emr':
    Base.metadata._sequences['main_prefix'] = ''
    Base.metadata._sequences['main_postfix'] = ''
    Base.metadata._sequences['sv_salesperson'] = ''
