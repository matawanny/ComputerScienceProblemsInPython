ERROR = '\033[31m'
FUNCTIONS = '\033[35;4m'
ARGS = '\033[33;2m'
VARIABLES = '\033[34;2m'
DEF = '\033[0m'

css = {'b': '\033[1m', '/b': '\033[0m',
       'i': '\033[4m', '/i': '\033[0m',
       'h1': '\033[32;1;4m', '/h1': DEF,
       'h2': '\033[32;3m', '/h2': DEF,
       'err': ERROR, '/err': DEF,
       }


def to_doc(indent=0):
    def decorator(f):
        def wrapper(*args, **kwargs):
            try:
                if len(args) > 1:
                    out = 'self, ' + ', '.join(str(ii) for ii in args[1:])
                else:
                    out = 'self'
                for kk in kwargs:
                    out = out + ', ' + ARGS + str(kk) + DEF + '='+VARIABLES+str(kwargs[kk])+DEF
                f_rep = FUNCTIONS + f.__name__ + DEF + '(''{}'.format(out)+'):'

                if True:
                    args[0].__doc__ = args[0].__doc__ + '\n' + '\t'*indent + \
                                                        '-' + f_rep + f.__doc__.format(**css) + \
                                                        '' + '\t'*(indent+1)
                if args[0].read_only:
                    return args[0]
                else:
                    return f(*args, **kwargs)

            except:
                f_rep = FUNCTIONS + f.__name__ + DEF + '(' + VARIABLES + '{}'.format(out) + DEF + '):'
                if True:
                    args[0].__doc__ = args[0].__doc__ + '\n' + '\t'*indent + '- ' + f_rep + ERROR + 'No docstring listed\033[0m' + '\n' \
                                                        '\t' * (indent+1)
                try:
                    if args[0].read_only:
                        return args[0]
                    else:
                        return f(*args, **kwargs)
                except:
                    return f(*args, **kwargs)
        return wrapper
    return decorator