# from cm_commons.util.cloudwatch_util import *
#
#
# colors = {'black': "\033[30m",
#           'red': "\033[31m",
#           'green': "\033[32m",
#           'yellow': "\033[33m",
#           'blue': "\033[34m",
#           'magenta': "\033[35m",
#           'cyan': "\033[36m",
#           'white': "\033[37m",
#           'reset': "\033[0m"}
#
# monochrome = False
# cloudwatch = False
#
#
#
# def err_print(inp, indent=0, log_name="edm_default"):
#     if monochrome:
#         print(colors['red'] + "|" + "\t"*indent + "ERROR: " + inp + colors['reset'])
#     else:
#         print("|" + "\t"*indent + "ERROR: " + inp )
#
#     if cloudwatch:
#         logger = logging.getLogger(log_name)
#         logger.info("ERROR: " + inp)
#
# def war_print(inp, indent=0,log_name="edm_default"):
#     if monochrome:
#         print(colors['yellow'] + "|" + "\t"*indent + "WARNING: " + inp + colors['reset'])
#     else:
#         print("|" + "\t"*indent + "WARNING: " + inp )
#     if cloudwatch:
#         logger = logging.getLogger(log_name)
#         logger.info("WARNING: " + inp)
#
# def out_print(inp, indent=0, log_name="edm_default"):
#     if monochrome:
#         print(colors['blue'] + "|" + "\t"*indent + inp + colors['reset'])
#     else:
#         print("|" + "\t"*indent + inp)
#     if cloudwatch:
#         logger = logging.getLogger(log_name)
#         logger.info("OUTPUT: " + inp)
#
# def suc_print(inp, indent=0, log_name="edm_default"):
#     if monochrome:
#         print(colors['green'] + "|" + "\t"*indent + colors['green'] + inp + colors['reset'])
#     else:
#         print("|" + "\t"*indent +  + inp)
#
#     if cloudwatch:
#         logger = logging.getLogger(log_name)
#         logger.info("SUCCESS: " + inp)
#
# def hea_print(inp, indent=0, log_name="edm_default"):
#     if monochrome:
#         print(colors['green'] + "|" + "\t"*indent + colors['green'] + inp + colors['reset'])
#     else:
#         print("|" + "\t"*indent +  + inp)
#     if cloudwatch:
#         logger = logging.getLogger(log_name)
#         logger.info("HEADER: " + inp)
#
# def bug_print(inp, indent=0, log_name="edm_default"):
#     if monochrome:
#         print(colors['cyan'] + "|" + "\t"*indent + "###########" + colors['cyan'] + inp + colors['reset'])
#     else:
#         print("|" + "\t"*indent + "###########" + + inp)
#     if cloudwatch:
#         logger = logging.getLogger(log_name)
#         logger.info("DEBUG:" + inp)
#
# def saf_print(inp, indent=0, log_name="edm_default"):
#     if monochrome:
#         print(colors['magenta'] + "|" + "\t"*indent + "SAFE-COUNT:" + colors['magenta'] + inp + colors['reset'])
#     else:
#         print("|" + "\t"*indent + "SAFE-COUNT:" + + inp)
#     if cloudwatch:
#         logger = logging.getLogger(log_name)
#         logger.info("SAFE-PRINT:" + inp)