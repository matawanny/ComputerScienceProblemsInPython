from datetime import datetime
import time


colors = {'black': "\033[30m",
          'red': "\033[31m",
          'green': "\033[32m",
          'yellow': "\033[33m",
          'blue': "\033[34m",
          'magenta': "\033[35m",
          'cyan': "\033[36m",
          'white': "\033[37m",
          'reset': "\033[0m"}

monochrome = True
cloudwatch = False

fmt = "[%y/%m/%d %H:%M:%S] "

def err_print(inp, indent=0, log_name="edm_default"):
    if monochrome:
        print(colors['red'] + "|" + datetime.now().strftime(fmt) + "\t"*indent + "ERROR: " + inp + colors['reset'])
    else:
        print("|" + datetime.now().strftime(fmt) + "\t"*indent + "ERROR: " + inp )

def war_print(inp, indent=0,log_name="edm_default"):
    if monochrome:
        print(colors['yellow'] + "|" + datetime.now().strftime(fmt) + "\t"*indent + "WARNING: " + inp + colors['reset'])
    else:
        print("|" + datetime.now().strftime(fmt) + "\t"*indent + "WARNING: " + inp )

def out_print(inp, indent=0, log_name="edm_default"):
    if monochrome:
        print(colors['blue'] + "|" + datetime.now().strftime(fmt) + "\t"*indent + inp + colors['reset'])
    else:
        print("|" + datetime.now().strftime(fmt) + "\t"*indent + inp)

def suc_print(inp, indent=0, log_name="edm_default"):
    if monochrome:
        print(colors['green'] + "|" + datetime.now().strftime(fmt) + "\t"*indent + colors['green'] + inp + colors['reset'])
    else:
        print("|" + datetime.now().strftime(fmt) + "\t"*indent + inp)


def hea_print(inp, indent=0, log_name="edm_default"):
    if monochrome:
        print(colors['green'] + "|" + datetime.now().strftime(fmt) + "\t"*indent + colors['green'] + inp + colors['reset'])
    else:
        print("|" + datetime.now().strftime(fmt) + "\t"*indent + inp)

def bug_print(inp, indent=0, log_name="edm_default"):
    if monochrome:
        print(colors['cyan'] + "|" + datetime.now().strftime(fmt) + "\t"*indent + "###########" + colors['cyan'] + inp + colors['reset'])
    else:
        print("|" + datetime.now().strftime(fmt) + "\t"*indent + "###########" + inp)

def tst_print(inp, indent=0, log_name="edm_default"):
    if monochrome:
        print(colors['cyan'] + "|" + datetime.now().strftime(fmt) + "\t"*indent + colors['cyan'] + inp + colors['reset'])
    else:
        print("|" + datetime.now().strftime(fmt) + "\t"*indent + inp)


def saf_print(inp, indent=0, log_name="edm_default"):
    if monochrome:
        print(colors['magenta'] + "|" + datetime.now().strftime(fmt) + "\t"*indent + "SAFE-COUNT:" + colors['magenta'] + inp + colors['reset'])
    else:
        print("|" + datetime.now().strftime(fmt) + "\t"*indent + "SAFE-COUNT:" + inp)

def sql_print(inp, indent=0, log_name="edm_default"):
    if monochrome:
        print(colors['cyan'] + "|" + datetime.now().strftime(fmt) + "\t"*indent + "SQL: " + colors['cyan'] + inp + colors['reset'])
    else:
        print("|" + datetime.now().strftime(fmt) + "\t"*indent + "SQL: " + inp)