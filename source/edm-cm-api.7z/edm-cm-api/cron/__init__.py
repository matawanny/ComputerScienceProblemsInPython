from api_config import MERGE_TABLE_NAME

# TODO: update merge table whenever it changes
MERGE_COUNT_QUERY = """
                    select count(distinct(sf_invalid, invalid_value, sf_valid, valid_value)) 
                    from cm_merge_rules
                    where sf_valid is not null and sf_invalid is not null
                    """


MERGE_DATA_QUERY = f"""
                    select sf_invalid, invalid_value, sf_valid, valid_value, entity_type_id
                    from cm_merge_rules
                    where sf_valid is not null and sf_invalid is not null
                    group by sf_invalid, invalid_value, sf_valid, valid_value, entity_type_id
                    order by entity_type_id asc
                    """