import argparse

from managers.salesforce_export_manager import SalesforceExportManager

# entity type map to send
HIERARCHY = ['1', '2', '3', '4', '5', '6', '7']


if __name__ == '__main__':
    """
    Main process to export Client Master data to Salesforce, using the Salesforce REST API
    
    Authors:
        @Adam Perez
        
    Available Export Jobs:
        - send valid FOP updates
            - hierarchy order (asc or desc)
        - send valid account information
            - valid agreements
            - valid sub agreements
        - send agreement deletes
    """
    # capture cmd line arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--all', action='store_true', help='run entity, agreement, and sub-agreement exports in order',
                        required=False)
    parser.add_argument('--entity', action='store_true', help='run entity export', required=False)
    parser.add_argument('--allagreements', action='store_true', help='run both agreement and sub-agreement export',
                        required=False)
    parser.add_argument('--agreement', action='store_true', help='run agreement export', required=False)
    parser.add_argument('--subagreement', action='store_true', help='run sub-agreement export', required=False)
    parser.add_argument('--flow', action='store_true', help='run flow export', required=False)
    parser.add_argument('--agreement-delete', action='store_true', help='# TODO', required=False)
    parser.add_argument('--merge', action='store_true', help='run merge export', required=False)
    parser.add_argument('--page', help='optional page flag that will allow restarts from specific spot', required=False)
    parser.add_argument('--batch-size', help='optional batch size flag that will change send size on the fly',
                        required=False)
    parser.add_argument('--hierarchy', help='optional hierarchy flag that will allow restarts from specific spot',
                        required=False)
    parser.add_argument('--reverse', action='store_true', help='optional flag that will reverse the hierarchy send',
                        required=False)
    parser.add_argument('--debug', action='store_true', help='debug flag', required=False)
    args = parser.parse_args()
    a = args._get_kwargs()

    # capture helper flags for processing
    arg_page = int(args.page) if args.page else 1
    if args.reverse:
        HIERARCHY = HIERARCHY[:int(args.hierarchy)] if args.hierarchy else HIERARCHY
        HIERARCHY.reverse()
    else:
        HIERARCHY = HIERARCHY[int(args.hierarchy) - 1:] if args.hierarchy else HIERARCHY
    arg_log_lvl = 'DEBUG' if args.debug else 'ERROR'
    arg_batch_size = int(args.batch_size) if args.batch_size else 100
    if arg_batch_size > 200:
        arg_batch_size = 200

    if args.entity:
        """
        Initialize Salesforce Export Manager and run entity export only
        """
        sf_export = SalesforceExportManager('entity', arg_log_lvl, arg_page)
        sf_export.export_logger.info('launching export job running only entity hierarchy')
        for pos in HIERARCHY:
            sf_export.send_entities_to_salesforce_by_type(pos, batch_size=arg_batch_size)
            sf_export = SalesforceExportManager('entity', arg_log_lvl, 1)
        sf_export.export_logger.info('export for entity only complete!')

    if args.allagreements:
        """
        Initialize SF Export for agreements, then subagreements, starting at page 1
        Assumption here is the run should include "all" agreements
        """
        job_type = 'agreement'
        sf_export = SalesforceExportManager(job_type, arg_log_lvl, 1)
        sf_export.export_logger.info('launching export job for both agreements and sub_agreements')
        sf_export.send_agreements_to_salesforce(job_type, batch_size=arg_batch_size)

        job_type = 'sub_agreement'
        sf_export = SalesforceExportManager(job_type, arg_log_lvl, 1)
        sf_export.send_agreements_to_salesforce(job_type, batch_size=arg_batch_size)
        sf_export.export_logger.info('export for all agreements complete!')

    if args.agreement:
        """
        Initialize Salesforce Export Manager and run agreement export only
        """
        job_type = 'agreement'
        sf_export = SalesforceExportManager(job_type, arg_log_lvl, arg_page)
        sf_export.export_logger.info('launching export job running only {}'.format(job_type))
        sf_export.send_agreements_to_salesforce(agreement_type=job_type, batch_size=arg_batch_size)
        sf_export.export_logger.info('export for {} only complete!'.format(job_type))

    if args.subagreement:
        """
        Initialize Salesforce Export Manager and run sub_agreement export only
        """
        job_type = 'sub_agreement'
        sf_export = SalesforceExportManager(job_type, arg_log_lvl, arg_page)
        sf_export.export_logger.info('launching export job running only {}'.format(job_type))
        sf_export.send_agreements_to_salesforce(agreement_type=job_type, batch_size=arg_batch_size)
        sf_export.export_logger.info('export for {} only complete!'.format(job_type))

    if args.flow:
        """
        Initalize Salesforce Export Manager and run flows export only
        """
        job_type = 'flow'
        sf_export = SalesforceExportManager(job_type, arg_log_lvl, arg_page)
        sf_export.export_logger.info('launching export job running {} only'.format(job_type))
        sf_export.send_flows_to_einstein()
        sf_export.export_logger.info('export for {} only complete!'.format(job_type))

    if args.agreement_delete:
        """
        Initialize Salesforce Export Manager and run agreement deletes only
        """
        job_type = 'agreement_delete'
        sf_export = SalesforceExportManager(job_type, arg_log_lvl, arg_page)
        sf_export.export_logger.info('launching agreement delete export job')
        sf_export.send_agreement_deletes_to_salesforce(arg_batch_size)
        sf_export.export_logger.info('export for all agreement deletes completed!')

    if args.merge:
        """
        Initialize Salesforce Export Manager and run merge instructions
        """
        job_type = 'merge'
        sf_export = SalesforceExportManager(job_type, arg_log_lvl, arg_page)
        sf_export.export_logger.info('launching export job for merge data')
        sf_export.send_merge_records_to_salesforce()
        sf_export.export_logger.info('export for all merge data complete!')
