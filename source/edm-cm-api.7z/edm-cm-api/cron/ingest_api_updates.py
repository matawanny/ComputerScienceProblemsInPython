import argparse
import os
import pandas as pd
import time as t

from fm.fileuploader import FileUploader
from fm.config import *
from fm.dynamo import *


# location where upload files will be house on disk
API_LOAD_FILES_LOCATION = 'edm-cm-api/updates'
RELATIVE_PATH = os.path.abspath(os.path.join(os.getcwd(), '../../{}'.format(API_LOAD_FILES_LOCATION)))

# date for conf files
unix_time = f"{int(t.time())}"


if __name__ == '__main__':
    """
    Process to ingest updates from Salesforce:
        - Verify that job can run
        - collect all files in `updates/`
        - merge all files together
        - Send to S3 using File Manager with matching .conf
    """
    # capture cmd line arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--filename', help='supply filename for ingest file', required=True)
    args = parser.parse_args()

    # capture ingest file name from args
    ingest_file_name = args.filename

    # supply location on S3
    uploader = FileUploader("salesforce")

    # get all files in upload dir, move to landing zone for upload
    f_list = []
    for root, dirs, files in os.walk(os.path.relpath(RELATIVE_PATH)):
        for filename in files:
            if 'csv' in filename:
                f_list.append(RELATIVE_PATH + '/' + filename)

    # if no files found, exit
    if not f_list:
        print('no files found, exiting ...')
        exit(0)

    # generate file name
    master_file_name = 'salesforce_entity_{}'.format(ingest_file_name)
    combined_file_name = RELATIVE_PATH + '/{}.csv'.format(master_file_name)

    # combine all files into data frame
    master_csv = pd.concat([pd.read_csv(f, dtype=str) for f in f_list])

    # filter out inactives from SF
    master_csv = master_csv.loc[~master_csv['inactive'].isin(['true'])]

    # combine to CSV
    master_csv.to_csv(combined_file_name, index=False, encoding='utf-8')

    # add big file to f_list to track for deletion
    f_list.append(combined_file_name)

    # send files to S3
    uploader.send_files([combined_file_name])

    # delete files from `updates/` dir after upload
    for f_name in f_list:
        try:
            if os.path.exists(f_name + '.gz'):
                os.remove(f_name + '.gz')
            elif os.path.exists(f_name):
                os.remove(f_name)
        except OSError:
            continue
