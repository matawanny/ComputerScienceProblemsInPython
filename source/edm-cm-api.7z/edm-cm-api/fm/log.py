from fm.config import *
import boto3
from datetime import *
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key


class LogColors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

# TODO: concat these?
def log(msg):
    print(LogColors.OKGREEN + "[LOG] " + msg + LogColors.ENDC)


def trace(msg):
    print(LogColors.OKBLUE + "[DEBUG] " + msg + LogColors.ENDC)


def warn(msg):
    print(LogColors.WARNING + "[IMPORTANT] " + msg + LogColors.ENDC)


def err(msg):
    print(LogColors.FAIL + "[ERROR] " + msg + LogColors.ENDC)


def log_cm_job(aws_region, dynamoDBTable="ClmasterJobStatus", **jobdata):
    try:
        # TODO: make this dnyamodb obj cleaner
        # print("Writing Jobid to dynamo db : "+jobdata['job_id'])
        if aws_region == 'US_EAST_2':
            dynamoDB = boto3.resource('dynamodb', region_name='us-east-2')
        else:
            dynamoDB = boto3.resource('dynamodb', region_name='us-east-1')
        table = dynamoDB.Table(dynamoDBTable)
        # print(boto3.client("dynamodb", "us-east-1").list_tables())
        response = table.query(
            KeyConditionExpression=Key('job_id').eq(jobdata["job_id"])
        )
        items = response['Items']
        jobcount = len(items)
        # no existing job status entry. insert the record.
        if jobcount == 0:
            nowdate = datetime.now().strftime('%Y%m%d')
            jobdata["jobdate"] = nowdate
            table.put_item(
                Item=
                jobdata
            )
        # job exists, update with additional info
        else:
            item = items[0]
            item.update(jobdata)
            table.put_item(Item=item)
    except ClientError as e:
        # err("Error writing to DynamoDB")
        # exit(1)
        raise e("Error writing to DynamoDB")
