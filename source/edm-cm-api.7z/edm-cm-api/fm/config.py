from api_config import local_prod
from common.envconfig import ENVS

env = 'prod' if local_prod else 'test'

# define FM config
BUCKETNAME = ENVS[env]['aws']['s3_bucket'].replace('s3://', '')
keyid = ENVS[env]['keyid']
aws_region = ENVS[env]['aws']['region_for_java']
assume_role = ENVS[env]['assumerole']
aws_path = "aws"
