import time as t
import boto3
from datetime import *
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError
from fm.config import *
import fm.log as l


def gen_appid():
    job_id = str(round(t.time() * 1000))
    return job_id


def get_time():
    return datetime.now().strftime('%Y%m%d %H:%M:%S')


def fm_start(f, job_id):
    job_data = {'job_id': f + "_" + job_id, 'fm_start': get_time()}
    l.log("##############################################")
    l.log("File manager start : " + str(job_data))
    l.log("##############################################")
    l.log_cm_job(aws_region=aws_region, **job_data)


def fm_end(f, job_id):
    job_data = {'job_id': f + "_" + job_id, 'fm_end': get_time()}
    l.log("##############################################")
    l.log("File Manager end : " + str(job_data))
    l.log("Success")
    l.log("##############################################")
    l.log_cm_job(aws_region=aws_region, **job_data)


def fm_error(f, job_id, msg):
    l.err("Writing Error to Dynamo")
    job_data = {'job_id': f + "_" + job_id, 'fm_error_time': get_time(), 'fm_error': msg}
    l.log_cm_job(aws_region=aws_region, **job_data)
