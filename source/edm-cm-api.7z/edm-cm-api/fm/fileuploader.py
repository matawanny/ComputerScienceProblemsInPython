import os
import json
import time as t

from fm.log import *


class FileUploader:
    def __init__(self, source):
        # used for the path in the data bucket
        self.source = source
        if not os.path.isdir(source):
            log("Making a source dir: " + source)
            if os.system("mkdir " + source) != 0:
                err("Error making dir : " + source)
                exit(1)
        self.start_time = t.time()
        log("Refreshing AWS Credentials")
        code = os.system(assume_role + " > /dev/null")
        if code != 0:
            err("Error assuming AWS credentials")
        log("Assumed role: " + assume_role)

    def send_file(self, filename, dest=None, bucket=BUCKETNAME, destcomponent=None):
        # check to see if file exists
        result = self.check_file(filename)

        # if time is > 10 min, execute role again
        elapsed_time = t.time() - self.start_time
        if elapsed_time > 600:
            os.system(assume_role + " > /dev/null")
            self.start_time = t.time()  # reset timer
            log("Refreshing AWS Credentials")
        # check to see if gzipped
        f, file_extension = os.path.splitext(filename)
        if file_extension != ".gz":
            log("Gzipping File :" + filename)
            if result == 1:
                os.system("gzip -f '" + filename + "'")
            else:
                os.system("gzip -f '" + self.source + "/" + filename + "'")
            filename = filename + ".gz"
        # Send file with jar
        self.encrypt_and_upload(filename, dest, bucket, destcomponent)

    def send_files(self, filelist, dest=None, bucket=BUCKETNAME, destcomponent=None):
        for f in filelist:
            self.send_file(f, dest, bucket, destcomponent)

    def is_json(self, myjson):
        try:
            json_object = json.loads(myjson)
        except ValueError:
            return False
        return True

    def check_file(self, filename):
        if os.path.isfile(self.source + "/" + filename):
            return 0
        else:
            if os.path.isfile(filename):
                return 1
            else:
                err("Error file does not exist :" + filename)
                exit(1)

    # source is the name of the source to use for the folder path
    def encrypt_and_upload(self, filename, destdir=None, bucket=BUCKETNAME, destcomponent=None):
        if destcomponent is None:
            destcomponent = "ETL"

        if destdir is None:
            destdir = self.source
        result = self.check_file(filename)
        if result == 0:
            trace(
                "java -classpath aws-encryption-sdk-java-1.3.7-SNAPSHOT-jar-with-dependencies.jar com.amazonaws.encryptionsdk.S3Ecopy \"{s3destbucket}\" \"{dest}\" {keyid} {region} \"{source}/{src}\"".format(
                    s3destbucket=bucket + "/" + destcomponent + "/data/" + destdir, dest=filename, src=filename,
                    source=self.source, region=aws_region, keyid=keyid))
            code = os.system(
                "java -classpath aws-encryption-sdk-java-1.3.7-SNAPSHOT-jar-with-dependencies.jar com.amazonaws.encryptionsdk.S3Ecopy \"{s3destbucket}\" \"{dest}\" {keyid} {region} \"{source}/{src}\" | python check_java.py".format(
                    s3destbucket=bucket + "/" + destcomponent + "/data/" + destdir, dest=filename, src=filename,
                    source=self.source, region=aws_region, keyid=keyid))
            if code == 256:
                err("Error uploading the file :" + filename)
                exit(1)
        elif result == 1:
            trace(
                "java -classpath aws-encryption-sdk-java-1.3.7-SNAPSHOT-jar-with-dependencies.jar com.amazonaws.encryptionsdk.S3Ecopy \"{s3destbucket}\" \"{dest}\" {keyid} {region} \"{src}\"".format(
                    s3destbucket=bucket + "/" + destcomponent + "/data/" + destdir, dest=os.path.basename(filename),
                    src=filename, region=aws_region, keyid=keyid))
            code = os.system(
                "java -classpath aws-encryption-sdk-java-1.3.7-SNAPSHOT-jar-with-dependencies.jar com.amazonaws.encryptionsdk.S3Ecopy \"{s3destbucket}\" \"{dest}\" {keyid} {region} \"{src}\" | python check_java.py".format(
                    s3destbucket=bucket + "/" + destcomponent + "/data/" + destdir, dest=os.path.basename(filename),
                    src=filename, region=aws_region, keyid=keyid))
            if code == 256:
                err("Error uploading the file :" + filename)
                exit(1)
            print(str(code))
        else:
            err("Unknown result")
            exit(1)

        log("Encrypted and sent : " + filename)
