from datetime import datetime, date, timedelta

from api_config import API_DATE_FORMAT, SALESFORCE_DATE_FORMAT


def format_date_for_salesforce(date_in, date_in_format='%Y-%m-%d %H:%M:%S'):
    """
    Format a given date to Salesforce format
    :param date_in:
    :param date_in_format: Default here is the API/CM Generic timestamp format
    :return:
    """
    if not date_in:
        return None
    try:
        formatted_date = datetime.strptime(date_in, SALESFORCE_DATE_FORMAT).strftime(SALESFORCE_DATE_FORMAT)
    except ValueError:
        try:
            formatted_date = datetime.strptime(date_in, date_in_format).strftime(SALESFORCE_DATE_FORMAT)
        except ValueError:
            formatted_date = datetime.strptime(date_in, '%Y-%m-%d %H:%M:%S.%f').strftime(SALESFORCE_DATE_FORMAT)
    return formatted_date if formatted_date else None


def format_date_for_einstein(date_in, date_in_format='%Y-%m-%d %H:%M:%S'):
    """
    Format given date for Einstein
    :param date_in:
    :param date_in_format:
    :return:
    """
    if not date_in:
        return None
    return datetime.strptime(date_in, date_in_format).strftime('%m/%d/%Y %H:%M')


def str_to_date(current_date, format=API_DATE_FORMAT):
    """
    Convert a string date to a date object
    :param current_date:
    :param format:
    :return:
    """
    try:
        return datetime.strptime(current_date, format)
    except ValueError:
        return datetime.strptime(current_date, '%Y-%m-%d %H:%M:%S.%f')


def get_implicit_end_date_by_type(session, cob_type):
    """
    Get current COB date from `edm_params`
    :param session:
    :param cob_type:
    :return:
    """
    cob_date = session.execute('select value1 from edm_params where key=\'{}\''.format(cob_type)).first()[0]
    return datetime.strptime(cob_date, '%Y-%m-%d %H:%M:%S')


def update_date_to_month_end(d):
    """
    Utility function to convert delta dates to month-end
    :param d:
    :return:
    """
    new_datetime = datetime(d.year + (d.month == 12), (d.month + 1 if d.month < 12 else 1), 1) - timedelta(1)
    return new_datetime
