import json
import requests
from requests.exceptions import SSLError
import time

from api_config import SALESFORCE_TOKEN_URL, ROOT_CERT_PATH


def smart_post(url, payload, headers):
    """
    Helper function to handle when to use SSL cert and when not
    :param url:
    :param payload:
    :param headers:
    :return:
    """
    try:
        resp = requests.post(url, data=payload, headers=headers)
    except SSLError:
        resp = requests.post(url, data=payload, headers=headers, verify=ROOT_CERT_PATH)
    return resp


def smart_patch(url, payload, headers):
    """
    Helper function to handle when to use SSL cert and when not
    :param url:
    :param payload:
    :param headers:
    :return:
    """
    try:
        resp = requests.patch(url, data=payload, headers=headers)
    except SSLError:
        resp = requests.patch(url, data=payload, headers=headers, verify=ROOT_CERT_PATH)
    return resp


def generate_salesforce_access_token(payload):
    """
    Helper function to generate a Salesforce access token for API requests
    :return:
    """
    # request for token
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    resp = smart_post(SALESFORCE_TOKEN_URL, payload, headers)

    # if response exists & token is available, return token
    if resp.content:
        resp = json.loads(resp.content)
        if resp['access_token']:
            return resp['access_token']
    return None


def post_data_to_target(tgt_url, data, token):
    """
    Helper function that will send POST request to target URL, with basic retry logic.
    Note: this method primarily sends to SF endpoints; hence why the headers are "hard coded" here
    :param tgt_url:
    :param data:
    :param token:
    :return:
    """
    headers = {'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json'}

    # retry logic for http failures
    retry = 0
    req_success = False
    while not req_success:
        if retry == 5:
            return None
        try:
            resp = smart_post(tgt_url, json.dumps(data), headers)
            req_success = True
            return resp
        except (ConnectionError, SSLError):
            retry = retry + 1
            time.sleep(5)


def send_data_to_salesforce(page, payload, endpoint, sf_token, object_type):
    """
    Send batched data to Salesforce, return page to advance send
    :param page:
    :param payload:
    :param endpoint:
    :param sf_token:
    :param object_type
    :return:
    """
    # string to handle error messages in response
    err = None

    while True:
        # send payload
        resp = post_data_to_target(endpoint, payload, token=sf_token)

        # capture errors that are in response
        if resp is None:
            # http error
            err = 'batch {} failed due to HTTP error, please investigate with networking team'.format(page + 1)
            page = page + 1
            break
        elif resp.status_code == 500:
            # error with entire batch
            err = 'error found in batch {} >> response: {}'.format(page + 1, resp.content)
            page = page + 1
            break
        else:
            # subset of errors within batch
            batch_err_log = capture_batch_error_messages(object_type, resp.content)
            if batch_err_log:
                err = 'err_msgs from batch {}: {}'.format(page + 1, batch_err_log)
            page = page + 1
            break
    return page, err


def capture_batch_error_messages(object_type, content):
    """
    Capture 'err_msg' from SF responses
    No error return for 'agreement_delete'
    :param object_type:
    :param content:
    :return:
    """
    if object_type == 'agreement_delete':
        return

    if object_type == 'flow':
        errors = json.loads(content)
        return errors.get('errors', None)

    if object_type == 'sub_agreement':
        object_type = 'agreement'

    key = object_type + '_id'
    return [{key: r.get(key),
             'salesforce_id': r.get('salesforce_id'),
             'err_msg': r.get('err_msg')} for r in json.loads(content) if r.get('err_msg')]


def update_job_flag(engine, job_type, job_status):
    """
    Update EDM Params key for active running job
    :param engine:
    :param job_type:
    :param job_status:
    :return:
    """
    resp = engine.execute(f"update edm_params set value1 = '{job_type}', active = '{job_status}' "
                          f"where key = 'active_sf_export_job' ")
    return bool(resp)
