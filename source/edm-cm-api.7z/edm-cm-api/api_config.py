import os
import json

from common.envconfig import ENVS
from common.security import get_secret
from cm_commons.util.boto_functions import check_if_secret_exists

# Client Master Local DB config
CM_DB, CM_LOCATION, CM_PORT, CM_USER, CM_PWD = None, None, None, None, None

# dynamic aws config after setting defaults for test
local_prod = True
api_target_env = 'prod'
db_env = 'prod'

if not local_prod:
    db_env, api_target_env = 'test', 'test'

CM_DB_SECRET_NAME = ENVS[db_env]['RDS']['secret']
API_SECRET_NAME = ENVS[api_target_env]['cm_salesforce_api']['api_secret']
REGION_NAME = ENVS[db_env]['aws']['region']
API_SECRETS, DB_SECRETS = None, None

print('connecting to cm {} ...'.format(db_env))
try:
    check_if_secret_exists(CM_DB_SECRET_NAME)
    API_SECRETS = get_secret(API_SECRET_NAME, api_target_env)
    DB_SECRETS = get_secret(CM_DB_SECRET_NAME, db_env)
except:
    print('cannot connect to secrets man, continuing with local config')

# Salesforce API Config
SALESFORCE_GRANT_TYPE = ENVS[api_target_env]['cm_salesforce_api']['sf_grant_type']
SALESFORCE_REDIRECT_URI = ENVS[api_target_env]['cm_salesforce_api']['sf_redirect_url']
SALESFORCE_TOKEN_URL = ENVS[api_target_env]['cm_salesforce_api']['sf_token_url']
SALESFORCE_ENTITY_POST_URL = ENVS[api_target_env]['cm_salesforce_api']['sf_base_url'] + \
                             ENVS[api_target_env]['cm_salesforce_api']['sf_entity_endpoint']
SALESFORCE_AGREEMENT_POST_URL = ENVS[api_target_env]['cm_salesforce_api']['sf_base_url'] + \
                                ENVS[api_target_env]['cm_salesforce_api']['sf_agreement_endpoint']
SALESFORCE_AGREEMENT_DELETE_POST_URL = ENVS[api_target_env]['cm_salesforce_api']['sf_base_url'] + \
                                       ENVS[api_target_env]['cm_salesforce_api']['sf_agreement_delete_endpoint']
SALESFORCE_MERGE_POST_URL = ENVS[api_target_env]['cm_salesforce_api']['sf_base_url'] + \
                            ENVS[api_target_env]['cm_salesforce_api']['sf_entity_merge_endpoint']
SALESFORCE_CLIENT_SECRET, SALESFORCE_CLIENT_ID, SALESFORCE_REFRESH_TOKEN = None, None, None

# Einstein API Config
EINSTEIN_GRANT_TYPE = ENVS[api_target_env]['cm_salesforce_api']['einstein_grant_type']
EINSTEIN_FLOW_POST_URL = ENVS[api_target_env]['cm_salesforce_api']['einstein_base_url'] + \
                         ENVS[api_target_env]['cm_salesforce_api']['einstein_flow_endpoint']
EINSTEIN_CLIENT_ID, EINSTEIN_CLIENT_SECRET, EINSTEIN_USER, EINSTEIN_PWD = None, None, None, None

if API_SECRETS:
    SALESFORCE_CLIENT_SECRET = API_SECRETS['sf_client_secret']
    SALESFORCE_CLIENT_ID = API_SECRETS['sf_client_id']
    SALESFORCE_REFRESH_TOKEN = API_SECRETS['sf_refresh_token']
    EINSTEIN_CLIENT_ID = API_SECRETS['einstein_client_id']
    EINSTEIN_CLIENT_SECRET = API_SECRETS['einstein_client_secret']
    EINSTEIN_USER = API_SECRETS['einstein_user']
    EINSTEIN_PWD = API_SECRETS['einstein_pwd']

if DB_SECRETS:
    CM_DB = DB_SECRETS['dbname']
    CM_LOCATION = DB_SECRETS['host']
    CM_PORT = DB_SECRETS['port']
    CM_USER = DB_SECRETS['username']
    CM_PWD = DB_SECRETS['password']

# Client Master Local DB config
LOCAL_CRED_STORE = os.path.dirname(os.path.abspath(__file__)) + '/cred.json'
if os.path.isfile(LOCAL_CRED_STORE):
    with open(os.path.dirname(os.path.abspath(__file__)) + '/cred.json', 'r') as f:
        creds = json.load(f)
    CM_DB = creds[db_env]['db']
    CM_LOCATION = creds[db_env]['location']
    CM_PORT = creds[db_env]['port']
    CM_USER = creds[db_env]['user']
    CM_PWD = creds[db_env]['pwd']

    SALESFORCE_CLIENT_ID = creds[api_target_env]['sf_client_id']
    SALESFORCE_CLIENT_SECRET = creds[api_target_env]['sf_client_secret']
    SALESFORCE_REFRESH_TOKEN = creds[api_target_env]['sf_refresh_token']
    EINSTEIN_CLIENT_ID = creds[api_target_env]['einstein_client_id']
    EINSTEIN_CLIENT_SECRET = creds[api_target_env]['einstein_client_secret']
    EINSTEIN_USER = creds[api_target_env]['einstein_user']
    EINSTEIN_PWD = creds[api_target_env]['einstein_pwd']

# API Configuration
APP_HOST = '0.0.0.0'
APP_PORT = 9010
APP_SECRET = 'ClientMa$t3r!'
DEFAULT_PAGINATION = 100
API_DATE_FORMAT = '%Y-%m-%d %H:%M:%S'
SALESFORCE_DATE_FORMAT = '%Y-%m-%dT%H:%M:%S.000Z'

# implicit end date config
SV_IMPLICIT_END_MONTH_RANGE = 4
FT_IMPLICIT_END_MONTH_RANGE = 1

# Flow config
FLOW_DEFAULT_PAGINATION = 10000
FLOW_UPLOAD_NAME = 'cm_flow_upload'
EINSTEIN_FOLDER_NAME = 'Client_Master_App'
EINSTEIN_UPLOAD_MODE = 'Upsert'

# merge config
MERGE_TABLE_NAME = 'cm_merge_rules'
MERGE_BATCH_SIZE = 1

# SSL Cert location (should be root of edmcm)
ROOT_CERT_PATH = str(os.path.dirname(__file__)) + '\\ssl.crt'
ROOT_PROJECT_PATH = os.path.dirname(os.path.abspath(__file__))
INGEST_UPDATE_PATH = os.path.join(ROOT_PROJECT_PATH, 'updates')
MERGE_RESPONSE_PATH = os.path.join(ROOT_PROJECT_PATH, 'merges')
DELETE_RESPONSE_PATH = os.path.join(ROOT_PROJECT_PATH, 'deletes')
