from api import create_app

# initialize app for running
application = create_app()


if __name__ == '__main__':
    """
    Startup cmd (4 core machine): `gunicorn --bind 0.0.0.0:9010 wsgi:application -w 3 --threads=3 --daemon`
    """
    application.run()
