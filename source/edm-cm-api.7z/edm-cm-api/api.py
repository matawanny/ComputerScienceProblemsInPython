from flask import Flask
from flask_jwt_extended import JWTManager

from api_config import APP_HOST, APP_SECRET, APP_PORT
from controllers.agreement_controller import agreement_blueprint
from controllers.entity_controller import entity_blueprint
from controllers.jwt_controller import jwt_blueprint
from controllers.ingestion_controller import ingestion_blueprint
from controllers.sub_agreement_controller import sub_agreement_blueprint
from controllers.health_controller import health_blueprint
from controllers.job_controller import job_blueprint

try:
    from cm_commons.util.cloudwatch_util import *
except:
    print('not using cw logging, using default py logger')
    import logging


def create_app():
    """
    Create Flask app
    :return:
    """
    # declare app
    app = Flask(__name__)
    app.secret_key = APP_SECRET

    # turn off JSON sorting
    app.config['JSON_SORT_KEYS'] = False

    # turn off strict slashes
    app.url_map.strict_slashes = False

    # register controllers
    app.register_blueprint(agreement_blueprint)
    app.register_blueprint(entity_blueprint)
    app.register_blueprint(ingestion_blueprint)
    app.register_blueprint(jwt_blueprint)
    app.register_blueprint(sub_agreement_blueprint)
    app.register_blueprint(health_blueprint)
    app.register_blueprint(job_blueprint)

    # attach custom logger to Flask app
    logger = logging.getLogger('werkzeug')
    app.logger.addHandler(logger)

    # jwt setup
    jwt = JWTManager(app)
    app.config['JWT_ERROR_MESSAGE_KEY'] = 'error'
    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = False

    return app


if __name__ == '__main__':
    # flask runner
    app = create_app()

    # run app
    app.run(host=APP_HOST, port=APP_PORT)
