from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required
import logging

from managers.entity_manager import EntityManager


# initialize the router to attach to the app
entity_blueprint = Blueprint('entity', __name__, url_prefix='/entity')

# logger init
logger = logging.getLogger('entity_controller')

# initialize manager
entity_manager = EntityManager()


@entity_blueprint.route('/', methods=['GET'])
@jwt_required
def get_all_entities():
    """
    Get all entities from database, paginated by default 
    :return:
    """
    # pagination from request
    page = request.args.get('page', 1, type=int)

    # pass parameters to entity manager
    logger.debug('get all entities: {}'.format(request.args))
    entities = entity_manager.get_all_entities(page, overload_to_full=True)
    if not entities:
        return jsonify({'message': 'no entities found'}), 404
    return jsonify(entities), 200


@entity_blueprint.route('/<persistence_id>', methods=['GET'])
@jwt_required
def get_entity_by_id(persistence_id):
    """
    Get Entity object by ID
    :param persistence_id:
    :return:
    """
    # pull by entity ID
    logger.debug('get entity by ID: {}'.format(persistence_id))
    entity = entity_manager.get_entity_by_id(persistence_id, overload_to_full=True)

    if not entity:
        return jsonify({'error': 'no entity found with persistence id {}'.format(persistence_id)}), 404
    return jsonify(entity), 200


# TODO: this will only accept a SINGLE JSON body
@entity_blueprint.route('/un-oopsie', methods=['POST'])
@jwt_required
def restore_entity():
    """
    Restore previously deleted entity
    :param persistence_id:
    :return:
    """
    if not request.json:
        return jsonify({'error': 'no json body supplied'}), 404

    # TODO: look up entity in DB
    # TODO: add ended at = null to all records in json body
    # TODO: add manager code (write to file)
    pass
