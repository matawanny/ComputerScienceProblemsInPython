import os
from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required
import logging
import subprocess

from api_config import INGEST_UPDATE_PATH, ROOT_PROJECT_PATH

# initialize the router to attach to the app
job_blueprint = Blueprint('job', __name__, url_prefix='/job')

# logger init
logger = logging.getLogger('job_controller')


def _count_update_files():
    """
    Helper function to count number of files in update dir
    :return:
    """
    num = subprocess.check_output('ls -1 {}/*.csv | wc -l'.format(INGEST_UPDATE_PATH), shell=True)
    return int(num.decode('utf-8').strip())


@job_blueprint.route('/update/count', methods=['GET'])
@jwt_required
def count_files_in_update():
    """
    Count files in update dir
    :return:
    """
    num = _count_update_files()
    return jsonify({'count': int(num)}), 200


@job_blueprint.route('/update/clear', methods=['GET'])
@jwt_required
def clear_files_in_update():
    """
    Clear files in update dir
    :return:
    """
    os.system('rm {}/*.csv'.format(INGEST_UPDATE_PATH))
    return jsonify({'success': True}), 200


@job_blueprint.route('/launch/ingest/<ingest_file_name>', methods=['GET'])
@jwt_required
def launch_ingest_job(ingest_file_name):
    """
    Launch ingest job for SF files
    :return:
    """
    num = _count_update_files()
    if num == 0:
        return jsonify({'count': num, 'message': 'no update files found', 'success': False})
    os.chdir('{}/cron/'.format(ROOT_PROJECT_PATH))
    os.system('nohup python3 ingest_api_updates.py --filename {} &'.format(ingest_file_name))
    return jsonify({'count': num, 'message': 'ingest job started', 'success': True})


@job_blueprint.route('/launch/export/<job_type>', methods=['GET'])
@jwt_required
def launch_export_job(job_type):
    """
    Launch export job for SF batch sends
    :param job_type:
    :return:
    """
    # capture runtime flags for page and hierarchy start
    start_page = request.args.get('page', 1, type=int)
    batch_size = request.args.get('batch-size', 100, type=int)
    hierarchy = request.args.get('hierarchy', '1')
    debug_flag = request.args.get('debug', False, type=bool)

    if batch_size > 200:
        batch_size = 200

    # create command
    cmd = 'nohup python3 salesforce_export.py --{} --page {} --hierarchy {} --batch-size {} &'\
        .format(job_type, start_page, hierarchy, batch_size)
    if debug_flag:
        cmd = 'nohup python3 salesforce_export.py --{} --page {} --hierarchy {} --batch-size {} --debug &'\
            .format(job_type, start_page, hierarchy, batch_size)
    # run command for export job
    os.chdir('{}/cron/'.format(ROOT_PROJECT_PATH))
    os.system(cmd)
    return jsonify({'success': '{} export job started'.format(job_type)})


@job_blueprint.route('/status/export', methods=['GET'])
@jwt_required
def get_export_job_status():
    """
    Status endpoint to check whether a job is currently running or not
    :return:
    """
    # get list of processes running as a string, split to list
    procs = os.popen('ps aux | grep "salesforce_export"').read()
    procs = procs.split('\n')

    # return current running job
    for proc in procs:
        if 'python' in proc and 'salesforce' in proc:
            curr_job = proc.split('python3')[1].split('--')
            job_desc = {
                'export_type': curr_job[1].strip(),
                'batch_size': curr_job[4].split(' ')[1].strip(),
                'debug': True if 'debug' in curr_job else False
            }
            return jsonify({'current_job': job_desc}), 200
    return jsonify({'message': 'no export jobs running'}), 400


@job_blueprint.route('/status/ingest', methods=['GET'])
@jwt_required
def get_ingest_job_status():
    """
    Status endpoint to check whether a job is currently running or not
    :return:
    """
    # get list of processes running as a string, split to list
    procs = os.popen('ps aux | grep "ingest_api_updates"').read()
    procs = procs.split('\n')

    # return current running job
    for proc in procs:
        if 'python' in proc and 'ingest' in proc:
            # nohup python3 ingest_api_updates.py &'
            return jsonify({'current_job': 'sf_ingest'}), 200
    return jsonify({'message': 'no ingest jobs running'}), 400


@job_blueprint.route('/stop/export', methods=['GET'])
@jwt_required
def kill_export_job():
    """
    Kill SF export job
    :return:
    """
    os.system('ps -ef | grep "salesforce_export" | grep -v grep | awk \'{print $2}\' | xargs -r kill -9')
    return jsonify({'success': 'export job stopped'})
