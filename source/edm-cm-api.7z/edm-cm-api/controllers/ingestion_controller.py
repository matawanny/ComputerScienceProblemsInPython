from datetime import datetime
from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required
import logging

from api_config import API_DATE_FORMAT
from managers.agreement_manager import AgreementManager
from managers.entity_manager import EntityManager

# initialize the router to attach to the app
ingestion_blueprint = Blueprint('ingestion', __name__, url_prefix='/ingest')

# logger init
logger = logging.getLogger('ingestion_controller')

# initialize managers
agreement_manager = AgreementManager()
entity_manager = EntityManager()


@ingestion_blueprint.route('/entity/<persistence_id>', methods=['POST'])
@jwt_required
def update_entity_by_id(persistence_id):
    """
    Endpoint to update entity by ID
    :param persistence_id:
    :return:
    """
    if not request.json:
        return jsonify({'error': 'no json body supplied'}), 404

    # process json from request
    ent = _update_entity_action(request.json, 'U')
    result = entity_manager.bulk_update_entities([ent])
    if not result:
        return jsonify({'error': 'entity {} not found'.format(persistence_id)}), 404
    return jsonify({'message': 'update for entity {} has been created'.format(persistence_id)}), 202


@ingestion_blueprint.route('/bulk/entity', methods=['POST'])
@jwt_required
def bulk_entity_upload():
    """
    Bulk upload Entity data
    :return:
    """
    if not request.json:
        return jsonify({'error': 'no json body supplied'}), 404
    if 'entities' not in request.json:
        return jsonify({'error': 'no entities present in request'}), 404

    # add delete
    for ent in request.json.get('entities'):
        ent = _update_entity_action(ent, 'U')

    # process list of updates
    res = entity_manager.bulk_update_entities(request.json.get('entities'))
    return jsonify({'message': 'entities {} have been processed for updates'
                   .format(','.join(str(id) for id in res))}), 202


@ingestion_blueprint.route('/entity/delete', methods=['DELETE'])
@jwt_required
def delete_entity():
    """
    Write record to local file for "deletion"
    :return:
    """
    if not request.json:
        return jsonify({'error': 'no json body supplied'}), 404

    ent = _update_entity_action(request.json, 'D')
    entity_manager.bulk_update_entities([request.json])
    return jsonify({'message': 'delete for {} has been processed'.format(ent.get('persistence_id'))}), 202


@ingestion_blueprint.route('/bulk/entity/delete', methods=['DELETE'])
@jwt_required
def bulk_entity_delete():
    """
    Bulk entity delete
    :return:
    """
    if not request.json:
        return jsonify({'error': 'no json body supplied'}), 404
    if 'entities' not in request.json:
        return jsonify({'error': 'no entities present in request'}), 404

    # add delete info
    for ent in request.json.get('entities'):
        ent = _update_entity_action(ent, 'D')

    # process list of deletes
    res = entity_manager.bulk_update_entities(request.json.get('entities'))
    return jsonify({'message': 'entities {} have been staged for deletes'
                   .format(','.join(str(id) for id in res))}), 202


def _update_entity_action(entity, action):
    """
    Update entity in json with action/ended_at
    :return:
    """
    if action == 'D':
        entity['action'] = action
        entity['ended_at'] = datetime.now().strftime(API_DATE_FORMAT)
    else:
        entity['action'] = action
        entity['ended_at'] = None
    return entity
