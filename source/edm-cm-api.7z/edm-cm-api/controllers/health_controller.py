from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request

# initialize the router to attach to the app
health_blueprint = Blueprint('health', __name__, url_prefix='/health')


@health_blueprint.route('/', methods=['GET'])
def health_check():
    """
    Check the status of the API
    :return:
    """
    return '', 200
