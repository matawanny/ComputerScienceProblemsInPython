from flask import Blueprint, jsonify, request
import logging

from managers.agreement_manager import AgreementManager

# initialize the router to attach to the app
sub_agreement_blueprint = Blueprint('sub_agreement', __name__, url_prefix='/sub-agreement')

# logger init
logger = logging.getLogger('sub_agreement_controller')

# initialize agreement manager
agreement_manager = AgreementManager()


@sub_agreement_blueprint.route('/', methods=['GET'])
def get_all_agreements():
    """
    Pull all Sub Agreements from database, paginated by a page request parameter
    :return:
    """
    # get query params from request
    pull_trades = request.args.get('trades', False, type=bool)
    page = request.args.get('page', 1, type=int)

    # pass parameters to agreement manager
    logger.debug('get all agreements: {}'.format(request.args))
    agreements = agreement_manager.get_all_sub_agreements(page, pull_trades)
    return jsonify(agreements), 200


@sub_agreement_blueprint.route('/<sub_agreement_id>', methods=['GET'])
def get_agreement_by_id(sub_agreement_id):
    """
    Get a Sub Agreement object by ID
    :param sub_agreement_id:
    :return:
    """
    # query param to pull trades, if required
    pull_trades = request.args.get('trades', False, type=bool)

    # pull by agreement ID
    logger.debug('get agreement by ID: {}'.format(sub_agreement_id))
    agreement = agreement_manager.get_sub_agreement_by_id(sub_agreement_id, pull_trades)
    if not agreement:
        return jsonify({'error': 'no sub agreement found with id {}'.format(sub_agreement_id)}), 404
    return jsonify(agreement), 200