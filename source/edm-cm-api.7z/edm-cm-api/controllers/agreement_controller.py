from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required
import logging

from managers.agreement_manager import AgreementManager


# initialize the router to attach to the app
agreement_blueprint = Blueprint('agreement', __name__, url_prefix='/agreement')

# logger init
logger = logging.getLogger('agreement_controller')

# initialize agreement manager
agreement_manager = AgreementManager()


@agreement_blueprint.route('/', methods=['GET'])
@jwt_required
def get_all_agreements():
    """
    Pull all Agreements from database, paginated by a page request parameter
    :return:
    """
    # get query params from request
    pull_trades = request.args.get('trades', False, type=bool)
    page = request.args.get('page', 1, type=int)

    # pass parameters to agreement manager
    logger.debug('get all agreements: {}'.format(request.args))
    agreements = agreement_manager.get_all_agreements(page, pull_trades)
    if not agreements:
        return jsonify({'message': 'no agreements found'}), 404
    return jsonify(agreements), 200


@agreement_blueprint.route('/<agreement_id>', methods=['GET'])
@jwt_required
def get_agreement_by_id(agreement_id):
    """
    Get an Agreement object by ID
    :param agreement_id:
    :return:
    """
    # query param to pull trades, if required
    pull_trades = request.args.get('trades', False, type=bool)

    # pull by agreement ID
    logger.debug('get agreement by ID: {}'.format(agreement_id))
    agreement = agreement_manager.get_agreement_by_id(agreement_id, pull_trades)
    if not agreement:
        return jsonify({'error': 'no agreement found with id {}'.format(agreement_id)}), 404
    return jsonify(agreement), 200
