from flask import Blueprint, jsonify, request
from flask_jwt_extended import create_access_token, get_jwt_identity, jwt_required
import time

# initialize the router to attach to the app
jwt_blueprint = Blueprint('jwt', __name__, url_prefix='/auth')


# helper function to add data to token
def add_claims_to_access_token(identity):
    return {
        'user': identity,
        'generated_on': int(time.time())
    }


@jwt_blueprint.route('/token', methods=['POST'])
@jwt_required
def login():
    """
    Generate a new secure JWT token by a provided username
    :return:
    """
    if not request.json:
        return jsonify({'error': 'Missing JSON in request'}), 400

    username = request.json.get('username', None)
    if not username:
        return jsonify({'error': 'Missing username parameter'}), 400

    # identity can be any data that is json serializable
    data = add_claims_to_access_token(username)
    tok = {'access_token': create_access_token(data)}
    return jsonify(tok), 200


@jwt_blueprint.route('/protected', methods=['GET'])
@jwt_required
def protected():
    """
    Example of a "protected route" on the API
    :return:
    """
    # Access the identity of the current user with get_jwt_identity
    current_user = get_jwt_identity()
    return jsonify(logged_in_as=current_user), 200
