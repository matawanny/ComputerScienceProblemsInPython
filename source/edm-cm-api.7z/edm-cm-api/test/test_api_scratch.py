"""
THIS IS A GARBAGE FILE FOR ME TO TEST SIMPLE THINGS WITHOUT RUNNING POSTMAN
"""

from managers.agreement_manager import AgreementManager
from managers.entity_manager import EntityManager


em = EntityManager()
am = AgreementManager()
persistence_id = '15da5b46b73a9f5bfbf20a3074109064'


def test_get_all_entities():
    res = em.get_all_entities(None, None, 1)
    print(res)


def test_pull_entity_by_id():
    res = em.get_entity_by_id(persistence_id)
    print(res)


def test_get_all_agreements():
    am.get_all_agreements(None, None, 1)


def test_get_single_agreement():
    am.get_agreement_by_id(-1001915100, None, None)