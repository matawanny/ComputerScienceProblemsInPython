from managers.entity_manager import EntityManager
from test.insert_test_models import create_test_entities


def test_generate_and_insert_one_entity(db_session):
    """
    Generate one entity, insert into test db
    :param db_session:
    :return:
    """
    # init manager
    em = EntityManager(provided_session=db_session)

    # create and insert one entity
    ent = create_test_entities(1)
    ent = ent[0]
    db_session.add(ent)
    db_session.commit()
    db_session.flush()

    # pull entity and assert
    item = em.get_entity_by_id(ent.persistence_id)

    assert item.get('persistence_id') == ent.entity_id


def test_generate_many_entities(db_session):
    """
    Test bulk insert into Entity table
    :param db_session:
    :return:
    """
    # init manager
    em = EntityManager(provided_session=db_session)

    # create 5 random entities and persist
    ents = create_test_entities(5)
    db_session.bulk_save_objects(ents)
    db_session.commit()
    db_session.flush()

    # pull entity and assert
    item = em.get_all_entities(None, None, 1)

    assert len(item.get('entities')) == 5
