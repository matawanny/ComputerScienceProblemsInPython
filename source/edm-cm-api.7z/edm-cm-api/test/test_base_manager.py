import json
from sqlalchemy import text

from api_config import MERGE_RESPONSE_PATH
from managers.base_manager import BaseManager



def test_function_call():
    base_manager = BaseManager()
    resp = base_manager.engine.execute(text('select update_delta_views(now()::timestamp)').execution_options(autocommit=True))
    print(resp)


def test_writing_merge_files():
    """
    Test writing a merge file with merge data via BaseManager code
    :return:
    """
    bm = BaseManager()
    data = """
        [ {
      "valid_salesforce_id" : "def",
      "valid_cm_id" : "456",
      "isSuccess" : true,
      "invalid_salesforce_id" : "abc",
      "invalid_cm_id" : "123"
    }]"""
    _json = json.loads(data)

    bm.write_response_data_to_file('sf_merge_test.csv', _json, MERGE_RESPONSE_PATH)
