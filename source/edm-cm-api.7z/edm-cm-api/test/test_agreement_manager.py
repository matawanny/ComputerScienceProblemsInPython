import json

from managers.agreement_manager import AgreementManager
from test.insert_test_models import create_test_agreements


def test_generate_and_insert_one_agreement(db_session):
    """
    Generate one agreement, insert into test db
    :param db_session:
    :return:
    """
    # init manager
    am = AgreementManager(provided_session=db_session)

    # create and insert one agreement
    agr = create_test_agreements(1)
    agr = agr[0]
    db_session.add(agr)
    db_session.commit()
    db_session.flush()

    # pull agreement and assert
    item = am.get_agreement_by_id(agr.agreement_id)

    assert item.get('agreement_id') == agr.agreement_id


def test_generate_many_agreements(db_session):
    """
    Test bulk insert into Agreement table
    :param db_session:
    :return:
    """
    # init manager
    am = AgreementManager(provided_session=db_session)

    # create 5 random entities and persist
    agrs = create_test_agreements(5)
    db_session.bulk_save_objects(agrs)
    db_session.commit()
    db_session.flush()

    # pull entity and assert
    item = am.get_all_agreements(None, None, 1)

    assert len(item.get('agreements')) == 5
