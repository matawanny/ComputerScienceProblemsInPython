import random
import string

from cm_commons.models.sqlalchemy.client_master_models import Agreement, Entity
from test.default_test_values import *


def create_test_entities(num):
    """
    Create n number of dummy entities with randomly chosen IDs
    :param num:
    :return:
    """
    entities = []
    for _ in range(num):
        entities.append(create_single_entity(''.join(random.choices(string.ascii_letters + string.digits, k=8))))
    return entities


def create_single_entity(mock_id):
    """
    Create a single Entity with a provided ID
    :param mock_id:
    :return:
    """
    return Entity(
        entity_id=mock_id,
        persistence_id=mock_id,
        entity_type_id=entity_type_id,
        entity_name=first_name + ' ' + last_name,
        aggregator_id=aggregator_id,
        fca_id=fca_id,
        client_type_id=client_type_id
    )


def create_test_agreements(num):
    """

    :param num:
    :return:
    """
    agreements = []
    for _ in range(num):
        agreements.append(create_single_agreement(''.join(random.choices(string.ascii_letters + string.digits, k=8))))
    return agreements


def create_single_agreement(mock_id):
    return Agreement(
        agreement_id=mock_id,
        channel_id=channel_id,
        money_type_id=money_type_id,
        external_identifier=external_identifier,
        external_identifier_type=external_type_id,
        currency_id=currency_id,
        origin_id=origin_id,
        aggregator_id=aggregator_id
    )