from managers.entity_manager import EntityManager
from util.salesforce_util import generate_salesforce_access_token, update_job_flag


def test_sf_token():
    resp = generate_salesforce_access_token()
    print(resp)


def test_job_update_flag():
    """
    Test job flag functionality
    :return:
    """
    em = EntityManager()
    resp = update_job_flag(em.engine, 'merge', 'Y')
    assert resp is True
