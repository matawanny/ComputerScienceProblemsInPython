from botocore.exceptions import NoCredentialsError
import pytest
from sqlalchemy.orm.session import sessionmaker

from cm_commons.db.cm_conn import create_cm_conn
from cm_commons.models.sqlalchemy import Base
from cm_commons.util.aws_secrets_manager import get_secret
from api_config import CM_DB_SECRET_NAME, REGION_NAME, CM_LOCATION, CM_PWD, CM_PORT, CM_USER
from test.create_static_tables import populate_all_static_tables


def _create_conn():
    """
    Create temporary connection to CM API test database
    :return:
    """
    try:
        secrets = get_secret(CM_DB_SECRET_NAME, REGION_NAME)
        engine, session = create_cm_conn(user=secrets['username'],
                                         pwd=secrets['password'],
                                         location=secrets['host'],
                                         port=secrets['port'],
                                         db='api_test')
    except NoCredentialsError:
        engine, session = create_cm_conn(user=CM_USER,
                                         pwd=CM_PWD,
                                         location=CM_LOCATION,
                                         port=CM_PORT,
                                         db='api_test')
    return engine, session


@pytest.fixture(scope='session')
def connection():
    """
    Create models connection; drop and create all tables
    :return:
    """
    # connect to models database
    engine, session = _create_conn()
    Base.metadata.bind = engine
    conn = engine.connect()

    # drop tables and create new tables
    Base.metadata.drop_all()
    Base.metadata.create_all(engine)

    return conn


@pytest.fixture(scope='module')
def db_session(connection):
    """
    Create models session to pass around in
    :param connection:
    :return:
    """
    # create session bound to models connection
    Session = sessionmaker(bind=connection.engine)
    session = Session()

    # insert static table data
    populate_all_static_tables(session)

    # return session for use
    yield session

    # close session and teardown database
    session.close_all()
    Base.metadata.drop_all()
