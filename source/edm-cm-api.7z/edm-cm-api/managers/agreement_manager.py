from datetime import datetime
from dateutil.relativedelta import relativedelta
import math

from cm_commons.models.sqlalchemy.client_master_models import ValidAgreement, ValidSubAgreement, ValidDeleteAgreement
from api_config import SV_IMPLICIT_END_MONTH_RANGE, FT_IMPLICIT_END_MONTH_RANGE
from managers.base_manager import BaseManager, DEFAULT_PAGINATION
from util.date_util import format_date_for_salesforce, str_to_date, get_implicit_end_date_by_type, \
    update_date_to_month_end


class AgreementManager(BaseManager):
    """
    Business logic manager for Agreement endpoint
    """
    def __init__(self, provided_session=None):
        super().__init__(provided_session=provided_session)
        self.cob_implicit_date = get_implicit_end_date_by_type(self.session, 'cob_implicit_date')
        self.sv_implicit_date = get_implicit_end_date_by_type(self.session, 'sv_implicit_date')

    def get_max_page_count(self, model):
        """
        Get maximum number of pages for all Agreements
        :return:
        """
        if model == 'ValidAgreement':
            return self.get_count_of_model(ValidAgreement)
        if model == 'ValidSubAgreement':
            return self.get_count_of_model(ValidSubAgreement)
        if model == 'ValidDeleteAgreement':
            return self.get_count_of_model(ValidDeleteAgreement)

    def get_all_agreements(self, page, pull_trades=False, metadata=True, batch_size=DEFAULT_PAGINATION):
        """
        Get all agreements, paginated by provided page, limited to default
        :param page:
        :param pull_trades:
        :param metadata:
        :param batch_size:
        :return:
        """
        # poll for all using pagination to limit queries
        results = self.session.query(ValidAgreement).limit(batch_size).offset((page - 1) * batch_size).all()
        if not results:
            return None

        # convert all sqlalchemy models to dictionaries
        data = [self.to_agreement_json(res, pull_trades) for res in results]
        if not metadata:
            return data

        # generate metadata
        metadata = self.generate_metadata(page, math.ceil(self.get_max_page_count('ValidAgreement') / batch_size))
        return {
            'metadata': metadata,
            'agreements': data
        }

    def get_agreement_by_id(self, agreement_id, pull_trades=False):
        """
        Get Agreement from DB by Agreement ID
        :param agreement_id:
        :param pull_trades:
        :return:
        """
        result = self.session.query(ValidAgreement).filter_by(agreement_id=agreement_id).first()
        if not result:
            return None

        return self.to_agreement_json(result, pull_trades)

    def get_agreements_by_ids(self, cm_ids):
        """
        Pull agreements by agreement IDs
        :param cm_ids:
        :return:
        """
        results = self.session.query(ValidAgreement).filter(ValidAgreement.agreement_id.in_(cm_ids)).all()
        data = [self.to_agreement_json(res) for res in results]
        return data

    def get_agreements_for_delete(self, page, batch_size=DEFAULT_PAGINATION):
        """
        Get all Agreements marked for deletion
        :param page:
        :param batch_size:
        :return:
        """
        results = self.session.query(ValidDeleteAgreement.agreement_id).limit(batch_size).offset((page - 1) * batch_size).all()
        if not results:
            return {
                'message': 'no agreements to be deleted'
            }
        ids = [r.agreement_id for r in results]
        return [{'agreement_id': id} for id in ids if id]

    def get_all_sub_agreements(self, page, pull_trades=False, metadata=True, batch_size=DEFAULT_PAGINATION):
        """
        Get all sub_agreements, paginated by provided page, limited to default
        :param page:
        :param pull_trades:
        :param metadata:
        :param batch_size:
        :return:
        """
        # poll for all using pagination to limit queries
        results = self.session.query(ValidSubAgreement).limit(batch_size).offset((page - 1) * batch_size).all()
        if not results:
            return {
                'message': 'no sub agreements found'
            }

        # convert all sqlalchemy models to dictionaries
        data = [self.to_agreement_json(res, pull_trades) for res in results]
        if not metadata:
            return data

        # generate metadata
        metadata = self.generate_metadata(page, math.ceil(self.get_max_page_count('ValidSubAgreement') / batch_size))

        return {
            'metadata': metadata,
            'sub_agreements': data
        }

    def get_sub_agreement_by_id(self, agreement_id, pull_trades=False):
        """
        Get Agreement from DB by Agreement ID
        :param agreement_id:
        :param pull_trades:
        :return:
        """
        result = self.session.query(ValidSubAgreement).filter_by(agreement_id=agreement_id).first()
        if not result:
            return None

        return self.to_agreement_json(result, pull_trades)

    def get_sub_agreements_by_ids(self, cm_ids):
        """
        Pull agreements by agreement IDs
        :param cm_ids:
        :return:
        """
        results = self.session.query(ValidSubAgreement).filter(ValidSubAgreement.agreement_id.in_(cm_ids)).all()
        data = [self.to_agreement_json(res) for res in results]
        return data

    def is_account_open(self, current_as_of_date, aggregator_id):
        """
        Using `aggregator_id`, determine how to use implicit end date for source
        SV/FT: use predefined cob date in database
        All other sources set to 4 month delay for safety
        :param current_as_of_date:
        :param aggregator_id:
        :return:
        """
        if aggregator_id == '2':
            today = self.cob_implicit_date
            month_lag = FT_IMPLICIT_END_MONTH_RANGE
        elif aggregator_id == '1':
            today = self.sv_implicit_date
            month_lag = SV_IMPLICIT_END_MONTH_RANGE
        else:
            today = datetime.now()
            month_lag = 4
        lower_limit = today - relativedelta(months=+month_lag)
        lower_limit = update_date_to_month_end(lower_limit)

        # explicit logic to handle as of dates in the future
        if str_to_date(current_as_of_date) >= today:
            return True
        else:
            return lower_limit <= str_to_date(current_as_of_date) <= today

    def to_agreement_json(self, valid_agreement, pull_trades=False):
        """
        Convert an agreement object to a JSON object
        :param valid_agreement:
        :param pull_trades:
        :return:
        """
        _json = {}

        # grab associated agreement
        agreement = valid_agreement.agreement
        try:
            _json['agreement_id'] = agreement.agreement_id
            _json['agreement_type'] = str(agreement.agreement_type)
            _json['agreement_name'] = agreement.agreement_name[:80] if agreement.agreement_name else None
            _json['inception_date'] = format_date_for_salesforce(agreement.inception_date, '%Y-%m-%d %H:%M:%S')

            # capture agreement date (explicit vs implicit)
            agr_end_date = None
            if agreement.ended_at:
                agr_end_date = format_date_for_salesforce(agreement.ended_at, '%Y-%m-%d %H:%M:%S')
            else:
                if agreement.aggregator_id in ['1', '2'] \
                        and not self.is_account_open(valid_agreement.as_of_date, agreement.aggregator_id):
                    agr_end_date = valid_agreement.as_of_date
            _json['agreement_end_date'] = format_date_for_salesforce(agr_end_date)

            # json keys for related entities to the agreement
            _json['account_entities'] = []
            _json['rep_code_id'] = None
            _json['rep_code_contacts'] = []

            for rel_entity in agreement.related_entities:
                if rel_entity.entity:
                    # if current related entity is a person, append entity id to rep_code_contacts
                    if rel_entity.entity.entity_type_info.entity_type_name.lower() == 'person':
                        if rel_entity.entity.valid_entity:
                            _json['rep_code_contacts'].append(rel_entity.entity.persistence_id)

                    # if current related entity is a team, append all team member entity ids to rep_code_contacts
                    if hasattr(rel_entity.entity, 'valid_team'):
                        if rel_entity.entity.valid_team:
                            _json['rep_code_contacts'].extend(rel_entity.entity.valid_team.valid_persons)

                    if rel_entity.relationship_type.relationship_type_desc.lower() == 'advisor':
                        if rel_entity.entity.valid_entity or rel_entity.entity.valid_team:
                            _json['rep_code_id'] = rel_entity.entity.persistence_id if rel_entity.entity else None

                    if rel_entity.entity.valid_entity:
                        _json['account_entities'].append({
                            'persistence_id': rel_entity.entity.persistence_id if rel_entity.entity else None,
                            'entity_type_id': int(rel_entity.entity.entity_type_id) if rel_entity.entity else None,
                            'relationship_type': rel_entity.relationship_type.relationship_type_desc,
                            'salesforce_id': rel_entity.entity.salesforce_id if rel_entity.entity else None
                        })

            _json['sales_owners'] = []
            _json['territory_name'] = None
            _json['channel_id'] = None
            _json['sub_channel_id'] = None

            # populate territory and sales owners from line of business
            if agreement.line_of_business:
                _json['territory_name'] = agreement.line_of_business[0].territory_name
                _json['channel_id'] = agreement.line_of_business[0].channel.parent_sf_channel_id \
                    if agreement.line_of_business[0].channel else None
                _json['sub_channel_id'] = agreement.line_of_business[0].sf_channel_id

                for lob in agreement.line_of_business:
                    _json['sales_owners'].append({
                        'employee_id': lob.employee_id,
                        'type': lob.employee_type
                    })

            _json['account_number'] = agreement.account_number
            _json['preferred_currency_id'] = int(agreement.preferred_currency_id) \
                if agreement.preferred_currency_id else 15
            _json['share_class_id'] = agreement.agreement_pmf[0].share_class_id if agreement.agreement_pmf else None
            _json['sub_strategy_id'] = agreement.agreement_pmf[0].sub_strategy_id if agreement.agreement_pmf else None
            _json['ta_number'] = agreement.ta_number
            _json['aggregator'] = int(agreement.aggregator_id)
            _json['origin'] = int(agreement.origin_id) if agreement.origin_id else None

            _json['assets'] = []
            if valid_agreement.aum_id:
                _json['assets'].append(
                        {
                            'aum_id': valid_agreement.aum_id,
                            'end_of_period_aum': format_date_for_salesforce(valid_agreement.as_of_date),
                            'raw_amount': valid_agreement.raw_amount if not _json['agreement_end_date'] else '0',
                            'raw_currency_id': valid_agreement.currency_iso3_code,
                            'usd_amount': valid_agreement.usd_amount if not _json['agreement_end_date'] else '0',
                        }
                    )

            # TODO: rip this out later
            if pull_trades:
                # send trade for the latest possible date
                if agreement.trades:
                    max_date = max(d.end_date for d in agreement.trades)
                    latest_trades = list(filter(lambda x: x.end_date == max_date, agreement.trades))

                    for trade in latest_trades:
                        if trade.trade_code and trade.trade_code.flow_type.lower() == 'inflow':
                            _json['period_inflows'].append(
                                {
                                    'trade_id': trade.trade_id,
                                    'start_date': str(trade.start_date),
                                    'end_date': str(trade.end_date),
                                    'amount': float(trade.amount),
                                    'aggregator_trade_code': trade.aggregator_trade_code,
                                }
                            )
                        elif trade.trade_code and trade.trade_code.flow_type.lower() == 'outflow':
                            _json['period_outflows'].append(
                                {
                                    'trade_id': trade.trade_id,
                                    'start_date': str(trade.start_date),
                                    'end_date': str(trade.end_date),
                                    'amount': float(trade.amount),
                                    'aggregator_trade_code': trade.aggregator_trade_code,
                                }
                            )
        except (TypeError, AttributeError) as e:
            print(e)
            print(agreement)
            return None
        return _json

    def process_agreement_for_update(self, curr_agreement):
        """
        Process agreement into list data for ETL reingestion
        :param curr_agreement:
        :return:
        """
        # pop financial level data
        curr_agreement.pop('assets')
        curr_agreement.pop('period_inflows')
        curr_agreement.pop('period_outflows')

        # list of entities that will be processed
        agreements = []

        # create JSONs for each related entity by iterating over all entities; else write flat structure to file
        related_entities = curr_agreement.pop('related_entities')
        if related_entities:
            # copy request JSON, add team member to dict, flatten
            for ent in related_entities:
                d = curr_agreement.copy()
                d['related_entity'] = ent
                agreements.append(self.flatten_json_requests(d))
        else:
            agreements.append(self.flatten_json_requests(curr_agreement))
        return agreements
