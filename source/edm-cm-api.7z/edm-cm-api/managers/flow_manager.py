from cm_commons.models.sqlalchemy.client_master_models import ValidFlows
from managers.base_manager import BaseManager, DEFAULT_PAGINATION
from util.date_util import format_date_for_einstein


class FlowManager(BaseManager):
    """
    Business logic manager for Flow export
    """
    def __init__(self):
        super().__init__()

    def get_max_page_count(self):
        """
        Get maximum number of pages for all Flows
        :return:
        """
        return self.get_count_of_model(ValidFlows)

    def get_all_valid_flows(self, page, batch_size=DEFAULT_PAGINATION):
        """
        Get all valid flows, paginated by provided page, limited to default
        :param page:
        :param batch_size:
        :return:
        """
        # poll for all using pagination to limit queries
        results = self.session.query(ValidFlows).limit(batch_size).offset((page - 1) * batch_size).all()
        if not results:
            return None

        # capture data for payload
        data = [self.to_flow_csv(res) for res in results]

        # create CSV payload
        data = '\n'.join(data)
        return data + '\n'

    def get_flows_by_trade_id_leading_char(self, leading_char):
        """
        Get all flows by Trade ID by their leading character
        :param leading_char:
        :return:
        """
        results = self.session.query(ValidFlows).filter(ValidFlows.flow_id.like('{}%'.format(leading_char))).all()
        if not results:
            return None
        return results

    def to_flow_csv(self, valid_flow):
        """
        Convert ValidFlow model to CSV structure
        :param valid_flow:
        :return:
        """
        try:
            return ','.join([valid_flow.salesforce_id, valid_flow.entity_id, valid_flow.agreement_id, valid_flow.flow_id,
                             valid_flow.flow_type, valid_flow.amount,
                             valid_flow.usd_amount, valid_flow.currency_id, valid_flow.share_class_id,
                             valid_flow.sub_strategy_id, valid_flow.vehicle_type_id, valid_flow.start_date,
                             valid_flow.end_date, valid_flow.created_at, valid_flow.updated_at, valid_flow.aggregator_id])
        except TypeError:
            return None
