from botocore.exceptions import NoCredentialsError
import csv
import math
import time

from api_config import DEFAULT_PAGINATION, CM_DB, CM_LOCATION, CM_PWD, CM_PORT, CM_USER, \
    INGEST_UPDATE_PATH
from cm_commons.db.connectors.postgres_connector import connect_to_postgres


class BaseManager:
    """
    Base business logic manager that all other API managers should inherit from
    Note: `provided_session` is ideally used for testing, shouldn't need it for API runtime
    """
    def __init__(self, provided_session=None, db_name=None):
        if provided_session:
            self.session = provided_session
        else:
            # try to pull credentials from secrets manager; if not, use local connection
            try:
                self.engine, self.session = connect_to_postgres(user=CM_USER, pwd=CM_PWD, location=CM_LOCATION,
                                                                port=CM_PORT, db=db_name if db_name else CM_DB,
                                                                autocommit=True)
            except NoCredentialsError:
                self.engine, self.session = connect_to_postgres(user=CM_USER, pwd=CM_PWD, location=CM_LOCATION,
                                                                port=CM_PORT, db=db_name if db_name else CM_DB,
                                                                autocommit=True)

    def get_count_of_model(self, model):
        """
        Use a model to generate current count on table
        :param model:
        :return:
        """
        count = self.session.query(model).count()
        return count

    def get_max_pages(self, model):
        """
        Generate the maximum number of pages for a given API query
        :param model:
        :return:
        """
        count = self.get_count_of_model(model)
        return math.ceil(count / DEFAULT_PAGINATION)

    def generate_metadata(self, page, max_page):
        """
        Generate metadata section for a given response
        :param page:
        :param max_page:
        :return:
        """
        return {
            'current_page': page,
            'max_pages': max_page
        }

    def flatten_json_requests(self, _json):
        """
        Helper function to flatten JSON requests for updates
        :param _json:
        :return:
        """
        # maintain list of dictionaries that need to be flattened
        dicts_to_flatten = []

        # convert lists to pipe delimited strings
        for k, v in _json.items():
            if type(v) is list:
                _json[k] = '|'.join(map(str, v))

            if type(v) is dict:
                dicts_to_flatten.append((k, v))

        # flatten dictionaries into original json
        for record in dicts_to_flatten:
            top_level_key = record[0]
            for k, v in record[1].items():
                _json['{}_{}'.format(top_level_key, k)] = v
            _json.pop(top_level_key)
        return _json

    def generate_response_file_name(self, file_type):
        """
        Generate SF file response file name
        :param file_type:
        :return:
        """
        f_date = str(str(time.time()).replace('.', ''))
        return 'salesforce_{}_{}.csv'.format(file_type, f_date)

    def write_response_data_to_file(self, file_path, filename, resp_data):
        """
        Write list of data to file
        :param file_path:
        :param filename:
        :param resp_data:
        :return:
        """
        if not isinstance(resp_data, list):
            resp_data = [resp_data]

        with open(file_path + '/' + filename, 'w', newline='', encoding='utf-8') as f_out:
            writer = csv.writer(f_out)

            # write header from first row of keys, then write each dictionary as values
            writer.writerow(list(resp_data[0].keys()))
            for data in resp_data:
                writer.writerow(data.values())
