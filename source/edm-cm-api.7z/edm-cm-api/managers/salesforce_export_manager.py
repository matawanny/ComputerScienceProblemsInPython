import base64
from datetime import datetime
import json
from requests.exceptions import ConnectionError
import time

from api_config import DEFAULT_PAGINATION, SALESFORCE_ENTITY_POST_URL, SALESFORCE_AGREEMENT_POST_URL, \
    SALESFORCE_MERGE_POST_URL, MERGE_BATCH_SIZE, SALESFORCE_AGREEMENT_DELETE_POST_URL, \
    EINSTEIN_FLOW_POST_URL, EINSTEIN_GRANT_TYPE, SALESFORCE_CLIENT_ID, SALESFORCE_CLIENT_SECRET, \
    SALESFORCE_GRANT_TYPE, SALESFORCE_REDIRECT_URI, SALESFORCE_REFRESH_TOKEN, EINSTEIN_CLIENT_ID, \
    EINSTEIN_CLIENT_SECRET, EINSTEIN_USER, EINSTEIN_PWD, FLOW_DEFAULT_PAGINATION, FLOW_UPLOAD_NAME, \
    EINSTEIN_FOLDER_NAME, EINSTEIN_UPLOAD_MODE, ROOT_PROJECT_PATH
from cron import MERGE_COUNT_QUERY, MERGE_DATA_QUERY
from managers.agreement_manager import AgreementManager
from managers.entity_manager import EntityManager
from managers.flow_manager import FlowManager
from util.salesforce_util import generate_salesforce_access_token, send_data_to_salesforce, post_data_to_target, smart_patch

try:
    from cm_commons.util.cloudwatch_util import *
except ConnectionError:
    print('not using cw logging, using default py logger')
    import logging


class SalesforceExportManager:
    """
    Manager class to handle various Salesforce Export jobs
    """
    def __init__(self, job_type, log_level, start_page=1):
        # loggers and dynamic levels
        self.error_logger = logging.getLogger('salesforce_export_error')
        self.export_logger = logging.getLogger('salesforce_export')
        self.export_logger.setLevel(logging.DEBUG if log_level == 'DEBUG' else logging.INFO)
        self.job_logger = logging.getLogger('sf_{}_export'.format(job_type))
        self.job_logger.setLevel(logging.DEBUG if log_level == 'DEBUG' else logging.INFO)

        # initialize object managers and export token
        self.page = start_page - 1
        if job_type in ['entity', 'agreement', 'sub_agreement', 'agreement_delete', 'merge']:
            self.entity_manager = EntityManager()
            self.agreement_manager = AgreementManager()
            auth_payload = {
                'grant_type': SALESFORCE_GRANT_TYPE,
                'client_id': SALESFORCE_CLIENT_ID,
                'client_secret': SALESFORCE_CLIENT_SECRET,
                'redirect_uri': SALESFORCE_REDIRECT_URI,
                'refresh_token': SALESFORCE_REFRESH_TOKEN
            }
            self.access_token = generate_salesforce_access_token(auth_payload)

        if job_type in ['flow']:
            self.flow_manager = FlowManager()
            auth_payload = {
                'grant_type': EINSTEIN_GRANT_TYPE,
                "client_id": EINSTEIN_CLIENT_ID,
                "client_secret": EINSTEIN_CLIENT_SECRET,
                "username": EINSTEIN_USER,
                "password": EINSTEIN_PWD
            }
            self.access_token = generate_salesforce_access_token(auth_payload)

    def log_export_checkpoint(self, job_type):
        """
        Check current batch number; if divisible by 25, log in `salesforce_export` log group to check where we left off
        Used primarily to checkpoint jobs, in case a job needs to be restarted/etc
        :param job_type:
        :return:
        """
        if self.page % 25 == 0:
            self.export_logger.info('{} export for batch {} has been completed'.format(job_type, self.page))

    def load_einstein_meta_config(self):
        """
        Open Einstein JSON config and return as dict
        :return:
        """
        with open(ROOT_PROJECT_PATH + '/einstein_meta_upload_config.json', 'r') as f:
            data = json.load(f)
            return json.dumps(data)

    def send_entities_to_salesforce_by_type(self, hierarchy_position, batch_size=DEFAULT_PAGINATION):
        """
        Send all entities to Salesforce with n number of entities in a batch, by hierarchy position
        :param hierarchy_position:
        :param batch_size:
        :return:
        """
        # get data in FOP order for entities
        max_count = self.entity_manager.get_count_by_hierarchy_pos(hierarchy_position)
        if max_count == 0:
            self.job_logger.info('no entities found for hierarchy {}, continuing ...'.format(hierarchy_position))
            return
        self.job_logger.info('### number of expected entities from cm by hierarchy {}: {}'
                             .format(hierarchy_position, max_count))

        # pull from database in batches and send to SF
        while self.page < int(max_count / batch_size) + 1:
            self.job_logger.info('preparing batch {} - ({})'.format(self.page + 1, int(time.time())))
            entities = self.entity_manager.get_entities_by_hierarchy(hierarchy_position, self.page + 1, batch_size)
            entities = [i for i in entities if i] if entities else None
            if not entities:
                self.job_logger.warning('no entities found in batch {}'.format(self.page))
                self.page = self.page + 1
                continue

            self.job_logger.debug('persistence IDs in batch {}: {}'
                               .format(self.page + 1, ','.join(e.get('persistence_id') for e in entities if entities)))
            # send data and log
            self.job_logger.info('sending batch {} to salesforce - ({})'.format(self.page + 1, int(time.time())))
            self.page, err_msg = send_data_to_salesforce(self.page, entities, SALESFORCE_ENTITY_POST_URL,
                                                         self.access_token, 'entity')
            if err_msg:
                self.error_logger.error('err_msgs from hierarchy {} in batch {}: {}'
                                        .format(hierarchy_position, self.page, err_msg))
            self.log_export_checkpoint('entity')

    def send_agreements_to_salesforce(self, agreement_type='agreement', batch_size=DEFAULT_PAGINATION):
        """
        Send all agreements to Salesforce with n number of agreements in a batch
        :param agreement_type:
        :param batch_size:
        :return:
        """
        max_count = self.agreement_manager.get_max_page_count('ValidSubAgreement') if agreement_type is 'sub_agreement' \
            else self.agreement_manager.get_max_page_count('ValidAgreement')
        self.job_logger.info('### number of expected {} from cm: {}'.format(agreement_type, max_count))

        # pull from database in batches and send to SF
        while self.page < int(max_count / batch_size) + 1:
            self.job_logger.info('preparing batch {} - ({})'.format(self.page + 1, int(time.time())))

            # flag on agreement type for data to pulled
            agreements = self.agreement_manager.get_all_agreements(self.page + 1, metadata=False, batch_size=batch_size) \
                if agreement_type is 'agreement' else self.agreement_manager.get_all_sub_agreements(self.page + 1,
                                                                                                    metadata=False,
                                                                                                    batch_size=batch_size)
            if not agreements:
                self.job_logger.warning('no agreements found in batch {}'.format(self.page))
                self.page = self.page + 1
                continue
            self.job_logger.debug('{} IDs in batch {}: {}'.format(agreement_type, self.page + 1,
                                                                  ','.join(a.get('agreement_id') for a in agreements
                                                                           if agreements)))
            # send data and log
            self.job_logger.info('sending batch {} to salesforce - ({})'.format(self.page + 1, int(time.time())))
            self.page, err_msg = send_data_to_salesforce(self.page, agreements, SALESFORCE_AGREEMENT_POST_URL,
                                                         self.access_token, agreement_type)
            if err_msg:
                self.error_logger.error('[{}]: {}'.format(agreement_type, err_msg))
            self.log_export_checkpoint(agreement_type)

    def send_agreement_deletes_to_salesforce(self, batch_size=DEFAULT_PAGINATION):
        """
        Send agreements marked for deletion to Salesforce
        :param batch_size:
        :return:
        """
        max_count = self.agreement_manager.get_max_page_count('ValidDeleteAgreement')
        self.job_logger.info('### number of expected of agreements deletes from cm: {}'.format(max_count))

        # pull from database in batches and send to SF
        while self.page < int(max_count / batch_size) + 1:
            self.job_logger.info('preparing batch {} - ({})'.format(self.page + 1, int(time.time())))

            # get agreements marked for deletion
            agreements = self.agreement_manager.get_agreements_for_delete(self.page + 1, batch_size=batch_size)
            if not agreements:
                self.job_logger.warning('no agreements found in batch {}'.format(self.page))
                self.page = self.page + 1
                continue

            self.job_logger.debug('deleted agreement IDs in batch {}: {}'
                               .format(self.page + 1, ','.join(a.get('agreement_id', None) for a in agreements if agreements)))
            # send data and log
            self.job_logger.info('sending batch {} to salesforce - ({})'.format(self.page + 1, int(time.time())))
            self.page, err_msg = send_data_to_salesforce(self.page, agreements, SALESFORCE_AGREEMENT_DELETE_POST_URL,
                                                         self.access_token, 'agreement_delete')
            if err_msg:
                self.error_logger.error('[{}]: {}'.format('agreement_delete', err_msg))
            self.log_export_checkpoint('agreement_delete')

    def send_flows_to_einstein(self, batch_size=FLOW_DEFAULT_PAGINATION):
        """
        Send flow data as a CSV payload to Einstein endpoint
        :return:
        """
        max_count = self.flow_manager.get_max_page_count()
        self.job_logger.info('### number of expected of flows from cm: {}'.format(max_count))

        # read Einstein meta config from json file
        json_config = self.load_einstein_meta_config()
        b64_metadata = str(base64.b64encode(json_config.encode('utf-8')), 'utf-8')

        # initiate upload
        init = {
            "format": "csv",
            "operation": EINSTEIN_UPLOAD_MODE,
            "edgemartalias": FLOW_UPLOAD_NAME,
            "edgemartcontainer": EINSTEIN_FOLDER_NAME,
            "metadatajson": b64_metadata
        }
        init_rest = post_data_to_target(EINSTEIN_FLOW_POST_URL, init, self.access_token)
        upload_id = json.loads(init_rest.content).get('id', None)
        if not upload_id:
            self.error_logger.error('could not create upload ID, exiting...')
            return
        self.job_logger.info('flow multipart upload successfully started in einstein with ID: {}'.format(upload_id))

        # TODO error handling
        # TODO logging
        lead_chars = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f']
        for char in lead_chars:
            flows_by_lead_char = self.flow_manager.get_flows_by_trade_id_leading_char(char)
            chunks = [flows_by_lead_char[i:i+FLOW_DEFAULT_PAGINATION]
                      for i in range(0, len(flows_by_lead_char), FLOW_DEFAULT_PAGINATION)]

            for i, chunk in enumerate(chunks):
                data = [self.flow_manager.to_flow_csv(flow) for flow in chunk]
                flows = '\n'.join(data) + '\n'

                # create flow payload
                encoded_flows = base64.b64encode(flows.encode('ascii'))
                flow_payload = {
                    "PartNumber": self.page + 1,
                    "InsightsExternalDataId": upload_id,
                    "DataFile": str(encoded_flows, 'utf-8')
                }

                # send payload to different endpoint (payload endpoint needs "part"), capture errors
                self.job_logger.info('sending batch {} part {} to einstein - ({})'.format(char, i + 1, int(time.time())))
                tgt = EINSTEIN_FLOW_POST_URL + 'Part'
                self.page, err_msg = send_data_to_salesforce(self.page, flow_payload, tgt, self.access_token, 'flow')
                if err_msg:
                    self.error_logger.error('[{}]: {}'.format('flow', err_msg))
                self.log_export_checkpoint('flow')

        # complete upload in Einstein to initiate ingest
        start_load_payload = {'Action': 'Process'}
        headers = {'Authorization': 'Bearer ' + self.access_token, 'Content-Type': 'application/json'}
        tgt = EINSTEIN_FLOW_POST_URL + '/{}'.format(upload_id)
        load_resp = smart_patch(tgt, json.dumps(start_load_payload), headers=headers)
        if str(load_resp.content, 'utf-8'):
            self.error_logger.error('an error occurred when attempting to close einstein load')
        self.job_logger.info('einstein flow upload {} successfully closed!'.format(upload_id))

    def send_merge_records_to_salesforce(self):
        """
        Pull merge records from database, send to salesforce
        :return:
        """
        # get count of records to send
        max_count = self.entity_manager.engine.execute(MERGE_COUNT_QUERY).first()
        max_count = int(max_count[0])
        self.job_logger.info('### number of expected merges from cm: {}'.format(max_count))

        # get all available merges from DB
        results = self.entity_manager.engine.execute(MERGE_DATA_QUERY)
        for res in results:
            # query database and construct merge json
            self.job_logger.info('preparing batch {}'.format(self.page + 1))

            # construct merge payload
            merge_list = [
                {'invalid_salesforce_id': res[0],
                 'invalid_cm_id': res[1],
                 'valid_salesforce_id': res[2],
                 'valid_cm_id': res[3],
                 'entity_type_id': int(res[4])}]

            if not merge_list:
                self.job_logger.info('no merge instruction for batch {}, exiting ...'.format(self.page + 1))
                self.page = self.page + 1
                break

            self.job_logger.debug('json for batch {}: {}'.format(self.page + 1, merge_list))
            self.job_logger.info('sending batch {} to salesforce - ({})'.format(self.page + 1, int(time.time())))
            self.page, err_msg = send_data_to_salesforce(self.page, merge_list, SALESFORCE_MERGE_POST_URL,
                                                         self.access_token, 'merge')
            if err_msg:
                self.error_logger.error('[{}]: {}'.format('merge', err_msg))
            self.log_export_checkpoint('merge')
