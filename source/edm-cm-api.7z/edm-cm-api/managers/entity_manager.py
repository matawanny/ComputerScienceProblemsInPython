from datetime import datetime
from queue import Full

from cm_commons.models.sqlalchemy.client_master_models import ValidEntityFull, ValidEntity
from api_config import INGEST_UPDATE_PATH
from managers.base_manager import BaseManager, DEFAULT_PAGINATION


class EntityManager(BaseManager):
    """
    Business logic manager for Entity endpoint
    """
    def __init__(self, provided_session=None):
        super().__init__(provided_session=provided_session)

    def is_entity_exist(self, persistence_id):
        """
        Check if an Entity exists by persistence_id
        :param persistence_id:
        :return:
        """
        count = self.session.query(ValidEntity).filter_by(persistence_id=persistence_id).count()
        return True if count > 0 else False

    def get_max_page_count(self, model):
        """
        Get maximum number of pages for all Entities
        :return:
        """
        return self.get_max_pages(model)

    def get_count_by_entity_type(self, entity_type_id):
        """
        Get count of entities by entity type
        :param entity_type_id:
        :return:
        """
        return self.session.query(ValidEntity).filter_by(entity_type_id=entity_type_id).count()

    def get_count_by_hierarchy_pos(self, hierarchy_pos):
        """
        Get count of entities by hierarchy position
        :param hierarchy_pos:
        :return:
        """
        return self.session.query(ValidEntity).filter_by(hierarchy=hierarchy_pos).count()

    def _valid_entity_full_model_overload(self, lookup_to_full):
        """
        Helper method to overload local model from ValidEntity to ValidEntityFull (used for API lookups)
        :return:
        """
        if lookup_to_full:
            return ValidEntityFull
        else:
            return ValidEntity

    def get_all_entities(self, page, overload_to_full=False):
        """
        Get all entities, paginated by provided page, limited to default. Method is overloarded to support API lookups
        to Valid entities full (total population, not delta)
        :param page:
        :param overload_to_full:
        :return:
        """
        # overload for API lookup
        model = self._valid_entity_full_model_overload(overload_to_full)

        # poll for all using pagination to limit queries
        results = self.session.query(model).limit(DEFAULT_PAGINATION).offset((page - 1) * DEFAULT_PAGINATION).all()
        if not results:
            return None

        # convert all sqlalchemy models to dictionaries
        data = [self.to_entity_json(res) for res in results]

        # add metadata
        metadata = self.generate_metadata(page, self.get_max_page_count(model))

        return {
            'metadata': metadata,
            'entities': data
        }

    def get_entities_by_ids(self, cm_ids):
        """
        Pull entities by Persistence or Entities IDs
        :param cm_ids:
        :return:
        """
        results = self.session.query(ValidEntity).filter(ValidEntity.persistence_id.in_(cm_ids)).all()
        data = [self.to_entity_json(res) for res in results]
        return data

    def get_entities_by_type(self, entity_type_id, page):
        """
        Get all entities by specific type
        :param entity_type_id:
        :param page:
        :return:
        """
        results = self.session.query(ValidEntity).filter_by(entity_type_id=entity_type_id).limit(DEFAULT_PAGINATION) \
            .offset((page - 1) * DEFAULT_PAGINATION).all()
        if not results:
            return None

        # convert all sqlalchemy models to dictionaries
        data = [self.to_entity_json(res) for res in results]
        return data

    def get_entities_by_hierarchy(self, hierarchy_pos, page, batch_size=DEFAULT_PAGINATION):
        """
        Get all entities by hierarchy position
        :param hierarchy_pos:
        :param page:
        :param batch_size:
        :return:
        """
        results = self.session.query(ValidEntity).filter_by(hierarchy=hierarchy_pos).limit(batch_size)\
            .offset((page - 1) * batch_size).all()
        if not results:
            return None

        # convert all sqlalchemy models to dictionaries
        data = [self.to_entity_json(res) for res in results]
        return data

    def get_entity_by_id(self, persistence_id, overload_to_full=True):
        """
        Get Entity from DB by Persistence ID
        :param persistence_id:
        :param overload_to_full:
        :return:
        """
        # overload to full for API lookup
        model = self._valid_entity_full_model_overload(overload_to_full)

        result = self.session.query(model).filter_by(persistence_id=persistence_id).first()
        if not result:
            return None
        return self.to_entity_json(result)

    def to_entity_json(self, entity):
        """
        Convert Entity object to JSON representation
        :param entity:
        :return:
        """
        _json = {}

        # grab associated entity
        entity = entity.entity

        if not entity:
            return None
        try:
            _json['entity_id'] = entity.entity_id
            _json['persistence_id'] = entity.persistence_id
            _json['salesforce_id'] = entity.salesforce_id
            _json['parent_entity_id'] = entity.parent_entity.entity_id if entity.parent_entity else None
            _json['parent_persistence_id'] = entity.parent_entity.persistence_id if entity.parent_entity else None
            _json['parent_salesforce_id'] = entity.parent_entity.salesforce_id if entity.parent_entity else None

            # if entity type is office, populate entity name using Firm Name + Address Line 1 + State
            if entity.entity_type_id != '201' or (entity.entity_name == 'edm_exempt' and entity.entity_name is None):
                _json['entity_name'] = entity.entity_name
            elif entity.entity_type_id == '201' and not entity.parent_entity:
                _json['entity_name'] = entity.entity_name
            else:
                firm_name = entity.parent_entity.entity_name
                addy_line_1 = entity.entity_address[0].street_address_1
                state = entity.entity_address[0].state
                _json['entity_name'] = ' '.join(filter(None, [firm_name, addy_line_1, state]))

            _json['entity_type_id'] = int(entity.entity_type_info.entity_type_id) if entity.entity_type_info \
                else entity.entity_type_id
            _json['entity_type_name'] = entity.entity_type_info.entity_type_name if entity.entity_type_info else None
            _json['client_type_id'] = entity.client_type_id
            _json['client_type_name'] = entity.client_type_info.client_type_name if entity.client_type_info else None
            _json['crm_id'] = entity.crm_id
            _json['employee_id'] = entity.employee_id
            _json['salesvision_id'] = entity.salesvision_id
            _json['crd'] = entity.crd
            _json['job_desc'] = 'Financial Advisor - Directly Authorized' if entity.entity_type_id == '101' and not entity.job_desc \
                else entity.job_desc

            # get billing/mailing addresses by specific type
            b_addy = None
            m_addy = None
            if hasattr(entity, 'entity_address') and len(entity.entity_address) > 0:
                b_addy = [addy for addy in entity.entity_address if addy.address_type_id == '300']
                b_addy = b_addy[0] if len(b_addy) > 0 else min(entity.entity_address,
                                                               key=lambda item: item.address_type_id)

                m_addy = [addy for addy in entity.entity_address if addy.address_type_id == '301']
                m_addy = m_addy[0] if len(m_addy) > 0 else min(entity.entity_address,
                                                               key=lambda item: item.address_type_id)
            _json['entity_billing_address'] = {
                'address_type': b_addy.address_type_id if b_addy else None,
                'street_1': b_addy.street_address_1 if b_addy else None,
                'street_2': b_addy.street_address_2 if b_addy else None,
                'city': b_addy.city if b_addy else None,
                'state': b_addy.state if b_addy and b_addy.country is not 'US' else None,
                'postal_code': b_addy.postal_code if b_addy else None,
                'country': b_addy.country if b_addy else None
            }
            _json['entity_mailing_address'] = {
                'address_type': m_addy.address_type_id if m_addy else None,
                'street_1': m_addy.street_address_1 if m_addy else None,
                'street_2': m_addy.street_address_2 if m_addy else None,
                'city': m_addy.city if m_addy else None,
                'state': m_addy.state if m_addy and m_addy.country is not 'US' else None,
                'postal_code': m_addy.postal_code if m_addy else None,
                'country': m_addy.country if m_addy else None
            }

            # capture secondary and primary phones by using the hierarchy in phone_type_enum
            secondary_phone = None
            primary_phone = None
            if hasattr(entity, 'entity_phone') and len(entity.entity_phone) > 0:
                primary_phone = [phone.phone_number for phone in entity.entity_phone
                                 if phone.phone_type.phone_type_name.lower() == 'primary']
                primary_phone = primary_phone[0] if primary_phone else None

                secondary_phone = max(entity.entity_phone, key=lambda item: item.phone_type.hierarchy)
                secondary_phone = secondary_phone.phone_number if secondary_phone else None

                _json['entity_primary_phone'] = primary_phone
                _json['entity_secondary_phone'] = secondary_phone if entity.salesvision_id else None
            else:
                _json['entity_primary_phone'] = primary_phone
                _json['entity_secondary_phone'] = secondary_phone

            # capture secondary and primary emails by using the hierarchy in email_type_enum
            secondary_email = None
            primary_email = None
            if hasattr(entity, 'entity_email') and len(entity.entity_email) > 0:
                primary_email = [email.email_address for email in entity.entity_email
                                 if email.email_type.email_type_name.lower() == 'primary']
                primary_email = primary_email[0] if primary_email else None

                secondary_email = max(entity.entity_email, key=lambda item: item.email_type.hierarchy)
                secondary_email = secondary_email.email_address if secondary_email else None

                _json['entity_primary_email'] = primary_email
                _json['entity_secondary_email'] = secondary_email if entity.salesvision_id else None
            else:
                _json['entity_primary_email'] = primary_email
                _json['entity_secondary_email'] = secondary_email

            # update ended at field only if record is not new (no SF ID)
            last_mod_date = datetime.strptime(entity.valid_entity.max_updated_at, '%Y-%m-%d %H:%M:%S') \
                .strftime('%Y-%m-%dT%H:%M:%S.000Z') if entity.valid_entity.max_updated_at else None
            _json['last_modified_date'] = last_mod_date if entity.salesforce_id else None
            _json['inactive'] = True if entity.ended_at else False
        except (TypeError, AttributeError) as e:
            print(e)
            print('broken entity id: {}'.format(entity.entity_id))
            return None
        return _json

    def bulk_update_entities(self, entities):
        """
        Bulk update entities (iterate through all entities and create load file)
        :param entities:
        :return:
        """
        # process updates from API request
        data = []
        for entity in entities:
            data.extend(self.process_entity_for_update(entity))

        # write updates to file
        file_name = self.generate_response_file_name('entity')
        self.write_response_data_to_file(INGEST_UPDATE_PATH, file_name, data)
        return set([entity['persistence_id'] for entity in data])

    def process_entity_for_update(self, curr_entity):
        """
        Process entity into list data for ETL re-ingestion
        :param curr_entity:
        :return:
        """
        # remove fields that we are not updating
        curr_entity.pop('agreement_ids', None)

        # list of entities that will be processed
        entities = []

        # create JSONs for each team member by iterating over team members list
        team_members = curr_entity.pop('team_members', None)
        if team_members:
            # copy request JSON, add team member to dict, flatten
            for mem in team_members:
                d = curr_entity.copy()
                d['team_members'] = mem
                entities.append(self.flatten_json_requests(d))
        else:
            entities.append(self.flatten_json_requests(curr_entity))
        return entities
