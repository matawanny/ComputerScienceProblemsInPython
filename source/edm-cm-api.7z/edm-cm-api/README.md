# EDM Client Master API

### Prerequisites
* Python 3.6+
* Packages (see `requirements.txt`)

### Packages
* `controllers`: endpoints for application
* `cron`: batch jobs
* `fm`: file manager lite package for data movement
* `managers`: business logic for controllers
* `merges`: landing zone for merge process response files
* `test`: testing suite
* `updates`: landing zone for ingest process response files
* `util`: utility classes & functions

### Usage
* Run API in development mode:
    * `python3 api.py`
* Run API in production mode:
    * `gunicorn --bind 0.0.0.0:9010 wsgi --daemon`
    * (For specific parameters, read docstring in `wsgi.py`)
   