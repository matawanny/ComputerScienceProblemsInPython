import pandas as pd
import pandera as pa

schema = pa.DataFrameSchema({
    'firm_id': pa.Column(pa.Int, nullable=False),
    'office_id': pa.Column(pa.Int, nullable=False),
    'person_id': pa.Column(pa.Int, allow_duplicates=False, nullable=False),
    'last_name': pa.Column(pa.String, nullable=False),
    'first_name': pa.Column(pa.String, nullable=False),
    'middle_name': pa.Column(pa.String),
    'broker_team': pa.Column(pa.String),
    'crm_firm_id': pa.Column(pa.String, nullable=False),
    'crm_office_id': pa.Column(pa.String, nullable=False),
    'crm_person_id': pa.Column(pa.String, nullable=False),
    'event_code': pa.Column(pa.String, pa.Check(lambda x: x.isin(['I', 'U', 'D'])), nullable=False),
    'crm_svc_req_id': pa.Column(pa.String),
    'person_status': pa.Column(pa.String),
    'home_office_flag': pa.Column(pa.String),
    'phone_number': pa.Column(pa.String),
    'email_address': pa.Column(pa.String),
    'crd_number': pa.Column(pa.Int, nullable=False),
    'broker_rep_code': pa.Column(pa.String),
    'created_at': pa.Column(pa.String, nullable=False),
    'created_by': pa.Column(pa.String, nullable=False),
    'updated_at': pa.Column(pa.DateTime, nullable=False),
    'updated_by': pa.Column(pa.String, pa.Check(lambda x: len(x.strip()) != 0), nullable=False)
}
)
PERSON_ACK_CSV = "C:\\ws_checkin1\\essential-sqlalchemy\\edmcm\\TEST_salesvision_person_profile_12_09_2020"
personAck = pd.read_csv(PERSON_ACK_CSV, sep=",", engine="python", keep_default_na=False, escapechar='\\',
                        error_bad_lines=False)
try:
    schema.validate(personAck)
except pa.errors.SchemaError as e:
    print(f'{e}')
