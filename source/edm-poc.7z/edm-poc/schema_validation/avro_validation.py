import pandas as pd

import json
from datetime import datetime
from avro_validator.schema import Schema
from avro_validator import EnumType

# to_date = lambda s: datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
schema = json.dumps(
{
        "name": "person schema",
        "type": "record",
        "doc": "schema for testing avro_validator",
        "fields": [{
            "name": "firm_id",
            "type": "int"
        },
            {
                "name": "office_id",
                "type": "int"
            },
            {
                "name": "person_id",
                "type": "int"
            },
            {
                "name": "last_name",
                "type": "string"
            },
            {
                "name": "first_name",
                "type": "string"
            },
            {
                "name": "middle_name",
                "type": "string"
            },
            {
                "name": "broker_team",
                "type": "string"
            },
            {
                "name": "crm_firm_id",
                "type": "string"
            },
            {
                "name": "crm_office_id",
                "type": "string"
            },
            {
                "name": "crm_person_id",
                "type": "string"
            },
            {
                "name": "event_code",
                "type": ["null", {
                    "type": "enum",
                    "name": "event_code_enum",
                    "symbols": ["I", "U", "D"]}]
            },
            {
                "name": "crm_svc_req_id",
                "type": "string"
            },
            {
                "name": "person_status",
                "type": "string"
            },
            {
                "name": "home_office_flag",
                "type": "string"
            },
            {
                "name": "phone_number",
                "type": "string"
            },
            {
                "name": "email_address",
                "type": "string"
            },
            {
                "name": "crd_number",
                "type": "string"
            },
            {
                "name": "broker_rep_code",
                "type": "string"
            },
            {
                "name": "created_at",
                "type": "string"
            },
            {
                "name": "created_by",
                "type": "string"
            },
            {
                "name": "updated_at",
                "type": "string"
            },
            {
                "name": "updated_by",
                "type": "string"
            }
        ]
    })
schema = Schema(schema)
parsed_schema = schema.parse()

PERSON_ACK_CSV = "C:\\ws_checkin1\\edm-poc\\schema_validation\\TEST_salesvision_person_profile_12_09_2020"
personAck = pd.read_csv(PERSON_ACK_CSV, sep=",", engine="python", keep_default_na=False, escapechar="\\",
                        error_bad_lines=False)
person_list = json.loads(json.dumps(list(personAck.T.to_dict().values())))

for index, person in enumerate(person_list):
    try:
        parsed_schema.validate(person)
    except ValueError as e:
        print(f"row {index}: {e}")
