from datetime import datetime
from sqlalchemy import (MetaData, Table, Column, Integer, Numeric, String,
                        DateTime, ForeignKey, Boolean, create_engine, )
from sqlalchemy import CheckConstraint
from sqlalchemy.exc import IntegrityError
import pandas as pd
import json
import datetime


class DataAccessLayer:
    connection = None
    engine = None
    conn_string = None
    metadata = MetaData()
    persons = Table('persons', metadata,
                    Column('firm_id', Integer(), nullable=False),
                    Column('office_id', Integer(), nullable=False),
                    Column('person_id', Integer(), unique=True),
                    Column('last_name', String(255), nullable=False),
                    Column('first_name', String(255), nullable=False),
                    Column('middle_name', String(255), nullable=True),
                    Column('broker_team', String(255), nullable=True),
                    Column('crm_firm_id', String(255), nullable=False),
                    Column('crm_office_id', String(255), nullable=False),
                    Column('crm_person_id', String(255), nullable=False),
                    Column('event_code', String(20), CheckConstraint('event_code in ("I","U","D")', name='event_code_constraint')),
                    Column('crm_svc_req_id', String(20), nullable=True),
                    Column('person_status', String(255), nullable=True),
                    Column('home_office_flag', String(20), nullable=True),
                    Column('phone_number', String(255), nullable=True),
                    Column('email_address', String(255), nullable=True),
                    Column('crd_number', Integer(), nullable=False),
                    Column('broker_rep_code', String(255), nullable=True),
                    Column('created_at', DateTime(), nullable=False),
                    Column('created_by', String(255), nullable=False),
                    Column('updated_at', DateTime(), nullable=False),
                    Column('updated_by', String(255), CheckConstraint('updated_by!=""', name='update_by_constraint'))
                    )

    def db_init(self, conn_string):
        self.engine = create_engine(conn_string or self.conn_string)
        self.metadata.create_all(self.engine)
        self.connection = self.engine.connect()


dal = DataAccessLayer()


def prep_db():
    PERSON_ACK_CSV = "C:\\ws_checkin1\\edm-poc\\schema_validation\\TEST_salesvision_person_profile_12_09_2020"
    personAck = pd.read_csv(PERSON_ACK_CSV, sep=",", engine="python", keep_default_na=False, escapechar='\\',
                            error_bad_lines=False)
    # data = personAck.to_json(orient='records', lines=True)
    # person_list = data.splitlines()
    person_list = json.loads(json.dumps(list(personAck.T.to_dict().values())))
    ins = dal.persons.insert()
    for person in person_list:
        persons = []
        # print(person)
        if person['created_at']:
            person['created_at'] = datetime.datetime.strptime(person['created_at'], '%Y-%m-%d %H:%M:%S')
        else:
            person['created_at'] = None
        if person['updated_at']:
            person['updated_at'] = datetime.datetime.strptime(person['updated_at'], '%Y-%m-%d %H:%M:%S')
        else:
            person['updated_at'] = None
        persons.append(person)
        try:
            dal.connection.execute(ins, persons)
        except IntegrityError as e:
            print(f'{e}')

    # dal.connection.execute(ins, person_list)


if __name__ == "__main__":
    dal.db_init('sqlite:///:memory:')
    prep_db()
