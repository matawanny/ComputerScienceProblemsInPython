import pandas as pd
from pandas_schema import Column, Schema
from pandas_schema.validation import LeadingWhitespaceValidation, TrailingWhitespaceValidation, CanConvertValidation, \
    CustomSeriesValidation, MatchesPatternValidation, DateFormatValidation, InListValidation, IsDistinctValidation,CustomElementValidation


OFFICE_ACK_CSV = "C:\\ws_checkin1\\edm-poc\\schema_validation\\TEST_salesvision_office_profile_12_09_2020"
officeAck = pd.read_csv(OFFICE_ACK_CSV, sep=",", engine="python", keep_default_na=False, escapechar='\\',
                        error_bad_lines=False)
office_ids = officeAck['office_id'].tolist()
schema = Schema([
                Column('firm_id', [CanConvertValidation(int)]),
                Column('office_id', [InListValidation(office_ids)]),
                Column('person_id', [CanConvertValidation(int), IsDistinctValidation()]),
                Column('last_name', [LeadingWhitespaceValidation(), TrailingWhitespaceValidation()]),
                Column('first_name', [LeadingWhitespaceValidation(), TrailingWhitespaceValidation()]),
                Column('middle_name', [LeadingWhitespaceValidation(), TrailingWhitespaceValidation()]),
                Column('broker_team', [LeadingWhitespaceValidation(), TrailingWhitespaceValidation()]),
                Column('crm_firm_id', [LeadingWhitespaceValidation(), TrailingWhitespaceValidation()]),
                Column('crm_office_id', [LeadingWhitespaceValidation(), TrailingWhitespaceValidation()]),
                Column('crm_person_id', [LeadingWhitespaceValidation(), TrailingWhitespaceValidation()]),
                Column('event_code', [InListValidation(['I', 'U', 'D'])]),
                Column('crm_svc_req_id', [LeadingWhitespaceValidation(), TrailingWhitespaceValidation()]),
                Column('person_status', [LeadingWhitespaceValidation(), TrailingWhitespaceValidation()]),
                Column('home_office_flag', [LeadingWhitespaceValidation(), TrailingWhitespaceValidation()]),
                Column('phone_number', [LeadingWhitespaceValidation(), TrailingWhitespaceValidation()]),
                Column('email_address', [LeadingWhitespaceValidation(), TrailingWhitespaceValidation()]),
                Column('crd_number',  [CustomSeriesValidation(lambda x: x.str.len() > 0, 'Cannot be empty')]),
                Column('broker_rep_code', [LeadingWhitespaceValidation(), TrailingWhitespaceValidation()]),
                Column('created_at', [DateFormatValidation('%Y-%m-%d %H:%M:%S')]),
                Column('created_by', [CustomSeriesValidation(lambda x: x.str.len() > 0, 'Cannot be empty')]),
                Column('updated_at', [DateFormatValidation('%Y-%m-%d %H:%M:%S')]),
                Column('updated_by', [CustomSeriesValidation(lambda x: x.str.len() > 0, 'Cannot be empty')])
                ])

PERSON_ACK_CSV = "C:\\ws_checkin1\\edm-poc\\schema_validation\\TEST_salesvision_person_profile_12_09_2020"
personAck = pd.read_csv(PERSON_ACK_CSV, sep=",", engine="python", keep_default_na=False, escapechar='\\',
                        error_bad_lines=False)

errors = schema.validate(personAck)
for error in errors:
    print(error)

