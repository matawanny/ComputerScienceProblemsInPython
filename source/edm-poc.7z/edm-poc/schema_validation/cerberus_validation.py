import pandas as pd

import json
from datetime import datetime
from cerberus import Validator


to_date = lambda s: datetime.strptime(s, '%Y-%m-%d %H:%M:%S')
schema = {
                'firm_id': {'type': 'integer'},
                'office_id': {'type': 'integer'},
                'person_id': {'type': 'integer', 'empty': False},
                'last_name': {'type': 'string'},
                'first_name': {'type': 'string'},
                'middle_name': {'type': 'string'},
                'broker_team': {'type': 'string'},
                'crm_firm_id': {'type': 'string'},
                'crm_office_id': {'type': 'string'},
                'crm_person_id': {'type': 'string'},
                'event_code': {'type': 'string', 'allowed': ['I','U','D']},
                'crm_svc_req_id': {'type': 'string'},
                'person_status': {'type': 'string'},
                'home_office_flag': {'type': 'string'},
                'phone_number': {'type': 'string'},
                'email_address': {'type': 'string'},
                'crd_number': {'type': 'string', 'empty': False},
                'broker_rep_code': {'type': 'string'},
                'created_at': {'type': 'datetime', 'coerce': lambda s: datetime.strptime(s, '%Y-%m-%d %H:%M:%S')},
                'created_by': {'type': 'string', 'empty': False},
                'updated_at': {'type': 'datetime', 'coerce': lambda s: datetime.strptime(s, '%Y-%m-%d %H:%M:%S')},
                'updated_by': {'type': 'string', 'empty': False}
}

PERSON_ACK_CSV = "C:\\ws_checkin1\\edm-poc\\schema_validation\\TEST_salesvision_person_profile_12_09_2020"
personAck = pd.read_csv(PERSON_ACK_CSV, sep=",", engine="python", keep_default_na=False, escapechar='\\',
                        error_bad_lines=False)
person_list = json.loads(json.dumps(list(personAck.T.to_dict().values())))

v = Validator()
for index, person in enumerate(person_list):
    v.validate(person, schema)
    if v.errors:
        print('row {}: {}'.format(index, v.errors))

