import setuptools

setuptools.setup(name='JobSystem',
      version='1.0',
      description='Job System',
      author='Greg L Pelts',
      author_email='greg.pelts@lazard.com',
      url='https://tbd',
      packages=setuptools.find_packages(),
      python_requires='>=3.6'
      )