import unittest
import jobsystem.job_runner  as job_runner
from datetime import  date


class TestJobSystem(unittest.TestCase):

    def test_jobrunner_etl(self):
        args = ['-codeToRun=launch_on_emr', '-targetMachine=lazard-<env:lower>-emr-etl', \
                "-inputs={'emr':'s3://lazard-test-client-master/etl-output/salesvision/firm/<cob:%Y-%m-%d:-2>.csv.gz','source':'SF'}", \
                "-outputs={'Example string for FileManager':'s3://lazard-<ENVPREFIX>-client-master/etl-output/salesvision/firm/<ENVprefix>SV_Firm_File<cob:%Y-%m-%d:-2>'}",\
                '-overrideEnv=test', "-parameters={'emr_function': 'etl','etl_name': 'SV Person ETL', 'packages': [], 'prefix': 'sv_person', 'file_extension': 'csv', 'source_type': 'csv', 'source_name': 'sv_person', 'schema_name': 'ENTITY_ADRRESS', 'destinations': ['postgres', 'parquet'], 'source_schema_name': 'sv_person_pipe', 'target_schema_name': 'ENTITY_ADRRESS','commons_branch':'release.1.1' }",\
                '-dryRun', '-alias=test_etl', "-aws"]

        COB = date(2002, 12, 31)
        jr = job_runner.main(args)



    def test_jobrunner_str_substitution(self):
        args = ['-codeToRun=launch_on_emr', '-targetMachine=lazard-<env:lower>-emr-etl', \
                "-inputs={'emr':'s3://lazard-test-client-master/etl-output/salesvision/firm/<cob:%Y-%m-%d:-2>','source':'SF'}", \
                "-outputs={'Example string for FileManager':'s3://lazard-<ENVPREFIX>-client-master/etl-output/salesvision/firm/<ENVprefix>SV_Firm_File<cob:%Y-%m-%d:-2>'}",\
                '-overrideEnv=test', "-parameters={'emr_function': 'etl', 'etl_name': 'SV Person ETL', 'packages': [], 'prefix': 'sv_person', 'file_extension': 'csv', 'source_type': 'csv', 'source_name': 'sv_person', 'schema_name': 'ENTITY_ADRRESS', 'destinations': ['postgres', 'parquet'], 'source_schema_name': 'sv_person_pipe', 'target_schema_name': 'ENTITY_ADRRESS','commons_branch':'release.1.1' }",\
                '-dryRun', '-alias=test_etl']

        COB = date(2002, 12, 31)
        jr = job_runner.main(args)
        result1 = jr.processSubstitutionVariables(jr.env, COB, "SV_Firm_File_<cob:%Y-%m-%d:-2>")
        self.assertEqual(result1, "SV_Firm_File_2002-12-29")
        result2 = jr.processSubstitutionVariables(jr.env, COB, "Fishtank_<COB:%Y-%m-%d:-1:MONTHEND>.csv.gz")
        self.assertEqual(result2, "Fishtank_2002-11-30.csv.gz")
        result3 = jr.processSubstitutionVariables(jr.env, COB, jr.targetMachine)
        self.assertEqual(result3, "lazard-test-emr-etl")

    def test_jobrunner_params_none(self):
        args = ['-codeToRun=launch_on_emr', '-alias="test_jobrunner', '-targetMachine=lazard-<env:lower>-emr-etl', \
                      "-inputs={'emr':'s3://lazard-test-client-master/etl-output/salesvision/firm/<cob:%Y-%m-%d:-2>', \
                      'source':'SF'}", "-outputs={'Example string for FileManager':'s3://lazard-<ENVPREFIX>-client-master/etl-output/salesvision/firm/<ENVprefix>SV_Firm_File<cob:%Y-%m-%d:-2>'}",\
                      '-overrideEnv=test',"-parameters={'emr_function': 'mdm'}",'-dryRun']
        jr = job_runner.main(args)
        self.assertEqual(jr.parameters, {})

    def test_jobrunner_mdm(self):
        args = ['-codeToRun=launch_on_emr', '-alias="test_jobrunner', '-targetMachine=lazard-<env:lower>-emr-etl',\
                  "-inputs={'emr':'s3://lazard-test-client-master/etl-output/salesvision/firm/<cob:%Y-%m-%d:-2>',"\
                  "'source':'SF'}", "-outputs={'Example string for FileManager':'s3://lazard-<ENVPREFIX>-client-master/etl-output/salesvision/firm/<ENVprefix>SV_Firm_File<cob:%Y-%m-%d:-2>'}",\
                  '-overrideEnv=test',"-parameters={'emr_function': 'mdm'}",'-dryRun']
        jr = job_runner.main(args)

    def test_jobrunner_localhost(self):
        args = ['-codeToRun=amg_file_manager_opswise', '-targetMachine=DUMMY', '-overrideEnv=test','-alias=testFilemanager', '-dryRun']
        jr = job_runner.main(args)
        self.assertEqual(jr.type, "local")


    def test_jobrunner_dbsync(self):
        args = ['-codeToRun=launch_on_emr', "-inputs={'dbsync_param':'sf_entity_api'}", '-overrideEnv=test',
            '-targetMachine=lazard-<env:lower>-emr-mdm', "-parameters={'emr_function': 'dbsync'}", '-alias=testDBSync', '-dryRun']
        jr = job_runner.main(args)

    def test_salesforce_ingest(self):
        args = ['-codeToRun=launch_on_emr', "-alias=test_salesforce_ingest", '-targetMachine=DUMMY', "-parameters={'endpoint':'job/launch/ingest/<COB:%m-%d-%Y:0>','emr_function':'dbsync'}", '-dryRun', '-overrideEnv=test']
        jr = job_runner.main(args)

    def test_jobrunner_emr_type(self):
        args = ['-codeToRun=launch_on_emr', '-alias="test_jobrunner', '-targetMachine=lazard-<env:lower>-emr-etl', \
                      "-inputs={'emr':'s3://lazard-test-client-master/etl-output/salesvision/firm/<cob:%Y-%m-%d:-2>', \
                      'source':'SF'}", "-outputs={'Example string for FileManager':'s3://lazard-<ENVPREFIX>-client-master/etl-output/salesvision/firm/<ENVprefix>SV_Firm_File<cob:%Y-%m-%d:-2>'}",\
                      '-overrideEnv=test',"-parameters={'emr_function': 'mdm'}",'-dryRun']
        jr = job_runner.main(args)
        #self.assertEqual(jr.type, "EMR")       TBD-glp 4/5/20    this test needs to be modified to check that the record in dynamo db has type=EMR since type is no longer an attribute of JobRunner and it's the dynamoDB record which should be tested, not job runner

if __name__ == '__main__':
    unittest.main()