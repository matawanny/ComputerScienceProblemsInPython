# JobSystem Package

The JobSystem package contains code to run any batch process, both on the local machine and AWS, and track historical runs.
A job remembers its inputs, outputs and parameters. If a job is rerun, its output(s) and log are not overwritten. Once 
started, a job blocks until it completes. Upon completion each job produces a status - SUCCESS|FAIL. 