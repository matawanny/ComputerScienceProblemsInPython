import boto3
from tabulate import tabulate
from pprint import pprint
import os
import sys
import argparse
from boto3.dynamodb.conditions import Attr, Key
from common.aws import EMR
from common.envconfig import ENVS


def assumeRole(args):
    # code to refresh aws credentials
    script =  ENVS[args.env]['assumerole']
    os.system(script + " > /dev/null")

def emr_step_info(args):
    act_clusters = get_active_cluster_dict()

    if args.clust_name not in act_clusters:
        print("{0} is not running".format(args.clust_name))
        sys.exit(1)
    clust_id = act_clusters[args.clust_name]
    header_list = ["cl_id","step_id", "step_name", "step_state", "duration", "start_time", "end_time"]
    step_list = []
    emr_conn = boto3.client("emr")
    step_states = ['RUNNING', 'COMPLETED', 'PENDING', 'FAILED', 'CANCELLED']
    if args.step_states:
        if args.step_states.lower() == "active":
            step_states=['RUNNING', 'PENDING']
        elif args.step_states.lower() == "failed":
            step_states=['FAILED']
        else:
            step_states=['RUNNING', 'COMPLETED', 'PENDING', 'FAILED', 'CANCELLED']
    response = emr_conn.list_steps(
        ClusterId=clust_id,
        StepStates=step_states
    )
    for step in response["Steps"]:
        elapsedTimeInMin = " "
        end_time = " "

        st_id = step["Id"]
        st_name = step["Name"]
        st_status = step["Status"]["State"]
        start_time = step['Status']['Timeline'].get('StartDateTime')
        end_time = step['Status']['Timeline'].get('EndDateTime')
        if start_time and end_time:
           elapsedTime = end_time - start_time
           duration_in_s = elapsedTime.total_seconds()
           elapsedTimeInMin = str(divmod(duration_in_s, 60)[0]) + " min"
        step_curr = [clust_id, st_id, st_name, st_status, elapsedTimeInMin, start_time,end_time]
        step_list.append(step_curr)
    print(tabulate(step_list, headers=header_list, tablefmt='orgtbl'))

def get_active_cluster_dict():
    active_clusters = {}
    client = boto3.client("emr")
    response = client.list_clusters(
           ClusterStates=['RUNNING', 'WAITING']
    )
    for c in response['Clusters']:
        cl_id=c["Id"]
        cl_name = c["Name"]
        if "etl" in cl_name:
           active_clusters['etl']=cl_id
        if "mdm" in cl_name:
           active_clusters['mdm']=cl_id
    return active_clusters


"""
{'Id': 'j-3VMUFXQ58T02Z', 'Name': 'lazard-test-emr-mdm', 'Status': {'State': 'WAITING', 'StateChangeReason': {'Message': 'Cluster ready after last step completed.'}, 'Timeline': {'CreationDateTime': datetime.datetime(2020, 3, 29, 8, 10, 54, 157000, tzinfo=tzlocal()), 'ReadyDateTime': datetime.datetime(2020, 3, 29, 8, 24, 45, 504000, tzinfo=tzlocal())}}, 'NormalizedInstanceHours': 6128, 'ClusterArn': 'arn:aws:elasticmapreduce:us-east-2:430815409173:cluster/j-3VMUFXQ58T02Z'}
"""
def get_active_clusters(args):
    cl_list = []
    header_list = ["cl_id", "cl_name", "cl_state", "cl_creation_time"]
    client = boto3.client("emr")
    response = client.list_clusters(
           ClusterStates=['RUNNING', 'WAITING']
    )
    for c in response['Clusters']:
        cl_id=c["Id"]
        cl_name = c["Name"]
        cl_state = c["Status"].get("State")
        cl_creation = c["Status"]["Timeline"]["CreationDateTime"]
        cl_curr = [cl_id,cl_name, cl_state, cl_creation]
        cl_list.append(cl_curr)
    print(tabulate(cl_list, headers=header_list, tablefmt='orgtbl'))


def get_opswise_status(args):
    job_list = []
    header_list = ["job_id", "jobdate", "jobalias","jobstart","jobend", "jobstatus", "joblog"]
    dynamoDBTable = "OpswiseJobStatus"
    dynamoDB = boto3.resource('dynamodb')

    table = dynamoDB.Table('OpswiseJobStatus')
    scan_kwargs = {
        'FilterExpression': Attr("jobdate").contains(args.job_date)
    }
    done = False
    start_key = None
    while not done:
        if start_key:
            scan_kwargs['ExclusiveStartKey'] = start_key
        response = table.scan(**scan_kwargs)
        items = response.get('Items', [])
        start_key = response.get('LastEvaluatedKey', None)
        done = start_key is None
        for item in items:
          jobid = item['jobid']
          jobdate = item['jobdate']
          jobstatus = item.get('Job Status')
          jobstart = item.get('job_start')
          jobend = item.get('job_end')
          joblog = item.get('job_log')
          jobalias = item.get('job_alias')
          curr_list = [jobid, jobdate, jobalias, jobstart, jobend, jobstatus, joblog]
          job_list.append(curr_list)
    job_list.sort(key = lambda job_list: job_list[3])
    print(tabulate(job_list, headers=header_list, tablefmt='orgtbl'))


def get_jobid(args):
    dynamoDBTable = "OpswiseJobStatus"
    dynamoDB = boto3.resource('dynamodb')
    table = dynamoDB.Table(dynamoDBTable)
    response = table.query(
                KeyConditionExpression=Key('jobid').eq(args.job_id)
               )
    item = response['Items']
    pprint(item)

def cancel_step(args):
    EMR.kill(args.env, args.clust_id, args.step_id)

def help():
    ex1 = "python emr_functions.py -method get_active_clusters  -env test"
    ex2 = "python emr_functions.py -method emr_step_info -env test -clust_name mdm -step_states all"
    ex3 = "python emr_functions.py -method get_opswise_status -env test  -job_date 20200406"
    ex4 = "python emr_functions.py -method get_jobid -env test -job_id d88c3afe780711ea9f71005056ad40a1"
    print(ex1)
    print(ex2)
    print(ex3)
    print(ex4)


def main(args):
    parser = argparse.ArgumentParser(description='Job System')
    # Required arguments
    parser.add_argument('-method', help='method to run', required=False)
    parser.add_argument('-clust_id', help='clusterID of EMR', required=False)
    parser.add_argument('-step_id', help='StepID of running step on EMR', required=False)
    parser.add_argument('-clust_name', help='EMR cluster name - etl or mdm ', required=False)
    parser.add_argument('-step_states', help='EMR states', required=False)
    parser.add_argument('-job_date', help='Job date for scanning dynamoDB', required=False)
    parser.add_argument('-job_id', help='JobID for query', required=False)
    parser.add_argument('-env', help='Environment - test/prod', required=False)
    parser.add_argument('-help', help='show help', action='store_true')



    args = parser.parse_args(args)
    if args.help:
        help()
        sys.exit(1)
    assumeRole(args)
    func = globals()[args.method]
    func(args)

if __name__ == "__main__":
    main(sys.argv[1:])

