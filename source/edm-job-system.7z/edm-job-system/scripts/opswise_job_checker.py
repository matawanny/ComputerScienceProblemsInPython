import sys
import argparse
from common.envconfig import ENVS
from common.security import *
from jobsystem.FeedAPI import FeedAPI
import json
import datetime


def check_on_status(args):
    status_set = set()
    json_acceptable_string = args.feeds.replace("'", "\"")
    d = json.loads(json_acceptable_string)
    cob = args.cob
    env  = args.env
    for datasource in d:
        for feedName in d[datasource]:
            feed_api = FeedAPI(env)
            output = feed_api.getFeedInstancesByFeedID(datasource, feedName, cob)
            print("output:{}".format(len(output)))
            if len(output) == 0:
               status_set.add(None)
            else:
               print(output)
               item = output.pop()
               print("runtime: {}, feedID: {}, jobstatus: {}".format(item.RunTime, item.FeedID,item.Status))
               status_set.add(item.Status)
    print(status_set)
    if len(status_set) > 1:
        raise ValueError("Some Job/s completed while others did not - exiting with ERROR")


def main(args):
    parser = argparse.ArgumentParser(description='Job System')
    # Required arguments
    parser.add_argument('-feeds', help='method to run', required=False)
    parser.add_argument('-cob', help='Close of bussiness day', required=False, default=datetime.datetime.now().strftime('%Y-%m-%d'))
    parser.add_argument('-env', help='Environment - test/prod', required=False)
    args = parser.parse_args(args)
    env = args.env
    assume_role(ENVS[env]['assumerole'])
    check_on_status(args)

if __name__ == "__main__":
    main(sys.argv[1:])
