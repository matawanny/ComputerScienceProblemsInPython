import boto3
import gzip
from io import BytesIO
import sys

#emrLogBucket = "aws-logs-617264982758-us-east-1"
emrLogBucket = "aws-logs-430815409173-us-east-2"
def retrieveS3Log(cluster_id, step_id):
     key = "elasticmapreduce/{0}/steps/{1}/stdout.gz".format(cluster_id, step_id)
     print("Retrieving Log Key:"+str(key))
     try:
         s3 = boto3.resource('s3')
         obj = s3.Object(emrLogBucket, key)
         n = obj.get()['Body'].read()
         gzipfile = BytesIO(n)
         gzipfile = gzip.GzipFile(fileobj=gzipfile)
         log_contents = gzipfile.read().decode('UTF-8')
         print(log_contents)
     except Exception as e:
        print(e)
        raise e

instance_id = sys.argv[1]
step_id = sys.argv[2]
retrieveS3Log(instance_id, step_id)
