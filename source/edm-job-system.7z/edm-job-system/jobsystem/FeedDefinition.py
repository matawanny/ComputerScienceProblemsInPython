import ast
from datetime import datetime

from common.aws import DynamoDB


class FeedDefinition:
    def __init__(self, PreviousFeedID, FeedID, Inputs, Outputs, System, CodeToRun, DataTypes,
                 ControlCheckThreshold, Transform, GetAndSend,
                 ETA, SLA, Contact, Escalation, ActiveDateStart=None, ActiveDateEnd=None,
                 Parameters={}):
        self._PreviousFeedID = PreviousFeedID
        self._FeedID = FeedID
        self._Inputs = Inputs
        self._Outputs = Outputs
        self._System = System
        self._CodeToRun = CodeToRun
        self._DataTypes = DataTypes
        self._ControlCheckThreshold = ControlCheckThreshold
        self._Transform = Transform
        self._GetAndSend = GetAndSend
        self._ETA = ETA
        self._SLA = SLA
        self._Contact = Contact
        self._Escalation = Escalation
        self._ActiveDateStart = ActiveDateStart
        self._ActiveDateEnd = ActiveDateEnd
        self._Parameters = Parameters

    def to_dict(self):
        return {"PreviousFeedID": self.PreviousFeedID,
                "feedID": self.FeedID,
                "Inputs": self._Inputs,
                "Outputs": self._Outputs,
                "System": self._System,
                "CodeToRun": self._CodeToRun,
                "DataTypes": self._DataTypes,
                "ControlCheckThreshold": self._ControlCheckThreshold,
                "Transform": self._Transform,
                "GetAndSend": self._GetAndSend,
                "ETA": self._ETA,
                "SLA": self._SLA,
                "Contact": self._Contact,
                "Escalation": self._Escalation,
                "ActiveDateStart": self._ActiveDateStart,
                "ActiveDateEnd": self._ActiveDateEnd,
                "Parameters": self._Parameters
                }

    @property
    def DataSource(self):
        data_source = str(self._FeedID).split('_')[0]
        return data_source

    @property
    def FeedName(self):
        feed_name = str(self._FeedID).split('_')[1]
        return feed_name

    @property
    def PreviousFeedID(self):
        return self._PreviousFeedID

    @property
    def FeedID(self):
        return self._FeedID

    @property
    def Inputs(self):
        return self._Inputs

    @property
    def Outputs(self):
        return self._Outputs

    @property
    def System(self):
        return self._System

    @property
    def CodeToRun(self):
        return self._CodeToRun

    @property
    def DataTypes(self):
        return self._DataTypes

    @property
    def ControlCheckThreshold(self):
        return self._ControlCheckThreshold

    @property
    def ValidationRules(self):
        return self._ValidationRules

    @property
    def ETA(self):
        return self._ETA

    @property
    def SLA(self):
        return self._SLA

    @property
    def Contact(self):
        return self._Contact

    @property
    def Escalation(self):
        return self._Escalation

    @property
    def ActiveDateStart(self):
        return self._ActiveDateStart

    @property
    def ActiveDateEnd(self):
        return self._ActiveDateEnd

    @property
    def Parameters(self):
        return self._Parameters

    # def deactivate(self,environment, end_date=datetime.now().timestamp()):
    #     self._ActiveDateEnd = int(end_date)
    #     with DynamoDB(environment) as dynamodb:
    #         dynamodb.upsert("feedInstance", self.to_dict())
    #
    # def is_active(self):
    #     if self._ActiveDateStart:
    #         return (int(datetime.now().timestamp()) >= self._ActiveDateStart
    #                 and (not self._ActiveDateEnd or int(datetime.now().timestamp()) < self._ActiveDateEnd))
    #     return False


class TimeWindow:
    def __init__(self, startTime, endTime):
        self._startTime = startTime
        self._endTime = endTime

    @property
    def startTime(self):
        return self._startTime

    @property
    def endTime(self):
        return self._endTime

    def to_dict(self):
        return {
            "startTime": self._startTime,
            "endTime": self._endTime
        }

    def decactivate(self, decactivation_date=datetime.now()):
        pass

    def activate(self, decactivation_date=datetime.now()):
        pass

    def is_activate(self):
        pass


class FunctionAndParameter:
    def __init__(self, functionName, functionParameters):
        self._functionName = functionName
        self._functionParameters = functionParameters

    @property
    def functionName(self):
        return self._functionName

    @property
    def functionParameters(self):
        return self._functionParameters

    def to_dict(self):
        return {
            "functionName": self._functionName,
            "functionParameters": self._functionParameters
        }


class ControlCheckThreshold:
    # todo: build this out
    # UC1 DayOverDay  ExactRecordCount  (Agreements:0,0, Persons:100,-100)
    # UC2 DayOverDay  PercentageRecordCount  (Agreements:0,0, Persons:5,-5)
    # and or criteria
    # UC3 VersusPreviosJob
    def __init__(self, Type):
        self._Type = Type

    @property
    def Type(self):
        return self._Type

    def to_dict(self):
        return {"Type": self._Type}

def getFeedDefinitionByFeedId(self, environment ,DataSource, FeedName):
        feed_id = DataSource + "_" + FeedName
        feed_definitions = []
        data = {"hash_key": "feedID",
                 "feedID": feed_id}
        with DynamoDB(environment) as dynamodb:
            query_results = dynamodb.query("feedDefinition", data)

        query_result = query_results[0]
        feed_definitions.append(FeedDefinition(query_result['PreviousFeedID'],
                                                query_result['feedID'],
                                                query_result['Inputs'],
                                                query_result['Outputs'],
                                                query_result['System'],
                                                query_result['CodeToRun'],
                                                query_result['DataTypes'],
                                                query_result['ControlCheckThreshold'],
                                                query_result['Transform'],
                                                query_result['GetAndSend'],
                                                query_result['ETA'],
                                                query_result['SLA'],
                                                query_result['Contact'],
                                                query_result['Escalation'],
                                                query_result['ActiveDateStart'],
                                                query_result['ActiveDateStart']
                                               ))

        return feed_definitions