#auto_generated file - contents are copied from build_config_<env>.py
branch = "master"
postgres_jar =  "/code/jars/postgresql-42.2.5.jar"
commons_zip  =  "/code/commons/{}/edm-commons.zip"
dpl_zip      =   "/code/dpl/{}/edm-dpl.zip"
etl_driver   =   "/code/dpl/{}/etl_driver.py"
mdm_driver   =   "/code/dpl/{}/mdm_driver.py"
circe_driver  =  "/code/dpl/{}/circe_driver.py"
dbsync_driver   =  "/code/dpl/{}/dbsync_driver.py"
spark_driver_memory =  "--conf", "spark.driver.memory=16G"
spark_executor_memory =   "--conf", "spark.executor.memory=16G"


