from db_query_lib import fx_rate_conversion_query


class FXRateElement:

    def __init__(self, current_symbol, current_rate, target_symbol, target_rate,
                 fx_rate, rate_date, end_date, fx_rate_id=None, created_at=None, updated_at=None):
        self.current_symbol = current_symbol
        self.current_rate = current_rate
        self.target_symbol = target_symbol
        self.target_rate = target_rate
        self.fx_rate = fx_rate
        self.rate_date = rate_date
        self.end_date = end_date
        self.fx_rate_id = fx_rate_id
        self.created_at = created_at
        self.updated_at = updated_at

    def __repr__(self):
        return iter([self.fx_rate_id, self.current_symbol, self.current_rate, self.target_symbol, self.target_rate,
                     self.fx_rate, self.rate_date, self.end_date])

    @classmethod
    def object_load_from_db(cls, cursor, date_range, target_currencies):
        target_query = fx_rate_conversion_query.format(date_range, target_currencies)
        fxrates = []
        cursor.execute(target_query)
        results = cursor.fetchall()
        for i, res in enumerate(results):
            fxrate = FXRateElement(
                fx_rate_id=i,
                current_symbol=res[0],
                current_rate=res[1],
                target_symbol=res[2],
                target_rate=res[3],
                fx_rate=res[4],
                rate_date=res[5].strip(),
                end_date=res[6].strip()
            )
            fxrates.append(fxrate.__repr__())
        return fxrates

    @classmethod
    def table_load_from_db(cls, cursor, date_range, target_currencies):
        target_query = fx_rate_conversion_query.format(date_range, target_currencies)
        cursor.execute(target_query)
        results = cursor.fetchall()
        return results

    @classmethod
    def get_header(cls):
        return (['fx_rate_id', 'current_symbol', 'current_rate', 'target_symbol', 'target_rate',
                 'fx_rate', 'rate_date', 'end_date'])
