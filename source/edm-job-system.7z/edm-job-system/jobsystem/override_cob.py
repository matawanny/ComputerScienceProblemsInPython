import argparse
import sys
from datetime import datetime, timedelta

from common.aws import DynamoDB

override_table = 'FeedOverrideCOB'

feed_name_col = 'FeedName'
override_cob_col = 'OverrideCOB'
time_to_live_col = 'TimeToLive'
created_at_col = 'CreatedAt'
data_source_col = 'DataSource'

cob_datetime_format = '%Y-%m-%d'
db_datetime_format = '%Y-%m-%d %H:%M:%S'
override_cob_key = "OverrideCOB"

all_data_sources = "All_Data_Source"



def get_cob_override_date(env, data_source):
    '''
    Checks Dynamo Db if there is custom date(not cob) for a particular Datafeed  opswise jobs are to be run
    :param env:  prod/test
    :param data_source:  Upstream data feed
    :return:  str/None
    '''
    data = {"hash_key": feed_name_col,
            feed_name_col: override_cob_key}

    with DynamoDB(env) as dynamo:
        query_results = dynamo.query(override_table, data)

    row = query_results[0]


    if not query_results or  \
            (row[data_source_col] != all_data_sources and data_source not in row[data_source_col]):
        return None

    time_to_live = datetime.strptime(row[time_to_live_col], db_datetime_format)
    if datetime.now() < time_to_live:
        cob_date_obj = datetime.fromtimestamp(row[override_cob_col])
        return cob_date_obj

    return None



def insert_cob_override_date(env, override_cob_date, data_source=all_data_sources, time_to_live=1):
    '''
    Insert into dynamo a custom date(not cob) for a particular Datafeed opswise jobs are to be run
    :param env:  prod/test
    :param data_source: Upstream data feed
    :param override_cob_date:  date str in format yyyy-mm-dd
    :param time_to_live:   Expiration time  for  override cob in terms number of hours
    '''

    if not override_cob_date:
        raise ValueError("Override COB date is empty")

    if int(time_to_live) < 0:
        raise ValueError("Override expiration date should be zero or  greater")

    current_time = datetime.now()
    time_to_live = current_time + timedelta(hours=int(time_to_live))

    cob_date_obj = datetime.strptime(override_cob_date, cob_datetime_format)
    cob_ts = datetime.timestamp(cob_date_obj)

    with DynamoDB(env) as dynamo:
        data = {feed_name_col: override_cob_key,
                data_source_col: data_source,
                override_cob_col: int(cob_ts),
                time_to_live_col: time_to_live.strftime(db_datetime_format),
                created_at_col: current_time.strftime(db_datetime_format)
                }
        dynamo.upsert(override_table, data)


def main(args):
    parser = argparse.ArgumentParser(description='Cob Override for Specific data feed')
    # Required arguments
    parser.add_argument('-env', help='Environment test/prod ', required=True)
    parser.add_argument('-override_cob', help='Date that is to override COB. Enter date in the format YYYY-MM-DD', required=True)
    parser.add_argument('-data_sources', help=f"One or more data sources with or without sepearators like comma. tab etc. For all data_sources enter {all_data_sources} and also  Defaults to  the same value  {all_data_sources}",
                        default=all_data_sources,  required=False)
    parser.add_argument('-duration', help='Number of hours that the override is to be active. Defaults to 1 hour', default=1, required=False)

    args = parser.parse_args(args)
    # if len(args) < 4:
    #     raise ValueError("Three arguments to required for    env , Overriding COB, Feed Name, COB Date ,  Time to Live")
    insert_cob_override_date(env=args.env, data_source= args.data_sources, override_cob_date= args.override_cob, time_to_live=args.duration)


if __name__ == "__main__":
    main(sys.argv[1:])
