import argparse
import ast
import calendar
import re
import sys
import time
import uuid
from datetime import date, timedelta, datetime
from importlib import import_module

from dateutil.parser import parse

from common.aws import DynamoDB, EMR
from common.utils import call_function

import signal


def calledByJobRunner(function):
    #jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None, parameters=None
    def wrapper(*args,**kwargs):
        #TBD-glp 4/5/20: parameter passing via kwargs should be handled
        if len(args)>0: jobId=args[0]
        else: raise ValueError(f"jobId must be the first parameter passed to {function}")
        if len(args)>1: codeToRun = args[1]
        else: raise ValueError(f"codeToRun must be the second parameter passed to {function}")
        if len(args)>2: targetMachine = args[2]
        else: raise ValueError(f"targetMachine must be the third parameter passed to {function}")
        if len(args)>3 and args[3].lower() in ("prod", "test"): env = args[3]
        else: raise ValueError(f"env must be the fourth parameter passed to {function} and must be either 'test' or 'prod'")
        if len(args)>4: cob = args[4]
        else: raise ValueError(f"cob must be the fifth parameter passed to {function}")
        inputs = args[5] if len(args)>5 else None
        outputs = args[6] if len(args)>6 else None
        alias = args[7] if len(args)>7 else None
        parameters = args[8] if len(args)>8 else None

        print("Calling {0}( env={1}, targetMachine={2}, inputs={3}, outputs={4}, parameters={5} )".format(function, env, targetMachine, str(inputs) if inputs else None, str(outputs) if outputs else None, str(parameters) if parameters else None))
        #assume_role(ENVS[env]['assumerole'])
        #function(jobId, codeToRun, targetMachine, env, cob, inputs, outputs, alias, parameters)
        # TBD-glp 2/21/20: call security.exit_role here
        print(f"Exiting {function}()")
        return function(jobId, codeToRun, targetMachine, env, cob, inputs, outputs, alias, parameters)

    return wrapper

class JobRunner:
    '''Wrapper class for running all jobs'''

    global assumeRoleTimeout
    assumeRoleTimeout = 600

    def __init__(self, codeToRun, targetMachine, inputs=None, outputs=None, alias=None, overrideEnv=None, overrideCOB=None, parameters=None, dryRun=False):
        print("register signal")
        signal.signal(signal.SIGTERM, self.handle_stop_signal)
        def processListOfDicts(list_of_dictionaries):
            result_list = []
            for dictionary in list_of_dictionaries:
                result_list.append(processTokensInDictStr(dictionary))
            return result_list

        def processTokensInDictStr(dictionary):
            temp = result = {}
            temp = ast.literal_eval(dictionary)
            for key, val in temp.items():
                result[key] = self.processSubstitutionVariables(self.env, self.COB, val)
            print("processed tokens result: {}".format(result))
            return result

        self.codeToRun = codeToRun if "{" not in codeToRun else ast.literal_eval(codeToRun)
        self.alias = alias
        self.env = self.getEnv(overrideEnv.lower())
        self.COB = parse(overrideCOB) if overrideCOB else self.getRunDate()
        self.targetMachine = self.processSubstitutionVariables(self.env, self.COB, targetMachine)
        if isinstance(inputs, list):
            self.inputs = processListOfDicts(inputs)
        else:
            self.inputs = processTokensInDictStr(inputs) if inputs else None
        if isinstance(outputs, list):
            self.outputs = processListOfDicts(outputs)
        else:
            self.outputs = processTokensInDictStr(outputs) if outputs else None

        self.jobID = self.gen_jobid()
        self.dryRun = dryRun
        # Convert parameters from a string into a dict
        self.parameters = processTokensInDictStr(parameters) if parameters else {}
        self.log = []

    def handle_stop_signal(self, signum, frame):
        print("sigterm caught:" + str(signum))
        print("job_id is" + self.jobID)
        jobdata = {
            'jobid': self.jobID,
            'hash_key': 'jobid'
        }
        dynamodb = DynamoDB(self.env)
        items = dynamodb.query("OpswiseJobStatus", jobdata)[0]

        job_details = items.get('job_details')
        if job_details:
            cluster_id = job_details.get('cluster_id')
            step_id = job_details.get('step_id')
            EMR.kill(self.env, cluster_id, step_id)
        sys.exit(1)

    def gen_jobid(self):
            jobid = uuid.uuid1()
            return jobid.hex

    def getRunDate(self):
        return date.today()

    def processSubstitutionVariables(self, env, COB, ioString):
        '''Substitutes the correct environment and COB into input and output parameters. Assumes self.env has been set prior to calling this method.
        Parameters:
                env:    The name of the environment to use.
                COB:    The COB date to use
            Returns:
                The input / output filename/path with all variables explicitly defined.
        '''
        def replaceVariable(match):
            def processMiddlePartOfEnvVariable(format):
                if format.lower() == 'lower':
                    return self.env.lower()
                elif format.lower() == 'upper':
                    return self.env.upper()
                elif format.lower() == 'capitalize':
                    return self.env.capitalize()
                else:
                    return self.env

            def processLastPartOfEnvVariable(env,thirdPart):
                logicParts=thirdPart.split(',')
                for mappingPair in logicParts:
                    source, target=mappingPair.split('-')
                    if env.lower() == source.lower():
                        return target

            variable=match.group(0)[1:-1] # strip the surrounding < >
            if variable[:3].lower()=='cob':
                partsOfCOBVariable= variable.split(':')
                if len(partsOfCOBVariable) == 3:
                    command, format, offset = partsOfCOBVariable
                    rundate = COB + timedelta(days=int(offset))
                elif len(partsOfCOBVariable) == 4:
                    command, format, offset, specialDate = partsOfCOBVariable
                    if specialDate.lower() == "monthend":
                        month=COB.month+int(offset)
                        # Ensure the proper year is used if more than available months in the current year are added/subtracted
                        year=COB.year
                        while month < 1:
                            year-=1
                            month+=12
                        while month > 12:
                            year+=1
                            month-=12
                        day=calendar.monthrange(year,month)[1]

                        rundate=date(year,month,day)
                return rundate.strftime(format)
            elif variable[:3].lower()=='env':
                envParts = variable.split(':')
                if len(envParts) == 1:
                    return self.env.upper()
                elif len(envParts) == 2:
                    return processMiddlePartOfEnvVariable(envParts[1])
                elif len(envParts) == 3:
                    return processLastPartOfEnvVariable(processMiddlePartOfEnvVariable(envParts[1]),envParts[2])
                else:
                    raise ValueError("The <env:lower|upper|capitalize:mappings> Variable can only have up to 3 strings separated by :")
        if ioString:
            if isinstance(ioString,list):
                # ioString is actually a list. Replace Variables in every item of the list
                return [re.sub("<(.*?)>",replaceVariable,item) for item in ioString]
            elif isinstance(ioString,str):
                return re.sub("<(.*?)>",replaceVariable,ioString)
            else:
                # ioString is a dict, int, float, etc. which don't need to be processed for Variables
                return ioString
        else:
            return None

    def getlog(self):
        return self.log

    def _log(self, msg):
        self.log.append(msg)

    def getTime(self):
        return datetime.now().strftime('%Y%m%d %H:%M:%S')

    def log_start_dynamodb(self):
        jobdata = {
            'jobid': self.jobID,
            'job_code_to_run':  self.codeToRun,
            'job_start': self.getTime(),
            'job_alias': self.alias.lower(),
            'job_inputs': self.inputs,
            'job_outputs': self.outputs,
            'job_parameters': self.parameters
        }
        nowdate = datetime.now().strftime('%Y%m%d')
        jobdata["jobdate"] = nowdate
        if not self.dryRun:
            with DynamoDB(self.env) as dynamo:
                dynamo.upsert("OpswiseJobStatus", jobdata, True)

    def log_to_dynamodb(self, data_dict):
        res_dict = {}

        jobdata = {
            'jobid':self.jobID,
            'hash_key': 'jobid'
        }
        res_dict.update(jobdata)
        res_dict.update(data_dict)
        if not self.dryRun:
            with DynamoDB(self.env) as dynamo:
                dynamo.upsert("OpswiseJobStatus", res_dict, False)

    def log_end_dynamodb(self, job_status):
        jobdata = {
            'jobid': self.jobID,
            'hash_key': 'jobid',
            'job_end': self.getTime(),
            'job_status': job_status
        }
        if not self.dryRun:
            with DynamoDB(self.env) as dynamo:
                dynamo.upsert("OpswiseJobStatus", jobdata, False)

    def run(self):
        '''Handle specifics of running on an on-premises machine
            Parameters:
                className: The complete path of the python class to run (e.g. ETL). Note that the python class must have
                    a run function which accepts inputs, outputs and kwargs. In the short-term, classnName can be the
                    full path of a python function
                inputs:    Dict where key is the name of the input and value is the location of the input. If S3 is used, the value
                    is a tuple, (S3 bucket, directory in that bucket)
                    outputs:   Dict similar to inputs
            Returns:
                The status (0 if successful) of the job.
        '''

        log("Run function "+self.codeToRun+" on "+self.targetMachine)
        log("Inputs: "+str(self.inputs))
        log("Outputs: "+str(self.outputs))
        log("Parameters: "+str(self.parameters))
        log("Job ID: "+str(self.jobID))
        log("Alias: "+str(self.alias))
        self.start_time = time.time()
        self.log_start_dynamodb()
        jobstatus = "success"

        argv = [self.codeToRun]
        try:
            #Is the request to run the code on EMR?
            if self.codeToRun == 'launch_on_emr':
                if not self.dryRun: self.log_start_dynamodb()
                #self.launch_on_emr()
                log("Running using new EMR class")
                with EMR(self.codeToRun, self.alias, self.env, self.COB, self.targetMachine, self.inputs, self.outputs, self.parameters, self.dryRun, self.jobID) as emr:
                    emr.run()
                    jobdata = {
                        'job_status': emr.get_status(),
                        'job_log': emr.getLogPath()
                    }
                    log(emr.getLog())
                    self.log_to_dynamodb(jobdata)

            elif self.codeToRun.strip().lower().split('.')[-1] in ('salesforce', 'load_share_classes') or self.codeToRun.find('.')!=-1:
                # Invoked by passing salesforce endpoint in the parameters dict
                if not self.dryRun: self.log_start_dynamodb()
                params=[self.jobID, self.codeToRun, self.targetMachine, self.env, self.COB, self.inputs, self.outputs, self.alias, self.parameters]
                if not self.dryRun: call_function(self.codeToRun, params)
            else:
                # Invoked as follows (existing FileManager code): sv_file_manager filename
                argv = [self.codeToRun]
                if not self.dryRun: self.log_start_dynamodb()
                if self.inputs:
                    argv.append(list(self.inputs.values())[0])
                if self.outputs:
                    argv.append(list(self.outputs.values())[0])
                import sys
                sys.argv = argv
                log("Running " + str(self.codeToRun))
                if not self.dryRun: import_module(self.codeToRun)
        except Exception as e:
            jobstatus = "failed"
            raise e
        finally:
            self.log_end_dynamodb(jobstatus)

    def getEnv(self, overrideEnv=None):
        if overrideEnv:
            return overrideEnv
        else:
            #TBD-rt 11/24/19: your code to auto-detect the correct env, TEST or PROD, goes here. NOTE: alternatively you can do all of it in the run method
            pass

    def kill(self):
        ''' kill job running on local machine - deferred till dec'''
        pass

def log(string):
    print(string)

def main(args):
    parser = argparse.ArgumentParser(description='Job System')
    # Required arguments
    parser.add_argument('-codeToRun', help='The function which will be run to execute the job', required=True)
    parser.add_argument('-targetMachine', help="The name of the machine or EMR cluster on which the job is run", required=True)
    # Optional arguments
    parser.add_argument('-inputs', help='List of files or database tables required by the job')
    parser.add_argument('-outputs', help='List of files or database tables updated/produced by the job')
    parser.add_argument('-alias', help="Human-readable name for the job. Otherwise, codeToRun is used")
    parser.add_argument('-aws', help="Specified if the targetMachine is on AWS", action='store_true')
    parser.add_argument('-overrideEnv', help="Specify to hardcode running the job in a specific environment, TEST or PROD")
    parser.add_argument('-overrideCOB', help="Specify to use this COB rather than generating it based on today's date")
    parser.add_argument('-parameters', help="Parameters which are passed to the job executed by codeToRun")
    parser.add_argument('-dryRun', help="If this option is used, the job won't actually run but will simulate the invocation", action='store_true')

    args = parser.parse_args(args)
    log("Running Job Runner with the following args" + str(args))
    jr = JobRunner(args.codeToRun, args.targetMachine, args.inputs, args.outputs, args.alias, args.overrideEnv, args.overrideCOB, args.parameters, args.dryRun)
    log("Running Jobrunner")
    jr.run()
    return jr

if __name__ == "__main__":
    main(sys.argv[1:])
