import csv
import datetime
import gzip
import json
import os
import re
import shutil
from time import sleep

import boto3
import requests
from jobsystem.FeedAPI import FeedAPI
from jobsystem.job_runner import calledByJobRunner

from common.aws import EMR
from common.aws import S3
from common.database import db_connection_factory
from common.enums import JobStatus, JobStatusLabels
from common.envconfig import ENVS
from common.ftp import SFTP
from common.log import logger
from common.security import get_secret
from common.utils import call_function
from common.utils import is_s3_file_present


class AlreadyProcessException(Exception):
    pass

def get_record_count_in_file(file_path, include_header=False, gzipped=False):
    record_count = 0
    if gzipped:
        with gzip.open(file_path) as file:
            for i, l in enumerate(file):
                pass
            record_count = i
    else:
        with open(file_path) as file:
            for i, line in enumerate(file):
                pass
            record_count = i

    if include_header:
        return record_count + 1
    return record_count

def amg_file_manager_opswise_wrapper(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
                       parameters=None, dryRun=None):
    print('amg_file_manager_wrapper')
    print('parameters: {}'.format(parameters))
    call_function('edm-fm.amg_file_manager_opswise', parameters)

    todays_date = f"{datetime.datetime.now():%m-%d-%Y}"
    file_name = "/home/edmfilemgr/edm-fm/amg/amg_data_" + todays_date + ".csv.gz"
    record_count = get_record_count_in_file(file_name, include_header=False, gzipped=True)
    return_object = {
        JobStatusLabels.COB.value: todays_date, JobStatusLabels.CONTENTS.value: {
        JobStatusLabels.LOADED.value: {'Entities': record_count, 'Agreements': record_count},
        JobStatusLabels.FILTERED.value: 0,
        JobStatusLabels.ERRORED.value: 0}
    }
    return return_object

def ldw_flows_batch_opswise_wrapper(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
                       parameters=None, dryRun=None):
    print('ldw_flows_batch_opswise_wrapper')
    print('parameters: {}'.format(parameters))

    parameters['start-date'] = ldw_start_date = inputs.get('start-date')
    parameters['end-date'] = ldw_end_date = outputs.get('end-date')
    call_function('edm-fm.ldw_flows_batch_opswise', parameters)

    file_name = '/home/edmfilemgr/edm-fm/ldw/' + 'ldw_flows_batch_data_' + 'range-'+ldw_start_date.replace('/','-')+'-'+ldw_end_date.replace('/','-')+'.csv.gz'
    record_count = get_record_count_in_file(file_name, include_header=False, gzipped=True)
    todaysdate = f"{datetime.datetime.now():%m-%d-%Y}"
    return_object = {
        'cob': todaysdate, 'contents': {
        'LoadedRecordCount': {'Entities': record_count, 'Agreements': record_count},
        'FilteredRecordCount': 0,
        'ErroredRecordCount': 0}
    }
    return return_object

def ldw_batch_file_manager_opswise_wrapper(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
                       parameters=None, dryRun=None):
    print('ldw_batch_file_manager_opswise_wrapper')
    print('parameters: {}'.format(parameters))
    parameters['start-date'] = ldw_start_date = inputs.get('start-date')
    parameters['end-date'] = ldw_end_date = outputs.get('end-date')
    call_function('edm-fm.ldw_batch_file_manager_opswise', parameters)

    file_name = '/home/edmfilemgr/edm-fm/ldw/ldw_batch_aum_' + 'range-' + ldw_start_date.replace('/', '-') + '-' + ldw_end_date.replace('/', '-') + '.csv.gz'
    record_count = get_record_count_in_file(file_name, include_header=False, gzipped=True)
    todaysdate = f"{datetime.datetime.now():%m-%d-%Y}"
    return_object = {
        'cob': todaysdate, 'contents': {
        'LoadedRecordCount': {'Entities': record_count, 'Agreements': record_count},
        'FilteredRecordCount': 0,
        'ErroredRecordCount': 0}
    }
    return return_object

def calledByGetFromSFTPAndSendToS3(function):
    def wrapper(input, output, cob, stripHeader, stripFooter, srcColSeparator, targetColSeparator=None, newHeader=None,
                file_offset=0, add_quotes_to_data=False, column_types=None, primary_key=None):
        if not os.path.isfile(input): raise ValueError(f"{input} file does not exist.")
        targetDir = output[:output.rindex('/')]
        if not os.path.isdir(targetDir): os.mkdir(targetDir)
        return function(input, output, cob, stripHeader, stripFooter, srcColSeparator, targetColSeparator, newHeader,
                        file_offset, add_quotes_to_data, column_types, primary_key)
    return wrapper

job_stats_metrics_list = [JobStatusLabels.LOADED.value, JobStatusLabels.FILTERED.value, JobStatusLabels.ERRORED.value]


def etl_processed_data(table_list, env, parameters):
    stats_map = {}
    for table in table_list:
        query = 'select count(*) from ' + parameters['prefix'] + '_' + table
        connection = db_connection_factory(env, "RDS")
        with connection as cursor:
            cursor.execute(query)
            count = int(cursor.fetchone()[0])
            stats_map[table] = {job_stats_metrics_list[0]: count, job_stats_metrics_list[1]: 0,
                                job_stats_metrics_list[2]: 0}
    return stats_map


def getFromSFTPAndSendToS3(env, input, output, dataSource, cob, failIfNoFile=True, saveCopy=True, rollback=False, processFileFunctionTuple=None,  unzipInput=True, zipOutput=True):
    '''Get one file from an SFTP server and save it on S3.
    Parameters:
        env:                        The name of the environment (e.g. TEST or PROD)
        input:                      Full remote path of the file including the filename on the SFTP server.
        output:                     Full path of the file including the filename in S3
        dataSource:                 The name of the (typically upstream) source from which data is retrieved (e.g. DataSource=SalesVision)
        cob:                        The date of the data contained in the file. The filename typically contains the COB.
        failIfNoFile:               If true, throw an exception if there's no file on the FTP server.
        saveCopy:                   If true, saves a copy of the file under $DATA_HOME/sent and $DATA_HOME/received
        rollback:                   If true, in case of an error puts the file back on the SFTP server. Needed primarily for the SalesVision SFTP server which removes files after a get command is sent
        processFileFunctionTuple:   If a file requires any transformation such as zipping, truncating the header, etc., a fully qualified name of the function and a dict containing its parameters are passed in a tuple.
                                    e.g. (jobsystem.feed_functions.transformFile, {...})
        Returns:                    If a function was passed in to process the file, returns whatever that function returns, otherwise does not return anything
    '''
    """Expected directory structure:
    /home/edmfilemgr/data
                        /received       #The first loop copies code here and calls codeToModifyInputs functions to transform the files and put them under the sent dir
                            /SalesVision
                                /Firm
                                    sv-firm-03-24-20.csv
                                /Person
                                /Office
                                /Trade
                                /PersHier
                            /AMG
                            /Fishtank
                        /sent 
                            /SalesVision
                                    sv-firm-03-24-20.csv
                            /AMG
                            /Fishtank
    """

    def getRemoteFilenameForWildcard(filename, remoteDir):
        listOfRemoteFiles = sftp.list_files(remoteDir)
        print(f"REMOTE_FILES={listOfRemoteFiles}")
        if listOfRemoteFiles:
            filenameAsRegExp = filename.replace("*", "(.*?)")
            compiledRegExp = re.compile(filenameAsRegExp)
            matchingRemoteFileList = []
            for remoteFile in listOfRemoteFiles:
                if compiledRegExp.match(remoteFile):
                    matchingRemoteFileList.append(remoteFile)
            if len(matchingRemoteFileList) > 1:
                raise ValueError(f"Multiple files - {matchingRemoteFileList.join(', ')} - matching {filename} were found.")
        if matchingRemoteFileList:
            return matchingRemoteFileList[0]
        else:
            raise ValueError(f"No file was found on the remote server matching {filename}")

    def rollback(remoteDir, remoteFilename):
        rollbackName = (remoteDir + '/' if remoteDir else "") + remoteFilename
        sftp.put_file(f"{receivedDir}/{remoteFilename}", rollbackName)

    if not input: raise ValueError("getDataAndSendToS3() requires the name of at least one file as input.")
    DATA_HOME = os.environ["DATA_HOME"]      # Get the root directory under which all copies of files transferred by this function are stored
    DATA_HOME = DATA_HOME[DATA_HOME[:-1]] if DATA_HOME[-1] == "/" else DATA_HOME    # Truncate tailing / if it exists
    RECEIVED_HOME = f"{DATA_HOME}/received"
    SENT_HOME = f"{DATA_HOME}/sent"

    sentDir = f"{SENT_HOME}/{dataSource}"
    if not os.path.isdir(sentDir): os.mkdir(sentDir)
    receivedDir = f"{RECEIVED_HOME}/{dataSource}"
    if not os.path.isdir(receivedDir):
        os.mkdir(receivedDir)                   # files received from the data source are stored here
        os.mkdir(f"{receivedDir}/unzipped")     # unzipped files are stored here
    os.chdir(receivedDir)

    # Get files from SFTP and save them under RECEIVED_HOME/data-source
    with SFTP(ENVS[env][dataSource]["server"],
              ENVS[env][dataSource]["user"],
              get_secret(ENVS[env][dataSource]["secret"],env)["pwd"],
              ENVS[env][dataSource]["port"]) as sftp:
        remoteDir = input[:input.rindex('/')] if input.find('/')==0 else None
        filename = input[input.rindex('/')+1:] if input.find('/')==0 else input
        # If the filename contains a wildcard, find out what the filename would evaluate to
        # TBD-glp 4/5/20: os calls should be in the try / except block
        if filename.find("*")!=-1:
            remoteFilename = getRemoteFilenameForWildcard(filename, remoteDir)
            renamedFilename = filename.replace("*","")
        else:
            renamedFilename = None
            remoteFilename = filename
        print(f"GETTING {remoteDir+'/' if remoteDir else ''}{remoteFilename} into {receivedDir}")
        sftp.get_file(f"{remoteDir+'/' if remoteDir else ''}{remoteFilename}", receivedDir)

        try:
            # Read file from DATA_HOME/received/data_source/filename and save it under DATA_HOME/sent/data_source/filename
            if unzipInput:
                shutil.copyfile(f"{receivedDir}/{remoteFilename}", f"{receivedDir}/unzipped/{remoteFilename}")
                if os.system("gzip -f -d " + f"{receivedDir}/unzipped/{remoteFilename}") != 0: raise ValueError(f"Could not unzip {receivedDir}/unzipped/{remoteFilename}")
                source = f"{receivedDir}/unzipped/{remoteFilename[:-3]}"
                target = f"{sentDir}/{renamedFilename[:-3] if renamedFilename else remoteFilename[:-3]}"   #When a zipped file is received, it's unzipped and processed first, so the name shouldn't have a .gz suffix
            else:
                source=f"{receivedDir}/{remoteFilename}"
                target = f"{sentDir}/{renamedFilename if renamedFilename else remoteFilename}"
            if processFileFunctionTuple:
                function, params = processFileFunctionTuple
                params.update(input=source, output=target)
                resultOfProcessing=call_function(function, params)
            else:
                shutil.copyfile(source,target)

            if unzipInput:
                if os.remove(f"{receivedDir}/unzipped/{remoteFilename}") != 0:
                    print(f"unable to remove unzipped file: {receivedDir}/unzipped/{remoteFilename}")

        except Exception as e:
            if rollback: rollback(remoteDir, remoteFilename)
            raise e
    print(f"RESULT = {str(resultOfProcessing)}")
    if zipOutput:
        if os.system("gzip -f -n " + target) != 0: raise ValueError(f"Could not zip {target}")
        target=f"{target}.gz"

    # Send each processed file to S3
    with S3(env) as s3:
        try:
            s3.send_file(f"{target}", f"{ENVS[env]['aws']['s3_bucket']}", output)
        except Exception as e:
            if rollback: rollback(remoteDir, remoteFilename)
            raise e
    if resultOfProcessing: return resultOfProcessing

@calledByJobRunner
def getFromDBAndSendToS3(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None, parameters=None):
    pass

@calledByGetFromSFTPAndSendToS3
def transformFile(input, output, cob, stripHeader, stripFooter, srcColSeparator, targetColSeparator=None, newHeader=None, file_offset=0):
    '''Read a local file specified by input, transform it according to the passed-in parameters and write it to the output.
    Parameters:
        if stripHeader=True is passed in parameters, strip the first line
        if stripFooder=True is passed in parameters, strip the last line
        srcColSeparator must be set to the character used to separate fields in a row
        if tgtColSeparator is passed in, then the file is processed to replace the srcColSeparator with the tgtColSeparator
        If codeToModifyInputs={key: functionName} is passed in parameters, then this function is called with arguments:
            full path and name of file, full path and name of what to name the output file. The full path of the function
            must be passed in. The key must be the same as the key in the inputs since a different function may be used
            to modify each input file. If codeToModifyInputs is not None, it must be a dict with the same keys and
            number of entries as the inputs parameter. If codeToModifyInputs is passed in, then codeToModifyInputsParameters may also be
            passed in optionally; they'll be passed to the function in codeToModifyInputs
    '''
    def processLine(line):
        is_ascii = lambda s: len(s) == len(s.encode())
        if not is_ascii(line):  #TBD-glp 4/26/20: use isascii() after upgrading to python 3.7
            return  None, f"ERROR: Line {line} has at least one non-ASCII character."
        col_list = line.rstrip().split(srcColSeparator)
        if len(col_list) != number_columns:
            #raise ValueError(f"ERROR: Line {count}: {line} has {len(col_list)} columns but the header has {number_columns} columns.")
            return col_list, f"ERROR: Line {count}: {line} has {len(col_list)} columns but the header has {number_columns} columns."
        processed_line = (targetColSeparator if targetColSeparator else srcColSeparator).join(
            [f'"{elem}"' if elem and elem[0] != '"' and not elem.isnumeric() else elem for elem in col_list])  # Put all alphanumeric strings in quotes. Used for FOP and merge files
        # TBD-glp 3/30/20: Ideally we should scan each field for " and ' to escape each quote
        if str(processed_line).__contains__("\""):
            processed_line = str(processed_line).replace("\"", "'")
            print("line contains one or more escaped double quote, it has been replaced by a single quote")
        # TBD-glp 3/30/20: Ideally we should scan each field for " and ' to escape each quote
        output.write(processed_line + '\n')
        return col_list, None

    oldHeader=None
    with open(input,"r") as input:
        with open(output, "w") as output:
            if stripHeader: oldHeader = input.readline()  # TBD-glp 3/30/20: Assert that the cob matches the date in the file

            # Write column header
            if newHeader:
                line = newHeader
            else:   #If column headers don't need to be appended then they're already in the file and don't need to be counted
                line = input.readline()

            output.write(line + '\n')
            number_columns = len(line.split(targetColSeparator))
            count = 0
            errors = []
            line = input.readline()    # Read the first non-column-header (i.e. data) line
            nextLine = input.readline()    #TBD-glp 4/30/20: Assumption that the file has at least 2 lines may not hold
            while nextLine:
                # Start writing column headers since the last line may be a footer
                col_list, error= processLine(line)
                if error: errors.append((count, error))
                line = nextLine
                nextLine = input.readline()
                count += 1
                if oldHeader and (line[:5] == oldHeader[:5] or line[-5:] ==oldHeader[-5:]): raise ValueError(f"The header occurs another time at line {count} of {input}. The file is probably concatenated.")

            if stripFooter:
                col_list=line.split(srcColSeparator)
                if col_list[0] == "T":  # Last line read should be a footer. FOP and Merge files
                    footer_count = int(col_list[1])
                elif col_list[0] == "TR":  # Last line read should be a footer. LQE files
                    footer_count = int(col_list[2])
                else:
                    raise ValueError(f"Malformed file. The last line read should've been a footer but is {srcColSeparator.join(col_list)}")
                if count != (footer_count - file_offset):
                    raise ValueError(f"The file contains {count} rows but the footer claims there are {footer_count} records.")

    if errors:
        print(f"There were {len(errors)} when processing {input}.")
        for i, error in errors: print(f"{i}: {error}")
    print(f"{count - len(errors)} lines were successfully processed.")
    return {"loaded":count - len(errors), "filtered":0, "errors":errors}

##################################################### SalesVision #####################################################
#@calledByJobRunner
# def getSalesVisionFirm(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None, parameters=None):
#     input=list(inputs.values())[0]
#     output=list(outputs.values())[0]
#     header_schema= ['firm_id','firm_name','address_line_1','address_line_2','address_city','address_state','address_zip','address_country','crm_firm_id','event_code','crm_svc_req_id','created_at','created_by','updated_at','updated_by']
#     column_types = {'firm_id':int,
#                     'firm_name':str,
#                     'address_line_1':str,
#                     'address_line_2':str,
#                     'address_city':str,
#                     'address_state':str,
#                     'address_zip':str,
#                     'address_country':str,
#                     'crm_firm_id':str,
#                     'event_code': ['I','U','D'],
#                     'crm_svc_req_id':str,
#                     'created_at':"date:%Y%m%d",
#                     'created_by':str,
#                     'updated_at':"date:%Y%m%d",
#                     'updated_by':str }
#     primary_key_col = "firm_id"
#     transformArgs={"cob":"Not Used Yet",
#                    "stripHeader":True,
#                    "stripFooter":True,
#                    "srcColSeparator":'|',
#                    "targetColSeparator":',',
#                    "newHeader":header_schema,
#                    'file_offset': 2,
#                    "add_quotes_to_data": True,
#                    "column_types":column_types,
#                    "primary_key":[primary_key_col]}
#
#     return getFromSFTPAndSendToS3(env=env, input=input, output=output,  dataSource="SalesVision", cob=cob, failIfNoFile=True, saveCopy=True, rollback=True,
#                                   processFileFunctionTuple=("jobsystem.common_FM.transformFileDataFrame", transformArgs))


##################################################### SalesForce #####################################################
#@calledByJobRunner
def salesforce(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None, parameters=None):
    if not parameters or not "endpoint" in parameters.keys() or not "waitURL" in parameters.keys():
        raise ValueError("A non-blank parameters dict must be specified with one entry for the key, endpoint.")
    secretName = ENVS[env]["cm-interface-to-salesforce"]["secret"]
    BASE_URL = ENVS[env]["cm-interface-to-salesforce"]["url"]
    BASE_URL = BASE_URL[:-1] if BASE_URL[-1]=='/' else BASE_URL      # Truncate trailing / if it exists
    TOKEN = get_secret(secretName,env)["pwd"]
    ENDPOINT = parameters["endpoint"]
    headers = {'Authorization': f"Bearer {TOKEN}", 'Content-Type': 'application/json'}

    # Ensure BASE_URL is suffixed with / prior to concatenating the ENDPOINT
    target_url = f"{BASE_URL}/{ENDPOINT}"
    print(f"TARGETURL: {target_url}")
    resp = requests.get(target_url, headers=headers)
    print(resp)

    # check to see if job actually started
    content = json.loads(resp.content)
    if not content['success']:
        raise ValueError('no files found on CM server, no ingest job started')

    # Poll to block until the request completes
    WAITENDPOINT = parameters["waitURL"]
    target_url =  f"{BASE_URL}/{WAITENDPOINT}"
    resp = requests.get(target_url, headers=headers, verify=False)
    while resp.status_code != 400:
        print('export job still running, sleeping for 5 sec...')
        sleep(5)
        resp = requests.get(target_url, headers=headers, verify=False)

##################################################### ShareClass #####################################################
#@calledByJobRunner
def load_share_classes(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None, parameters=None, dryRun=None):
    colHeader = """SHARE_CLASS_ID,VEHICLE_TYPE_ID,PRODUCT_ID,VEHICLE_TYPE_DESC,PRODUCT_NAME,SHARE_CLASS_NAME,STATUS,CURRENCY_ID,ISIN,CUSIP,TICKER,APIR_CODE,SSALUR,PMF_ID,SUB_STRATEGY_ID,category_id,category_desc
    """
    sql = f"select {colHeader} from amv_mktg_share_class_detailed"
    print(f"SQL Query = {sql}")
    bucket_name = ENVS[env]['aws']['s3_bucket']

    DATA_HOME = os.environ["DATA_HOME"]      # Get the root directory under which all copies of files transferred by this function are stored
    DATA_HOME = DATA_HOME[DATA_HOME[:-1]] if DATA_HOME[-1] == "/" else DATA_HOME    # Truncate tailing / if it exists
    RECEIVED_HOME = f"{DATA_HOME}/received"
    SENT_HOME = f"{DATA_HOME}/sent"
    source = parameters['DataSource']
    file_name =inputs['filenameToSaveQuery']  # we only get file name, no directory
    received_folder = f"{RECEIVED_HOME}/{source}"
    print("received_folder =" + received_folder)
    if not os.path.isdir(received_folder):
        logger.info(f"Create local {received_folder} folder")
        os.mkdir(received_folder)
    send_folder = f"{SENT_HOME}/{source}"
    if not send_folder:
        logger.info(f"Create local {send_folder} folder")
        os.mkdir(send_folder)
    receivedpath = f"{received_folder}/{file_name}"
    print("receivedpath = " + receivedpath)
    sendpath = f"{send_folder}/{file_name}"
    print("sendpath = " + sendpath)
    num_of_lines = 0
    connection = db_connection_factory(env, "AMG")
    with connection as cursor, open(receivedpath, 'w') as outputfile:
        logger.info(sql)
        cursor.execute(sql)
        logger.info("Executed Query to DB")
        outputfile.write(colHeader)
        output = csv.writer(outputfile, lineterminator='\n')
        for row in cursor:
            output.writerow(row)
            num_of_lines += 1

    shutil.copyfile(receivedpath, sendpath)
    os.system(f"gzip -f {sendpath}")
    gz_file_path = sendpath + '.gz'
    print("gz_file_path = " + gz_file_path)
    with S3(env) as s3:
        s3.send_file(gz_file_path, bucket_name, outputs["filenameToSaveQuery"])

    print(f"{str(datetime.datetime.now())} share_class_enum Completed. job_id={jobId}")
    logger.info(f"{str(datetime.datetime.now())} share_class_enum Completed. job_id={jobId}")
    cob = file_name.split('_')[-1].split('.')[0]
    stats = {
        'cob': cob, 'contents': {
        'LoadedRecordCount': {'share_class_enum': num_of_lines},
        'FilteredRecordCount': {'share_class_enum': 0},
        'ErroredRecordCount': {'share_class_enum': 0} }
    }
    print(stats)
    return stats


@calledByJobRunner
def load_share_classes_control_check(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None, parameters=None):
    source_sql = "select count(*) from amv_mktg_share_class_detailed"
    connection = db_connection_factory(env, "AMG")
    with connection as cursor:
        logger.info(source_sql)
        cursor.execute(source_sql)
        row = cursor.fetchone()
        source_count = int(row[0])

    des_sql = "select count(*) from share_class_enum"
    connection = db_connection_factory(env, "RDS")
    with connection as cursor:
        logger.info(des_sql)
        cursor.execute(des_sql)
        row = cursor.fetchone()
        des_count = int(row[0])
    raise_exception = False
    if not source_count and des_count:
        raise_exception = True
    elif source_count and not des_count:
        raise_exception = True
    elif not source_count and not des_count:
        raise_exception = False
    elif source_count != des_count:
        raise_exception = True

    if raise_exception:
        raise ValueError(f'share_class_enum work flow has error:  source_count = {source_count}, des_count = {des_count}')
    else:
        print(f'Control Check is successful, source_count = {source_count}, des_count = {des_count}')


################################################## Trade Code Enum ##################################################
def load_trade_code_enum(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
                         parameters=None, dryRun=None):
    """
    Opswise task to load static reference data from s3 and post-ETL trade code file to create Trade Code Enum.
    :param jobId:
    :param codeToRun:
    :param targetMachine:
    :param env:
    :param cob:
    :param inputs:
    :param outputs:
    :param alias:
    :param parameters:
    :param dryRun:
    :return:
    """
    # capture all files to run through
    enum_files = parameters['files_to_load']
    s3_path = parameters['s3_path']

    # create DL path for files
    download_file_path = os.getcwd() + '/' + s3_path.split('/')[-1]
    if not os.path.exists(download_file_path):
        os.makedirs(download_file_path)

    # for each file in params dict: download to local memory, upload to DB in it's own table
    connection = db_connection_factory(env, "RDS")
    with connection as db:
        with S3(env) as s3:
            for file in enum_files:
                # define fully qualified enum file paths
                local_enum_file = '{}/{}'.format(download_file_path, file)
                s3_enum_file = '{}/{}'.format(s3_path, file)

                # get file from s3 and load to DB
                s3.get_file(local_enum_file, ENVS[env]['aws']['s3_bucket'], s3_enum_file)
                load_enum_data_from_file_to_db(local_enum_file, file.split('.')[0], env)
                print('loaded {} from s3 into cm db'.format(file))

        # create `sv_trade_code_enum` (transcode & direction)
        print('executing sv trade code direction creation...')
        SV_TRADE_CODE_MAPPING = """
            drop table if exists "sv_trade_code_enum";

            create table sv_trade_code_enum
            as
                select
                    tc.trc_id as aggregator_trade_code, tc.trc_trans_code_override,
                    tc.trc_trans_override_desc as trade_desc, flow_type, direction
                from sv_tradecode_salesvision_trade_code_enum tc
                left join sv_trans_code_to_flow df on tc.trc_trans_code_override = df.trans_code;
        """
        db.execute(SV_TRADE_CODE_MAPPING)

        # load master Trade Code table
        print('building final Trade Code ENUM')
        TRADE_CODE_ENUM_MASTER = """
        drop table if exists "trade_code_enum";

        create table trade_code_enum
        as
            SELECT
                sv.aggregator_trade_code::varchar, sv.trade_desc, sv.flow_type, direction,
                (SELECT aggregator_id FROM aggregator where aggregator_name = 'SalesVision')::varchar as aggregator_id
            FROM sv_trade_code_enum sv
            UNION
            SELECT
                ldw.aggregator_trade_code, ldw.trade_desc, ldw.flow_type, '1' as direction,
                (SELECT aggregator_id FROM aggregator where aggregator_name = 'LDW')::varchar as aggregator_id
            FROM ldw_trade_code_enum ldw
            UNION
            SELECT
                ai.aggregator_trade_code, ai.trade_desc, ai.flow_type, '1' as direction,
                (SELECT aggregator_id FROM aggregator where aggregator_name = 'Alternative Investments')::varchar as aggregator_id
            FROM ai_trade_code_enum ai
            UNION
            SELECT
                ft.aggregator_trade_code, ft.trade_desc, ft.flow_type, '1' as direction,
                (SELECT aggregator_id FROM aggregator where aggregator_name = 'FishTank')::varchar as aggregator_id
            FROM ft_trade_code_enum ft
            UNION
            SELECT
                rs.aggregator_trade_code::varchar, rs.trade_desc, rs.flow_type, '1' as direction,
                (SELECT aggregator_id FROM aggregator where aggregator_name = 'RegiStreet')::varchar as aggregator_id
            FROM registreet_active_trade_code_enum rs;
        """
        db.execute(TRADE_CODE_ENUM_MASTER)

    # error check: if there are results in the trade code table, return a success; else failure
    connection = db_connection_factory(env, "RDS")
    with connection as db:
        db.execute("select count(*) from trade_code_enum")
        total = db.fetchone()
        total = total[0]
        is_successful = 'success' if total != 0 else 'failed'

        return {
            JobStatusLabels.COB.value: cob,
            JobStatusLabels.JOB_STATUS.value: is_successful,
            JobStatusLabels.CONTENTS.value: {
                    JobStatusLabels.LOADED.value: total,
                    JobStatusLabels.FILTERED.value: 0,
                    JobStatusLabels.ERRORED.value: 0
            }
        }


def load_enum_data_from_file_to_db(file_name, table_name, env):
    """
    Drop previous table, reload from file
    :param file_name:
    :param table_name:
    :return:
    """
    with open(file_name, 'r') as f:
       connection = db_connection_factory(env, "RDS")
       with connection as cursor:
            # drop previous table
            sql = 'drop table if exists "{}" cascade'.format(table_name)
            print(sql)
            cursor.execute(sql)

            # create table using header
            header = next(f).strip().split(',')
            sql = 'create table {} ('.format(table_name)
            for col in header:
                sql = sql + '{} varchar,'.format(col)
            sql = sql + ');'
            sql = sql.replace(',);', ');')
            print(sql)
            cursor.execute(sql)

            # load data from ENUM file
            cursor.copy_from(f, table_name, sep=',')


##################################################### Stg Switcher #####################################################
@calledByJobRunner
def update_stg_switch_by_param(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None, parameters=None):
    """
    Using SQL function, update STG switch required for MDM
    :param stg_tgt:
    :return:
    """
    # retrieve CM secret
    cm_info = get_secret(ENVS[env]['RDS']['secret'], env)

    STG_SQL_FUNCTION = f"""
        CREATE OR REPLACE FUNCTION update_stg_switch(stg_switch text, out stg_switch text) 
        RETURNS text AS 
        $$
            update edm_params
            set value1 = stg_switch
            where key = 'active_mdm_stage';
            
            select value1 from edm_params where key = 'active_mdm_stage';
        $$ LANGUAGE SQL;
    """

    # connect to CM and execute update
    connection = db_connection_factory(env, "RDS")
    with connection as cursor:
        logger.info('refreshing sql function to update stg switch: {}'.format(STG_SQL_FUNCTION))
        cursor.execute(STG_SQL_FUNCTION)

        update_sql = 'select update_stg_switch(\'{}\');'.format(parameters['stg_switch'])
        logger.info('updating stg switch based on input from job runner: {}'.format(update_sql))
        cursor.execute(update_sql)


@calledByJobRunner
def perform_control_check_amg(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None, parameters=None):
    import gzip
    import os.path
    mismatch = False
    fm_jobs =  {'amg':'amc_edmcm_AMG_input_batch_FileManager','ldw_batch':'amc_edmcm_AMG_input_LDW_AUM_batch_FileManager','ldw_flows':'amc_edmcm_AMG_input_LDW_Flows_batch_FileManager'}
    etl_jobs = {'amg': 'amc_edmcm_AMG_ETL','ldw_batch':'amc_edmcm_AMG_input_LDW_AUM_batch_ETL','ldw_flows':'amc_edmcm_AMG_input_LDW_Flows_batch_ETL'}
    for key in inputs:
       if not  os.path.isfile(inputs[key]):
            raise ValueError(f"The file {inputs[key]} does not exist. AMG control failed")
       with gzip.open(inputs[key], 'rb') as f:
           for file_line_count, l in enumerate(f):
              pass
       connection = db_connection_factory(env, "RDS")
       with connection as cursor:
          cursor.execute(parameters[key])
          dbcount = int(cursor.fetchone()[0])
       if file_line_count != dbcount:
          print("MISTMATCH: {0} loaded by ({1}) contain {2} lines and dbcount contains {3} loaded by ({4})".format(inputs[key], file_line_count, fm_jobs[key] , dbcount, etl_jobs[key]))
          mismatch = True
       else:
          print("MATCH: {1} contain {0} lines and dbcount contains {2}".format(file_line_count, inputs[key], dbcount))
       if mismatch:
           raise ValueError(f"ERROR CONTROL-CHECK: Mismatch on one or more file/DB counts")

@calledByJobRunner
def sv_generator_fop(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None, parameters=None):
    """
    Generate SalesVision FOP exporting files, back up in AWS, then sftp to sftp server
    :param env: test or prod
    :return:
    """
    DATA_HOME = os.environ["DATA_HOME"]      # Get the root directory under which all copies of files transferred by this function are stored
    DATA_HOME = DATA_HOME[DATA_HOME[:-1]] if DATA_HOME[-1] == "/" else DATA_HOME    # Truncate tailing / if it exists
    RECEIVED_HOME = f"{DATA_HOME}/received"
    SENT_HOME = f"{DATA_HOME}/sent"
    source = parameters['DataSource']
    received_folder = f"{RECEIVED_HOME}/{source}"
    print("received_folder =" + received_folder)
    if not os.path.isdir(received_folder):
        logger.info(f"Create local {received_folder} folder")
        os.mkdir(received_folder)
    send_folder = f"{SENT_HOME}/{source}"
    if not os.path.isdir(send_folder):
        logger.info(f"Create local {send_folder} folder")
        os.mkdir(send_folder)

    sftp_secret = ENVS[env]['SalesVision']['secret']
    sftp_password_dic = get_secret(sftp_secret, env)
    sftp_password = sftp_password_dic['pwd']

    todaysdate = datetime.datetime.today().strftime('%m_%d_%Y')
    colHeader = "H|{dt}|{dt}\n".format(dt=todaysdate)
    substring = datetime.datetime.today().strftime('profile_%m_%d_%Y')
    sv_today_files = []
    with SFTP(ENVS[env]['SalesVision']['server'],
              ENVS[env]['SalesVision']['user'],
              sftp_password,
              int(ENVS[env]['SalesVision']['port'])) as sftp:
        file_list = sftp.list_files('/'+ENVS[env]['SalesVision']['root-dir'])
        for file_name in file_list:
            if file_name.find(substring) != -1:
                sv_today_files.append(file_name)
    try:
        sql_fir = "select * from sv_export_fir"
        entity_fir = "firm"
        sv_generator_fop_helper(env, inputs, outputs, sql_fir, entity_fir, sftp_password, colHeader, received_folder, send_folder, sv_today_files)
    except AlreadyProcessException as ape:
        print(f'{ape}')
    except Exception:
        raise

    try:
        sql_ofl = "select * from sv_export_ofl"
        entity_ofl = "office"
        sv_generator_fop_helper(env, inputs, outputs, sql_ofl, entity_ofl, sftp_password, colHeader, received_folder, send_folder, sv_today_files)
    except AlreadyProcessException as ape:
        print(f'{ape}')
    except Exception:
        raise

    try:
        sql_per = "select * from sv_export_per"
        entity_per = "person"
        sv_generator_fop_helper(env, inputs, outputs, sql_per, entity_per, sftp_password, colHeader, received_folder, send_folder, sv_today_files)
    except AlreadyProcessException as ape:
        print(f'{ape}')
    except Exception:
        raise

    try:
        sql_mrg = "select * from sv_export_mrg"
        entity_mrg = "merge"
        sv_generator_fop_helper(env, inputs, outputs, sql_mrg, entity_mrg, sftp_password, colHeader, received_folder, send_folder, sv_today_files)
    except AlreadyProcessException as ape:
        print(f'{ape}')
    except Exception:
        raise

    connection = db_connection_factory(env, "RDS")
    with connection as cursor:
        cursor.execute("select value1 as stg_prefix from edm_params where key = 'active_mdm_stage'")
        prefix = cursor.fetchone()[0]
        todaydate = datetime.datetime.today().strftime('%Y-%m-%d') + ' 00:00:00'
        sql = f"""
        INSERT INTO edm_export_params (mdm_stage, send_to_sv_date, send_to_sf_date) 
        VALUES('{prefix}', '{todaydate}', null)
        ON CONFLICT (mdm_stage)
        DO
            UPDATE SET send_to_sv_date = '{todaydate}';
        """
        cursor.execute(sql)

    print(f"{str(datetime.datetime.now())} sv_generator_fop Completed. job_id={jobId}")
    logger.info(f"{str(datetime.datetime.now())} sv_generator_fop Completed. job_id={jobId}")

    return {
        JobStatusLabels.COB.value: cob,
        JobStatusLabels.JOB_STATUS.value: 'success',
        JobStatusLabels.CONTENTS.value: {
                JobStatusLabels.LOADED.value: 0,
                JobStatusLabels.FILTERED.value: 0,
                JobStatusLabels.ERRORED.value: 0
	    }
    }

def sv_generator_fop_helper(env, inputs, outputs, sql, entity, sftp_password, colHeader, received_folder, send_folder, sv_today_files):
    entity_file_name = inputs[entity]
    root_folder = '/'+ENVS[env]['SalesVision']['root-dir']
    entity_gz_name = entity_file_name + '.gz'
    if entity_gz_name in sv_today_files:
        message = entity_gz_name + ' has been generated and upload to SV SFTP server.'
        raise AlreadyProcessException(message)

    receivedpath = f"{received_folder}/{entity_file_name}"
    print("receivedpath = " + receivedpath)
    sendpath = f"{send_folder}/{entity_file_name}"
    print("sendpath = " + sendpath)

    connection = db_connection_factory(env, "RDS")
    with connection as cursor, open(receivedpath, 'w') as outputfile:
        logger.info(sql)
        cursor.execute(sql)
        logger.info("Executed Query to DB")
        outputfile.write(colHeader)
        output = csv.writer(outputfile, lineterminator='\n', delimiter='|', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        records = cursor.fetchall()
        for row in records:
            output.writerow(row)
        outputfile.write("T|" + str(cursor.rowcount))

    shutil.copyfile(receivedpath, sendpath)
    os.system(f"gzip -f {sendpath}")
    gz_file_path = sendpath + '.gz'
    print("gz_file_path = " + gz_file_path)

    with S3(env) as s3:
        s3.send_file(gz_file_path, ENVS[env]['aws']['s3_bucket'], outputs[entity])

    with SFTP(ENVS[env]['SalesVision']['server'],
              ENVS[env]['SalesVision']['user'],
              sftp_password,
              int(ENVS[env]['SalesVision']['port'])) as sftp:
        filepath, fn = os.path.split(gz_file_path)
        if env == 'test':
            fn = 'TEST_' + fn
            print(f'filepath = {filepath}, filename={fn}')
        sftp.put_file(gz_file_path, fn, root_folder)


##################################################Fish Tank#############################################################
#job_stats_metrics_list = ['LoadedRecordCount', 'FilteredRecordCount', 'ErrorRecordCount']


# def ftp_files_from_fish_tank(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
#                              parameters=None, dryRun=None):
#     argv = ["edm-fm.sftp_file_manager"]
#     num_lines_of_header = 1
#     num_lines_of_footer = 0
#     tables_list = ["AUM", "Agreement", "Trade"]
#     input_file_name = list(inputs.values())[0]
#
#     if inputs:
#         argv.append(input_file_name)
#     if outputs:
#         argv.append(list(outputs.values())[0])
#
#     import sys
#     sys.argv = argv
#     from importlib import import_module
#     import_module(argv[0])
#
#     count = 0
#     dir, file = os.path.split(input_file_name)
#     print("file->", file)
#     downloaded_file_path = os.path.dirname(__file__) + '/../edm-fm/bak/' + file
#     print('Downloaded fishtank file path', downloaded_file_path)
#     with open(downloaded_file_path, "r") as file:
#         count = sum(1 for line in file) - num_lines_of_header - num_lines_of_footer
#     # cob = input_file_name.split('/')[-1].split('.')[0].split('_')[1]
#     table_stats = {}
#     for table in tables_list:
#         table_stats[table] = {job_stats_metrics_list[0]: count, job_stats_metrics_list[1]: 0,
#                               job_stats_metrics_list[2]: 0}
#
#     return_stats = {}
#     build_stats_for_fishtank(return_stats, cob, table_stats)
#
#     return return_stats


# def etl_fish_tank_data(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
#                        parameters=None, dryRun=None):
#     with EMR(codeToRun, alias, env, cob, targetMachine, inputs, outputs, parameters, dryRun, jobId) as emr:
#         emr.run()
#         emr_return_dict = {
#             'job_status': emr.get_status(),
#             'job_log': emr.getLogPath(),
#             'cob': cob
#         }
#         print(emr.getLog())
#         emr.log_to_dynamodb(emr_return_dict)
#
#     if emr_return_dict['job_status'] == 'FAILED':
#         emr_return_dict['cob'] = cob
#         return emr_return_dict
#
#     table_list = ['entity', 'aum', 'agreement', 'trade']
#
#     def etl_processed_data(table_list):
#         stats_map = {}
#
#         for table in table_list:
#             query = 'select count(*) from ' + parameters['prefix'] + '_' + table
#             with PostgreSQL(env, "RDS") as cursor:
#                 cursor.execute(query)
#                 count = int(cursor.fetchone()[0])
#                 stats_map[table] = {job_stats_metrics_list[0]: count, job_stats_metrics_list[1]: 0,
#                                     job_stats_metrics_list[2]: 0}
#
#         return stats_map
#
#     table_stats = etl_processed_data(table_list)
#     build_stats_for_fishtank(emr_return_dict, cob, table_stats)
#     return emr_return_dict


# def mdm_fish_tank_data(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
#                        parameters=None, dryRun=None):
#     with EMR(codeToRun, alias, env, cob, targetMachine, inputs, outputs, parameters, dryRun, jobId) as emr:
#         emr.run()
#         emr_return_dict = {
#             'job_status': emr.get_status(),
#             'job_log': emr.getLogPath(),
#             'cob': cob
#         }
#         print(emr.getLog())
#         emr.log_to_dynamodb(emr_return_dict)
#
#     if emr_return_dict['job_status'] == 'FAILED':
#         emr_return_dict['cob'] = cob
#         return emr_return_dict
#
#     table_list = ['entity', 'aum', 'agreement', 'trade']
#     with PostgreSQL(env, "RDS") as cursor:
#         cursor.execute("select value1 as stg_prefix from edm_params where key = 'active_mdm_stage'")
#         table_prefix = cursor.fetchone()[0]
#
#     def mdm_processed_data(tables_list):
#         stats_map = {}
#
#         for table in table_list:
#             loaded_data_query = 'select count(*) from stg_' + table_prefix + '_' + table
#             errored_data_query = 'select count(*) from stg_' + table_prefix + '_' + table + '_resolution'
#             with PostgreSQL(env, "RDS") as cursor:
#                 cursor.execute(loaded_data_query)
#                 loaded_count = int(cursor.fetchone()[0])
#                 cursor.execute(errored_data_query)
#                 errored_data_query = int(cursor.fetchone()[0])
#
#                 stats_map[table] = {job_stats_metrics_list[0]: loaded_count, job_stats_metrics_list[1]: 0,
#                                     job_stats_metrics_list[2]: errored_data_query}
#
#         return stats_map
#
#     table_stats = mdm_processed_data(table_list)
#     build_stats_for_fishtank(emr_return_dict, cob, table_stats)
#     return emr_return_dict


# def build_stats_for_fishtank(job_stats, cob, table_stats):
#     '''
#     Builds a d
#     :param job_stats:
#     :param cob:
#     :param table_stats:
#     :return:
#     '''
#     loaded_stats = {}
#     errored_stats = {}
#     filtered_stats = {}
#
#     for table_name, stats_dict in table_stats.items():
#         loaded_stats[table_name] = stats_dict[job_stats_metrics_list[0]]
#         filtered_stats[table_name] = stats_dict[job_stats_metrics_list[1]]
#         errored_stats[table_name] = stats_dict[job_stats_metrics_list[2]]
#
#     stats_by_breakdown = {job_stats_metrics_list[0]: loaded_stats, job_stats_metrics_list[1]: filtered_stats,
#                           job_stats_metrics_list[2]: errored_stats}
#     job_stats['cob'] = cob
#     job_stats['contents'] = stats_by_breakdown
#     print(job_stats)


#########################Generic FM    #######################################################################
def ftp_files_and_generate_stats(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
                                 parameters=None, dryRun=None):
    argv = ["edm-fm.sftp_file_manager"]
    num_lines_of_header = parameters.get('no_of_header_lines', 0)
    num_lines_of_footer = parameters.get('no_of_footer_lines', 0)
    tables_list = parameters.get('tables_list')

    input_file_name = list(inputs.values())[0]

    if inputs:
        argv.append(input_file_name)
    if outputs:
        argv.append(list(outputs.values())[0])

    import sys
    sys.argv = argv
    from importlib import import_module
    try:
        import_module(argv[0])
    except :
        return {JobStatusLabels.COB.value: cob, JobStatusLabels.JOB_STATUS.value: JobStatus.FAILED.value}

    return build_stats_for_ftp_job(input_file_name, tables_list, cob, num_lines_of_header,
                                   num_lines_of_footer)

def sv_ftp_file_to_s3_and_generate_stats(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
                                 parameters=None, dryRun=None):
    tables_list = parameters.get('tables_list')
    data_source = parameters.get('DataSource').lower()

    if 'firm' in data_source:
        results_stats = getSalesVisionFirm(jobId, codeToRun, targetMachine, env, cob, inputs, outputs, alias, parameters)
    elif 'office' in data_source:
        results_stats = getSalesVisionOffice(jobId, codeToRun, targetMachine, env, cob, inputs, outputs, alias, parameters)
    elif 'person' in data_source  and not  'salesperson' in data_source:
        results_stats = getSalesVisionPerson(jobId, codeToRun, targetMachine, env, cob, inputs, outputs, alias, parameters)
    elif 'merge' in data_source:
        results_stats = getSalesVisionMerge(jobId, codeToRun, targetMachine, env, cob, inputs, outputs, alias, parameters)
    else :
         results_stats = getSalesVisionLQE(jobId, codeToRun, targetMachine, env, cob, inputs, outputs, alias, parameters)

    stats_dict = build_contents_of_job_stats(results_stats["loaded"], tables_list)
    return {JobStatusLabels.COB.value: cob, JobStatusLabels.CONTENTS.value: stats_dict}




def build_stats_for_ftp_job(file_name, tables_list, cob, num_of_header_lines=0, num_of_footer_lines=0):
    count = 0
    dir, file = os.path.split(file_name)
    print("file->", file)
    downloaded_file_path = os.path.dirname(__file__) + '/../edm-fm/bak/' + file
    print('Downloaded file path', downloaded_file_path)

    with open(downloaded_file_path, "r") as file:
        print('Header lines, Footer lines:', num_of_header_lines, num_of_footer_lines)
        count = sum(1 for line in file) - num_of_header_lines - num_of_footer_lines

    stats_dict = build_contents_of_job_stats(count, tables_list)

    jobs_stats = {JobStatusLabels.COB.value: cob, JobStatusLabels.CONTENTS.value: stats_dict, JobStatusLabels.JOB_STATUS.value: JobStatus.SUCCESS.value}

    return jobs_stats

def  build_contents_of_job_stats(count, tables_list):
    stats_dict = {}

    for label in job_stats_metrics_list:
        stats_dict[label] = {}
        for table in tables_list:
            if label == job_stats_metrics_list[0]:
                stats_dict[label][table] = count
            else:
                stats_dict[label][table] = 0

    return stats_dict


def build_stats_for_S3_files(env,s3_file_path,tables,cob,num_lines_of_header=0,num_lines_of_footer=0):
    table_stats = {JobStatusLabels.LOADED.value: {},
                   JobStatusLabels.FILTERED.value: {},
                   JobStatusLabels.ERRORED.value: {}
                    }
    jobs_stats = {JobStatusLabels.COB.value: cob, JobStatusLabels.CONTENTS.value: table_stats, JobStatusLabels.JOB_STATUS.value: JobStatus.SUCCESS.value}

    print('Calling S3 files name : ', ENVS[env]['aws']['s3_bucket'] + s3_file_path)


    if not is_s3_file_present(ENVS[env]['aws']['s3_bucket'] + s3_file_path):
        num_of_lines = 0
    else:
         # Download file to tmp , run counts and then delete it
        # create temp dir if does not exists
        if not os.path.exists(os.getcwd() + os.path.sep + "tmp"):
            os.mkdir('tmp')
        os.chdir('tmp')

        download_file_path = os.getcwd() + os.pathsep + s3_file_path.split('/')[-1]

        with S3(env) as s3:
            s3.get_file(download_file_path, ENVS[env]['aws']['s3_bucket'], s3_file_path)

        with open(download_file_path, "r") as file:
            num_of_lines = sum(1 for line in file) #- num_lines_of_header - num_lines_of_footer

        os.remove(download_file_path)


    for table in tables:
        table_stats[JobStatusLabels.LOADED.value][table] = num_of_lines
        table_stats[JobStatusLabels.FILTERED.value][table] = 0
        table_stats[JobStatusLabels.ERRORED.value][table] = 0

    return jobs_stats






######  File Manager  #############################################
def upload_and_generate_stats_salesforce_files(jobId, codeToRun, targetMachine, env, cob=None, inputs=None,
                                               outputs=None,
                                               alias=None, parameters=None, dryRun=None):
    '''
    Steps involved in uploading and running stats
        1) run the saleforce job to load data into S3
        2) check if  file exists for the cob on S3
                i) if no file then returns stats with count as zero
        3) Download the file , count the number of lines minus Header,Footer and generate stats


    :return: Dictionary  with job id, cob and stats for all data elements
    '''
    num_lines_of_header = 0
    num_lines_of_footer = 0
    salesforce(jobId, codeToRun, targetMachine, env, cob, inputs, outputs, alias, parameters)

    run_date = parameters['endpoint'].split('/')[-1]
    s3_file_path = parameters['s3_file_path'].format(run_date=run_date)

    from common.utils import is_s3_file_present
    print('Calling S3 files name : ', ENVS[env]['aws']['s3_bucket'] + s3_file_path)

    if not is_s3_file_present(ENVS[env]['aws']['s3_bucket'] + s3_file_path):
        return {JobStatusLabels.COB.value: cob, JobStatusLabels.CONTENTS.value: {JobStatusLabels.LOADED.value: {'entity': 0}, JobStatusLabels.FILTERED.value: {'entity': 0},
                                         JobStatusLabels.ERRORED.value: {'ErrorRecordCount': 0}}}
    # Download file to tmp , run counts and then delete it

    # create temp dir if does not exists
    if not os.path.exists(os.getcwd() + os.path.sep + "tmp"):
        os.mkdir('tmp')
    os.chdir('tmp')

    download_file_path = os.getcwd() + os.path.sep + s3_file_path.split('/')[-1]
    #Bypassing the stats part until appropriate AWS role is available
    # with S3(env) as s3:
    #     s3.get_file(download_file_path, ENVS[env]['aws']['s3_bucket'], s3_file_path)

    # with open(download_file_path, "r") as file:
    #     count = sum(1 for line in file) - num_lines_of_header - num_lines_of_footer
    # os.remove(download_file_path)
    return {JobStatusLabels.COB.value: cob, JobStatusLabels.CONTENTS.value: {JobStatusLabels.LOADED.value: {'entity': 0}, JobStatusLabels.FILTERED.value: {'entity': 0},
                                     JobStatusLabels.ERRORED.value: {'entity': 0}}}


#########################Stats - EMR###################################################################################
#job_stats_metrics_list = ['LoadedRecordCount', 'FilteredRecordCount', 'ErroredRecordCount']


def run_emr_and_generate_stats(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
                               parameters=None, dryRun=None):
    '''
    Calls the EMR job and post that generates the stats by calling the build_stats_of_emr_job_run
    '''
    emr_function = parameters['emr_function']
    job_stats_dict = run_emr_job(jobId, codeToRun, targetMachine, env, cob, inputs, outputs, alias, parameters, dryRun)


    build_stats_of_emr_job_run(parameters['stats_table_list'], parameters['stats_queries_dict'], env,
                               emr_function, parameters.get('prefix'), job_stats_dict)
    return job_stats_dict


def run_emr_job(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
                parameters=None, dryRun=None):
    '''
    calls the EMR class to run the etl or mdm job and reutrns a dict with status,log path and cob
    :param jobId:
    :param codeToRun:
    :param targetMachine:
    :param env:
    :param cob: close of business
    :param inputs:
    :param outputs:
    :param alias:
    :param parameters: Contains all the
    :param dryRun:

    :return:
    '''
    with EMR(codeToRun, alias, env, cob, targetMachine, inputs, outputs, parameters, dryRun, jobId) as emr:
        try:
            emr.run()
        except Exception as e:
            print("Error Message:"+str(e))

        status = emr.get_status()
        emr_result = {
            JobStatusLabels.JOB_STATUS.value: status,
            JobStatusLabels.JOB_LOG.value: emr.getLogPath(),
            JobStatusLabels.COB.value: cob
        }
    if status == "NOTRUN":
        emr.log_to_dynamodb(emr_result)
        raise ValueError('EMR job did not run. Go investigate')

    print(emr.getLog())
    emr.log_to_dynamodb(emr_result)

    if status == "FAILED":
        emr.log_to_dynamodb(emr_result)
        raise ValueError('EMR job failed. Go investigate')

    return emr_result



def build_stats_of_emr_job_run(tables_list, queries_dict, env, emr_action, prefix=None, job_stats_dict={}):
    """
    Calculates the rows in the table that an emr job(etl/mdm)  inserts rows into.Iterates
    over list of tables and runs the queries for the following categories loaded,filtered and errored, captures them
    into a dictionary broken down by  categories/tables. Adds this to job stats as content.
    :param job_stats_dict: job stats is a dict built after the emr run and contains  job status and log path.It also has
            the cob
    :param tables_list: contains the tables  that data has been inserted into after the EMR job
    :param queries_dict:  queries for loaded, errored, filtered
    :param env: env the emr job was run in
    :param emr_action:  emr job was etl or mdm
    :param prefix: prefix only in case of
    :return:
    """
    if emr_action == 'mdm':
        connection = db_connection_factory(env, "RDS")
        with connection as cursor:
            cursor.execute("select value1 as stg_prefix from edm_params where key = 'active_mdm_stage'")
            prefix = cursor.fetchone()[0]
    elif emr_action == 'dbsync':
        return build_stats_of_dbsync_job_run(tables_list, queries_dict, env, emr_action, prefix, job_stats_dict)

    stats_dict = {}
    for key in queries_dict.keys():
        stats_dict[key] = {}

    if emr_action in ['mdm','circe']:
        connection = db_connection_factory(env, "RDS")
        with connection as cursor:
            cursor.execute("select value1 as stg_prefix from edm_params where key = 'active_mdm_stage'")
            prefix = cursor.fetchone()[0]

    connection = db_connection_factory(env, "RDS")
    with connection as cursor:
        for table in tables_list:
            for key, query in queries_dict.items():
                if query.strip():
                    if prefix and len(prefix) > 0:
                        for item in prefix.split(","):
                            cursor.execute(query.format(table_name=table, prefix=item))
                            count = int(cursor.fetchone()[0])
                            stats_dict[key][table] = count
                    elif not prefix or len(prefix) == 0:
                        cursor.execute(query.format(table_name=table))
                        count = int(cursor.fetchone()[0])
                        stats_dict[key][table] = count
                else:
                    stats_dict[key][table] = 0

    job_stats_dict['contents'] = stats_dict
    print('Stats: ', job_stats_dict)


def build_stats_of_dbsync_job_run(tables_list, queries_dict, env, emr_action, prefix=None, job_stats_dict={}):
    stats_dict = {}
    for key in queries_dict.keys():
        stats_dict[key] = {}

    connection = db_connection_factory(env, "RDS")
    with connection as cursor:
        prefix_list = prefix.split(",")
        tables_list_increment = int(round(len(tables_list) / len(prefix_list)))
        tables_by_prefixes = [tables_list[i:i + tables_list_increment] for i in
                              range(0, len(tables_list), tables_list_increment)]
        print(tables_by_prefixes)

        count = tables_list_increment
        for i in range(0, count):
            prefix = prefix_list[i]
            tables = tables_by_prefixes[i]
            for table in tables:
                for key, query in queries_dict.items():
                    if query.strip():
                        cursor.execute(query.format(table_name=table, prefix=prefix))
                        count = int(cursor.fetchone()[0])
                        stats_dict[key][table] = count
                    else:
                        stats_dict[key][table] = 0

    job_stats_dict[JobStatusLabels.CONTENTS.value] = stats_dict
    print('Stats: ', job_stats_dict)




#@calledByJobRunner
def perform_jobstatus_checker(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None, parameters=None,  dryRun=None):
     status_set = set()
     d = inputs
     for datasource in d:
        for feedName in d[datasource]:
            feed_api = FeedAPI(env)
            output = feed_api.getFeedInstancesByFeedID(datasource, feedName, cob)
            print("output:{}".format(len(output)))
            if len(output) == 0:
               status_set.add(None)
            else:
               print(output)
               item = output.pop()
               print("runtime: {}, feedID: {}, jobstatus: {}".format(item.RunTime, item.FeedID,item.Status))
               status_set.add(item.Status)
     print(status_set)

     if len(status_set) > 1:
         raise ValueError("Some Job/s completed while others did not - exiting with ERROR")

     stats_dict = {JobStatusLabels.JOB_STATUS.value: JobStatus.SUCCESS.value,
              JobStatusLabels.CONTENTS.value: { JobStatusLabels.LOADED.value: 0,
                                                JobStatusLabels.FILTERED.value: 0,
                                                JobStatusLabels.ERRORED.value: 0
                                                }
              }
     print("Return object is :", stats_dict)
     return stats_dict

def gen_push_circe_conf(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None,
                                       alias=None, parameters=None, dryRun=None):

    json_str = """
    {
      "load_src": "s3",
      "IGNORED_FIELD_LIST": [
        "staging_id",
        "stewardship_type",
        "create_rule",
        "etl_error",
        "etl_source",
        "error_message",
        "updated_at"
      ],
      "TABLES_LIST": [
        "agreement",
        "agreement_entity_xref",
        "aum",
        "entity",
        "trade"
      ],
      "file_date": "8-9-2020",
      "rowcount": 113,
      "PKEY_FKEY_MAPPINGS": {
        "entity": {
          "entity": "parent_id",
          "agreement_entity_xref": "entity_id",
          "entity_email_xref": "entity_id",
          "entity_phone_xref": "entity_id",
          "entity_address_xref": "entity_id"
        },
        "agreement": {
          "agreement_entity_xref": "agreement_id",
          "aum": "agreement_id",
          "trade": "agreement_id"
        }
      },
      "COLUMNS": [
        "TDS_ID",
        "source_name",
        "etl_source",
        "original_record_",
        "column_name",
        "invalid_value",
        "valid_value",
        "stewardship_type",
        "create_rule",
        "created_at",
        "updated_at",
        "submitted_at",
        "cascade"
      ],
      "TDS_ID": "tds_id",
      "STAGING_ID": "tds_master",
      "MASTER": "true",
      "ETL_SOURCE": "etl_source",
      "STEWARDSHIP_TYPE": "stewardship_type",
      "comment": "Pkey / fkey mappings is a dict where the keys are pkey table names and the values are dicts corresponding to the key / foreign key relationships."
    }
    
    """
    circe_conf_str  = json_str.replace('\n', '')
    json_data = json.loads(circe_conf_str)
    json_data["file_date"] = parameters['file_date']
    json_data["jobid"] = jobId
    json_data["input_location"] =  inputs
    #json_data["output_location"] = outputs

    s3 = boto3.resource('s3')
    filename = "{}_{}.conf".format(parameters['filename'], str(jobId))

    circe_conf_dir = outputs.get("circe_conf_dir")
    file_path = "{}{}".format(circe_conf_dir, filename)
    print(f"Copying file circe conf to S3:{str(file_path)}")
    s3.Object(ENVS[env]['aws']['s3_bucket'][5:], file_path).put(Body=json.dumps(json_data))
    print("File successfully copied to S3")

    stats_dict = {JobStatusLabels.JOB_STATUS.value: JobStatus.SUCCESS.value,
                  JobStatusLabels.CONTENTS.value: {JobStatusLabels.LOADED.value: 0,
                                                   JobStatusLabels.FILTERED.value: 0,
                                                   JobStatusLabels.ERRORED.value: 0
                                                   }
                  }
    print("Return object is :", stats_dict)
    return stats_dict
