import ast
import atexit
import calendar
import re
import uuid
from datetime import date, timedelta, datetime

from dateutil.parser import parse
from jobsystem.FeedDefinition import FeedDefinition
from jobsystem.FeedInstance import FeedInstance
# todo: move below references out of job runner and into jobsystem.utils
from jobsystem.job_runner import calledByJobRunner
from jobsystem.override_cob import get_cob_override_date

from common.aws import DynamoDB
from common.enums import JobStatus, JobStatusLabels
from common.utils import call_function


class FeedAPI:
    _workflow_graph = None

    @classmethod
    def regenerate_workflow_graph(cls, environment):
        cls._workflow_graph = None
        return cls.generate_workflow_graph(environment)

    @classmethod
    def generate_workflow_graph(cls, environment):
        print('generate_workflow_graph')
        def search_workflow_graph(list_of_feed_definition_nodes, feedId):
            print('search_workflow_graph')
            for feedDefinitionNode in list_of_feed_definition_nodes:
                if feedDefinitionNode['feedDefinition'].FeedID == feedId:
                    return feedDefinitionNode

        if cls._workflow_graph is not None:
            return cls._workflow_graph
        # get all feed Instances
        all_feed_definition_nodes = cls.get_all_feed_definition_nodes(environment)

        for feed_definition_node in all_feed_definition_nodes:
            if feed_definition_node['feedDefinition'].PreviousFeedID != "":
                parent = search_workflow_graph(all_feed_definition_nodes, feed_definition_node['feedDefinition'].PreviousFeedID)
                if parent is not None:
                    parent['children'].append(feed_definition_node)

        cls._workflow_graph = all_feed_definition_nodes
        return cls._workflow_graph

    @classmethod
    def get_all_feed_definition_nodes(cls, env):
        print('get_all_feed_definition_nodes')
        feed_def_nodes = []
        feed_defs = cls.get_all_feed_definitions(env)
        for feed_def in feed_defs:
            feed_def_nodes.append({'feedDefinition': feed_def, 'children': [], 'processed': False })
        return feed_def_nodes

    #todo: remove. for testing only
    # def get_all_feed_definitions(cls, environment):
    #     print('get_all_feed_definitions')
    #     SV_FOP_INPUT = FeedDefinition('', 'SVFOP', '', '', '', '', '', '', '', '', '', '', '', '')
    #     SV_FOP_INPUT_ETL = FeedDefinition('SVFOP', 'SVFOPETL', '', '', '', '', '', '', '', '', '', '', '', '')
    #     all_feed_definitions = []
    #     all_feed_definitions.append(SV_FOP_INPUT)
    #     all_feed_definitions.append(SV_FOP_INPUT_ETL)
    #     return all_feed_definitions

    @classmethod
    def get_all_feed_definitions(cls, environment):
        feed_definitions = []
        data = {"hash_key": "feedID", "feedID": "*"}
        with DynamoDB(environment) as dynamodb:
            query_results = dynamodb.query("feedDefinition", data)

        for query_result in query_results:
            feed_definitions.append(FeedDefinition(query_result['PreviousFeedID'],
                                                   query_result['feedID'],
                                                   query_result['Inputs'],
                                                   query_result['Outputs'],
                                                   query_result['System'],
                                                   query_result['CodeToRun'],
                                                   query_result['DataTypes'],
                                                   query_result['ControlCheckThreshold'],
                                                   query_result['Transform'],
                                                   query_result['GetAndSend'],
                                                   query_result['ETA'],
                                                   query_result['SLA'],
                                                   query_result['Contact'],
                                                   query_result['Escalation'],
                                                   query_result['ActiveDateStart'],
                                                   query_result['ActiveDateStart']
                                                   ))
        return feed_definitions



    def __init__(self, environment):
        self.generate_workflow_graph(environment)
        self.environment = environment
        #accomodate process
        self.env = environment

    def validate(self, prior_feed_instance_data, current_feed_instance_data, threshold_data):
        all_validations_pass_fail = True
        threshold_check = ['LoadedRecordCount', 'FilteredRecordCount', 'ErrorRecordCount']
        validation_result_data = []
        for item in threshold_check:
            try:
                for key, value in current_feed_instance_data[item].items():
                    try:
                        threshold_percentage = int(threshold_data[item][key])
                        prior_value = int(prior_feed_instance_data[item][key])
                        difference = abs(int(value)-prior_value)
                        if difference > (prior_value * (threshold_percentage/100)):
                            validation_result_data.append({'ThresholdCheck': item,
                                                           'key': key,
                                                           'validationStatus': 'Failed',
                                                           'reason': 'over percentage threshold',
                                                           'currentValue': value,
                                                           'priorValue': prior_value})
                            all_validations_pass_fail = False
                        else:
                            validation_result_data.append({'ThresholdCheck': item,
                                                           'key': key,
                                                           'validationStatus': 'Passed',
                                                           'reason': 'within threshold',
                                                           'currentValue': value,
                                                           'priorValue': prior_value})
                    except Exception as ex:
                        message = "unable to find key [{}] in prior feed instance data".format(key)
                        validation_result_data.append({'ThresholdCheck': item,
                                                       'key': key,
                                                       'validationStatus': 'Exception',
                                                       'reason': message})
            except Exception as ex:
                message = "unable to find threshold check [{}] in current feed instance data".format(item)
                validation_result_data.append({'ThresholdCheck': item,
                                               'validationStatus': 'Exception',
                                               'reason': message})
        validation_result = {'ValidationResult': all_validations_pass_fail,
                             'ValidationResultData': validation_result_data}
        return validation_result

    # onboard a feed aka FeedDefinition

    ################### Feed Defintion Data Access #####################

    def registerFeedDefinition(self, feed_definition):
        with DynamoDB(self.environment) as dynamodb:
            dynamodb.upsert("feedDefinition", feed_definition.to_dict())

    # update  # a FeedDefinition
    def updateFeedDefinition(self, feed_definition):
        with DynamoDB(self.environment) as dynamodb:
            dynamodb.upsert("feedDefinition", feed_definition.to_dict())

    def deleteFeedDefinition(self, DataSource, FeedName):
        feed_id = DataSource + "_" + FeedName
        data = {"hash_key": "feedID",
                 "feedID": feed_id}
        with DynamoDB(self.environment) as dynamodb:
            dynamodb.delete(self.tableName, data)

    def getFeedDefinitionByFeedId(self, DataSource, FeedName):
        feed_id = DataSource + "_" + FeedName
        feed_definitions = []
        data = {"hash_key": "feedID",
                 "feedID": feed_id}
        with DynamoDB(self.environment) as dynamodb:
            query_results = dynamodb.query("feedDefinition", data)

        for query_result in query_results:
            feed_definitions.append(FeedDefinition(query_result['PreviousFeedID'],
                                                    query_result['feedID'],
                                                    query_result['Inputs'],
                                                    query_result['Outputs'],
                                                    query_result['System'],
                                                    query_result['CodeToRun'],
                                                    query_result['DataTypes'],
                                                    query_result['ControlCheckThreshold'],
                                                    query_result['Transform'],
                                                    query_result['GetAndSend'],
                                                    query_result['ETA'],
                                                    query_result['SLA'],
                                                    query_result['Contact'],
                                                    query_result['Escalation'],
                                                    query_result['ActiveDateStart'],
                                                    query_result['ActiveDateStart']
                                                   ))
        return feed_definitions



    # the code contained in a FeedDefinition on a COB. Return a FeedInstance
    def run(self, jobId, codeToRun, targetMachine, env, cob, inputs, outputs, alias, parameters, dryRun=False):
        def processTokensInDictStr(dictionary):
            temp = result = {}
            temp = ast.literal_eval(dictionary)
            for key, val in temp.items():
                result[key] = self.processSubstitutionVariables(self.env, self.COB, val, parameters['DataSource'])
            return result
        processed_inputs = []
        processed_outputs = []

        self.COB = parse(cob) if cob else self.getRunDate()

        feed_definition_to_run = None
        all_feed_definitions = self.getFeedDefinitionByFeedId(parameters['DataSource'], parameters['FeedName'])
        if len(all_feed_definitions) == 0:
            raise 'Could not retrieve feed definition with DataSource: {} and FeedName: {}'.format(parameters['DataSource'], parameters['FeedName'])
        if len(all_feed_definitions) >= 2:
            raise 'more than one feed definition with DataSource: {} and FeedName: {} was retrieved'.format(parameters['DataSource'], parameters['FeedName'])
        else:
            feed_definition_to_run = all_feed_definitions[0]

        # if not feed_definition_to_run.is_active():
        #     raise ValueError(f"Feed definition expired on {feed_definition_to_run.ActiveDateEnd()}")

        if feed_definition_to_run.Inputs:
            if isinstance(feed_definition_to_run.Inputs, list):
                print("processing Inputs as list")
                for input_item in feed_definition_to_run.Inputs:
                    processed_inputs.append(processTokensInDictStr(input_item))
            elif isinstance(feed_definition_to_run.Inputs, str):
                print("processing Inputs as string")
                processed_inputs = processTokensInDictStr(feed_definition_to_run.Inputs)
            else:
                print("No Inputs to Process")
                processed_inputs = None


        if feed_definition_to_run.Outputs:
            if isinstance(feed_definition_to_run.Outputs, list):
                print("processing Outputs as list")
                for output_item in feed_definition_to_run.Outputs:
                    processed_outputs.append(processTokensInDictStr(output_item))
            elif isinstance(feed_definition_to_run.Outputs, str):
                print("processing Outputs as string")
                processed_outputs = processTokensInDictStr(feed_definition_to_run.Outputs)
            else:
                print("No Outputs to Process")
                processed_outputs = None


        function_to_call_params = []
        function_to_call_params.append(jobId)
        function_to_call_params.append(feed_definition_to_run.CodeToRun)
        function_to_call_params.append(targetMachine)
        function_to_call_params.append(env)
        function_to_call_params.append(cob)
        function_to_call_params.append(processed_inputs)
        function_to_call_params.append(processed_outputs)
        function_to_call_params.append(alias)
        function_to_call_params.append(parameters)
        function_to_call_params.append(dryRun)

        feed_instance_object = FeedInstance(feed_definition_to_run.FeedID,
                                         datetime.now().strftime('%Y%m%d %H:%M:%S'),
                                        "",
                                        jobId,
                                        JobStatus.STARTED.value,
                                        cob,
                                        None,
                                        None,
                                        None)
        self.writeFeedInstance(feed_instance_object)

        atexit.register(system_signal_handler, SystemExit, feed_instance_object)

        # run feed definition
        #EDM - 2699 fix ...adding try/catch to fix it and will later  look at refactoring
        try:
            call_function_result = call_function(feed_definition_to_run.CodeToRun, function_to_call_params)
            print("Results of run: {}".format(call_function_result))
        except Exception as ex:
            feed_instance_object._Status = JobStatus.FAILED.value
            self.writeFeedInstance(feed_instance_object)
            raise ex

        if not JobStatus.FAILED.value in (call_function_result.get(JobStatusLabels.JOB_STATUS.value), feed_instance_object._Status):
            call_function_result_contents = call_function_result.get(JobStatusLabels.CONTENTS.value)
            print(call_function_result_contents)
            feed_instance_object._LoadedRecordCount =  call_function_result_contents.get(JobStatusLabels.LOADED.value)
            feed_instance_object._FilteredRecordCount = call_function_result_contents.get(JobStatusLabels.FILTERED.value)
            feed_instance_object._ErroredRecordCount = call_function_result_contents.get(JobStatusLabels.ERRORED.value)
            feed_instance_object._Status = JobStatus.SUCCESS.value
        else:
             feed_instance_object._Status = JobStatus.FAILED.value


        self.writeFeedInstance(feed_instance_object)

        return feed_instance_object

    def writeFeedInstance(self, FeedInstanceObject):
        print("FeedInstance: {}".format(FeedInstanceObject.to_dict()))
        with DynamoDB(self.environment) as dynamodb:
            dynamodb.upsert("feedInstance", FeedInstanceObject.to_dict())

    def getFeedInstancesByFeedID(self, DataSource, FeedName, COB=None, runTime=None):
        feed_id = DataSource + "_" + FeedName
        feed_instances = []
        data = {}

        if COB:
            data['CloseOfBusinessDay'] = COB

        if runTime:
            data['runTime'] = runTime
            data["range_key"] = "runTime"

        data["hash_key"] = "feedID"
        data["feedID"] = feed_id

        with DynamoDB(self.environment) as dynamodb:
            query_results = dynamodb.query("feedInstance", data)

        for query_result in query_results:
            feed_instance = FeedInstance(query_result['feedID'],
                            query_result['runTime'],
                            query_result['DetailLinkID'],
                            query_result['JobID'],
                            query_result['Status'],
                            query_result['CloseOfBusinessDay'],
                            query_result['LoadedRecordCount'],
                            query_result['FilteredRecordCount'],
                            query_result['ErroredRecordCount']
                            )
            if COB:
                if feed_instance.CloseOfBusinessDay == COB:
                    feed_instances.append(feed_instance)
            else:
                feed_instances.append(feed_instance)

        return feed_instances


#todo: move this to common.utils?
    def gen_jobid(self):
            jobid = uuid.uuid1()
            return jobid.hex

    def getRunDate(self):
        return date.today()

    def processSubstitutionVariables(self, env, COB, ioString, data_source):
        '''Substitutes the correct environment and COB into input and output parameters. Assumes self.env has been set prior to calling this method.
        Parameters:
                env:    The name of the environment to use.
                COB:    The COB date to use
            Returns:
                The input / output filename/path with all variables explicitly defined.
        '''

        def replaceVariable(match):
            def processMiddlePartOfEnvVariable(format):
                if format.lower() == 'lower':
                    return self.env.lower()
                elif format.lower() == 'upper':
                    return self.env.upper()
                elif format.lower() == 'capitalize':
                    return self.env.capitalize()
                else:
                    return self.env

            def processLastPartOfEnvVariable(env,thirdPart):
                logicParts=thirdPart.split(',')
                for mappingPair in logicParts:
                    source, target=mappingPair.split('-')
                    if env.lower() == source.lower():
                        return target

            variable=match.group(0)[1:-1] # strip the surrounding < >
            if variable[:3].lower()=='cob':
                partsOfCOBVariable= variable.split(':')

                override_date_obj = get_cob_override_date(env,data_source)
                if override_date_obj :
                        return override_date_obj.strftime(partsOfCOBVariable[1])

                if len(partsOfCOBVariable) == 3:
                    command, format, offset = partsOfCOBVariable
                    rundate = COB + timedelta(days=int(offset))
                elif len(partsOfCOBVariable) == 4:
                    command, format, offset, specialDate = partsOfCOBVariable
                    if specialDate.lower() == "monthend":
                        month=COB.month+int(offset)
                        # Ensure the proper year is used if more than available months in the current year are added/subtracted
                        year=COB.year
                        while month < 1:
                            year-=1
                            month+=12
                        while month > 12:
                            year+=1
                            month-=12
                        day=calendar.monthrange(year,month)[1]

                        rundate=date(year,month,day)
                return rundate.strftime(format)
            elif variable[:3].lower()=='env':
                envParts = variable.split(':')
                if len(envParts) == 1:
                    return self.env.upper()
                elif len(envParts) == 2:
                    return processMiddlePartOfEnvVariable(envParts[1])
                elif len(envParts) == 3:
                    return processLastPartOfEnvVariable(processMiddlePartOfEnvVariable(envParts[1]),envParts[2])
                else:
                    raise ValueError("The <env:lower|upper|capitalize:mappings> Variable can only have up to 3 strings separated by :")
        if ioString:
            if isinstance(ioString,list):
                # ioString is actually a list. Replace Variables in every item of the list
                return [re.sub("<(.*?)>",replaceVariable,item) for item in ioString]
            elif isinstance(ioString,str):
                return re.sub("<(.*?)>",replaceVariable,ioString)
            else:
                # ioString is a dict, int, float, etc. which don't need to be processed for Variables
                return ioString
        else:
            return None

def system_signal_handler(system_code, feed_instance):
    print('inside system signal handler')
    if system_code != 0:
        feed_instance._Status =  JobStatus.FAILED.value
    else:
        feed_instance.status =  JobStatus.SUCCESS.value

#this feedDefinition Wrapper is needed to instantiate an instance of the FeedAPI class (call_function cannot yet call a function of a class)
@calledByJobRunner
def runFeed(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None, parameters=None):

    print("FeedAPI.runFeed, jobId: {}, "
          "codeToRun: {}, "
          "targetMachine: {}, "
          "env: {}, "
          "cob: {}, "
          "inputs: {}, "
          "outputs: {}, "
          "alias: {}, "
          "parameters: {}.".format(jobId,
                                              codeToRun,
                                              targetMachine,
                                              env,
                                              cob,
                                              inputs,
                                              outputs,
                                              alias,
                                              parameters))


    feed_api = FeedAPI(env)

    run_feed_definition_result = feed_api.run(jobId, codeToRun, targetMachine, env, str(cob), inputs, outputs, alias,
                                              parameters)

    print("feed definition result: {}".format(run_feed_definition_result))

    return run_feed_definition_result


