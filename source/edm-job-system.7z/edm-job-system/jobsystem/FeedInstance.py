class FeedInstance:
    def __init__(self, FeedID, runTime, DetailLinkID, JobID, Status, CloseOfBusinessDay, LoadedRecordCount, FilteredRecordCount, ErroredRecordCount):
        self._runTime = runTime
        self._FeedID = FeedID
        self._DetailLinkID = DetailLinkID
        self._JobID = JobID
        self._Status = Status
        self._CloseOfBusinessDay = CloseOfBusinessDay
        self._LoadedRecordCount = LoadedRecordCount
        self._FilteredRecordCount = FilteredRecordCount
        self._ErroredRecordCount = ErroredRecordCount

    @property
    def FeedID(self):
        return self._FeedID

    @property
    def RunTime(self):
        return self._runTime

    #do we need DetailLinkType = tablename/log file/etc..???
    @property
    def DetailLinkID(self):
        return self._DetailLinkID

    @property
    def JobID(self):
        return self._JobID

    @property
    def Status(self):
        return self._Status

    @property
    def CloseOfBusinessDay(self):
        return self._CloseOfBusinessDay

    @property
    def LoadedRecordCount(self):
        return self._LoadedRecordCount

    @property
    def FilteredRecordCount(self):
        return self._FilteredRecordCount

    @property
    def ErroredRecordCount(self):
        return self._ErroredRecordCount

    def to_dict(self):
        return {
                 "feedID":  self.FeedID,
                 "runTime": self._runTime,
                 "DetailLinkID":  self._DetailLinkID,
                 "JobID": self._JobID,
                 "Status":  self._Status,
                 "CloseOfBusinessDay": self._CloseOfBusinessDay,
                 "LoadedRecordCount": self._LoadedRecordCount,
                 "FilteredRecordCount": self._FilteredRecordCount,
                 "ErroredRecordCount": self._ErroredRecordCount
                }