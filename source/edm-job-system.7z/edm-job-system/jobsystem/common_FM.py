import csv
import io
import os
import re
import shutil
from contextlib import redirect_stderr

import pandas as pd

from common.aws import S3
from common.database import load_from_db_into_csv
from common.enums import JobStatus, JobStatusLabels, DataFlowFoldersName
from common.envconfig import ENVS
from common.ftp import SFTP
from common.security import get_secret
from common.utils import call_function

def get_recieve_and_sent_folder(data_source):
    DATA_HOME = os.environ[
        "DATA_HOME"]  # Get the root directory under which all copies of files transferred by this function are stored
    DATA_HOME = DATA_HOME[DATA_HOME[:-1]] if DATA_HOME[-1] == "/" else DATA_HOME  # Truncate tailing / if it exists
    RECEIVED_HOME = f"{DATA_HOME}/{DataFlowFoldersName.RECEIVED.value}"
    SENT_HOME = f"{DATA_HOME}/{DataFlowFoldersName.SENT.value}"
    sent_dir = f"{SENT_HOME}/{data_source}"
    if not os.path.isdir(sent_dir): os.mkdir(sent_dir)
    received_dir = f"{RECEIVED_HOME}/{data_source}"
    if not os.path.isdir(received_dir):
        os.mkdir(received_dir)  # files received from the data source are stored here
        os.mkdir(f"{received_dir}/{DataFlowFoldersName.UNZIPPED.value}")  # unzipped files are stored here
    return [received_dir, sent_dir]

def getFromSFTPAndSendToS3(env, input, output, dataSource, cob, failIfNoFile=True, saveCopy=True, rollback=False,
                           processFileFunctionTuple=None, unzipInput=True, zipOutput=True):
    '''Get one file from an SFTP server and save it on S3.
    Parameters:
        env:                        The name of the environment (e.g. TEST or PROD)
        input:                      Full remote path of the file including the filename on the SFTP server.
        output:                     Full path of the file including the filename in S3
        dataSource:                 The name of the (typically upstream) source from which data is retrieved (e.g. DataSource=SalesVision)
        cob:                        The date of the data contained in the file. The filename typically contains the COB.
        failIfNoFile:               If true, throw an exception if there's no file on the FTP server.
        saveCopy:                   If true, saves a copy of the file under $DATA_HOME/sent and $DATA_HOME/received
        rollback:                   If true, in case of an error puts the file back on the SFTP server. Needed primarily for the SalesVision SFTP server which removes files after a get command is sent
        processFileFunctionTuple:   If a file requires any transformation such as zipping, truncating the header, etc., a fully qualified name of the function and a dict containing its parameters are passed in a tuple.
                                    e.g. (jobsystem.feed_functions.transformFile, {...})
        Returns:                    If a function was passed in to process the file, returns whatever that function returns, otherwise does not return anything
    '''
    """Expected directory structure:
    /home/edmfilemgr/data
                        /received       #The first loop copies code here and calls codeToModifyInputs functions to transform the files and put them under the sent dir
                            /SalesVision
                                /Firm
                                    sv-firm-03-24-20.csv
                                /Person
                                /Office
                                /Trade
                                /PersHier
                            /AMG
                            /Fishtank
                        /sent 
                            /SalesVision
                                    sv-firm-03-24-20.csv
                            /AMG
                            /Fishtank
    """

    def getRemoteFilenameForWildcard(filename, remoteDir):
        listOfRemoteFiles = sftp.list_files(remoteDir)
        print(f"REMOTE_FILES={listOfRemoteFiles}")
        if listOfRemoteFiles:
            filenameAsRegExp = filename.replace("*", "(.*?)")
            compiledRegExp = re.compile(filenameAsRegExp)
            matchingRemoteFileList = []
            for remoteFile in listOfRemoteFiles:
                if compiledRegExp.match(remoteFile):
                    matchingRemoteFileList.append(remoteFile)
            if len(matchingRemoteFileList) > 1:
                raise ValueError(
                    f"Multiple files - {matchingRemoteFileList.join(', ')} - matching {filename} were found.")
        if matchingRemoteFileList:
            return matchingRemoteFileList[0]
        else:
            raise ValueError(f"No file was found on the remote server matching {filename}")

    def rollback(remoteDir, remoteFilename):
        rollbackName = (remoteDir + '/' if remoteDir else "") + remoteFilename
        sftp.put_file(f"{receivedDir}/{remoteFilename}", rollbackName)

    if not input: raise ValueError("getDataAndSendToS3() requires the name of at least one file as input.")
    DATA_HOME = os.environ[
        "DATA_HOME"]  # Get the root directory under which all copies of files transferred by this function are stored
    DATA_HOME = DATA_HOME[DATA_HOME[:-1]] if DATA_HOME[-1] == "/" else DATA_HOME  # Truncate tailing / if it exists
    RECEIVED_HOME = f"{DATA_HOME}/{DataFlowFoldersName.RECEIVED.value}"
    SENT_HOME = f"{DATA_HOME}/{DataFlowFoldersName.SENT.value}"

    sentDir = f"{SENT_HOME}/{dataSource}"
    if not os.path.isdir(sentDir): os.mkdir(sentDir)
    receivedDir = f"{RECEIVED_HOME}/{dataSource}"
    if not os.path.isdir(receivedDir):
        os.mkdir(receivedDir)  # files received from the data source are stored here
        os.mkdir(f"{receivedDir}/{DataFlowFoldersName.UNZIPPED.value}")  # unzipped files are stored here
    os.chdir(receivedDir)

    # Get files from SFTP and save them under RECEIVED_HOME/data-source
    if "secret" in ENVS[env][dataSource]:
        passwd = get_secret(ENVS[env][dataSource]["secret"], env)["pwd"]
    else:
        passwd = ''

    with SFTP(ENVS[env][dataSource]["server"],
              ENVS[env][dataSource]["user"],
              passwd,
              ENVS[env][dataSource]["port"]) as sftp:
        remoteDir = input[:input.rindex('/')] if input.find('/') == 0 else None
        filename = input[input.rindex('/') + 1:] if input.find('/') == 0 else input
        # If the filename contains a wildcard, find out what the filename would evaluate to
        # TBD-glp 4/5/20: os calls should be in the try / except block
        if filename.find("*") != -1:
            remoteFilename = getRemoteFilenameForWildcard(filename, remoteDir)
            renamedFilename = filename.replace("*", "")
        else:
            renamedFilename = None
            remoteFilename = filename
        print(f"GETTING {remoteDir + '/' if remoteDir else ''}{remoteFilename} into {receivedDir}")
        sftp.get_file(f"{remoteDir + '/' if remoteDir else ''}{remoteFilename}", receivedDir)

        try:
            # Read file from DATA_HOME/received/data_source/filename and save it under DATA_HOME/sent/data_source/filename
            if unzipInput:
                shutil.copyfile(f"{receivedDir}/{remoteFilename}", f"{receivedDir}/unzipped/{remoteFilename}")
                if os.system("gzip -f -d " + f"{receivedDir}/{DataFlowFoldersName.UNZIPPED.value}/{remoteFilename}") != 0: raise ValueError(
                    f"Could not unzip {receivedDir}/{DataFlowFoldersName.UNZIPPED.value}/{remoteFilename}")
                source = f"{receivedDir}/{DataFlowFoldersName.UNZIPPED.value}/{remoteFilename[:-3]}"
                target = f"{sentDir}/{renamedFilename[:-3] if renamedFilename else remoteFilename[:-3]}"  # When a zipped file is received, it's unzipped and processed first, so the name shouldn't have a .gz suffix
            else:
                source = f"{receivedDir}/{remoteFilename}"
                target = f"{sentDir}/{renamedFilename if renamedFilename else remoteFilename}"
            if processFileFunctionTuple:
                function, params = processFileFunctionTuple
                params.update(input=source, output=target)
                resultOfProcessing = call_function(function, params)
            else:
                shutil.copyfile(source, target)
        except Exception as e:
            if rollback: rollback(remoteDir, remoteFilename)
            raise e
    print(f"RESULT = {str(resultOfProcessing)}")
    if zipOutput:
        if os.system("gzip -f -n " + target) != 0: raise ValueError(f"Could not zip {target}")
        target = f"{target}.gz"

    # Send each processed file to S3
    filename = target.split('/')[-1]
    s3_path_including_file_name = output if 'gz' in output else output+filename
    with S3(env) as s3:
        try:
            s3.send_file(f"{target}", f"{ENVS[env]['aws']['s3_bucket']}", s3_path_including_file_name)
        except Exception as e:
            if rollback: rollback(remoteDir, remoteFilename)
            raise e
    if resultOfProcessing: return resultOfProcessing


'''
moves one file to s3, zipping first if necessary
'''
def move_to_s3(env, target, output, sent_path, remove_on_sucess=True, zipOutput=True):
    print("target: {}, output: {}, zipOuput: {}".format(target, output,zipOutput))
    if zipOutput:
        if os.system("gzip -f -n " + target) != 0: raise ValueError(f"Could not zip {target}")
        target = f"{target}.gz"

    # Send each processed file to S3
    filename = target.split('/')[-1]
    s3_path_including_file_name = output if 'gz' in output else output+filename
    print("target: {}, output: {}, s3_path_including_file_name: {}".format(target, output, s3_path_including_file_name))
    print("S3 including filename: {}".format(s3_path_including_file_name))
    with S3(env) as s3:
        try:
            s3.send_file(f"{target}", f"{ENVS[env]['aws']['s3_bucket']}", s3_path_including_file_name)
        except Exception as e:
            #rollback will be handled by client code
            raise e
    #move to sent directory:
    destination = os.path.join(sent_path, filename)
    print("copy file [{}] to [{}]".format(target, destination))
    shutil.copy(target, destination)
    if remove_on_sucess:
        print("removing file: {}".format(target))
        os.remove(target)


'''
gets one file and unzips if needed from sftp
inputs 
env, dataSource, input, unzipInput
returns
source, target, receivedDir, remoteDir
'''
def get_file(env, dataSource, input, unzipInput=True):
    def rollback(sftp, remoteDir, remoteFilename):
        rollbackName = (remoteDir + '/' if remoteDir else "") + remoteFilename
        sftp.put_file(f"{receivedDir}/{remoteFilename}", rollbackName)

    if not input: raise ValueError("getDataAndSendToS3() requires the name of at least one file as input.")
    DATA_HOME = os.environ[
        "DATA_HOME"]  # Get the root directory under which all copies of files transferred by this function are stored
    DATA_HOME = DATA_HOME[DATA_HOME[:-1]] if DATA_HOME[-1] == "/" else DATA_HOME  # Truncate tailing / if it exists
    RECEIVED_HOME = f"{DATA_HOME}/{DataFlowFoldersName.RECEIVED.value}"
    SENT_HOME = f"{DATA_HOME}/{DataFlowFoldersName.SENT.value}"

    sentDir = f"{SENT_HOME}/{dataSource}"
    if not os.path.isdir(sentDir): os.mkdir(sentDir)
    receivedDir = f"{RECEIVED_HOME}/{dataSource}"
    if not os.path.isdir(receivedDir):
        os.mkdir(receivedDir)  # files received from the data source are stored here
        os.mkdir(f"{receivedDir}/{DataFlowFoldersName.UNZIPPED.value}")  # unzipped files are stored here
    os.chdir(receivedDir)


    # Get files from SFTP and save them under RECEIVED_HOME/data-source
    if "secret" in ENVS[env][dataSource]:
        passwd = get_secret(ENVS[env][dataSource]["secret"], env)["pwd"]
    else:
        passwd = ''

    with SFTP(ENVS[env][dataSource]["server"],
              ENVS[env][dataSource]["user"],
              passwd,
              ENVS[env][dataSource]["port"]) as sftp:
        remoteDir = input[:input.rindex('/')] if input.find('/') == 0 else None
        filename = input[input.rindex('/') + 1:] if input.find('/') == 0 else input
        # If the filename contains a wildcard, find out what the filename would evaluate to
        # TBD-glp 4/5/20: os calls should be in the try / except block
        if filename.find("*") != -1:
            remoteFilename = getRemoteFilenameForWildcard(filename, remoteDir)
            renamedFilename = filename.replace("*", "")
        else:
            renamedFilename = None
            remoteFilename = filename
        print(f"GETTING {remoteDir + '/' if remoteDir else ''}{remoteFilename} into {receivedDir}")
        sftp.get_file(f"{remoteDir + '/' if remoteDir else ''}{remoteFilename}", receivedDir)

        try:
            # Read file from DATA_HOME/received/data_source/filename and save it under DATA_HOME/sent/data_source/filename
            if unzipInput:
                shutil.copyfile(f"{receivedDir}/{remoteFilename}", f"{receivedDir}/{DataFlowFoldersName.UNZIPPED.value}/{remoteFilename}")
                if os.system("gzip -f -d " + f"{receivedDir}/{DataFlowFoldersName.UNZIPPED.value}/{remoteFilename}") != 0: raise ValueError(
                    f"Could not unzip {receivedDir}/{DataFlowFoldersName.UNZIPPED.value}/{remoteFilename}")
                source = f"{receivedDir}/{DataFlowFoldersName.UNZIPPED.value}/{remoteFilename[:-3]}"
                target = f"{sentDir}/{renamedFilename[:-3] if renamedFilename else remoteFilename[:-3]}"  # When a zipped file is received, it's unzipped and processed first, so the name shouldn't have a .gz suffix
            else:
                source = f"{receivedDir}/{remoteFilename}"
                target = f"{sentDir}/{renamedFilename if renamedFilename else remoteFilename}"
            #moved to calling code
            # #todo wrap this in an if with flag from calling code for multiple file processing
            #
            # if processFileFunctionTuple:
            #     function, params = processFileFunctionTuple
            #     params.update(input=source, output=target)
            #     resultOfProcessing = call_function(function, params)
            # else:
            #     shutil.copyfile(source, target)

        except Exception as e:
            if rollback: rollback(sftp, remoteDir, remoteFilename)
            raise e
    return source, target, receivedDir, remoteDir


def getRemoteFilenameForWildcard(sftp, filename, remoteDir):
    listOfRemoteFiles = sftp.list_files(remoteDir)
    print(f"REMOTE_FILES={listOfRemoteFiles}")
    if listOfRemoteFiles:
        filenameAsRegExp = filename.replace("*", "(.*?)")
        compiledRegExp = re.compile(filenameAsRegExp)
        matchingRemoteFileList = []
        for remoteFile in listOfRemoteFiles:
            if compiledRegExp.match(remoteFile):
                matchingRemoteFileList.append(remoteFile)
        if len(matchingRemoteFileList) > 1:
            raise ValueError(
                f"Multiple files - {matchingRemoteFileList.join(', ')} - matching {filename} were found.")
    if matchingRemoteFileList:
        return matchingRemoteFileList[0]
    else:
        raise ValueError(f"No file was found on the remote server matching {filename}")


# def getFromDBAndSendToS3(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
#                          parameters=None):
#     pass


def calledByGetFromSFTPAndSendToS3(function):
    def wrapper(input, output, cob, stripHeader, stripFooter, srcColSeparator, targetColSeparator=None, newHeader=None,
                file_offset=0, add_quotes_to_data=False, column_types=None, primary_key=None,  drop_columns=None,entities_list=[]):
        if not os.path.isfile(input): raise ValueError(f"{input} file does not exist.")
        targetDir = output[:output.rindex('/')]
        if not os.path.isdir(targetDir): os.mkdir(targetDir)
        return function(input, output, cob, stripHeader, stripFooter, srcColSeparator, targetColSeparator, newHeader,
                        file_offset, add_quotes_to_data, column_types, primary_key, drop_columns,entities_list=[])

    return wrapper

@calledByGetFromSFTPAndSendToS3
def transformFileDataFrame(input, output, cob, stripHeader, stripFooter, srcColSeparator, targetColSeparator=None,
                           newHeader=None, file_offset=0, add_quotes_to_data=False, column_types=None,
                           primary_key=None, drop_columns=None, entities_list=[]):
    # need first line and last line for checks
    first_line = None
    last_line = None
    errors = []
    filtered_count = 0
    skipfooter = 1 if stripHeader else 0
    skiprows = 1 if stripHeader else 0
    destination_column_separator = targetColSeparator if targetColSeparator else srcColSeparator
    LQE_file_flag = False

    with open(input, 'rb') as f:
        first_line = f.readline().decode()
        second_line = f.readline().decode()
        f.seek(-2, os.SEEK_END)
        while f.read(1) != b'\n':
            f.seek(-2, os.SEEK_CUR)
        last_line = f.readline().decode()

    if not newHeader:
        # header is contained within LQE files @ second row
        with open(input, 'r') as f:
            lines = f.readlines()
            newHeader = lines[1].split(',')

    if not primary_key:
        # primary key is going to be different for each file for SV FOP...
        #not having a primary_key sent in is not a great indicator of an LQE file
        #TODO: rework this block to me more configurable
        LQE_file_flag = True
        primary_key = newHeader[1]
        if "Holding_Files" in input:
            primary_key = "ACP_ID0"
        if "Trade_Files" in input:
            primary_key = "TCA_ID0"
        if "SalesHier_File" in input:
            primary_key = "SHD_SAH_ID0"
        if "Asset_File" in input:
            primary_key = ["ASP_ACP_ID0", "ASP_ASSET_DATE1"]
        if "SalesPers" in input:
            primary_key = "SAP_ID0"
        if "TransCode" in input:
            primary_key = "TRC_ID0"

    print("header: {}".format(newHeader))
    print("first Line: {}".format(first_line))
    print("Last Line: {}".format(last_line))

    input_data_frame = pd.read_csv(input, sep=srcColSeparator, names=newHeader, engine="python",
                                   skipfooter=skipfooter, skiprows=skiprows, index_col=None, keep_default_na=False, header=None, dtype='string', skipinitialspace=True)

    count = input_data_frame.shape[0]
    print("input_data_frame rows: {}".format(count))
    print("input_data_frame columns: {}".format(len(input_data_frame.columns)))
    print(input_data_frame)

    #1 filter based on All columns except created_at/updated_at from column_types
    schema_for_dupe_check = list(newHeader)
    if 'created_at' in schema_for_dupe_check:
        schema_for_dupe_check.remove('created_at')
    if 'updated_at' in schema_for_dupe_check:
        schema_for_dupe_check.remove('updated_at')
    print("schema_for_dupe_check: {}".format(schema_for_dupe_check))
    #row_level_dupes = input_data_frame[input_data_frame.duplicated(subset=schema_for_dupe_check)]
    row_level_dupes = input_data_frame[input_data_frame.duplicated(subset=schema_for_dupe_check)]
    input_data_frame.drop_duplicates(subset=schema_for_dupe_check, inplace=True)
    print("row level dupes rows: {}".format(row_level_dupes.shape[0]))


    #2 run duplicated with just the primary key
    print("primary key column: {}".format(primary_key))
    #errored_dupes = input_data_frame[input_data_frame.duplicated(subset=primary_key)]
    # errored_dupes = input_data_frame[input_data_frame.duplicated(subset=primary_key)]
    # print("errored_df rows: {}".format(errored_dupes.shape[0]))
    #
    # input_data_frame.drop_duplicates(subset=primary_key, keep='first', inplace=True)
    # print("result_df rows: {}".format(input_data_frame.shape[0]))


    if stripFooter:
        col_list = last_line.split(srcColSeparator)
        if str(col_list[0]) == str("T"):  # Last line read should be a footer. FOP and Merge files
            footer_count = int(col_list[1])
        elif str(col_list[0]) == str("TR"):  # Last line read should be a footer. LQE files
            footer_count = int(col_list[2])
        else:
            raise ValueError(
                f"Malformed file. The last line read should've been a footer but is {srcColSeparator.join(col_list)}")
        if count != footer_count-file_offset:
            raise ValueError(
                f"The file contains {count} rows but the footer claims there are {footer_count} records.")

    #write dupes
    file_name = output.split('/')[-1]
    filtered_file_path = "~/data/processed/" + file_name + '.Filtered_Dupes.csv'
    row_level_dupes.to_csv(filtered_file_path, sep='|')
    #write errors:
    #errored_file_path = "~/data/processed/" + file_name + '.Errored_Dupes.csv'
    #errored_dupes.to_csv(errored_file_path, sep='|')

    if LQE_file_flag:
        input_data_frame.to_csv(output, sep=destination_column_separator, header=False, index=False, columns=newHeader)
        #copy to /SalesVision/sent "/home/edmfilemgr/data/sent/SalesVision/"
        print("copy file [{}] to [{}]".format(output, "/home/edmfilemgr/data/sent/SalesVision/"))
        shutil.copy(output, "/home/edmfilemgr/data/sent/SalesVision/")

    else:
        headerToWrite = list(newHeader)
        if 'deprecated' in input_data_frame.columns:
            print('removeing deprecated column')
            input_data_frame.drop(columns=['deprecated'], inplace=True)
            headerToWrite.remove('deprecated')

        print("data frame in final form:")
        print(input_data_frame)
        input_data_frame.to_csv(output, sep=destination_column_separator, header=True, index=False, columns=headerToWrite)

    return  build_stats(entities_list, cob, JobStatus.SUCCESS.value,  input_data_frame.shape[0], len(row_level_dupes), 0)
    # return {
    #     JobStatusLabels.COB.value: cob,
    #     JobStatusLabels.JOB_STATUS.value: JobStatus.SUCCESS.value,
    #     JobStatusLabels.CONTENTS.value: {JobStatusLabels.LOADED.value: input_data_frame.shape[0],
    #                                      JobStatusLabels.FILTERED.value: len(row_level_dupes),
    #                                      JobStatusLabels.ERRORED.value: 0 #len(errored_dupes)
    #                                      }
    # }


@calledByGetFromSFTPAndSendToS3
def transformFile(input, output, cob, stripHeader, stripFooter, srcColSeparator, targetColSeparator=None,
                  newHeader=None, file_offset=0, add_quotes_to_data=None, columnTypes=None, primaryKey=None, drop_columns=None, entities_list=[]):
    header = 1 if stripHeader else 0
    skip_num_of_lines_end = 1 if stripFooter else 0
    destination_column_separator = targetColSeparator if targetColSeparator else srcColSeparator

    with io.StringIO() as buf, redirect_stderr(buf):
        input_data_frame = pd.read_csv(input, sep=srcColSeparator, names=newHeader,
                                       skipfooter=skip_num_of_lines_end, header=header,  error_bad_lines=False,warn_bad_lines=True, dtype="string", keep_default_na=False)
        output_lines = buf.getvalue()
    print(output_lines)
    error_lines = list(filter(None, output_lines.split("\n")))
    num_of_valid_lines = len(input_data_frame)
    num_of_error_lines = len(error_lines)


    if stripFooter:
        df_last_line = pd.read_csv(input, sep=srcColSeparator, header=None, skipfooter=0,
                                   skiprows=num_of_valid_lines + num_of_error_lines + header + 1, error_bad_lines=True)

        predicate = df_last_line[0][0]

        if predicate == "T":  # Last line read should be a footer. FOP and Merge files
            footer_count = int(df_last_line[0][1])
        elif predicate == "TR":  # Last line read should be a footer. LQE files
            footer_count = int(df_last_line[0][2])
        else:
            raise ValueError(
                f"Malformed file. The last line read should've been a footer but is {df_last_line[0].to_string(index=False)}")
        total_lines = num_of_valid_lines + num_of_error_lines
        if total_lines != (footer_count - file_offset):
            raise ValueError(
                f"The file contains {total_lines} rows but the footer claims there are {footer_count} records.")


    if drop_columns:
            input_data_frame.drop(input_data_frame.columns[drop_columns], axis=1, inplace=True)

    input_data_frame.to_csv(output, quoting=csv.QUOTE_MINIMAL, sep=destination_column_separator, mode='w', header=True,
                            index=False, escapechar='\\')

    if len(error_lines) > 0:
        print(f"There were {len(error_lines)} when processing {input}.")
        for error in error_lines: print(f" {error}")
    print(f"{num_of_valid_lines} lines were successfully processed.")

    return build_stats(entities_list, cob, JobStatus.SUCCESS.value,  num_of_valid_lines, 0, num_of_error_lines)



def build_stats( entities_list , cob = None, status = JobStatus.SUCCESS.value , loaded_count =0, filtered_count=0, errored_count=0):
     return {
        JobStatusLabels.COB.value: cob,
        JobStatusLabels.JOB_STATUS.value: status,
        JobStatusLabels.CONTENTS.value: {JobStatusLabels.LOADED.value : create_dict_with_count(entities_list, loaded_count),
                                         JobStatusLabels.FILTERED.value: create_dict_with_count(entities_list, filtered_count),
                                         JobStatusLabels.ERRORED.value: create_dict_with_count(entities_list, errored_count)
                                         }
     }

def create_dict_with_count(entities_list, count):
    entity_count_dict ={}
    for entity in entities_list:
         entity_count_dict.update({entity : count})
    return entity_count_dict




#####Get from  DB  and Send to S3#######################

#################Database Connection ##############################
# def connect_to_oracle(env, data_source):
#     dsn = cx_Oracle.makedsn(ENVS[env][data_source]["server"], ENVS[env][data_source]["port"],
#                             ENVS[env][data_source]["sid"])
#     connect = cx_Oracle.connect(ENVS[env][data_source]["user"], get_password(env, data_source), dsn)
#     return connect


# def connect_to_sybase(env, data_source):
#     connect = sqlanydb.connect(userid=ENVS[env][data_source]["user"], password=get_password(env, data_source),
#                                host=ENVS[env][data_source]["server"] + ":" + ENVS[env][data_source]["port"])
#     return connect


# def get_password(env, data_source):
#     return get_secret(ENVS[env][data_source]["secret"], env)["pwd"]


# def copy_data_into_csv(connection, header, sql_query, csv_file_name):
#     try:
#         cursor = connection.cursor()
#         cursor.execute(sql_query)
#         rows = cursor.fetchall()
#         with open(csv_file_name, mode="w") as f:
#             csv_writer = csv.writer(f)
#             csv_writer.writerow(header)
#             csv_writer.writerows(rows)
#     finally:
#         if cursor:
#             cursor.close()
#         if connection:
#             connection.close()


def upload_to_S3(env, local_file_path_including_file_name, s3_bucket, s3_file_path):
    with S3(env) as s3:
        try:
            s3.send_file(f"{local_file_path_including_file_name}", s3_bucket, f"{s3_file_path}")
        except Exception as e:
            raise e


def check_and_create_dir(dir_path):
    if not os.path.isdir(dir_path):
        os.mkdirs(dir_path)


def get_from_DB_and_send_to_s3(env,  header, data_source,  sql_query, csv_file_name, s3_bucket,
                               s3_path_file_name, config_key=None):
    recieved_dir, sent_dir = get_recieve_and_sent_folder(data_source)
    recieved_file_path = recieved_dir + os.path.sep + csv_file_name

    env_key = config_key if config_key else data_source
    record_count = load_from_db_into_csv(env,  env_key, header, sql_query, recieved_file_path)

    sent_file_path = sent_dir + os.path.sep + csv_file_name
    shutil.copyfile(recieved_file_path, sent_file_path)
    os.system(f"gzip -f {sent_file_path}")
    csv_path_file_name = sent_file_path + ".gz"

    try:
            upload_to_S3(env, csv_path_file_name, s3_bucket, s3_path_file_name)
    except Exception as e :
        raise ValueError(e)

    return record_count
