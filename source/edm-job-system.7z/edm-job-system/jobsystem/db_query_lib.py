amg_fm_query = """
SELECT
        DISTINCT AM_PORTFOLIO2.MUTUAL_FUND_INDICATOR_CODE,
        AM_PORTFOLIO.portfolio_no,
        AM_PORTFOLIO.portfolio_no_char,
        AM_PORTFOLIO.ACCOUNT_LEGAL_NAME1,
        AM_PORTFOLIO.ACCOUNT_LEGAL_NAME2,
        AM_PORTFOLIO.ACCOUNT_LEGAL_NAME3,
        AM_PORTFOLIO.ACCOUNT_SHORT_NAME,
        PORTIA_PMF_T07_PRODUCT.PMF_T07_ID,
        AM_PORTFOLIO2.CLIENT_BUSINESS_CODE,
        AM_PORTFOLIO2.SERVICING_TYPE,
        AM_PORTFOLIO2.CRM_RELATIONSHIP_ID,
        AM_PORTFOLIO2.ACCOUNT_ADDR_LINE1,
        AM_PORTFOLIO2.ACCOUNT_ADDR_LINE2,
        AM_PORTFOLIO2.ACCOUNT_CITY,
        AM_PORTFOLIO2.ACCOUNT_STATE_CODE,
        AM_PORTFOLIO2.ACCOUNT_COUNTRY_CODE,
        AM_PORTFOLIO2.ACCOUNT_ZIP_CODE,
        AM_PORTFOLIO2.entity_code,
        CASE AM_PORTFOLIO.portfolio_no
                WHEN 13292
                THEN 'N'
                WHEN 17727
                THEN 'N'
                ELSE AM_PORTFOLIO2.DUMMY_YN
        END AS DUMMY_YN, -- Hardcodes dummy_yn='N' for portfolios 13292 and 17727
        AM_PORTFOLIO2.SEED_ACCOUNT_YN,
        AM_PORTFOLIO2.ACCOUNT_LOST_DATE,
        PORTIA_PMF_NEW.CURRENCY,
        PORTIA_PMF_NEW.INCEPTION_DATE,
        employee_master.lazard_id
FROM
        AM_PORTFOLIO
    LEFT JOIN
                (       SELECT
                    CONTACT_TYPE_CODE,
                    ACCOUNT_NO,
                    CONTACT_NO
                FROM
                    AM_ACCOUNT_CONTACT_XREF
                WHERE
                    CONTACT_TYPE_CODE IN
                    (
                    'BROKER',
                    'CLICON',
                    'CONSUL',
                    'CUADMN',
                    'CUASST',
                    'CUCORP',
                    'CUSCON',
                    'CUSDOM',
                    'CUSFX1',
                    'CUSFX2',
                    'CUSGLB',
                    'CUSMST',
                    'CUSSEN',
                    'CUSSUB',
                    'CUSTLE',
                    'CUSTOD',
                    'CUSTRD',
                    'CUSTTE',
                    'MAILCL',
                    'PRICLI'
                    )
                        ) cct_x
                ON AM_PORTFOLIO.account_no = cct_x.ACCOUNT_NO
    LEFT JOIN AM_CONTACT ON cct_x.CONTACT_NO = AM_CONTACT.CONTACT_NO
    LEFT JOIN AM_ADDRESSES ON AM_ADDRESSES.ADDRESS_CODE = AM_CONTACT.ADDRESS_CODE
    LEFT JOIN AM_PORTFOLIO2 ON AM_PORTFOLIO.account_no = AM_PORTFOLIO2.ACCOUNT_NO
    LEFT JOIN portia_pmf_new ON AM_PORTFOLIO.portfolio_no_char = portia_pmf_new.symbol
    LEFT JOIN portia_pmf_t07_product ON portia_pmf_t07_product.pmf_t07_udt_table_name = portia_pmf_new.product
    LEFT JOIN am_internal_contact
                ON (
                        am_internal_contact.account_no=am_portfolio.account_no
                        AND
                        am_internal_contact.internal_contact_type= 'CLNT_SVC_REP'
                        )
    LEFT JOIN AM_INTERNAL_CONTACT INTERNAL_CONTACT_CS_ASSOCIATE
                ON (
                        INTERNAL_CONTACT_CS_ASSOCIATE.account_no=AM_PORTFOLIO.account_no
                        and
                        INTERNAL_CONTACT_CS_ASSOCIATE.internal_contact_type='CS_ASSOCIATE'
                        )
    LEFT JOIN EMPLOYEE_MASTER EMPLOYEE_MASTER_UK_CS_ASSOC on EMPLOYEE_MASTER_UK_CS_ASSOC.employee_id=INTERNAL_CONTACT_CS_ASSOCIATE.employee_id
    LEFT JOIN employee_master ON am_internal_contact.employee_id= employee_master.employee_id
where
(
        (
                AM_PORTFOLIO2.account_status='ACTIVE'
                or
                (
                AM_PORTFOLIO2.account_status='TERMINATED'
            and
            AM_PORTFOLIO2.ACCOUNT_LOST_DATE > to_date('2018-12-31', 'YYYY-MM-DD')
                )
        )
        AND
        (
                -- Exclude MF-ONLY portfolios....  with exceptions below
                (
                        AM_PORTFOLIO2.MUTUAL_FUND_INDICATOR_CODE != 'MF-ONLY'
                        OR
                        AM_PORTFOLIO2.MUTUAL_FUND_INDICATOR_CODE IS NULL
                )
                -- Include MF-ONLY portfolios if related to a London/Dubai CS_Associate
                OR
                (
                        EMPLOYEE_MASTER_UK_CS_ASSOC.curr_location_city in ('London', 'Dubai')
                        and
                        --EMPLOYEE_MASTER_UK_CS_ASSOC.opsysid<>'BARBERM'
                        EMPLOYEE_MASTER_UK_CS_ASSOC.ps_deptid_desc<>'LAM Mutual Funds Support'
                        and
                        AM_PORTFOLIO2.MUTUAL_FUND_INDICATOR_CODE = 'MF-ONLY'
                )
        )
        AND
        (
            -- Remove most Funds
                AM_PORTFOLIO2.entity_code != 'FUNDS'
                OR
                (
                    -- Include Funds only if they are Sub-Advised or MF-Only
                        AM_PORTFOLIO2.ENTITY_CODE='FUNDS'
                        AND
                        (
                AM_PORTFOLIO2.vehicle_code='SUB-ADVISED'
                or
                -- Include MF-Only Funds
                AM_PORTFOLIO2.MUTUAL_FUND_INDICATOR_CODE = 'MF-ONLY'
                        )
                )
        )
        AND
        (
                AM_PORTFOLIO2.CLIENT_BUSINESS_CODE != 'EMPLOY'
                OR
                AM_PORTFOLIO2.CLIENT_BUSINESS_CODE IS NULL
        )
)
"""

ldw_batch_query = """ 
select s.as_of_date
    , s.portfolio_symbol
    , s.portfolio_currency_symbol
    , sum(case s.security_class when 'Option' then s.mv_physical_port_cur else s.mv_port_cur end) mv
from mensa.am_ror_hld s
inner join apoprod.pmf p on (s.portfolio_symbol = p.symbol)
where s.as_of_date <= '{ldw_end_date}' and s.as_of_date >= '{ldw_start_date}' -- for some reason, there are future-dated holdings in there. We need to ignore that.
    and p.system_stat = 0
    and p.pmf_string_06 != ' '  -- not a combo (Combo Acct Name is blank)
    and (
        ((p.pmf_table_08 = 3 or p.pmf_table_08 = 23) and p.inception_date <= getdate())
        or (p.pmf_table_08 = 6 and p.termination_dt > getdate())
        )    
group by s.as_of_date, s.portfolio_symbol, s.portfolio_currency_symbol
order by s.as_of_date asc
"""

ldw_flow_query = """ 
-- SET THESE VARIABLES TO THE BEGIN AND END DATE VALUES
declare @begin_date date, @end_date date
select @begin_date='{ldw_start_date}'
select @end_date='{ldw_end_date}'
--Find portfolios that are active and real
create table #cm_pmf_ids (id recnum not null)
insert into #cm_pmf_ids
select id
from apoprod.pmf
where system_stat = 0
and pmf_string_06 != ' '  -- not a combo (Combo Acct Name is blank)
and (
        ((pmf_table_08 = 3 or pmf_table_08 = 23) and inception_date <= getdate())
        or (pmf_table_08 = 6 and termination_dt > getdate())
    )
--RKS corrections delete the old one and a new one re-appears.
--Portia handles corrections by changing the old entry to tran_status = 30 (ignored) and creating a new one with tran_status < 10 (captured here)
create table #aum_flow_cm (
    pmf_id                RECNUM       not null,
    pmf_symbol            varchar(15)  not null,
    smf_id                RECNUM       not null,
    smf_desc              MPDESCSTR    not null,
    tran_trade_date       DATEtime     not null,
    tran_type             varchar(3)   not null,
    tran_type_desc        varchar(40)  not null,
    tran_remark           varchar(3)   not null,
    tran_remark_desc      varchar(40)  not null,
    port_cur_iso3         MPSTR5       not null,
    flow_port_cur         MPDOUBLE     null
)
--Security Flows
insert into #aum_flow_cm
select distinct a.portfolio
    , p.symbol
    , a.security
    , s.description1
    , a.tran_date
    , convert(varchar(3),a.tran_type)
    , e.portia_description
    , convert(varchar(3),t4.id)
    , t4.description
    , cp.currency_symbol
    , isnull(((a.principal_value + a.interest_value) * hp.xrate) / nullif(hs.xrate,0),0)
from apoprod.mtf a
inner join apoprod.tran_type_ext e on (a.tran_type = e.id)
inner join apoprod.mtfudf u on (a.TF_GROUP = u.tf_group and a.mtf_userdefined = u.id)
inner join apoprod.smf s on (a.security = s.id)
inner join apoprod.pmf p on (a.portfolio = p.id)
inner join apoprod.mtf_t04 t4 on (u.table_04 = t4.id)
inner join apoprod.cur cp on (p.currency = cp.id)
inner join mensa.am_ror_hld h on h.portfolio_symbol = p.symbol and h.as_of_date = @end_date
inner join #cm_pmf_ids temp_ids on temp_ids.id = a.portfolio  -- This is a change. Inner join only on the id's, not on dates as we want batch.
left join apoprod.hfx hp on (hp.rate_date <= a.tran_date and   hp.end_date >= a.tran_date and p.currency = hp.currency)
left join apoprod.hfx hs on (hs.rate_date <= a.tran_date and   hs.end_date >= a.tran_date and s.currency = hs.currency)
where
a.tran_date between @begin_date and @end_date
and s.unmanaged_asset = 0 // Exclusion of Unmanaged Holdings
and a.tran_status < 10
and hp.source = 1 and hp.rate_type = 1
and hs.source = 1 and hs.rate_type = 1
and (
        (a.tran_type = 5 and u.table_04 in (66,42))
        or (a.tran_type = 103 and u.table_04 in (66))
    )
--Cash Flows
insert into #aum_flow_cm
select distinct a.portfolio
    , p.symbol
    , a.security
    , s.description1
    , a.trade_date
    , convert(varchar(3),a.tran_type)
    , e.portia_description
    , convert(varchar(3),t4.id)
    , t4.description
    , cp.currency_symbol
    , isnull(a.total_amount / nullif(a.sec_port_xrate,0),0)
from apoprod.mtf a
inner join apoprod.tran_type_ext e on (a.tran_type = e.id)
inner join apoprod.mtfudf u on (a.TF_GROUP = u.tf_group and a.mtf_userdefined = u.id)
inner join apoprod.smf s on (a.security = s.id)
inner join apoprod.pmf p on (a.portfolio = p.id)
inner join apoprod.mtf_t04 t4 on (u.table_04 = t4.id)
inner join apoprod.cur cp on (p.currency = cp.id)
inner join mensa.am_ror_hld h on h.portfolio_symbol = p.symbol and h.as_of_date = @end_date
inner join #cm_pmf_ids temp_ids on temp_ids.id = a.portfolio  -- This is a change. Inner join only on the id's, not on dates as we want batch.
where
a.trade_date between @begin_date and @end_date
and s.unmanaged_asset = 0 //Exclusion of Unmanaged Holdings
and a.tran_status < 10
and (
        (a.tran_type = 175 and u.table_04 not in (54,17,65,56,57,60,71,151))
        or (a.tran_type = 78 and u.table_04 not in (28,54,17,65,56,57,60,71,151))
    )
--select pmf_symbol, tran_trade_date, tran_type || '-' || tran_remark tran_type_remark, tran_type_desc, case WHEN tran_type in ('5','78') THEN 'Inflow' WHEN tran_type in ('103','175') THEN 'Outflow' ELSE '' END as flow_type, port_cur_iso3, round(sum(flow_port_cur),2) flow_port_cur
--from #aum_flow_cm
--group by pmf_symbol, tran_trade_date, tran_type_remark,tran_type_desc, flow_type, port_cur_iso3
--order by tran_trade_date asc
--drop table #aum_flow_cm
--drop table #cm_pmf_ids
select pmf_symbol, tran_trade_date, tran_type || '-' || tran_remark tran_type_remark, port_cur_iso3, round(sum(flow_port_cur),2) flow_port_cur
from #aum_flow_cm
group by pmf_symbol, tran_trade_date, tran_type, tran_remark, port_cur_iso3
order by tran_trade_date asc
drop table #aum_flow_cm
drop table #cm_pmf_ids
"""

fx_rate_conversion_query = """
select  cur_b.currency_symbol currency_symbol_b, 
        hfx_b.xrate xrate_b,
        cur_f.currency_symbol currency_symbol_f, 
        hfx_f.xrate xrate_f,
        hfx_f.xrate/hfx_b.xrate xrate_b_f,
        convert(char(20), hfx_b.rate_date, 20),
        convert(char(20), hfx_b.end_date, 20)
from    apoprod.cur cur_b,
        apoprod.hfx hfx_b, 
        apoprod.cur cur_f, 
        apoprod.hfx hfx_f  
where   hfx_b.rate_date in ({0}) 
and     hfx_b.end_Date >= hfx_b.rate_date
and     hfx_f.rate_date = hfx_b.rate_date
and     hfx_f.end_date >= hfx_f.rate_date
and     hfx_b.rate_type = 1 and hfx_b.source = 1
and     hfx_f.rate_type = 1 and hfx_f.source = 1
and     hfx_b.xrate > 0 and hfx_f.xrate > 0
and     cur_b.currency_symbol in ('AUD', 'CAD', 'CHF', 'DKK', 'EUR', 'GBP', 'HKD', 'JPY', 'KRW', 'NOK', 'NZD', 'SGD', 'SEK', 'AED')
and     cur_f.currency_symbol in ('AUD', 'CAD', 'CHF', 'DKK', 'EUR', 'GBP', 'HKD', 'JPY', 'KRW', 'NOK', 'NZD', 'SGD', 'SEK', 'AED')
and     hfx_b.currency = cur_b.id
and     hfx_f.currency = cur_f.id
--order by hfx_b.rate_date, cur_b.currency_symbol, cur_f.currency_symbol  
UNION  
select  'USD' currency_symbol_b, 
        1 xrate_b,
        cur_f.currency_symbol currency_symbol_f, 
        hfx_f.xrate xrate_f,
        hfx_f.xrate xrate_b_f,
        convert(char(20), hfx_f.rate_date, 20),
        convert(char(20), hfx_f.end_date, 20)
from    apoprod.cur cur_f, 
        apoprod.hfx hfx_f  
where   hfx_f.rate_date in ({0}) 
and     hfx_f.end_Date >= hfx_f.rate_date
and     hfx_f.rate_type = 1 and hfx_f.source = 1
and     hfx_f.xrate > 0
and     cur_f.currency_symbol in ({1})
and     hfx_f.currency = cur_f.id
--order by hfx_f.rate_date, cur_f.currency_symbol, cur_f.currency_symbol  
UNION  
select  cur_b.currency_symbol currency_symbol_b, 
        hfx_b.xrate xrate_b,
        'USD' currency_symbol_f, 
        1 xrate_f,
        1 / hfx_b.xrate xrate_b_f,
        convert(char(20), hfx_b.rate_date, 20),
        convert(char(20), hfx_b.end_date, 20)
from    apoprod.cur cur_b, 
        apoprod.hfx hfx_b  
where   hfx_b.rate_date in ({0}) 
and     hfx_b.end_Date >= hfx_b.rate_date
and     hfx_b.rate_type = 1 and hfx_b.source = 1
and     hfx_b.xrate > 0
and     cur_b.currency_symbol in ({1})
and     hfx_b.currency = cur_b.id
--order by hfx_b.rate_date, cur_b.currency_symbol, cur_b.currency_symbol  
UNION  
-- Add a rows for USD to USD for completeness.
select  'USD' currency_symbol_b, 
        1 xrate_b,
        'USD' currency_symbol_f, 
        1 xrate_f,
        1 xrate_b_f,
        convert(char(20), hfx_b.rate_date, 20),
        convert(char(20), hfx_b.end_date, 20)
from    apoprod.cur cur_b, 
        apoprod.hfx hfx_b  
where   hfx_b.rate_date in ({0}) 
and     hfx_b.end_Date >= hfx_b.rate_date
and     hfx_b.rate_type = 1 and hfx_b.source = 1
and     hfx_b.xrate > 0
and     cur_b.currency_symbol in ('EUR')
and     hfx_b.currency = cur_b.id
"""
