import csv
import hashlib
import json
import os
import shutil
from datetime import datetime

import pandas as pd
from psycopg2.errors import UndefinedTable

from business_model import FXRateElement
from common.aws import S3
from common.database import db_connection_factory
from common.enums import JobStatusLabels, JobStatus, OpsWiseParametersNames, JobsParameter
from common.envconfig import ENVS
from common.utils import datetime_range, gzipFile
from common_FM import getFromSFTPAndSendToS3, check_and_create_dir, get_from_DB_and_send_to_s3, get_file,get_recieve_and_sent_folder, move_to_s3, build_stats
from db_query_lib import amg_fm_query, ldw_batch_query, ldw_flow_query

fileLoadingData = [{"fileName": "firm",
                    "transformArgs": {"cob": "Not Used Yet",
                                        "stripHeader": True,
                                        "stripFooter": True,
                                        "srcColSeparator": '|',
                                        "targetColSeparator": ',',
                                        "headerSchema": ['firm_id', 'firm_name', 'Firm_address_1', 'Firm_address_2', 'city', 'state', 'zip',
                                                      'country', 'crm',
                                                      'event_code', 'some_field_2', 'some_field_3', 'client_type', 'some_field_5',
                                                      'created_at', 'created_by', 'updated_at', 'updated_by'],
                                        "add_quotes_to_data": True,
                                        "column_types": {
                                                         'firm_id': int,
                                                         'firm_name': str,
                                                         'address_line_1': str,
                                                         'address_line_2': str,
                                                         'address_city': str,
                                                         'address_state': str,
                                                         'address_zip': str,
                                                         'address_country': str,
                                                         'crm_firm_id': str,
                                                         'event_code': ['I', 'U', 'D'],
                                                         'crm_svc_req_id': str,
                                                         'created_at': "date:%Y%m%d",
                                                         'created_by': str,
                                                         'updated_at': "date:%Y%m%d",
                                                         'updated_by': str
                                                         },
                                        "primary_key": ["firm_id"],
                                        "RDS_Header": ["entity_id","persistence_id","salesvision_id","salesforce_id", "entity_name","street_address_1","street_address_2","city","state",
                                                       "postal_code","country","created_at","updated_at"],
                                        "RDS_Query": """select  e.entity_id, e.persistence_id, e.salesvision_id, e.salesforce_id, e.entity_name, addr.street_address_1, addr.street_address_2, addr.city, addr.state, addr.postal_code, addr.country,
                                                               e.created_at, e.updated_at
                                                        from stg_@STAGING_SWITCH@_entity e
                                                        left join stg_@STAGING_SWITCH@_entity_address_xref addr
                                                        on e.entity_id = addr.entity_id  and 
                                                             (addr.ended_at = 'None' or addr.ended_at is null)
                                                        where e.entity_type_id like '30%' and
                                                             --e.salesvision_id != 'None' and 
                                                             (e.ended_at = 'None' or e.ended_at is null)
                                                        order by street_address_1"""
                                      }
                    },
                    {
                        "fileName": "office",
                        "transformArgs": {"cob": "Not Used Yet", "stripHeader": True, "stripFooter": True, "srcColSeparator": '|',
                                        "targetColSeparator": ',', "headerSchema": ['firm_id', 'office_id', 'office_address_1', 'office_address_2', 'office_address_3', 'city', 'state',
                                        'zip', 'country', 'CRM',
                                        'some_field_1', 'event_code', 'some_field_3', 'some_field_4', 'some_field_5',
                                        'created_at', 'created_by', 'updated_at', 'updated_by'],
                                        'column_types': {
                                                    'firm_id': int,
                                                    'office_id': int,
                                                    'firm_name': str,
                                                    'address_line_1': str,
                                                    'address_line_2': str,
                                                    'address_line_3': str,
                                                    'address_city': str,
                                                    'address_state': str,
                                                    'address_zip': str,
                                                    'address_country': str,
                                                    'crm_firm_id': str,
                                                    'crm_office_id': str,
                                                    'event_code': ['I', 'U', 'D'],
                                                    'crm_svc_req_id': str,
                                                    'created_at': "date:%Y%m%d",
                                                    'created_by': str,
                                                    'updated_at': "date:%Y%m%d",
                                                    'updated_by': str
                                        },
                                        'primary_key': ["office_id"],
                                        "RDS_Header": ["firm_persistence_id", "firm_salesvision_id", "entity_id", "persistence_id", "salesvision_id", "salesforce_id", "entity_name",
                                                     "street_address_1", "street_address_2", "city", "state",
                                                     "postal_code", "country", "created_at", "updated_at"],
                                        "RDS_Query": """select parent.persistence_id firm_persistence_id, parent.salesvision_id firm_salesvision_id,
                                                               e.entity_id, e.persistence_id, e.salesvision_id, e.salesforce_id, e.entity_name, addr.street_address_1, addr.street_address_2, 
                                                               addr.city, addr.state, addr.postal_code, addr.country, e.created_at, e.updated_at
                                                        from stg_@STAGING_SWITCH@_entity e
                                                        inner join stg_@STAGING_SWITCH@_entity parent
                                                            on e.parent_id = parent.entity_id and
                                                                e.entity_type_id like '20%' and
                                                                --e.salesvision_id != 'None' and 
                                                                e.ended_at is null and 
                                                                parent.ended_at is null 
                                                                --and parent.salesvision_id != 'None'
                                                        left join stg_@STAGING_SWITCH@_entity_address_xref addr
                                                            on e.entity_id = addr.entity_id and
                                                            addr.ended_at is null
                                                        order by addr.street_address_1"""
                                          }
                      },
                   {
                        "fileName": "person",
                        "transformArgs": {"cob": "Not Used Yet", "stripHeader": True, "stripFooter": True, "srcColSeparator": '|',
                                        "targetColSeparator": ',', "headerSchema": ['firm_id', 'office_id', 'person_id', 'last_name', 'first_name', 'middle_name', 'broker_team',
                                        'crm_firm_id', 'crm_office_id', 'crm_person_id', 'event_code', 'crm_svc_req_id', 'person_status',
                                        'home_office_flag', 'phone_number', 'email_address', 'crd_number', 'broker_rep_code',
                                        'created_at', 'created_by', 'updated_at', 'updated_by'],
                                        'column_types': {
                                                    'firm_id': int,
                                                    'office_id': int,
                                                    'person_id': int,
                                                    'name_last': str,
                                                    'name_first': str,
                                                    'name_middle': str,
                                                    'broker_team': ['Y', 'N'],
                                                    'crm_firm_id': str,
                                                    'crm_office_id': str,
                                                    'crm_person_id': str,
                                                    'event_code': ['I', 'U', 'D'],
                                                    'crm_svc_req_id': str,
                                                    'person_status': str,
                                                    'home_office_flag': ['Y', 'N'],
                                                    'phone': 'phone',
                                                    'email': 'email',
                                                    'crd_number': str,
                                                    'broker_rep_code': int,
                                                    'created_at': "date:%Y%m%d",
                                                    'created_by': str,
                                                    'updated_at': "date:%Y%m%d",
                                                    'updated_by': str},
                                        'primary_key': ["person_id"],
                                        "RDS_Header": ["firm_persistence_id", "firm_salesvision_id", "office_persistence_id", "office_salesvision_id",
                                                     "persistence_id", "salesvision_id", "salesforce_id", "entity_name",
                                                     "street_address_1", "street_address_2", "city", "state",
                                                     "postal_code", "country", "created_at", "updated_at", "phone_number", "email_address"],
                                        "RDS_Query": """select grandparent.persistence_id firm_persistence_id, grandparent.salesvision_id firm_salesvision_id,
                                                            parent.persistence_id office_persistence_id, parent.salesvision_id office_salesvision_id,
                                                            e.persistence_id, e.salesvision_id, e.salesforce_id, e.entity_name, 
                                                            addr.street_address_1, addr.street_address_2, addr.city, addr.state, addr.postal_code, addr.country,
                                                            e.created_at, e.updated_at, phone.phone_number, email.email_address
                                                            from stg_@STAGING_SWITCH@_entity e 
                                                            inner join stg_@STAGING_SWITCH@_entity parent 
                                                               on e.parent_id = parent.entity_id and
                                                                  e.entity_type_id like '10%' and
                                                                  --e.salesvision_id != 'None' and 
                                                                  e.ended_at is null and
                                                                  parent.ended_at is null 
                                                                  --and parent.salesvision_id != 'None' 
                                                            inner join stg_@STAGING_SWITCH@_entity grandparent 
                                                             on parent.parent_id = grandparent.entity_id and
                                                                grandparent.ended_at is null 
                                                                --and grandparent.salesvision_id != 'None'
                                                            left join stg_@STAGING_SWITCH@_entity_address_xref addr 
                                                             on  e.entity_id = addr.entity_id and
                                                                addr.ended_at is null  
                                                            left join stg_@STAGING_SWITCH@_entity_email_xref email 
                                                             on  e.entity_id = email.entity_id and
                                                                 email.ended_at is null and
                                                                 email.email_type_id = '1' 
                                                            left join stg_@STAGING_SWITCH@_entity_phone_xref phone
                                                             on  e.entity_id = phone.entity_id and
                                                                 phone.ended_at is null and
                                                                 phone.phone_type_id = '1'
                                                            order by addr.street_address_1"""

                                        }
                    },                   {
                        "fileName": "merge",
                        "transformArgs": {"cob": "Not Used Yet", "stripHeader": True, "stripFooter": True, "srcColSeparator": '|',
                                        "targetColSeparator": ',', "headerSchema": ['merge_type','sv_from_id','sv_to_id','crm_from_id','crm_to_id','deprecated'],
                                        'column_types': {"entity_type":['F','O','P'], "sv_from_id":int, "sv_to_id":int, "crm_from_id":str, "crm_to_id":str},
                                        'primary_key': ["sv_from_id"],
                                        "RDS_Header": [],
                                        "RDS_Query": ""
                                        }
                    }
                   ]


def getTransformArgsData(filename):
    #todo: consider expanding to use datasource if needed
    result = None
    for fld in fileLoadingData:
        if fld['fileName'] == filename:
            result = fld['transformArgs']
            break
    return result

def getItemInList(inputList, attribute, valuetomatch, ouputattribute):
    result = None
    for item in inputList:
        if item[attribute] == valuetomatch:
            result = item[ouputattribute]
            break
    return result

def get_md5_hash(input):
    return hashlib.md5(str(input).encode('utf-8')).hexdigest()


def processSalesVisionFirmOfficePeopleMerge(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None, parameters=None, dryRun=None):
    firm_record_count = 0
    office_record_count = 0
    person_record_count = 0
    firmTransformArgs = getTransformArgsData('firm')
    officeTransformArgs = getTransformArgsData('office')
    personTransformArgs = getTransformArgsData('person')
    mergeTransformArgs = getTransformArgsData('merge')
    # mergeTransformArgs["entities_list"] = parameters[JobsParameter.STATS_TABLE_LIST.value]

    firm_SV = None
    office_SV = None
    person_SV = None
    merge_SV = None

    firm_filtered_records = pd.DataFrame()
    firm_errored_records = pd.DataFrame()
    office_filtered_records = pd.DataFrame()
    office_errored_records = pd.DataFrame()
    person_filtered_records = pd.DataFrame()
    person_errored_records = pd.DataFrame()

    for input in inputs:
        print("input: {}".format(input))

    source_target = []

    for input in inputs:
        input_file_name = list(input.values())[0]
        source, target, received_dir, remote_dir = get_file(env,
                                                            dataSource=parameters[OpsWiseParametersNames.DATASOURCE.value],
                                                            input=input_file_name)
        stats_file = None
        if 'firm' in input_file_name:
            stats_file = 'firm'
            firm_SV = getDataFrame(firmTransformArgs['headerSchema'], input_file_name)
            print("firm dataframe record count {}".format(firm_SV.shape[0]))
        if 'office' in input_file_name:
            stats_file = 'office'
            office_SV = getDataFrame(officeTransformArgs['headerSchema'], input_file_name)
            print("office dataframe record count {}".format(office_SV.shape[0]))
        if 'person' in input_file_name:
            stats_file = 'person'
            person_SV = getDataFrame(personTransformArgs['headerSchema'], input_file_name)
            print("person dataframe record count {}".format(person_SV.shape[0]))
        if 'merge' in input_file_name:
            stats_file = 'merge'
            merge_SV = getDataFrame(mergeTransformArgs['headerSchema'], input_file_name)
            print("merge dataframe record count {}".format(merge_SV.shape[0]))
        source_target.append({'file': stats_file, "filestats": {"source": source, "target": target, "received_dir": received_dir, "remote_dir": remote_dir}})

    if merge_SV is not None and merge_SV.shape[0] > 0:
        merge_SV.columns = ['merge_type','person_id','sv_to_id','crm_from_id','crm_to_id','deprecated']
        merge_SV.set_index(['person_id'])

        print(merge_SV)
        print(merge_SV.merge_type)
        #split into seperate df's based on merge type merge_type
        firm_merge_SV = merge_SV[merge_SV.merge_type == 'F']
        print("Firm Merge dataframe records {}".format(firm_merge_SV.shape[0]))
        office_merge_SV = merge_SV[merge_SV.merge_type == 'O']
        print("Office Merge dataframe records {}".format(office_merge_SV.shape[0]))
        person_merge_SV = merge_SV[merge_SV.merge_type == 'P']
        print("person Merge dataframe records {}".format(person_merge_SV.shape[0]))

        # #firm
        #firm_merge_SV = ['merge_type','person_id','sv_to_id','crm_from_id','crm_to_id','deprecated']
        #firm_merge_SV.set_index(['person_id'])

        updates_deletes_firm_SV = firm_SV[firm_SV['firm_id'].isin(firm_merge_SV['person_id'])]
        number_u = updates_deletes_firm_SV[(updates_deletes_firm_SV['firm_id'].isin(firm_merge_SV['person_id'])) & (updates_deletes_firm_SV.event_code == 'U')].shape[0]
        number_d = updates_deletes_firm_SV[(updates_deletes_firm_SV['firm_id'].isin(firm_merge_SV['person_id'])) & (updates_deletes_firm_SV.event_code == 'D')].shape[0]

        updates_deletes_firm_SV["Error Message"] = "contains record in merge file"
        print('firm number_d: {}'.format(number_d))
        print('firm number_u: {}'.format(number_u))
        if number_d == number_u:
            firm_filtered_records = pd.concat([firm_filtered_records, updates_deletes_firm_SV], ignore_index=True)
            print('adding {} firm records to Filtered dataframe collection'.format(updates_deletes_firm_SV.shape[0]))
        else:
            firm_errored_records = pd.concat([firm_errored_records, updates_deletes_firm_SV], ignore_index=True)
            print('adding {} firm records to filtered dataframe collection'.format(updates_deletes_firm_SV.shape[0]))

        firm_SV = firm_SV[~firm_SV['firm_id'].isin(firm_merge_SV['person_id'])]

        #office

        updates_deletes_office_SV = office_SV[office_SV['office_id'].isin(office_merge_SV['person_id'])]

        number_u = updates_deletes_office_SV[(updates_deletes_office_SV['office_id'].isin(office_merge_SV['person_id'])) & (updates_deletes_office_SV.event_code == 'U')].shape[0]
        number_d = updates_deletes_office_SV[(updates_deletes_office_SV['office_id'].isin(office_merge_SV['person_id'])) & (updates_deletes_office_SV.event_code == 'D')].shape[0]
        print('office number_d: {}'.format(number_d))
        print('office number_u: {} '.format(number_u))
        if number_d == number_u:
            office_filtered_records = pd.concat([office_filtered_records, updates_deletes_office_SV], ignore_index=True)
            print('adding {} office records to Filtered dataframe collection'.format(updates_deletes_office_SV.shape[0]))
            print('office_filtered_records count:{}'.format(office_filtered_records.shape[0]))
        else:
            office_errored_records = pd.concat([office_errored_records, updates_deletes_office_SV], ignore_index=True)
            print('adding {} office records to filtered dataframe collection'.format(updates_deletes_office_SV.shape[0]))
            print('office_errored_records count: {}'.format(updates_deletes_office_SV.shape[0]))

        #person
        updates_deletes_person_SV = person_SV[person_SV['person_id'].isin(person_merge_SV['person_id'])]
        number_u = updates_deletes_person_SV[(updates_deletes_person_SV['person_id'].isin(person_merge_SV['person_id'])) & (updates_deletes_person_SV.event_code == 'U')].shape[0]
        number_d = updates_deletes_person_SV[(updates_deletes_person_SV['person_id'].isin(person_merge_SV['person_id'])) & (updates_deletes_person_SV.event_code == 'D')].shape[0]
        print('person number_d: {}'.format(number_d))
        print('person number_u: {}'.format(number_u))
        if number_d == number_u:
            person_filtered_records = pd.concat([person_filtered_records, updates_deletes_person_SV], ignore_index=True)
            print('adding {} person records to Filtered dataframe collection'.format(updates_deletes_person_SV.shape[0]))
        else:
            person_errored_records = pd.concat([person_errored_records, updates_deletes_person_SV], ignore_index=True)
            print('adding {} person records to filtered dataframe collection'.format(updates_deletes_person_SV.shape[0]))


    #filter out unknowns
    firm_unknown_records = firm_SV.loc[firm_SV['firm_name'].str.contains('UNKNOWN - CRM Firm Id')]
    print('filtering out {} firm records with UNKNOWN - CRM Firm ID in firm_name'.format(firm_unknown_records.shape[0]))
    firm_SV = firm_SV[~firm_SV['firm_name'].str.contains('UNKNOWN - CRM Firm Id')]
    firm_unknown_records["Error Message"] = "contains UNKNOWN"
    firm_filtered_records = pd.concat([firm_filtered_records, firm_unknown_records], ignore_index=True)


    office_unknown_records = office_SV.loc[office_SV['office_address_1'].str.contains('UNKNOWN - CRM Office Id')]
    print('filtering out {} office records with UNKNOWN - CRM Firm ID in office_address_1'.format(office_unknown_records.shape[0]))
    office_SV = office_SV[~office_SV['office_address_1'].str.contains('UNKNOWN - CRM Firm Id')]
    office_unknown_records["Error Message"] = "contains UNKNOWN"
    office_filtered_records = pd.concat([office_filtered_records, office_unknown_records], ignore_index=True)

    #filter out updates from update delete events (update and delete are dupes asside from event code, U, D)
    firm_SV, UD_event_firm_errored_records = UpdateDeleteEventfilter(firm_SV,  'firm_id')
    firm_errored_records = pd.concat([firm_errored_records, UD_event_firm_errored_records], ignore_index=True)

    office_SV, UD_event_office_errored_records = UpdateDeleteEventfilter(office_SV, 'office_id')
    office_errored_records = pd.concat([office_errored_records,UD_event_office_errored_records], ignore_index=True)

    person_SV, UD_event_person_errored_records = UpdateDeleteEventfilter(person_SV, 'person_id')
    person_errored_records = pd.concat([person_errored_records,UD_event_person_errored_records], ignore_index=True)

    # Get the firm in CM whose CM IDs are hashes of the SF IDs
    firm_CM = getQueryResult(env, firmTransformArgs["RDS_Query"], firmTransformArgs['RDS_Header'])
    if firm_CM is not None and firm_SV.shape[0] > 0:
        # firm
        print("firm_SV initial count {}".format(firm_SV.shape[0]))
        # Get the firm loaded from SV whose CM IDs are not hashes of the SV IDs
        firm_SV['SV_firm_id_hash_to_check'] = firm_SV.apply(lambda x: get_md5_hash(x['firm_id'] + '_firm'), axis=1)
        firm_SV_no_md5_match = firm_SV.loc[~firm_SV['SV_firm_id_hash_to_check'].eq(firm_SV['crm']) & ~firm_SV['crm'].eq('')]

        firm_CM['SF_firm_id_hash_to_check'] = firm_CM.apply(lambda x: get_md5_hash(x['salesforce_id']), axis=1)
        firm_CM_SF_md5_match = firm_CM.loc[firm_CM['SF_firm_id_hash_to_check'].eq(firm_CM['persistence_id']) & ~firm_CM['persistence_id'].eq('')]

        # Are the firm loaded from SV whose CM IDs are not hashes of the SV IDs, hashes of the SF IDs
        firm_SV_matched_SF_id = firm_SV_no_md5_match.loc[firm_SV_no_md5_match['crm'].isin(firm_CM_SF_md5_match['SF_firm_id_hash_to_check'])]

        # the following are errors
        firm_SV_no_md5_match = firm_SV_no_md5_match.loc[~firm_SV_no_md5_match['crm'].isin(firm_CM_SF_md5_match['SF_firm_id_hash_to_check'])]
        firm_SV = firm_SV.loc[~(firm_SV['crm'].isin(firm_SV_no_md5_match['crm']))]

        print("firm: firm_SV final count {}".format(firm_SV.shape[0]))
        print("firm: firm_SV_no_md5_match count {}".format(firm_SV_no_md5_match.shape[0]))
        print("firm: firm_CM count {}".format(firm_CM.shape[0]))
        print("firm: firm_CM_SF_md5_match count {}".format(firm_CM_SF_md5_match.shape[0]))
        print("firm: firm_SV_matched_SF_id count: {}".format(firm_SV_matched_SF_id.shape[0]))

        firm_SV_no_md5_match["Error Message"] = "Persistence ID not an md5 hash of SF or SV IDs"
        #merge firm md5 errors with other firm errors:
        firm_errored_records = pd.concat([firm_errored_records, firm_SV_no_md5_match],ignore_index=True)


    # Get the offices in CM whose CM IDs are hashes of the SF IDs
    office_CM = getQueryResult(env, officeTransformArgs["RDS_Query"], officeTransformArgs['RDS_Header'])
    if office_CM is not None and office_SV.shape[0]:
        # office
        print("office_SV initial count {}".format(office_SV.shape[0]))

        # Get the offices loaded from SV whose CM IDs are not hashes of the SV IDs
        office_SV['SF_office_id_hash_to_check'] = office_SV.apply(lambda x: get_md5_hash(x['office_id'] + '_office'), axis=1)
        office_SV_no_md5_match = office_SV.loc[~office_SV['SF_office_id_hash_to_check'].eq(office_SV['some_field_1']) & ~office_SV['some_field_1'].eq('')]

        office_CM['SF_office_id_hash_to_check'] = office_CM.apply(lambda x: get_md5_hash(x['salesforce_id']), axis=1)
        office_CM_SF_md5_match = office_CM.loc[office_CM['SF_office_id_hash_to_check'].eq(office_CM['persistence_id']) & ~office_CM['persistence_id'].eq('')]

        # Are the offices loaded from SV whose CM IDs are not hashes of the SV IDs, hashes of the SF IDs
        office_SV_matched_SF_id = office_SV_no_md5_match.loc[office_SV_no_md5_match['some_field_1'].isin(office_CM_SF_md5_match['SF_office_id_hash_to_check'])]

        # the following are errors
        office_SV_no_md5_match = office_SV_no_md5_match.loc[~office_SV_no_md5_match['some_field_1'].isin(office_CM_SF_md5_match['SF_office_id_hash_to_check'])]
        office_SV = office_SV.loc[~(office_SV['some_field_1'].isin(office_SV_no_md5_match['some_field_1']))]

        print("office: office_SV final count {}".format(office_SV.shape[0]))
        print("office: office_SV_no_md5_match count {}".format(office_SV_no_md5_match.shape[0]))
        print("office: office_CM count {}".format(office_CM.shape[0]))
        print("office: office_CM_SF_md5_match count {}".format(office_CM_SF_md5_match.shape[0]))
        print("office: office_SV_matched_SF_id count: {}".format(office_SV_matched_SF_id.shape[0]))
        office_SV_no_md5_match["Error Message"] = "Persistence ID not an md5 hash of SF or SV IDs"
        office_errored_records = pd.concat([office_errored_records, office_SV_no_md5_match], ignore_index=True)

    # Get the persons in CM whose CM IDs are hashes of the SF IDs
    person_CM = getQueryResult(env, personTransformArgs["RDS_Query"], personTransformArgs['RDS_Header'])
    if person_CM is not None and person_SV.shape[0]:
        # person
        print("person_SV initial count {}".format(person_SV.shape[0]))

        # Get the persons loaded from SV whose CM IDs are not hashes of the SV IDs
        person_SV['SV_firm_id_hash_to_check'] = person_SV.apply(lambda x: get_md5_hash(x['person_id'] + '_person'),axis=1)
        person_SV_no_md5_match = person_SV.loc[~person_SV['SV_firm_id_hash_to_check'].eq(person_SV['crm_person_id']) & ~person_SV['crm_person_id'].eq('')]

        person_CM['SF_person_id_hash_to_check'] = person_CM.apply(lambda x: get_md5_hash(x['salesforce_id']), axis=1)
        person_CM_SF_md5_match = person_CM.loc[person_CM['SF_person_id_hash_to_check'].eq(person_CM['persistence_id']) & ~person_CM['persistence_id'].eq('')]

        # Are the persons loaded from SV whose CM IDs are not hashes of the SV IDs, hashes of the SF IDs
        person_SV_matched_SF_id = person_SV_no_md5_match.loc[person_SV_no_md5_match['crm_person_id'].isin(person_CM_SF_md5_match['SF_person_id_hash_to_check'])]

        # the following are errors
        person_SV_no_md5_match = person_SV_no_md5_match.loc[~person_SV_no_md5_match['crm_person_id'].isin(person_CM_SF_md5_match['SF_person_id_hash_to_check'])]
        person_SV = person_SV.loc[~(person_SV['crm_person_id'].isin(person_SV_no_md5_match['crm_person_id']))]

        print("person: person_SV final count {}".format(person_SV.shape[0]))
        print("person: person_SV_no_md5_match count {}".format(person_SV_no_md5_match.shape[0]))
        print("person: person_CM count {}".format(person_CM.shape[0]))
        print("person: person_CM_SF_md5_match count {}".format(person_CM_SF_md5_match.shape[0]))
        print("person: person_SV_matched_SF_id count: {}".format(person_SV_matched_SF_id.shape[0]))
        person_SV_no_md5_match["Error Message"] = "Persistence ID not an md5 hash of SF or SV IDs"
        person_errored_records = pd.concat([person_errored_records, person_SV_no_md5_match], ignore_index=True)

        # firm_SV, office_SV, person_SV, firm_that_should_not_be_deleted, offices_that_should_not_be_deleted = FirmDeleteWithLiveOfficeCheck(firm_SV, office_SV, person_SV, firm_CM, office_CM, person_CM)
        #
        # firm_errored_records = pd.concat([firm_errored_records, firm_that_should_not_be_deleted])
        #
        # office_errored_records = pd.concat([office_errored_records, offices_that_should_not_be_deleted])

    #todo: extract a function for below repeating code
    for output in outputs:
        output_file_name = list(output.values())[0]
        print("output_file_name: {}".format(output_file_name))
        if 'merge' in output_file_name:
            merge_source_target = getItemInList(source_target, 'file', 'merge', 'filestats')
            file_name = merge_source_target['source'].split('/')[-1]
            error_file_path = "~/data/processed/SalesVision/"+file_name+'.errored.csv'
            filtered_file_path = "~/data/processed/SalesVision/"+file_name+'.filtered.csv'
            #write file
            merge_SV.to_csv(merge_source_target['source'], sep=mergeTransformArgs['targetColSeparator'], header=True, index=False)
            #move file to s3
            move_to_s3(env, merge_source_target['source'], output_file_name, "/home/edmfilemgr/data/sent/SalesVision/", zipOutput=True)

        if 'firm' in output_file_name:
            firm_source_target = getItemInList(source_target, 'file', 'firm', 'filestats')
            file_name = firm_source_target['source'].split('/')[-1]
            error_file_path = "~/data/processed/SalesVision/"+file_name+'.errored.csv'
            filtered_file_path = "~/data/processed/SalesVision/"+file_name+'.filtered.csv'
            if firm_filtered_records.shape[0] > 0:
                #write filtered
                firm_filtered_records.to_csv(filtered_file_path, sep=firmTransformArgs['targetColSeparator'], header=True, index=False)

            if firm_errored_records.shape[0] > 0:
                #write errored
                firm_errored_records.to_csv(error_file_path, sep=firmTransformArgs['targetColSeparator'], header=True, index=False)

            #write file
            firm_SV.to_csv(firm_source_target['source'], sep=firmTransformArgs['targetColSeparator'], header=True, index=False, columns=firmTransformArgs['headerSchema'])
            #move file to s3
            move_to_s3(env, firm_source_target['source'], output_file_name, "/home/edmfilemgr/data/sent/SalesVision/", zipOutput=True)

        if 'office' in output_file_name:
            office_source_target = getItemInList(source_target, 'file', 'office', 'filestats')
            file_name = office_source_target['source'].split('/')[-1]
            error_file_path = "~/data/processed/SalesVision/"+file_name+'.errored.csv'
            filtered_file_path = "~/data/processed/SalesVision/"+file_name+'.filtered.csv'

            if office_errored_records.shape[0] > 0:
                #write filtered
                office_filtered_records.to_csv(filtered_file_path, sep=officeTransformArgs['targetColSeparator'], header=True, index=False)

            if office_errored_records.shape[0] > 0:
                #write errored
                office_errored_records.to_csv(error_file_path, sep=officeTransformArgs['targetColSeparator'], header=True, index=False)

            #write file
            office_SV.to_csv(office_source_target['source'], sep=officeTransformArgs['targetColSeparator'], header=True, index=False, columns=officeTransformArgs['headerSchema'])
            #move file to s3
            move_to_s3(env, office_source_target['source'], output_file_name, "/home/edmfilemgr/data/sent/SalesVision/", zipOutput=True)

        if 'person' in output_file_name:
            person_source_target = getItemInList(source_target, 'file', 'person', 'filestats')
            file_name = person_source_target['source'].split('/')[-1]
            error_file_path = "~/data/processed/SalesVision/"+file_name+'.errored.csv'
            filtered_file_path = "~/data/processed/SalesVision/"+file_name+'.filtered.csv'
            #write filtered
            if person_filtered_records.shape[0] > 0:
                #write filtered
                person_filtered_records.to_csv(filtered_file_path, sep=personTransformArgs['targetColSeparator'], header=True, index=False)
            if person_errored_records.shape[0] > 0:
                #write errored
                person_errored_records.to_csv(error_file_path, sep=personTransformArgs['targetColSeparator'],header=True, index=False)
            #write file
            print(f" person_SV length before writing to csv: {person_SV.shape[0]}")
            person_SV.to_csv(person_source_target['source'], sep=personTransformArgs['targetColSeparator'], header=True, index=False, columns=personTransformArgs['headerSchema'])
            #move to s3
            move_to_s3(env, person_source_target['source'], output_file_name, "/home/edmfilemgr/data/sent/SalesVision/", zipOutput=True)


    return_object = {
        JobStatusLabels.COB.value: cob, JobStatusLabels.CONTENTS.value: {
            JobStatusLabels.LOADED.value: {'Firm': firm_SV.shape[0], 'Office': office_SV.shape[0], 'Person': person_SV.shape[0], 'Merge': merge_SV.shape[0]},
            JobStatusLabels.FILTERED.value: {'Firm': firm_filtered_records.shape[0], 'Office': office_filtered_records.shape[0], 'Person': person_filtered_records.shape[0]},
            JobStatusLabels.ERRORED.value: {'Firm': firm_errored_records.shape[0], 'Office': office_errored_records.shape[0], 'Person': person_errored_records.shape[0]}}}

    return return_object

def FirmDeleteWithLiveOfficeCheck(firm_SV, office_SV, person_SV, firm_CM, office_CM, person_CM):
    #get parents that have children for offices or firms
    def findChildrenForOffices(offices=None):
        offices_that_should_not_be_deleted = None
        #crm_office_id
        office_delete = None
        if offices is not None:
            office_delete = offices
        else:
            office_delete = office_SV.loc[office_SV["event_code"].eq('D')]

        if office_delete is not None:
            children_in_deleted_offices = person_SV.loc[person_SV["crm_office_id"].isin(office_delete["some_field_1"])]

            persons_sv_didnt_delete = person_SV.loc[~person_SV["event_code"].eq('D')]

            children_in_deleted_offices_that_didnt_get_deletes_from_SV = children_in_deleted_offices.loc[children_in_deleted_offices["person_id"].isin(persons_sv_didnt_delete["person_id"])]

            offices_that_should_not_be_deleted = office_SV.loc[office_SV["some_field_1"].isin(children_in_deleted_offices_that_didnt_get_deletes_from_SV["crm_office_id"])]

        return offices_that_should_not_be_deleted

    firms_that_should_not_be_deleted = None
    offices_that_should_not_be_deleted = None

    #get firm deletes
    firm_delete_query = "event_code == 'D'"
    firm_deletes = firm_SV.query(firm_delete_query)
    print("firm_SV firm delete records [{}]".format(firm_deletes.shape[0]))
    print(firm_deletes)

    if firm_deletes is not None:
        #get offices in firms that are being deleted
        offices_in_firms_that_are_being_deleted = office_SV.loc[office_SV["firm_id"].isin(firm_deletes["firm_id"])]
        print("offices in firms that are being deleted:")
        print(offices_in_firms_that_are_being_deleted)

        #the firm associated with these offices (offices_in_firms_that_are_being_deleted) cannot be deleted:

        #find offices in firms that should not be deleted findChildrenForOffices
        #office_in_firm_that_should_not_be_deleted = findChildrenForOffices(offices_in_firms_that_are_being_deleted)

        #find firms that should not be delete
        firms_that_should_not_be_deleted = firm_SV["firm_id"].isin(offices_in_firms_that_are_being_deleted["firm_id"])
        firms_that_should_not_be_deleted["Error Message"] = "firm Should not be deleted - firm has live office(s)"
        print(firms_that_should_not_be_deleted)

        firm_SV = firm_SV.loc[~firm_SV["firm_id"].isin(offices_in_firms_that_are_being_deleted["firm_id"])]
    else:
        print("FirmDeleteWithLiveOfficeCheck: there are no firm Deletes to check...")

    #find offices that should not be deleted
    offices_that_should_not_be_deleted = findChildrenForOffices()
    if offices_that_should_not_be_deleted is not None:
        offices_that_should_not_be_deleted["Error Message"] = "office Should not be deleted - office has non-end-dated persons"
        print("offices that should NOT be deleted: {}".format(offices_that_should_not_be_deleted.shape[0]))
        print(offices_that_should_not_be_deleted)
        #remove offices that should not be deleted from input
        office_SV = office_SV.loc[~office_SV["office_id"].isin(offices_that_should_not_be_deleted["office_id"])]

    return firm_SV, office_SV, person_SV, firms_that_should_not_be_deleted, offices_that_should_not_be_deleted

def UpdateDeleteEventfilter(input, key_col):
    print("Filtering update records from Update Delete Event for key_col: {}".format(key_col))

    dupes = input.loc[input.duplicated(subset=[key_col], keep=False)]
    print("dupes {} ".format(dupes.shape[0]))
    non_dupes = input.loc[~input[key_col].isin(dupes[key_col])]
    print("non_dupes {} ".format(non_dupes.shape[0]))
    print(dupes)
    # #this line only returns the 'D' event code Dupes
    dupes_u = dupes.loc[dupes["event_code"].eq("U")]
    print("dupes_u {} ".format(dupes_u.shape[0]))
    dupes_d = dupes.loc[dupes["event_code"].eq("D")]
    print("dupes_d {} ".format(dupes_d.shape[0]))
    u = dupes_u.loc[~(dupes_u[key_col].isin(dupes_d[key_col]))]
    print(" u {} ".format(u.shape[0]))
    filtered_u = dupes_u.loc[dupes_u[key_col].isin(dupes_d[key_col])]
    print("filtered_u {} ".format(dupes_u.shape[0]))
    output = pd.concat([non_dupes, u, dupes_d], ignore_index=True)
    filtered_u["Error Message"] = "record contains UD Event Duplicate"
    print("output {}".format(output.shape[0]))

    return output, filtered_u


def getDataFrame(schema, filename, srcColSeparator=',', skipfooter=1, skiprows=1):
    data_frame = pd.read_csv(filename, sep=srcColSeparator, names=schema, engine="python",
                skipfooter=skipfooter, skiprows=skiprows, index_col=None, keep_default_na=False, header=None,
                dtype='string', skipinitialspace=True, encoding="ISO-8859-1")
    return data_frame

def getQueryResult(environment, query, header, database="RDS"):
    #I still do not like this staging switch situation...
    result_df = None
    staging_switch_query = "select value1 as stg_prefix from edm_params where key = 'active_mdm_stage'"

    connection = db_connection_factory(environment, database)
    with connection as db:
        db.execute(staging_switch_query)
        staging_switch_from_db = str(db.fetchone()[0])
        print("staging switch from db: {}".format(staging_switch_from_db))
        staging_switch = staging_switch_from_db

    if environment == 'test':
        staging_switch = "jjtest11"

    query_with_staging_switch = query.replace('@STAGING_SWITCH@', staging_switch)
    print("query with s switch: {}".format(query_with_staging_switch))
    connection = db_connection_factory(environment, database)
    with connection as db:
        try:
            db.execute(query_with_staging_switch)
            result_df = pd.DataFrame(db.fetchall())
            result_df.columns = header

        except UndefinedTable as newStagingSwitchException:
            print("no table corresponding to staging switch exists")
            return None

    return result_df


# def getSalesVisionMerge(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None, parameters=None, dryRun=None):
#     #TBD-glp 3/16/20: The current assumption is that this function gets called for one file at a time
#     input=list(inputs.values())[0]
#     output=list(outputs.values())[0]
#     header_schema=['merge_type','sv_from_id','sv_to_id','crm_from_id','crm_to_id','deprecated']
#     column_types = {"entity_type":['F','O','P'], "sv_from_id":int, "sv_to_id":int, "crm_from_id":str, "crm_to_id":str}
#     primary_key_col = "sv_from_id"
#     transformArgs = {"cob": "Not Used Yet", "stripHeader": True, "stripFooter": True, "srcColSeparator": '|',"targetColSeparator": ',',
#                      "newHeader": header_schema, 'column_types':column_types, 'primary_key':[primary_key_col],
#                      "entities_list": parameters[JobsParameter.STATS_TABLE_LIST.value]}
#
#     return getFromSFTPAndSendToS3(env=env, input=input, output=output,
#                                   dataSource=parameters[OpsWiseParametersNames.DATASOURCE.value], cob=cob,
#                                   failIfNoFile=True, saveCopy=True, rollback=True,
#                                   processFileFunctionTuple=("jobsystem.common_FM.transformFileDataFrame", transformArgs))

def getSalesVisionLQE(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None, parameters=None, dryRun=None):
    #TBD-glp 3/16/20: The current assumption is that this function gets called for one file at a time
    input=list(inputs.values())[0]
    output=list(outputs.values())[0]

    transformArgs = {"cob": "Not Used Yet", "stripHeader": True, "stripFooter": True, "srcColSeparator": ',',
                     "targetColSeparator": ',', "newHeader": None, 'file_offset': 2,
                     "entities_list": parameters[JobsParameter.STATS_TABLE_LIST.value]}
    return getFromSFTPAndSendToS3(env=env, input=input, output=output,
                                  dataSource=parameters[OpsWiseParametersNames.DATASOURCE.value],
                                  cob=cob, failIfNoFile=True, saveCopy=True, rollback=True,
                                  processFileFunctionTuple=("jobsystem.common_FM.transformFileDataFrame", transformArgs))


def ft_fm(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
          parameters=None, dryRun=None):
    # TBD-glp 3/16/20: The current assumption is that this function gets called for one file at a time
    input = list(inputs.values())[0]
    output = list(outputs.values())[0]
    strip_header = parameters.get('strip_header', False)
    strip_footer = parameters.get('strip_footer', False)
    transformArgs = {"cob": "Not Used Yet", "stripHeader": strip_header, "stripFooter": strip_footer,
                     "srcColSeparator": ',', "targetColSeparator": ',', "newHeader": None,
                     "entities_list": parameters[JobsParameter.STATS_TABLE_LIST.value]}
    return getFromSFTPAndSendToS3(env=env, input=input, output=output,
                                  dataSource=parameters[OpsWiseParametersNames.DATASOURCE.value], cob=cob,
                                  failIfNoFile=True, saveCopy=True, rollback=True,
                                  processFileFunctionTuple=("jobsystem.common_FM.transformFile", transformArgs),
                                  unzipInput=False)

def salesforceGenerateMergeConf(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
          parameters=None, dryRun=None):
    input = list(inputs.values())[0]
    merge_file_output = list(outputs[0].values())[0]
    conf_file_output = list(outputs[1].values())[0]
    file_date = cob
    if file_date is None:
        file_date = datetime.now.strftime("%d_%m_%Y")
    strip_header = parameters.get('strip_header', False)
    strip_footer = parameters.get('strip_footer', False)
    transformArgs = {"cob": "Not Used Yet", "stripHeader": strip_header, "stripFooter": strip_footer,
                     "srcColSeparator": ',', "targetColSeparator": ',', "newHeader": None,
                     "entities_list": parameters[JobsParameter.STATS_TABLE_LIST.value] }
    file_move_result = getFromSFTPAndSendToS3(env=env, input=input, output=merge_file_output,
                                              dataSource=parameters[OpsWiseParametersNames.DATASOURCE.value], cob=cob,
                                              failIfNoFile=True, saveCopy=True, rollback=True,
                                              processFileFunctionTuple=("jobsystem.common_FM.transformFile", transformArgs),
                                              unzipInput=False)
    conf_gen_stats = gen_salesforce_conf_file(jobId, env, file_date, merge_file_output, input, conf_file_output)
    print(conf_gen_stats)
    return file_move_result


def gen_salesforce_conf_file(jobId, env, file_date, merge_file_location_on_s3,  input=None, output=None):
    print('generating salesForce Conf File')
    # this should be generic and in processSubstitutionVariables
    output = str(output).replace('%JOBID%', str(jobId))
    print("using output: {}".format(output))
    json_str ="""
    {
        "load_src":    "s3",
        "IGNORED_FIELD_LIST":    [
        ],
        "TABLES_LIST":    [
                "entity"
        ],
        "rowcount":    0,
        "PKEY_FKEY_MAPPINGS":    {
                "entity":    {
                        "entity":    "parent_id",
                         "agreement_entity_xref":    "entity_id",
                          "entity_email_xref":    "entity_id",
                          "entity_phone_xref":    "entity_id",
                          "entity_address_xref":    "entity_id"
                },
                "agreement":    {
                        "agreement_entity_xref":    "agreement_id",
                        "aum":    "agreement_id",
                        "trade":    "agreement_id"
                }
        },
        "COLUMNS":    [
                "TDS_ID",
                "source_name",
                "etl_source",
                "original_record_",
                "column_name",
                "invalid_value",
                "valid_value",
                "stewardship_type",
                "create_rule",
                "created_at",
                "updated_at",
                "submitted_at",
                "cascade"
        ],
        "TDS_ID":    "tds_id",
        "STAGING_ID":    "tds_master",
        "MASTER":    "true",
        "ETL_SOURCE":    "etl_source",
        "STEWARDSHIP_TYPE":    "stewardship_type",
        "comment":    "Pkey    /    fkey    mappings    is    a    dict    where    the    keys    are    pkey    table    names    and    the    values    are    dicts    corresponding    to    the"
    }"""

    circe_conf_str  = json_str.replace('\n', '')
    json_data = json.loads(circe_conf_str)
    json_data["file_date"] = file_date
    json_data["jobid"] = jobId

    sent_path_and_file_name = "/home/edmfilemgr/data/sent/SF/" + output.split('/').pop(-1)
    print("local file path: {}".format(sent_path_and_file_name))

    output_location = 's3://' + ENVS[env]['aws']['s3_bucket'][5:] + '/etl-output/salesvision/merge/'
    input_location = 's3://' + ENVS[env]['aws']['s3_bucket'][5:] + '/' + merge_file_location_on_s3
    json_data["output_location"] = {'emr': output_location}
    json_data["input_location"] = {'emr': input_location}

    with open(sent_path_and_file_name, 'w') as conf_file:
        json.dump(json_data, conf_file)

    with S3(env) as s3:
        print("sending conf file: with params: {}, {}, {}".format(sent_path_and_file_name, ENVS[env]['aws']['s3_bucket'][5:], output))
        s3.send_file(sent_path_and_file_name, ENVS[env]['aws']['s3_bucket'][5:], output, encrypt=False)

    stats_dict = {JobStatusLabels.JOB_STATUS.value: JobStatus.SUCCESS.value,
                  JobStatusLabels.CONTENTS.value: {JobStatusLabels.LOADED.value: 0,
                                                   JobStatusLabels.FILTERED.value: 0,
                                                   JobStatusLabels.ERRORED.value: 0
                                                   }
                  }
    print("Return object is :", stats_dict)
    return stats_dict

def au_fm(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
          parameters=None, dryRun=None):
    # TBD-glp 3/16/20: The current assumption is that this function gets called for one file at a time
    input = list(inputs.values())[0]
    output = list(outputs.values())[0]
    strip_header = parameters.get('strip_header', False)
    strip_footer = parameters.get('strip_footer', False)
    drop_columns = parameters.get('drop_columns', None)
    if drop_columns :
        drop_columns = [int(i) for i in drop_columns]
    transformArgs = {"cob": "Not Used Yet", "stripHeader": strip_header, "stripFooter": strip_footer,
                     "srcColSeparator": ',', "targetColSeparator": ',', "newHeader": None, "drop_columns": drop_columns,
                     "entities_list": parameters[JobsParameter.STATS_TABLE_LIST.value] }
    return getFromSFTPAndSendToS3(env=env, input=input, output=output,
                                  dataSource=parameters[OpsWiseParametersNames.DATASOURCE.value], cob=cob,
                                  failIfNoFile=True, saveCopy=True, rollback=True,
                                  processFileFunctionTuple=("jobsystem.common_FM.transformFile", transformArgs),
                                  unzipInput=False)


def amg_opswise_send_s3(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
                        parameters=None, dryRun=None):
    #database = ENVS[env]['AMG']['db']
    csv_dir_path = os.environ["DATA_HOME"] + "/received"
    check_and_create_dir(csv_dir_path)

    today_date = f"{datetime.now():%m-%d-%Y}"
    csv_file_name = f"amg_data_{today_date}.csv"
    csv_path_file_name = f"{csv_dir_path}/{csv_file_name}"

    header = """MUTUAL_FUND_INDICATOR_CODE,portfolio_no,portfolio_no_char,ACCOUNT_LEGAL_NAME1,ACCOUNT_LEGAL_NAME2,ACCOUNT_LEGAL_NAME3,ACCOUNT_SHORT_NAME,PMF_T07_ID,CLIENT_BUSINESS_CODE,SERVICING_TYPE,CRM_RELATIONSHIP_ID,ACCOUNT_ADDR_LINE1,ACCOUNT_ADDR_LINE2,ACCOUNT_CITY,ACCOUNT_STATE_CODE,ACCOUNT_COUNTRY_CODE,ACCOUNT_ZIP_CODE,entity_code,DUMMY_YN,SEED_ACCOUNT_YN,ACCOUNT_LOST_DATE,CURRENCY,INCEPTION_DATE,lazard_id
"""
    sql_query = amg_fm_query
    s3_bucket_name = ENVS[env]['aws']['s3_bucket']
    try:
        record_count = get_from_DB_and_send_to_s3(env,  header, parameters[OpsWiseParametersNames.DATASOURCE.value], sql_query, csv_file_name,
                                                  s3_bucket_name, f"ETL/data/amg/{csv_file_name}.gz")
    except ValueError as e:
        print(e)
        raise e
    return_object = build_stats(parameters[JobsParameter.STATS_TABLE_LIST.value], cob, JobStatus.SUCCESS.value,  record_count, 0, 0)

    # return_object = {
    #     JobStatusLabels.COB.value: today_date, JobStatusLabels.CONTENTS.value: {
    #         JobStatusLabels.LOADED.value: {'Entities': record_count, 'Agreements': record_count},
    #         JobStatusLabels.FILTERED.value: 0,
    #         JobStatusLabels.ERRORED.value: 0}}

    return return_object



def ldw_batch_send_to_s3(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
                         parameters=None, dryRun=None):
    today_date = f"{datetime.now():%m-%d-%Y}"

    #database = ENVS[env]['LDW']['db']
    csv_dir_path = os.environ["DATA_HOME"] + "/received"
    check_and_create_dir(csv_dir_path)

    ldw_start_date = inputs.get('start-date')
    ldw_end_date = outputs.get('end-date')

    csv_file_name = f"ldw_batch_aum_range-{ldw_start_date.replace('/', '-')}-{ldw_end_date.replace('/','-')}.csv"
    csv_path_file_name = f"{csv_dir_path}/{csv_file_name}"

    header = """as_of_date,portfolio_symbol,portfolio_currency_symbol,mv_port_cur"""
    sql_query = ldw_batch_query.format(ldw_end_date=ldw_end_date, ldw_start_date=ldw_start_date)
    s3_bucket_name = ENVS[env]['aws']['s3_bucket']

    try:
        record_count = get_from_DB_and_send_to_s3(env,   header, parameters[OpsWiseParametersNames.DATASOURCE.value], sql_query, csv_file_name,
                                                  s3_bucket_name, f"ETL/data/ldw/{csv_file_name}.gz", "LDW")
    except ValueError as e:
        print(e)
        raise e

    return_object = build_stats(parameters[JobsParameter.STATS_TABLE_LIST.value], cob, JobStatus.SUCCESS.value,  record_count, 0, 0)
    # return_object = {
    #     JobStatusLabels.COB.value: today_date, JobStatusLabels.CONTENTS.value: {
    #         JobStatusLabels.LOADED.value: {'Entities': record_count, 'Agreements': record_count},
    #         JobStatusLabels.FILTERED.value: 0,
    #         JobStatusLabels.ERRORED.value: 0}}

    return return_object

def ldw_flows_send_to_s3(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
                         parameters=None, dryRun=None):
    today_date = f"{datetime.now():%m-%d-%Y}"

    #database = ENVS[env]['LDW']['db']
    csv_dir_path = os.environ["DATA_HOME"] + "/received"
    check_and_create_dir(csv_dir_path)

    ldw_start_date = inputs.get('start-date')
    ldw_end_date = outputs.get('end-date')

    csv_file_name = f"ldw_flows_batch_data_range-{ldw_start_date.replace('/', '-')}-{ldw_end_date.replace('/','-')}.csv"
    csv_path_file_name = f"{csv_dir_path}/{csv_file_name}"

    header = """pmf_symbol,tran_trade_date,tran_type,port_cur_iso3,flow_port_cur"""
    sql_query = ldw_flow_query.format(ldw_end_date=ldw_end_date, ldw_start_date=ldw_start_date)
    s3_bucket_name = ENVS[env]['aws']['s3_bucket']

    try:
        record_count = get_from_DB_and_send_to_s3(env,   header, parameters[OpsWiseParametersNames.DATASOURCE.value], sql_query, csv_file_name,
                                                  s3_bucket_name, f"ETL/data/ldw/{csv_file_name}.gz", "LDW")
    except ValueError as e:
        print(e)
        raise e

    return_object = build_stats(parameters[JobsParameter.STATS_TABLE_LIST.value], cob, JobStatus.SUCCESS.value,  record_count, 0, 0)
    # return_object = {
    #     JobStatusLabels.JOB_STATUS.value: JobStatus.SUCCESS.value,
    #     JobStatusLabels.COB.value: today_date, JobStatusLabels.CONTENTS.value: {
    #         JobStatusLabels.LOADED.value: {'Entities': record_count, 'Agreements': record_count},
    #         JobStatusLabels.FILTERED.value: 0,
    #         JobStatusLabels.ERRORED.value: 0}}

    return return_object

def ref_data_send_to_s3(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
                         parameters=None, dryRun=None):
    today_date = f"{datetime.now():%m-%d-%Y}"

    #database = ENVS[env]['AMG']['db']
    csv_dir_path = os.environ["DATA_HOME"] + "/received"
    check_and_create_dir(csv_dir_path)

    csv_file_name = inputs['filenameToSaveQuery']
    s3_path = outputs['filenameToSaveQuery']
    csv_path_file_name = f"{csv_dir_path}/{csv_file_name}"

    header =  """SHARE_CLASS_ID,VEHICLE_TYPE_ID,PRODUCT_ID,VEHICLE_TYPE_DESC,PRODUCT_NAME,SHARE_CLASS_NAME,STATUS,CURRENCY_ID,ISIN,CUSIP,TICKER,APIR_CODE,SSALUR,PMF_ID,SUB_STRATEGY_ID,category_id,category_desc"""
    sql_query = f"select {header} from amv_mktg_share_class_detailed"

    s3_bucket_name = ENVS[env]['aws']['s3_bucket']

    try:
        record_count = get_from_DB_and_send_to_s3(env,   header, parameters[OpsWiseParametersNames.DATASOURCE.value], sql_query, csv_file_name,
                                                  s3_bucket_name, f"{s3_path}")
    except ValueError as e:
        print(e)
        raise e

    return_object = build_stats(['share_class_enum'], today_date, JobStatus.SUCCESS.value,  record_count, 0, 0)
    # return_object = {
    #     JobStatusLabels.COB.value: today_date, JobStatusLabels.CONTENTS.value: {
    #         JobStatusLabels.LOADED.value: {'share_class_enum': record_count},
    #         JobStatusLabels.FILTERED.value:{'share_class_enum': 0},
    #         JobStatusLabels.ERRORED.value: {'share_class_enum':0}}
    # }

    return return_object

def fx_rate_conversion_send_to_s3(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None,
                         parameters=None, dryRun=None):
    TARGET_CURRENCIES = ['AUD', 'CAD', 'CHF', 'DKK', 'EUR', 'GBP', 'HKD', 'JPY', 'KRW', 'NOK', 'NZD', 'SGD', 'SEK',
                         'AED', 'USD']
    source = 'FXRATE'
    # start_date = datetime(2020, 1, 1)
    today_date = f"{datetime.now():%m-%d-%Y}"
    start_date_str = inputs['startDate']
    start_date = datetime.strptime(start_date_str, '%m-%d-%Y')
    end_date = datetime.today()
    # create string version of date range
    dates = list(datetime_range(start=start_date, end=end_date))
    dates = [d.strftime('%m/%d/%Y') for d in dates]
    date_range = ', '.join(f"'{k}'" for k in dates)
    currs = ', '.join(f"'{k}'" for k in TARGET_CURRENCIES)

    recieved_dir, sent_dir = get_recieve_and_sent_folder(parameters[OpsWiseParametersNames.DATASOURCE.value])
    #csv_dir_path = os.environ["DATA_HOME"] + "/received"
    check_and_create_dir(recieved_dir)

    csv_file_name = inputs['filenameToSaveQuery']
    csv_path_file_name = f"{recieved_dir} + os.path.sep + {csv_file_name}"

    s3_bucket_name = ENVS[env]['aws']['s3_bucket']
    connection = db_connection_factory(env, source)
    with connection as cursor, open(f'{csv_path_file_name}', 'w', newline='') as f:
        fxrates = FXRateElement.object_load_from_db(cursor, date_range, currs)
        record_count = len(fxrates)
        writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        # Add the header/column names
        writer.writerow(FXRateElement.get_header())
        for fxrate in fxrates:
            writer.writerow(fxrate)

    sent_file_path = sent_dir + os.path.sep + csv_file_name
    shutil.copyfile(csv_path_file_name, sent_file_path)
    gzipFileWithPath = gzipFile(sent_file_path)
    destpath = outputs['filenameToSaveQuery']
    try:
        with S3(env) as s3:
            s3.send_file(gzipFileWithPath, s3_bucket_name, destpath)
    except Exception as e:
        print(e)
        raise e


    return_object = build_stats(['fx_rate_conversion'], today_date, JobStatus.SUCCESS.value,  record_count, 0, 0)

    # return_object = {
    #     JobStatusLabels.COB.value: today_date, JobStatusLabels.CONTENTS.value: {
    #         JobStatusLabels.LOADED.value: {'fx_rate_conversion': record_count},
    #         JobStatusLabels.FILTERED.value:{'fx_rate_conversion': 0},
    #         JobStatusLabels.ERRORED.value: {'fx_rate_conversion': 0}}
    # }

    return return_object
