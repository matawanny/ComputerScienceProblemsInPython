import sys
from datetime import datetime

from dateutil.relativedelta import relativedelta
from jobsystem.FeedAPI import FeedAPI
from jobsystem.FeedDefinition import *


def main(args):
    # AMG
    environment = "test"
    feed_api = FeedAPI(environment)

    now = datetime.now()
    now_string = now.strftime("%Y-%m-%d, %H:%M:%S")
    onehundred_years_from_now = now + relativedelta(years=100)
    onehundred_years_from_now_string = onehundred_years_from_now.strftime("%Y-%m-%d, %H:%M:%S")
    time_window = TimeWindow(now_string, onehundred_years_from_now_string)

    function_and_parameter = FunctionAndParameter("", "")
    control_check_threshold = ControlCheckThreshold("")

    AMG_Import_File = FeedDefinition("amc_edmcm_stg_switch_update_ops",
                                     "AMG_Import_File",
                                     "",
                                     "",
                                     "ClientMaster",
                                     "feed_FM.amg_opswise_send_s3",
                                     "",
                                     control_check_threshold.to_dict(),
                                     function_and_parameter.to_dict(),
                                     function_and_parameter.to_dict(),
                                     time_window.to_dict(),
                                     "16:00:00",
                                     "cahalym@lazard.com;cahalym@lazard.com",
                                     "cahalym@lazard.com;cahalym@lazard.com",
                                     now_string,
                                     onehundred_years_from_now_string)

    AMG_Import_LDW_AUM_File = FeedDefinition("amc_edmcm_stg_switch_update_ops",
                                                   "AMG_Import_LDW_AUM_File",
                                                   '{"start-date":"01/01/2019"}',
                                                   '{"end-date":"<COB:%m/%d/%Y:-1>"}',
                                                   "ClientMaster",
                                                   "feed_FM.ldw_batch_send_to_s3",
                                                   "",
                                                   control_check_threshold.to_dict(),
                                                   function_and_parameter.to_dict(),
                                                   function_and_parameter.to_dict(),
                                                   time_window.to_dict(),
                                                   "16:00:00",
                                                   "cahalym@lazard.com;cahalym@lazard.com",
                                                   "cahalym@lazard.com;cahalym@lazard.com",
                                                   now_string,
                                                   onehundred_years_from_now_string)

    AMG_Import_LDW_Flows_File = FeedDefinition("amc_edmcm_stg_switch_update_ops",
                                                     "AMG_Import_LDW_Flows_File",
                                                     '{"start-date":"01/01/2019"}',
                                                     '{"end-date":"<COB:%m/%d/%Y:-1>"}',
                                                     "ClientMaster",
                                                     "feed_FM.ldw_flows_send_to_s3",
                                                     "",
                                                     control_check_threshold.to_dict(),
                                                     function_and_parameter.to_dict(),
                                                     function_and_parameter.to_dict(),
                                                     time_window.to_dict(),
                                                     "16:00:00",
                                                     "cahalym@lazard.com;cahalym@lazard.com",
                                                     "cahalym@lazard.com;cahalym@lazard.com",
                                                     now_string,
                                                     onehundred_years_from_now_string)

    AMG_Import_ETL = FeedDefinition("",
                             "AMG_Import_ETL",
                             "{'emr': 's3://lazard-<ENV:lower>-client-master/ETL/data/amg/amg_data_<COB:%m-%d-%Y:0>.csv.gz','source':'AMG'}",
                             "{'emr':'s3://lazard-<ENV:lower>-client-master/etl-output/amg/'}",
                             "ClientMaster",
                             "feed_functions.run_emr_and_generate_stats",
                             "",
                             control_check_threshold.to_dict(),
                             function_and_parameter.to_dict(),
                             function_and_parameter.to_dict(),
                             time_window.to_dict(),
                             "16:00:00",
                             "cahalym@lazard.com;cahalym@lazard.com",
                             "cahalym@lazard.com;cahalym@lazard.com",
                             now_string,
                             onehundred_years_from_now_string)

    AMG_Import_LDW_AUM_ETL = FeedDefinition("",
                                                 "AMG_Import_LDW_AUM_ETL",
                                                 "{'emr': 's3://lazard-<ENV:lower>-client-master/ETL/data/ldw/ldw_batch_aum_range-01-01-2019-<COB:%m-%d-%Y:-1>.csv.gz','source':'AMG'}",
                                                 "{'emr':'s3://lazard-<ENV:lower>-client-master/etl-output/ldw_batch_aum/'}",
                                                 "ClientMaster",
                                                 "feed_functions.run_emr_and_generate_stats",
                                                 "",
                                                 control_check_threshold.to_dict(),
                                                 function_and_parameter.to_dict(),
                                                 function_and_parameter.to_dict(),
                                                 time_window.to_dict(),
                                                 "16:00:00",
                                                 "cahalym@lazard.com;cahalym@lazard.com",
                                                 "cahalym@lazard.com;cahalym@lazard.com",
                                                 now_string,
                                                 onehundred_years_from_now_string)

    AMG_Import_LDW_Flows_ETL = FeedDefinition("",
                                                   "AMG_Import_LDW_Flows_ETL",
                                                   "{'emr': 's3://lazard-<ENV:lower>-client-master/ETL/data/ldw/ldw_flows_batch_data_range-01-01-2019-<COB:%m-%d-%Y:-1>.csv.gz','source':'AMG'}",
                                                   "{'emr':'s3://lazard-<ENV:lower>-client-master/etl-output/ldw_trade/'}",
                                                   "ClientMaster",
                                                   "feed_functions.run_emr_and_generate_stats",
                                                   "Transactions|Positions",
                                                   control_check_threshold.to_dict(),
                                                   function_and_parameter.to_dict(),
                                                   function_and_parameter.to_dict(),
                                                   time_window.to_dict(),
                                                   "16:00:00",
                                                   "cahalym@lazard.com;cahalym@lazard.com",
                                                   "cahalym@lazard.com;cahalym@lazard.com",
                                                   now_string,
                                                   onehundred_years_from_now_string)

    AMG_Import_MDM = FeedDefinition("",
                             "AMG_Import_MDM",
                             "{'mdm_conf_dir':'s3://lazard-<ENV:lower>-client-master/MDM/conf/AMG/incoming/','mdm_prefix':'AMG'}",
                             '',
                             "ClientMaster",
                             "feed_functions.run_emr_and_generate_stats",
                             "",
                             control_check_threshold.to_dict(),
                             function_and_parameter.to_dict(),
                             function_and_parameter.to_dict(),
                             time_window.to_dict(),
                             "16:00:00",
                             "cahalym@lazard.com;cahalym@lazard.com",
                             "cahalym@lazard.com;cahalym@lazard.com",
                             now_string,
                             onehundred_years_from_now_string)

    feed_api.registerFeedDefinition( AMG_Import_File)
    feed_api.registerFeedDefinition(AMG_Import_LDW_AUM_File)
    feed_api.registerFeedDefinition(AMG_Import_LDW_Flows_File)

    feed_api.registerFeedDefinition(AMG_Import_ETL)
    feed_api.registerFeedDefinition(AMG_Import_LDW_AUM_ETL)
    feed_api.registerFeedDefinition(AMG_Import_LDW_Flows_ETL)

    feed_api.registerFeedDefinition(AMG_Import_MDM)

    ######################## FishTank ##############################

    Fishtank_Import_File = FeedDefinition("amc_edmcm_stg_switch_update_ops",
                                          "Fishtank_Import_File",
                                          "{'Fishtank':'/fishtankFTP/incoming/Fishtank_<COB:%Y-%m-%d:-1:monthend>.csv'}",
                                          "{'output_directory':'ETL/data/fishtank/'}",
                                          "ClientMaster",
                                          "feed_FM.ft_fm",
                                          "",
                                          control_check_threshold.to_dict(),
                                          function_and_parameter.to_dict(),
                                          function_and_parameter.to_dict(),
                                          time_window.to_dict(),
                                          "16:00:00",
                                          "cahalym@lazard.com;cahalym@lazard.com",
                                          "cahalym@lazard.com;cahalym@lazard.com",
                                          now_string,
                                          onehundred_years_from_now_string)

    Fishtank_Import_ETL = FeedDefinition("",
                                  "Fishtank_Import_ETL",
                                  "{'emr': 's3://lazard-<ENV:lower>-client-master/ETL/data/fishtank/Fishtank_<COB:%Y-%m-%d:-1:monthend>.csv.gz','source':'FT'}",
                                  "{'emr':'s3://lazard-<ENV:lower>-client-master/etl-output/fishtank/'}",
                                  "ClientMaster",
                                  "feed_functions.run_emr_and_generate_stats",
                                  "",
                                  control_check_threshold.to_dict(),
                                  function_and_parameter.to_dict(),
                                  function_and_parameter.to_dict(),
                                  time_window.to_dict(),
                                  "16:00:00",
                                  "cahalym@lazard.com;cahalym@lazard.com",
                                  "cahalym@lazard.com;cahalym@lazard.com",
                                  now_string,
                                  onehundred_years_from_now_string)

    Fishtank_Import_MDM = FeedDefinition("",
                                  "Fishtank_Import_MDM",
                                  "{'mdm_conf_dir':'s3://lazard-<ENV:lower>-client-master/MDM/conf/FT/incoming/','mdm_prefix':'FT'}",
                                  '',
                                  "ClientMaster",
                                  "feed_functions.run_emr_and_generate_stats",
                                  "",
                                  control_check_threshold.to_dict(),
                                  function_and_parameter.to_dict(),
                                  function_and_parameter.to_dict(),
                                  time_window.to_dict(),
                                  "16:00:00",
                                  "cahalym@lazard.com;cahalym@lazard.com",
                                  "cahalym@lazard.com;cahalym@lazard.com",
                                  now_string,
                                  onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(Fishtank_Import_File)
    feed_api.registerFeedDefinition(Fishtank_Import_ETL)
    feed_api.registerFeedDefinition(Fishtank_Import_MDM)

    ########### SalesForce#############
    Salesforce_Import_FOP_File = FeedDefinition("",
                                            "Salesforce_Import_FOP_File",
                                            "",
                                            "",
                                            "ClientMaster",
                                            "feed_functions.upload_and_generate_stats_salesforce_files",
                                            "",
                                            control_check_threshold.to_dict(),
                                            function_and_parameter.to_dict(),
                                            function_and_parameter.to_dict(),
                                            time_window.to_dict(),
                                            "16:00:00",
                                            "cahalym@lazard.com;cahalym@lazard.com",
                                            "cahalym@lazard.com;cahalym@lazard.com",
                                            now_string,
                                            onehundred_years_from_now_string)

    Salesforce_Import_ETL = FeedDefinition("",
                                    "Salesforce_Import_ETL",
                                    "{'emr': 's3://lazard-<ENV:lower>-client-master/ETL/data/salesforce/salesforce_entity_<COB:%m-%d-%Y:0>.csv.gz','source':'SF'}",
                                    "{'emr':'s3://lazard-<ENV:lower>-client-master/etl-output/salesforce/'}",
                                    "ClientMaster",
                                    "feed_functions.run_emr_and_generate_stats",
                                    "",
                                    control_check_threshold.to_dict(),
                                    function_and_parameter.to_dict(),
                                    function_and_parameter.to_dict(),
                                    time_window.to_dict(),
                                    "16:00:00",
                                    "cahalym@lazard.com;cahalym@lazard.com",
                                    "cahalym@lazard.com;cahalym@lazard.com",
                                    now_string,
                                    onehundred_years_from_now_string)

    Salesforce_Import_MDM = FeedDefinition("",
                                    "Salesforce_Import_MDM",
                                    "{'mdm_conf_dir':'s3://lazard-<ENV:lower>-client-master/MDM/conf/SF/incoming/','mdm_prefix':'SF'}",
                                    "",
                                    "ClientMaster",
                                    "feed_functions.run_emr_and_generate_stats",
                                    "",
                                    control_check_threshold.to_dict(),
                                    function_and_parameter.to_dict(),
                                    function_and_parameter.to_dict(),
                                    time_window.to_dict(),
                                    "16:00:00",
                                    "cahalym@lazard.com;cahalym@lazard.com",
                                    "cahalym@lazard.com;cahalym@lazard.com",
                                    now_string,
                                    onehundred_years_from_now_string)

    Salesforce_Import_FOP_Merge_MDM = FeedDefinition("",
                                   "Salesforce_Import_FOP_Merge_MDM",
                                   "{'circe_conf_dir':'s3://lazard-<ENV:lower>-client-master/CIRCE/conf/SF/incoming/','circe_prefix':'SF'}",
                                   '',
                                   "ClientMaster",
                                   "feed_functions.run_emr_and_generate_stats",
                                   "",
                                   control_check_threshold.to_dict(),
                                   function_and_parameter.to_dict(),
                                   function_and_parameter.to_dict(),
                                   time_window.to_dict(),
                                   "16:00:00",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   now_string,
                                   onehundred_years_from_now_string)



    #########################################Sales Force FOP dbsync ######################

    SalesForce_Export_FOP_DBSync = FeedDefinition("",
                                                  "SalesForce_Export_FOP_DBSync",
                                                  "{'dbsync_param':'sf_entity_api'}",
                                                  "",
                                                  "ClientMaster",
                                                  "feed_functions.run_emr_and_generate_stats",
                                                  "",
                                                  control_check_threshold.to_dict(),
                                                  function_and_parameter.to_dict(),
                                                  function_and_parameter.to_dict(),
                                                  time_window.to_dict(),
                                                  "16:00:00",
                                                  "cahalym@lazard.com;cahalym@lazard.com",
                                                  "cahalym@lazard.com;cahalym@lazard.com",
                                                  now_string,
                                                  onehundred_years_from_now_string)
    SalesForce_Export_TradeCodes_DBSync_File = FeedDefinition("",
                                        "SalesForce_Export_TradeCodes_DBSync_File",
                                        "{'filenameToSaveQuery': ''}",
                                        "{'filenameToSaveQuery': ''}",
                                        "ClientMaster",
                                        "feed_functions.load_trade_code_enum",
                                        "",
                                        control_check_threshold.to_dict(),
                                        function_and_parameter.to_dict(),
                                        function_and_parameter.to_dict(),
                                        time_window.to_dict(),
                                        "16:00:00",
                                        "pereza@lazard.com;pereza@lazard.com",
                                        "pereza@lazard.com;pereza@lazard.com",
                                        now_string,
                                        onehundred_years_from_now_string)

    # Todo: delete in next release
    #SalesForce_Export_TradeCodes_DBSync_File = FeedDefinition("",
    #                                                 "SalesForce_Export_TradeCodes_DBSync_File",
    #                                                 "{'dbsync_param':'sf_agreement_api'}",
    #                                                 "",
    #                                                 "ClientMaster",
    #                                                 "feed_functions.run_emr_and_generate_stats",
    #                                                 "",
    #                                                 control_check_threshold.to_dict(),
    #                                                 function_and_parameter.to_dict(),
    #                                                 function_and_parameter.to_dict(),
    #                                                 time_window.to_dict(),
    #                                                 "16:00:00",
    #                                                 "cahalym@lazard.com;cahalym@lazard.com",
    #                                                 "cahalym@lazard.com;cahalym@lazard.com",
    #                                                 now_string,
    #                                                 onehundred_years_from_now_string)



    SalesForce_Export_Agreement_DBSync = FeedDefinition("",
                                                        "SalesForce_Export_TradeCodes_DBSync_File",
                                                        "{'dbsync_param':'sf_agreement_api'}",
                                                        "",
                                                        "ClientMaster",
                                                        "feed_functions.run_emr_and_generate_stats",
                                                        "",
                                                        control_check_threshold.to_dict(),
                                                        function_and_parameter.to_dict(),
                                                        function_and_parameter.to_dict(),
                                                        time_window.to_dict(),
                                                        "16:00:00",
                                                        "cahalym@lazard.com;cahalym@lazard.com",
                                                        "cahalym@lazard.com;cahalym@lazard.com",
                                                        now_string,
                                                        onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(Salesforce_Import_FOP_File)
    feed_api.registerFeedDefinition(Salesforce_Import_ETL)
    feed_api.registerFeedDefinition(Salesforce_Import_MDM)
    feed_api.registerFeedDefinition(Salesforce_Import_FOP_Merge_MDM)

    feed_api.registerFeedDefinition(SalesForce_Export_FOP_DBSync)
    feed_api.registerFeedDefinition(SalesForce_Export_TradeCodes_DBSync_File)
    feed_api.registerFeedDefinition(SalesForce_Export_Agreement_DBSync)

    ########################### AU Platform ##############################
    AU_Platfrom_Import_File = FeedDefinition("",
                                             "AU_Platfrom_Import_File",
                                             "{'AU Platform':'/registreetFTP/incoming/au_platform_until_<COB:%Y-%m-%d:-2:monthend>.csv'}",
                                             "{'output_directory':'ETL/data/au_platform/'}",
                                             "ClientMaster",
                                             "feed_FM.au_fm",
                                             "",
                                             control_check_threshold.to_dict(),
                                             function_and_parameter.to_dict(),
                                             function_and_parameter.to_dict(),
                                             time_window.to_dict(),
                                             "16:00:00",
                                             "cahalym@lazard.com;cahalym@lazard.com",
                                             "cahalym@lazard.com;cahalym@lazard.com",
                                             now_string,
                                             onehundred_years_from_now_string)

    AU_Platfrom_Import_ETL = FeedDefinition("",
                                     "AU_Platfrom_Import_ETL",
                                     "{'emr': 's3://lazard-<ENV:lower>-client-master/ETL/data/au_platform/au_platform_until_<COB:%Y-%m-%d:-2:monthend>.csv.gz','source':'AU'}",
                                     "{'emr':'s3://lazard-<ENV:lower>-client-master/etl-output/au_platform/'}",
                                     "ClientMaster",
                                     "feed_functions.run_emr_and_generate_stats",
                                     "",
                                     control_check_threshold.to_dict(),
                                     function_and_parameter.to_dict(),
                                     function_and_parameter.to_dict(),
                                     time_window.to_dict(),
                                     "16:00:00",
                                     "cahalym@lazard.com;cahalym@lazard.com",
                                     "cahalym@lazard.com;cahalym@lazard.com",
                                     now_string,
                                     onehundred_years_from_now_string)

    AU_Platfrom_Import_MDM = FeedDefinition("",
                                     "AU_Platfrom_Import_MDM",
                                     "{'mdm_conf_dir':'s3://lazard-<ENV:lower>-client-master/MDM/conf/AU/incoming/','mdm_prefix':'AU'}",
                                     '',
                                     "ClientMaster",
                                     "feed_functions.run_emr_and_generate_stats",
                                     "",
                                     control_check_threshold.to_dict(),
                                     function_and_parameter.to_dict(),
                                     function_and_parameter.to_dict(),
                                     time_window.to_dict(),
                                     "16:00:00",
                                     "cahalym@lazard.com;cahalym@lazard.com",
                                     "cahalym@lazard.com;cahalym@lazard.com",
                                     now_string,
                                     onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(AU_Platfrom_Import_File)
    feed_api.registerFeedDefinition(AU_Platfrom_Import_ETL)
    feed_api.registerFeedDefinition(AU_Platfrom_Import_MDM)

    ################################################### AU_Registreet ##########################################################################
    ########### AU_Registreet_DataCleaner ###################################
    AU_Registreet_Import_DataCleaner_Agreement_File = FeedDefinition("",
                                                                     "AU_Registreet_Import_DataCleaner_Agreement_File",
                                                                     "{'DataCleaner':'/registreetFTP/incoming/datacleaner_agreement_until_<COB:%Y-%m-%d:-1:monthend>.csv'}",
                                                                     "{'output directory':'ETL/data/Registreet/'}",
                                                                     "ClientMaster",
                                                                    "feed_FM.au_fm",
                                                                     "",
                                                                     control_check_threshold.to_dict(),
                                                                     function_and_parameter.to_dict(),
                                                                     function_and_parameter.to_dict(),
                                                                     time_window.to_dict(),
                                                                     "16:00:00",
                                                                     "cahalym@lazard.com;cahalym@lazard.com",
                                                                     "cahalym@lazard.com;cahalym@lazard.com",
                                                                     now_string,
                                                                     onehundred_years_from_now_string)
    AU_Registreet_Import_DataCleaner_Agreement_ETL = FeedDefinition("",
                                                             "AU_Registreet_Import_DataCleaner_Agreement_ETL",
                                                             "{'emr': 's3://lazard-<ENV:lower>-client-master/ETL/data/Registreet/datacleaner_agreement_until_<COB:%Y-%m-%d:-1:monthend>.csv.gz','source':'AU'}",
                                                             "{'emr':'s3://lazard-<ENV:lower>-client-master/etl-output/registreet_datacleaner/'}",
                                                             "ClientMaster",
                                                             "feed_functions.run_emr_and_generate_stats",
                                                             "",
                                                             control_check_threshold.to_dict(),
                                                             function_and_parameter.to_dict(),
                                                             function_and_parameter.to_dict(),
                                                             time_window.to_dict(),
                                                             "16:00:00",
                                                             "cahalym@lazard.com;cahalym@lazard.com",
                                                             "cahalym@lazard.com;cahalym@lazard.com",
                                                             now_string,
                                                             onehundred_years_from_now_string)

    ###################################### AU_Registreet_DataCleaner_Entity ##################################
    AU_Registreet_Import_DataCleaner_Entity_File = FeedDefinition("",
                                                                  "AU_Registreet_Import_DataCleaner_Entity_File",
                                                                  "{'DataCleaner':'/registreetFTP/incoming/datacleaner_entity_until_<COB:%Y-%m-%d:-1:monthend>.csv'}",
                                                                  "{'output directory':'ETL/data/Registreet/'}",
                                                                  "ClientMaster",
                                                                  "feed_FM.au_fm",
                                                                  "",
                                                                  control_check_threshold.to_dict(),
                                                                  function_and_parameter.to_dict(),
                                                                  function_and_parameter.to_dict(),
                                                                  time_window.to_dict(),
                                                                  "16:00:00",
                                                                  "cahalym@lazard.com;cahalym@lazard.com",
                                                                  "cahalym@lazard.com;cahalym@lazard.com",
                                                                  now_string,
                                                                  onehundred_years_from_now_string)
    AU_Registreet_Import_DataCleaner_Entity_ETL = FeedDefinition("",
                                                          "AU_Registreet_Import_DataCleaner_Entity_ETL",
                                                          "{'emr': 's3://lazard-<ENV:lower>-client-master/ETL/data/Registreet/datacleaner_entity_until_<COB:%Y-%m-%d:-1:monthend>.csv.gz','source':'AU'}",
                                                          "{'emr':'s3://lazard-<ENV:lower>-client-master/etl-output/registreet_datacleaner/'}",
                                                          "ClientMaster",
                                                          "feed_functions.run_emr_and_generate_stats",
                                                          "",
                                                          control_check_threshold.to_dict(),
                                                          function_and_parameter.to_dict(),
                                                          function_and_parameter.to_dict(),
                                                          time_window.to_dict(),
                                                          "16:00:00",
                                                          "cahalym@lazard.com;cahalym@lazard.com",
                                                          "cahalym@lazard.com;cahalym@lazard.com",
                                                          now_string,
                                                          onehundred_years_from_now_string)


    ###################################### AU_Registreet_DataCleaner_Trades##################################

    AU_Registreet_Import_DataCleaner_Trade_File = FeedDefinition("",
                                                      "AU_Registreet_Import_DataCleaner_Trade_File",
                                                      "{'Registreet trades':'/registreetFTP/incoming/registreet_trades_until_date_<COB:%Y-%m-%d:-1:monthend>.csv'}",
                                                      "{'output directory':'ETL/data/Registreet/'}",
                                                      "ClientMaster",
                                                      "feed_FM.au_fm",
                                                      "",
                                                      control_check_threshold.to_dict(),
                                                      function_and_parameter.to_dict(),
                                                      function_and_parameter.to_dict(),
                                                      time_window.to_dict(),
                                                      "16:00:00",
                                                      "cahalym@lazard.com;cahalym@lazard.com",
                                                      "cahalym@lazard.com;cahalym@lazard.com",
                                                      now_string,
                                                      onehundred_years_from_now_string)

    AU_Registreet_Import_DataCleaner_Trade_ETL = FeedDefinition("",
                                              "AU_Registreet_Import_DataCleaner_Trade_ETL",
                                              "{'emr': 's3://lazard-<ENV:lower>-client-master/ETL/data/Registreet/registreet_trades_until_date_<COB:%Y-%m-%d:-1:monthend>.csv.gz','source':'AU'}",
                                              "{'emr':'s3://lazard-<ENV:lower>-client-master/etl-output/registreet/'}",
                                              "ClientMaster",
                                              "feed_functions.run_emr_and_generate_stats",
                                              "",
                                              control_check_threshold.to_dict(),
                                              function_and_parameter.to_dict(),
                                              function_and_parameter.to_dict(),
                                              time_window.to_dict(),
                                              "16:00:00",
                                              "cahalym@lazard.com;cahalym@lazard.com",
                                              "cahalym@lazard.com;cahalym@lazard.com",
                                              now_string,
                                              onehundred_years_from_now_string)

    ###################################### AU_Registreet_DataCleaner_Trades##################################
    AU_Registreet_Import_DataCleaner_AUM_File = FeedDefinition("",
                                                   "AU_Registreet_Import_DataCleaner_AUM_File",
                                                   "{'Registreet AUM':'/registreetFTP/incoming/registreet_aum_until_date_<COB:%Y-%m-%d:-1:monthend>.csv'}",
                                                   "{'output directory':'ETL/data/Registreet/'}",
                                                   "ClientMaster",
                                                  "feed_FM.au_fm",
                                                   "",
                                                   control_check_threshold.to_dict(),
                                                   function_and_parameter.to_dict(),
                                                   function_and_parameter.to_dict(),
                                                   time_window.to_dict(),
                                                   "16:00:00",
                                                   "cahalym@lazard.com;cahalym@lazard.com",
                                                   "cahalym@lazard.com;cahalym@lazard.com",
                                                   now_string,
                                                   onehundred_years_from_now_string)
    AU_Registreet_Import_DataCleaner_AUM_ETL = FeedDefinition("",
                                           "AU_Registreet_Import_DataCleaner_AUM_ETL",
                                           "{'emr': 's3://lazard-<ENV:lower>-client-master/ETL/data/Registreet/registreet_aum_until_date_<COB:%Y-%m-%d:-1:monthend>.csv.gz','source':'AU'}",
                                           "{'emr':'s3://lazard-<ENV:lower>-client-master/etl-output/registreet/'}",
                                           "ClientMaster",
                                           "feed_functions.run_emr_and_generate_stats",
                                           "",
                                           control_check_threshold.to_dict(),
                                           function_and_parameter.to_dict(),
                                           function_and_parameter.to_dict(),
                                           time_window.to_dict(),
                                           "16:00:00",
                                           "cahalym@lazard.com;cahalym@lazard.com",
                                           "cahalym@lazard.com;cahalym@lazard.com",
                                           now_string,
                                           onehundred_years_from_now_string)

    AU_Registreet_Import_DataCleaner_JobChecker = FeedDefinition("",
                                                      "AU_Registreet_Import_DataCleaner_JobChecker",
                                                      "{'AU_Registreet': ['DataCleaner_Entity_FileManager','DataCleaner_Agreement_FileManager','AUM_FileManager','Trades_FileManager']}",
                                                      "",
                                                      "ClientMaster",
                                                      "feed_functions.perform_jobstatus_checker",
                                                      "",
                                                      control_check_threshold.to_dict(),
                                                      function_and_parameter.to_dict(),
                                                      function_and_parameter.to_dict(),
                                                      time_window.to_dict(),
                                                      "16:00:00",
                                                      "cahalym@lazard.com;cahalym@lazard.com",
                                                      "cahalym@lazard.com;cahalym@lazard.com",
                                                      now_string,
                                                      onehundred_years_from_now_string)


    AU_Registreet_Import_MDM = FeedDefinition("",
                                       "AU_Registreet_Import_MDM",
                                       "{'mdm_conf_dir':'s3://lazard-<ENV:lower>-client-master/MDM/conf/AU/incoming/','mdm_prefix':'AU'}",
                                       '',
                                       "ClientMaster",
                                       "feed_functions.run_emr_and_generate_stats",
                                       "",
                                       control_check_threshold.to_dict(),
                                       function_and_parameter.to_dict(),
                                       function_and_parameter.to_dict(),
                                       time_window.to_dict(),
                                       "16:00:00",
                                       "cahalym@lazard.com;cahalym@lazard.com",
                                       "cahalym@lazard.com;cahalym@lazard.com",
                                       now_string,
                                       onehundred_years_from_now_string)

    ########################### AU_Registreet_DataCleaner_MDM############################

    feed_api.registerFeedDefinition(AU_Registreet_Import_DataCleaner_Agreement_File)
    feed_api.registerFeedDefinition(AU_Registreet_Import_DataCleaner_Agreement_ETL)

    feed_api.registerFeedDefinition(AU_Registreet_Import_DataCleaner_Entity_File)
    feed_api.registerFeedDefinition(AU_Registreet_Import_DataCleaner_Entity_ETL)

    feed_api.registerFeedDefinition(AU_Registreet_Import_DataCleaner_Trade_File)
    feed_api.registerFeedDefinition(AU_Registreet_Import_DataCleaner_Trade_ETL)

    feed_api.registerFeedDefinition(AU_Registreet_Import_DataCleaner_AUM_File)
    feed_api.registerFeedDefinition(AU_Registreet_Import_DataCleaner_AUM_ETL)

    feed_api.registerFeedDefinition(AU_Registreet_Import_DataCleaner_JobChecker)

    feed_api.registerFeedDefinition(AU_Registreet_Import_MDM)

##################################### SV  ###################################################################

    SalesVision_Import_FOPM_File = FeedDefinition("",
                                       "SalesVision_Import_FOPM_File",
                                       [
                                            "{'SalesVisionFirm':'<env:upper:TEST-TEST_,PROD->salesvision_firm_profile_<COB:%m_%d_%Y:-1>.gz'}",
                                            "{'SalesVisionFile':'<env:upper:TEST-TEST_,PROD->salesvision_office_profile_<COB:%m_%d_%Y:-1>.gz'}",
                                            "{'SalesVisionPerson':'<env:upper:TEST-TEST_,PROD->salesvision_person_profile_<COB:%m_%d_%Y:-1>.gz'}",
                                            "{'SalesVisionFOPMerge': '<env:upper:TEST-TEST_,PROD->salesvision_merge_profile_<COB:%m_%d_%Y:-1>.gz'}"
                                       ],
                                       [
                                            "{'SalesVisionFirm': 'ETL/data/salesvision/<env:upper:TEST-TEST_,PROD->salesvision_firm_profile_<cob:%m_%d_%Y:-1>.gz'}",
                                            "{'SalesVisionOffice':'ETL/data/salesvision/<env:upper:TEST-TEST_,PROD->salesvision_office_profile_<cob:%m_%d_%Y:-1>.gz'}",
                                            "{'SalesVisionPerson':'ETL/data/salesvision/<env:upper:TEST-TEST_,PROD->salesvision_person_profile_<cob:%m_%d_%Y:-1>.gz'}",
                                            "{'SalesVisionFOPMerge':'/CIRCE/data/salesvision/<env:upper:TEST-TEST_,PROD->salesvision_merge_profile_<COB:%m_%d_%Y:-1>.gz'}"
                                       ],
                                       "ClientMaster",
                                       "feed_FM.processSalesVisionFirmOfficePeopleMerge",
                                       "",
                                       control_check_threshold.to_dict(),
                                       function_and_parameter.to_dict(),
                                       function_and_parameter.to_dict(),
                                       time_window.to_dict(),
                                       "16:00:00",
                                       "cahalym@lazard.com;cahalym@lazard.com",
                                       "cahalym@lazard.com;cahalym@lazard.com",
                                       now_string,
                                       onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(SalesVision_Import_FOPM_File)

    SalesVision_Import_Firm_ETL = FeedDefinition("SalesVision_Import_FOPM_File",
                                      "SalesVision_Import_Firm_ETL",
                                      "{'emr': 's3://lazard-<env:lower>-client-master/ETL/data/salesvision/<env:upper"
                                      ":TEST-TEST_,PROD->salesvision_firm_profile_<cob:%m_%d_%Y:-1>.gz','source':'SV'}",
                                      "{'emr':'s3://lazard-<env:lower>-client-master/etl-output/salesvision/firm/'}",
                                      "ClientMaster",
                                      "feed_functions.run_emr_and_generate_stats",
                                      "",
                                      control_check_threshold.to_dict(),
                                      function_and_parameter.to_dict(),
                                      function_and_parameter.to_dict(),
                                      time_window.to_dict(),
                                      "16:00:00",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      now_string,
                                      onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(SalesVision_Import_Firm_ETL)


    SalesVision_Import_Office_ETL = FeedDefinition("SalesVision_Import_FOPM_File",
                                      "SalesVision_Import_Office_ETL",
                                      "{'emr':'s3://lazard-<env:lower>-client-master/ETL/data/salesvision/<env:upper:TEST"
                                      "-TEST_,PROD->salesvision_office_profile_<cob:%m_%d_%Y:-1>.gz','source':'SV'}",
                                      "{'emr':'s3://lazard-<env:lower>-client-master/etl-output/salesvision/office/'}",
                                      "ClientMaster",
                                      "feed_functions.run_emr_and_generate_stats",
                                      "",
                                      control_check_threshold.to_dict(),
                                      function_and_parameter.to_dict(),
                                      function_and_parameter.to_dict(),
                                      time_window.to_dict(),
                                      "16:00:00",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      now_string,
                                      onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(SalesVision_Import_Office_ETL)


    SalesVision_Import_Person_ETL = FeedDefinition("SalesVision_Import_FOPM_File",
                                      "SalesVision_Import_Person_ETL",
                                      "{'emr':'s3://lazard-<env:lower>-client-master/ETL/data/salesvision/<env:upper:TEST"
                                      "-TEST_,PROD->salesvision_person_profile_<cob:%m_%d_%Y:-1>.gz','source':'SV'}",
                                      "{'emr':'s3://lazard-<env:lower>-client-master/etl-output/salesvision/person/'}",
                                      "ClientMaster",
                                      "feed_functions.run_emr_and_generate_stats",
                                      "",
                                      control_check_threshold.to_dict(),
                                      function_and_parameter.to_dict(),
                                      function_and_parameter.to_dict(),
                                      time_window.to_dict(),
                                      "16:00:00",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      now_string,
                                      onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(SalesVision_Import_Person_ETL)




    SalesVision_Import_Holding_File = FeedDefinition("",
                                   "SalesVision_Import_Holding_File",
                                   "{'SalesVisionHolding':'CLTMSTR<env:upper:TEST-T_,PROD->ADX_LQE_Holding_Files_<COB:%Y-%m-%d:0>*.CSV.gz'}",
                                   "{'SalesVisionHolding': 'ETL/data/salesvision/CLTMSTR<env:upper:TEST-T_,PROD->ADX_LQE_Holding_Files_<cob:%Y-%m-%d:0>.CSV.gz'}",
                                   "ClientMaster",
                                   "feed_FM.getSalesVisionLQE",
                                   "",
                                   control_check_threshold.to_dict(),
                                   function_and_parameter.to_dict(),
                                   function_and_parameter.to_dict(),
                                   time_window.to_dict(),
                                   "16:00:00",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   now_string,
                                   onehundred_years_from_now_string)

    SalesVision_Import_Holding_ETL = FeedDefinition("SalesVision_Import_Holding_File",
                                      "SalesVision_Import_Holding_ETL",
                                      "{'emr': 's3://lazard-<env:lower>-client-master/ETL/data/salesvision"
                                      "/CLTMSTR<env:upper:TEST-T_,PROD->ADX_LQE_Holding_Files_<cob:%Y-%m-%d:0>.CSV.gz','source':'SV'}",
                                      "{'emr':'s3://lazard-<env:lower>-client-master/etl-output/salesvision/holdings/'}",
                                      "ClientMaster",
                                      "feed_functions.run_emr_and_generate_stats",
                                      "",
                                      control_check_threshold.to_dict(),
                                      function_and_parameter.to_dict(),
                                      function_and_parameter.to_dict(),
                                      time_window.to_dict(),
                                      "16:00:00",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      now_string,
                                      onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(SalesVision_Import_Holding_File)
    feed_api.registerFeedDefinition(SalesVision_Import_Holding_ETL)

    SalesVision_Import_SalesHierarchy_File = FeedDefinition("",
                                   "SalesVision_Import_SalesHierarchy_File",
                                   "{'SalesVisionFile':'CLTMSTR<env:upper:TEST-T_,PROD->ADX_LQE_SalesHier_File_<COB:%Y-%m-%d:0>*'}",
                                   "{'SalesVisionSalesHierarchy': 'ETL/data/salesvision/CLTMSTR<env:upper:TEST-T_,PROD->ADX_LQE_SalesHier_File_<COB:%Y-%m-%d:0>.CSV.gz'}",
                                   "ClientMaster",
                                   "feed_FM.getSalesVisionLQE",
                                   "",
                                   control_check_threshold.to_dict(),
                                   function_and_parameter.to_dict(),
                                   function_and_parameter.to_dict(),
                                   time_window.to_dict(),
                                   "16:00:00",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   now_string,
                                   onehundred_years_from_now_string)

    SalesVision_Import_SalesHierarchy_ETL = FeedDefinition("SalesVision_Import_SalesHierarchy_File",
                                      "SalesVision_Import_SalesHierarchy_ETL",
                                      "{'emr': 's3://lazard-<ENV:lower>-client-master/ETL/data/salesvision/CLTMSTR<env"
                                      ":upper:TEST-T_,PROD->ADX_LQE_SalesHier_File_<COB:%Y-%m-%d:0>.CSV.gz',"
                                      "'source':'SV'}",
                                      "{'emr':'s3://lazard-<ENV:lower>-client-master/etl-output/salesvision/sales_hier/'}",
                                      "ClientMaster",
                                      "feed_functions.run_emr_and_generate_stats",
                                      "",
                                      control_check_threshold.to_dict(),
                                      function_and_parameter.to_dict(),
                                      function_and_parameter.to_dict(),
                                      time_window.to_dict(),
                                      "16:00:00",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      now_string,
                                      onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(SalesVision_Import_SalesHierarchy_File)
    feed_api.registerFeedDefinition(SalesVision_Import_SalesHierarchy_ETL)

    SalesVision_Import_Trade_File = FeedDefinition("",
                                   "SalesVision_Import_Trade_File",
                                   "{'SalesVisionTrade':'CLTMSTR<env:upper:TEST-T_,PROD->ADX_LQE_Trade_Files_<COB:%Y-%m-%d:0>*'}",
                                   "{'SalesVisionTrade': 'ETL/data/salesvision/CLTMSTR<env:upper:TEST-T_,PROD->ADX_LQE_Trade_Files_<COB:%Y-%m-%d:0>.CSV.gz'}",
                                   "ClientMaster",
                                   "feed_FM.getSalesVisionLQE",
                                   "",
                                   control_check_threshold.to_dict(),
                                   function_and_parameter.to_dict(),
                                   function_and_parameter.to_dict(),
                                   time_window.to_dict(),
                                   "16:00:00",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   now_string,
                                   onehundred_years_from_now_string)
    SalesVision_Import_Trade_ETL = FeedDefinition("SalesVision_Import_Trade_File",
                                      "SalesVision_Import_Trade_ETL",
                                      "{'emr': 's3://lazard-<ENV:lower>-client-master/ETL/data/salesvision/CLTMSTR<env"
                                      ":upper:TEST-T_,PROD->ADX_LQE_Trade_Files_<COB:%Y-%m-%d:0>.CSV.gz','source':'SV'}",
                                      "{'emr':'s3://lazard-<ENV:lower>-client-master/etl-output/salesvision/trade/'}",
                                      "ClientMaster",
                                      "feed_functions.run_emr_and_generate_stats",
                                      "",
                                      control_check_threshold.to_dict(),
                                      function_and_parameter.to_dict(),
                                      function_and_parameter.to_dict(),
                                      time_window.to_dict(),
                                      "16:00:00",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      now_string,
                                      onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(SalesVision_Import_Trade_File)
    feed_api.registerFeedDefinition(SalesVision_Import_Trade_ETL)

    SalesVision_Import_Asset_File = FeedDefinition("",
                                   "SalesVision_Import_Asset_File",
                                   "{'SalesVisionAsset':'CLTMSTR<env:upper:TEST-T_,PROD->ADX_LQE_Asset_File_<COB:%Y-%m-%d:0>*'}",
                                   "{'SalesVisionAsset':'ETL/data/salesvision/CLTMSTR<env"
                                    ":upper:TEST-T_,PROD->ADX_LQE_Asset_File_<COB:%Y-%m-%d:0>.CSV.gz'}",
                                   "ClientMaster",
                                   "feed_FM.getSalesVisionLQE",
                                   "",
                                   control_check_threshold.to_dict(),
                                   function_and_parameter.to_dict(),
                                   function_and_parameter.to_dict(),
                                   time_window.to_dict(),
                                   "16:00:00",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   now_string,
                                   onehundred_years_from_now_string)

    SalesVision_Import_Asset_ETL = FeedDefinition("SalesVision_Import_Asset_File",
                                      "SalesVision_Import_Asset_ETL",
                                      "{'emr': 's3://lazard-<env:lower>-client-master/ETL/data/salesvision/CLTMSTR<env"
                                      ":upper:TEST-T_,PROD->ADX_LQE_Asset_File_<COB:%Y-%m-%d:0>.CSV.gz','source':'SV'}",
                                      "{'emr':'s3://lazard-<env:lower>-client-master/etl-output/salesvision/asset/'}",
                                      "ClientMaster",
                                      "feed_functions.run_emr_and_generate_stats",
                                      "",
                                      control_check_threshold.to_dict(),
                                      function_and_parameter.to_dict(),
                                      function_and_parameter.to_dict(),
                                      time_window.to_dict(),
                                      "16:00:00",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      now_string,
                                      onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(SalesVision_Import_Asset_File)
    feed_api.registerFeedDefinition(SalesVision_Import_Asset_ETL)


    SalesVision_Import_SalesPerson_File = FeedDefinition("",
                                   "SalesVision_Import_SalesPerson_File",
                                   "{'SalesVisionFile':'CLTMSTR<env:upper:TEST-T_,PROD->ADX_LQE_SalesPers_Files_<COB:%Y-%m-%d:0>*'}",
                                   "{'SalesVisionSalesPerson': 'ETL/data/salesvision/CLTMSTR<env:upper:TEST-T_,PROD->ADX_LQE_SalesPers_Files_<COB:%Y-%m-%d:0>.CSV.gz'}",
                                   "ClientMaster",
                                   "feed_FM.getSalesVisionLQE",
                                   "",
                                   control_check_threshold.to_dict(),
                                   function_and_parameter.to_dict(),
                                   function_and_parameter.to_dict(),
                                   time_window.to_dict(),
                                   "16:00:00",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   now_string,
                                   onehundred_years_from_now_string)

    SalesVision_Import_SalesPerson_ETL = FeedDefinition("SalesVision_Import_SalesPerson_File",
                                      "SalesVision_Import_SalesPerson_ETL",
                                      "{'emr': 's3://lazard-<ENV:lower>-client-master/ETL/data/salesvision/CLTMSTR<env"
                                      ":upper:TEST-T_,PROD->ADX_LQE_SalesPers_Files_<COB:%Y-%m-%d:0>.CSV.gz',"
                                      "'source':'SV'}",
                                      "{'emr':'s3://lazard-<ENV:lower>-client-master/etl-output/salesvision/sales_per/'}",
                                      "ClientMaster",
                                      "feed_functions.run_emr_and_generate_stats",
                                      "",
                                      control_check_threshold.to_dict(),
                                      function_and_parameter.to_dict(),
                                      function_and_parameter.to_dict(),
                                      time_window.to_dict(),
                                      "16:00:00",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      now_string,
                                      onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(SalesVision_Import_SalesPerson_File)
    feed_api.registerFeedDefinition(SalesVision_Import_SalesPerson_ETL)

    SalesVision_Import_TradeDescription_File = FeedDefinition("",
                                   "SalesVision_Import_TradeDescription_File",
                                   "{'SalesVisionTransCode':'CLTMSTR<env:upper:TEST-T_,PROD->ADX_LQE_TransCode_Files_<COB:%Y-%m-%d:0>*'}",
                                   "{'SalesVisionTransCode': 'ETL/data/salesvision/CLTMSTR<env:upper:TEST-T_,PROD->ADX_LQE_TransCode_Files_<COB:%Y-%m-%d:0>.CSV.gz'}",
                                   "ClientMaster",
                                   "feed_FM.getSalesVisionLQE",
                                   "",
                                   control_check_threshold.to_dict(),
                                   function_and_parameter.to_dict(),
                                   function_and_parameter.to_dict(),
                                   time_window.to_dict(),
                                   "16:00:00",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   now_string,
                                   onehundred_years_from_now_string)

    SalesVision_Import_TradeDescription_ETL = FeedDefinition("SalesVision_Import_TradeDescription_File",
                                      "SalesVision_Import_TradeDescription_ETL",
                                      "{'emr': 's3://lazard-<ENV:lower>-client-master/ETL/data/salesvision/CLTMSTR<env"
                                      ":upper:TEST-T_,PROD->ADX_LQE_TransCode_Files_<COB:%Y-%m-%d:0>.CSV.gz',"
                                      "'source':'SV'}",
                                      "{'emr':'s3://lazard-<ENV:lower>-client-master/etl-output/salesvision/trade_code/'}",
                                      "ClientMaster",
                                      "feed_functions.run_emr_and_generate_stats",
                                      "",
                                      control_check_threshold.to_dict(),
                                      function_and_parameter.to_dict(),
                                      function_and_parameter.to_dict(),
                                      time_window.to_dict(),
                                      "16:00:00",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      "cahalym@lazard.com;cahalym@lazard.com",
                                      now_string,
                                      onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(SalesVision_Import_TradeDescription_File)
    feed_api.registerFeedDefinition(SalesVision_Import_TradeDescription_ETL)

    SalesVision_Import_Conf_Merge_Generator = FeedDefinition("SalesVision_Import_FopMerge_File",
                                       "SalesVision_Import_Conf_Merge_Generator",
                                       "{'emr': 's3://lazard-<ENV:lower>-client-master/CIRCE/data/salesvision/<env:upper:TEST-TEST_,PROD->salesvision_merge_profile_<COB:%m_%d_%Y:-1>.gz'}",
                                       "{'circe_conf_dir':'CIRCE/conf/SV/incoming/'}",
                                       "ClientMaster",
                                       "feed_functions.gen_push_circe_conf",
                                       "",
                                       control_check_threshold.to_dict(),
                                       function_and_parameter.to_dict(),
                                       function_and_parameter.to_dict(),
                                       time_window.to_dict(),
                                       "16:00:00",
                                       "cahalym@lazard.com;cahalym@lazard.com",
                                       "cahalym@lazard.com;cahalym@lazard.com",
                                       now_string,
                                       onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(SalesVision_Import_Conf_Merge_Generator)

    SalesVision_Import_MDM = FeedDefinition("SalesVision_Import_Firm_ETL, SalesVision_Import_Office_ETL, SalesVision_Import_Person_ETL, SalesVision_Import_Holding_ETL, SalesVision_Import_SalesHierarchy_ETL, SalesVision_Import_Trade_ETL, SalesVision_Import_Asset_ETL, SalesVision_Import_SalesPerson_ETL, SalesVision_Import_TradeDescription_ETL",
                                       "SalesVision_Import_MDM",
                                       "{'mdm_conf_dir':'s3://lazard-<ENV:lower>-client-master/MDM/conf/SV/incoming/','mdm_prefix':'SV'}",
                                       '',
                                       "ClientMaster",
                                       "feed_functions.run_emr_and_generate_stats",
                                       "",
                                       control_check_threshold.to_dict(),
                                       function_and_parameter.to_dict(),
                                       function_and_parameter.to_dict(),
                                       time_window.to_dict(),
                                       "16:00:00",
                                       "cahalym@lazard.com;cahalym@lazard.com",
                                       "cahalym@lazard.com;cahalym@lazard.com",
                                       now_string,
                                       onehundred_years_from_now_string)
    feed_api.registerFeedDefinition(SalesVision_Import_MDM)

    SalesVision_Import_Merge_FOP_Circe = FeedDefinition("SalesVision_Import_Conf_Merge_Generator, SalesVision_Import_MDM",
                                       "SalesVision_Import_Merge_FOP_Circe",
                                       "{'circe_conf_dir':'s3://lazard-<ENV:lower>-client-master/CIRCE/conf/SV/incoming/','circe_prefix':'SV'}",
                                       '',
                                       "ClientMaster",
                                       "feed_functions.run_emr_and_generate_stats",
                                       "",
                                       control_check_threshold.to_dict(),
                                       function_and_parameter.to_dict(),
                                       function_and_parameter.to_dict(),
                                       time_window.to_dict(),
                                       "16:00:00",
                                       "cahalym@lazard.com;cahalym@lazard.com",
                                       "cahalym@lazard.com;cahalym@lazard.com",
                                       now_string,
                                       onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(SalesVision_Import_Merge_FOP_Circe)

############################################# SalesVision Output FOP ###################################################


    SalesVision_Export_FOP_DBSync = FeedDefinition("",
                                   "SalesVision_Export_FOP_DBSync",
                                   "{'dbsync_param':'sv_fopm_export','emr_function':'dbsync'}",
                                   "",
                                   "ClientMaster",
                                   "feed_functions.run_emr_and_generate_stats",
                                   "",
                                   control_check_threshold.to_dict(),
                                   function_and_parameter.to_dict(),
                                   function_and_parameter.to_dict(),
                                   time_window.to_dict(),
                                   "16:00:00",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   now_string,
                                   onehundred_years_from_now_string)

    SalesVision_Export_FOP_File = FeedDefinition("",
                                   "SalesVision_Export_FOP_File",
                                   "{'firm': 'crm_firm_profile_<COB:%m_%d_%Y:0>', 'office': "
                                   "'crm_office_profile_<COB:%m_%d_%Y:0>', 'person': "
                                   "'crm_person_profile_<COB:%m_%d_%Y:0>', 'merge': "
                                   "'crm_merge_profile_<COB:%m_%d_%Y:0>'}",
                                   "{'firm': '/ETL/data/SalesVision/crm_firm_profile_<COB:%m_%d_%Y:0>.gz', 'office': "
                                   "'/ETL/data/SalesVision/crm_office_profile_<COB:%m_%d_%Y:0>.gz', 'person': "
                                   "'/ETL/data/SalesVision/crm_person_profile_<COB:%m_%d_%Y:0>.gz', "
                                   "'merge': '/ETL/data/SalesVision/crm_merge_profile_<COB:%m_%d_%Y:0>.gz'}",
                                   "ClientMaster",
                                   "feed_functions.sv_generator_fop",
                                   "",
                                   control_check_threshold.to_dict(),
                                   function_and_parameter.to_dict(),
                                   function_and_parameter.to_dict(),
                                   time_window.to_dict(),
                                   "16:00:00",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   now_string,
                                   onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(SalesVision_Export_FOP_DBSync)
    feed_api.registerFeedDefinition(SalesVision_Export_FOP_File)




############################################# Reference Data ###################################################

    Reference_Data_Import_ShareClass_File = FeedDefinition("",
                                   "Reference_Data_Import_ShareClass_File",
                                   "{'filenameToSaveQuery': 'share_class_enum_data_<COB:%m-%d-%Y:0>.csv'}",
                                   "{'filenameToSaveQuery': '/ETL/data/ReferenceData/ShareClassEnum/share_class_enum_data_<COB:%m-%d-%Y:0>.csv.gz'}",
                                   "ClientMaster",
                                   "feed_FM.ref_data_send_to_s3",
                                   "",
                                   control_check_threshold.to_dict(),
                                   function_and_parameter.to_dict(),
                                   function_and_parameter.to_dict(),
                                   time_window.to_dict(),
                                   "16:00:00",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   now_string,
                                   onehundred_years_from_now_string)

    Reference_Data_Import_ShareClass_ETL = FeedDefinition("",
                                   "Reference_Data_Import_ShareClass_ETL",
                                   "{'emr': 's3://lazard-<ENV:lower>-client-master/ETL/data/ReferenceData/ShareClassEnum/share_class_enum_data_<COB:%m-%d-%Y:0>.csv.gz', 'source': 'enum'}",
                                   "{'emr':'s3://lazard-<ENV:lower>-client-master/etl-output/salesvision/share_class_enum/'}",
                                   "ClientMaster",
                                   "feed_functions.run_emr_and_generate_stats",
                                   "",
                                   control_check_threshold.to_dict(),
                                   function_and_parameter.to_dict(),
                                   function_and_parameter.to_dict(),
                                   time_window.to_dict(),
                                   "16:00:00",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   now_string,
                                   onehundred_years_from_now_string)


    feed_api.registerFeedDefinition(Reference_Data_Import_ShareClass_File)
    feed_api.registerFeedDefinition(Reference_Data_Import_ShareClass_ETL)

############################################# FX Rate ###################################################
    Reference_Data_Import_FXRateConversion_File = FeedDefinition("",
                                   "Reference_Data_Import_FXRateConversion_File",
                                   "{'filenameToSaveQuery':'fx_rate_conversion_<COB:%m-%d-%Y:0>.csv', 'startDate':'01-01-2020'}",
                                   "{'filenameToSaveQuery':'/ETL/data/ReferenceData/FXRate/fx_rate_conversion_<COB:%m-%d-%Y:0>.csv.gz'}",
                                   "ClientMaster",
                                   "feed_FM.fx_rate_conversion_send_to_s3",
                                   "",
                                   control_check_threshold.to_dict(),
                                   function_and_parameter.to_dict(),
                                   function_and_parameter.to_dict(),
                                   time_window.to_dict(),
                                   "16:00:00",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   now_string,
                                   onehundred_years_from_now_string)

    Reference_Data_Import_FXRateConversion_ETL = FeedDefinition("",
                                   "Reference_Data_Import_FXRateConversion_ETL",
                                   "{'emr':'s3://lazard-<ENV:lower>-client-master/ETL/data/ReferenceData/FXRate/fx_rate_conversion_<COB:%m-%d-%Y:0>.csv.gz', 'source':'conversion'}",
                                   "{'emr':'s3://lazard-<ENV:lower>-client-master/etl-output/salesvision/fx_rate/'}",
                                   "ClientMaster",
                                   "feed_functions.run_emr_and_generate_stats",
                                   "",
                                   control_check_threshold.to_dict(),
                                   function_and_parameter.to_dict(),
                                   function_and_parameter.to_dict(),
                                   time_window.to_dict(),
                                   "16:00:00",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   "cahalym@lazard.com;cahalym@lazard.com",
                                   now_string,
                                   onehundred_years_from_now_string)

    feed_api.registerFeedDefinition(Reference_Data_Import_FXRateConversion_File)
    feed_api.registerFeedDefinition(Reference_Data_Import_FXRateConversion_ETL)

    SalesForce_Import_Merge_File = FeedDefinition("",
                                          "SalesForce_Import_Merge_File",
                                          "{'SalesForce':'/salesforceFTP/incoming/MergeAttempt12-02-2020.csv'}",
                                          [
                                            "{'output_directory':'CIRCE/data/salesforce/salesforce_merge_profile_<COB:%m_%d_%Y:0>.gz'}",
                                            "{ 'emr': 'CIRCE/conf/SF/incoming/salesforce_merge_profile_<COB:%m_%d_%Y:0>_%JOBID%.conf'}"
                                          ],
                                          "ClientMaster",
                                          "feed_FM.salesforceGenerateMergeConf",
                                          "",
                                          control_check_threshold.to_dict(),
                                          function_and_parameter.to_dict(),
                                          function_and_parameter.to_dict(),
                                          time_window.to_dict(),
                                          "16:00:00",
                                          "cahalym@lazard.com;cahalym@lazard.com",
                                          "cahalym@lazard.com;cahalym@lazard.com",
                                          now_string,
                                          onehundred_years_from_now_string)
    feed_api.registerFeedDefinition(SalesForce_Import_Merge_File)





if __name__ == "__main__":
    main(sys.argv[1:])
