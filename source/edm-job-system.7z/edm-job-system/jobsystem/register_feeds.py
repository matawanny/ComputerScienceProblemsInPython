import json
import os
import sys

from jobsystem.FeedDefinition import *


def main(args):
    # with open('config/fish_tank_registration.json') as f:
    #     d = json.load(f)
    #
    # for k, v in d['feed_definitions'].items():
    #     print(k)
    #     print(v['input_file'])
    #     print(v['output_file'])
    #     print(v['function'])
    if len(args) > 0:
        environment = args[1]
    else:
        environment = "test"

    print(f"Environment is being set to {environment}")
    load_all_feeds(environment)


def load_data_source(file_name, env):
    data_source = json.load(file_name)
    for key, value in data_source:
        feed_definiton = FeedDefinition(**value)
        feed_definiton.upsert(env)


def load_all_feeds(files_path, env):
    if os.path.isfile(files_path):
        load_data_source(files_path, env)
    elif os.path.isdir(files_path):
        for dirpath, dirnames, filenames in os.walk(files_path):
            for filename in filenames:
                if 'json' in filename:
                    load_data_source(filename, env)


# def load_all_feeds(env):
#     feed_api = FeedAPI(env)
#
#     now = datetime.now()
#     now_string = now.strftime("%Y-%m-%d, %H:%M:%S")
#     onehundred_years_from_now = now + relativedelta(years=100)
#     onehundred_years_from_now_string = onehundred_years_from_now.strftime("%Y-%m-%d, %H:%M:%S")
#     time_window = TimeWindow(now_string, onehundred_years_from_now_string)
#
#     function_and_parameter = FunctionAndParameter("", "")
#     control_check_threshold = ControlCheckThreshold("")
#
#
#     json_files = [f"config/{f}" for f in os.listdir('config') if f.endswith('json')]
#     print(json_files)
#     for file in json_files:
#         list_feeds =[]
#         with open(file) as f:
#          d = json.load(f)
#
#         for feed_name, values in d['feed_definitions'].items():
#             feed_definition = FeedDefinition("",
#                                  feed_name,
#                                  values['input_file'],
#                                  values['output_file'],
#                                  "ClientMaster",
#                                  values["function"],
#                                  "",
#                                  control_check_threshold.to_dict(),
#                                  function_and_parameter.to_dict(),
#                                  function_and_parameter.to_dict(),
#                                  time_window.to_dict(),
#                                  "16:00:00",
#                                  "cahalym@lazard.com;cahalym@lazard.com",
#                                  "cahalym@lazard.com;cahalym@lazard.com",
#                                  now_string,
#                                  onehundred_years_from_now_string)
#             list_feeds.append(feed_definition)
#         insert_into_dynamo(list_feeds,feed_api)


if __name__ == "__main__":
    main(sys.argv[1:])
