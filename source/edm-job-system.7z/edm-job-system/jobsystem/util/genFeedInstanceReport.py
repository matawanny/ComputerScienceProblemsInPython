import os
import pprint

import boto3
import pandas as pd
from boto3.dynamodb.conditions import Attr

from common.envconfig import ENVS
from common.utils import send_email


def assumeRole(env):
    # code to refresh aws credentials
    script =  ENVS[env]['assumerole']
    os.system(script + " > /dev/null")

def getLoadedCounts(x):
   loadedRecordCountStr = ""
   if x is None or x == {}:
      return ""

   if isinstance(x, dict):
      for t in x:
           loadedRecordCountStr += " {0}:{1},".format(t, x[t])
           loadedRecordCountStr = loadedRecordCountStr[:-1]
      return loadedRecordCountStr
   return str(x)

def queryDynamoDB(dynamodb_table, attr, cob):
    dynamoDB = boto3.resource('dynamodb')
    table = dynamoDB.Table(dynamodb_table)
    scan_kwargs = {
        'FilterExpression': Attr(attr).contains(cob)
    }
    done = False
    start_key = None
    all_items = []
    while not done:
        if start_key:
            scan_kwargs['ExclusiveStartKey'] = start_key
        response = table.scan(**scan_kwargs)
        items = response.get('Items', [])
        start_key = response.get('LastEvaluatedKey', None)
        done = start_key is None
        all_items.extend(items)
    return all_items


class feedInstanceReport:

    def __init__(self, parameters):
        self.env = parameters.get('env', 'test')
        self.cob = parameters['cob']
        self.cob_stripped = parameters['cob'].replace("-", "")
        self.to_email = parameters['to_email']
        if self.to_email and "," in self.to_email:
            self.to_email_list = self.to_email.spint(",")
        else:
            self.to_email_list = [self.to_email]
        self.email = True if 'email' in parameters and parameters['email'] else False
        self.rename_dict = {'job_end': 'End', 'job_start': 'Start', 'LoadedRecordCount': 'Loaded',
                            'FilteredRecordCount': 'Filtered', 'CloseOfBusinessDay': 'COB',
                            'job_status': 'Status', 'ErroredRecordCount': 'Errors'
                            }

    def get_subject(self):
        return "FeedInstance status report for {0} - {1} ".format(self.cob, self.env)

    @staticmethod
    def strip_datasource(feedID):
        str_list = feedID.split("_")
        if len(str_list) > 3:
            return "_".join(str_list[:-2])
        else:
            return "_".join(str_list[:-1])

    @staticmethod
    def strip_feed(feedID):
        str_list = feedID.split("_")
        if len(str_list) > 3:
            return "_".join(str_list[-2:])
        else:
            return "_".join(str_list[-1:])

    @staticmethod
    def format_recordcount(recordCounts):
        # if type(recordCounts) == dict:
        #      return  ", ".join("=".join(_) for _ in recordCounts.items())
        # else:
        return recordCount

    class feedInstanceReport:

        def __init__(self, parameters):
            self.env = parameters.get('env', 'test')
            self.cob = parameters['cob']
            self.cob_stripped = parameters['cob'].replace("-", "")
            self.to_email = parameters['to_email']
            if self.to_email and "," in self.to_email:
                self.to_email_list = self.to_email.spint(",")
            else:
                self.to_email_list = [self.to_email]
            self.email = True if 'email' in parameters and parameters['email'] else False
            self.rename_dict = {'job_end': 'End', 'job_start': 'Start', 'LoadedRecordCount': 'Loaded',
                                'FilteredRecordCount': 'Filtered', 'CloseOfBusinessDay': 'COB',
                                'job_status': 'Status', 'ErroredRecordCount': 'Errors'
                                }

        def get_subject(self):
            return "FeedInstance status report for {0} - {1} ".format(self.cob, self.env)

        @staticmethod
        def strip_datasource(feedID):
            str_list = feedID.split("_")
            if len(str_list) > 3:
                return "_".join(str_list[:-2])
            else:
                return "_".join(str_list[:-1])

        @staticmethod
        def strip_feed(feedID):
            str_list = feedID.split("_")
            if len(str_list) > 3:
                return "_".join(str_list[-2:])
            else:
                return "_".join(str_list[-1:])

        @staticmethod
        def format_recordcount(recordCounts):
            # if type(recordCounts) == dict:
            #      return  ", ".join("=".join(_) for _ in recordCounts.items())
            # else:
            return recordCount

    def gen_report(self):

        feed_items = queryDynamoDB("feedInstance", "CloseOfBusinessDay", self.cob)
        job_items = queryDynamoDB("OpswiseJobStatus", "jobdate", self.cob_stripped)
        pprint.pprint(feed_items)

        df_feed = pd.DataFrame(feed_items)
        df_job = pd.DataFrame(job_items)
        df = pd.merge(left=df_feed, right=df_job, how='left', left_on='JobID', right_on='jobid', indicator=False)
        # print(df.feedID.unique)

        df['Feed'] = df['feedID'].apply(self.strip_feed)
        df['DataSource'] = df['feedID'].apply(self.strip_datasource)

        # df['LoadedRecordCount'] = df['LoadedRecordCount'].apply(self.format_recordcount)

        final_table_columns = ['CloseOfBusinessDay', 'DataSource', 'Feed', 'job_start', 'job_end', 'job_status',
                               'LoadedRecordCount', 'FilteredRecordCount', 'ErroredRecordCount']
        df = df.drop(columns=[col for col in df if col not in final_table_columns])
        df = df.sort_values('job_start')

        df['job_start'] = pd.to_datetime(df['job_start'], format='%Y%m%d %H:%M:%S')
        df['job_start'] = df['job_start'].dt.strftime('%m/%d %H:%M')

        df['job_end'] = pd.to_datetime(df['job_end'], format='%Y%m%d %H:%M:%S')
        df['job_end'] = df['job_end'].dt.strftime('%m/%d %H:%M')

        print(df)
        df = df[final_table_columns]
        df.rename(self.rename_dict, axis='columns', inplace=True)
        # output = build_table(df, 'blue_light', font_size = 'medium', font_family = 'Century Gothic', text_align = 'right')
        output = df.to_html(index=False)
        if self.email:
            send_email(self.get_subject(), output, "client_master_reports@lazard.com", self.to_email_list, [])


def main(jobId, codeToRun, targetMachine, env, cob=None, inputs=None, outputs=None, alias=None, parameters=None,  dryRun=None):
    assumeRole(parameters.get('env', "test"))
    print(parameters)
    report = feedInstanceReport(parameters)
    report.gen_report()

if __name__ == "__main__":
    parameters = eval("{'cob': '2020-12-22','to_email':'ron.tovbin@lazard.com','email':True}")
    main(1, "util.genFeedInstanceReport.main", "DUMMMY", "test", parameters=parameters)
