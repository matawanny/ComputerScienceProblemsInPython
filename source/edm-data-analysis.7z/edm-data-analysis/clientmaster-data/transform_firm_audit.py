import sys
import pandas as pd
import shutil
from common.envconfig import *
from common.database import PostgreSQL
from pandas import DataFrame

DB_SWITCH="sv_init_3"
filename="salesvision_firm_profile_2020-08-07"
outputfilename="firm_output"

print("Running with the following parameters:")
print("\tDB_SWITCH = %s" % DB_SWITCH)
print("\tCM FIRM Audit File = %s" % filename)
print("\tOutput Filename = %s" % outputfilename )
print()

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', -1)

firm_header = "firm_id|firm_name|address_line_1|address_line_2|address_city|address_state|address_zip|address_country|crm_firm_id|event_code|crm_svc_req_id|firm_status|firm_type|parent_firm|created_on|created_by|updated_on|updated_by|FIR_END_DATE"
orig_firm_header = "firm_id|firm_name|address_line_1|address_line_2|address_city|address_state|address_zip|address_country|crm_firm_id|firm_type|parent_firm|created_on|created_by|updated_on|updated_by|FIR_END_DATE"

target_header=firm_header
orig_header=orig_firm_header
status_field_name = "firm_status"

#get the right header field lists
fh = target_header.split("|")
orig_fh = orig_header.split("|")

print("Opening Firm audit file", filename)
df = pd.read_csv(filename, sep=",", names=orig_fh, header=None, engine="python", skiprows=2, skipfooter=1, keep_default_na=False)
print("Done reading firm audit file")
print()

#add blank columns: event_code, crm_svc_req_id, and (firm_status, office_status, or person_status)
df['event_code']='X'
df['crm_svc_req_id']=''
df[status_field_name]=''

#reorder columns to target file header
df_result=df[fh]

#read CM firms from database
print("About to query database:")
query = "select salesvision_id from stg_%s_entity where salesvision_id is not null and ended_at is null and entity_type_id='301'" % DB_SWITCH
print("query = %s" % query)

cm=pd.DataFrame(pd.np.empty((0,1)))
#with PostgreSQL("prod", "RDS") as cursor:
#	cursor.execute(query)
#	cm = DataFrame(cursor.fetchall())
cm.columns=['salesvision_id']
print("cm firm file count = %d and type=%s" % ( len(cm), type(cm) ) )
print(cm)
print("Done querying database")
print()

print("Processing data:")

def is_firm_in_cm(k):
	a = 0
	if k in cm.salesvision_id:
		a=1
	return a

df_result['sv_firm_id_exists_in_cm']=df_result['firm_id'].map( is_firm_in_cm )
df_result['sv_firm_id_is_active']=df_result['FIR_END_DATE'].map(len)==0

df_result.drop('FIR_END_DATE', 1, inplace=True)

df_result.loc[ (df_result['sv_firm_id_is_active']) & (df_result['sv_firm_id_exists_in_cm']), 'event_code']='U'
df_result.loc[ (df_result['sv_firm_id_is_active']) & ~(df_result['sv_firm_id_exists_in_cm']), 'event_code']='I'
df_result.loc[~(df_result['sv_firm_id_is_active']) & (df_result['sv_firm_id_exists_in_cm']), 'event_code']='D'

print("Removing unused records")
df_result.drop(df_result[df_result.event_code=='X'].index, inplace=True)
print("Done processing data")
print()

print("Setting firm_crm_id to null")
df_result['crm_firm_id']=""

# generate output file
print("Generating output file")
header_record = "H|2020-06-03 00:00:00|2020-06-04 10:44:43\n"
trailer_record = "T|"+str(len(df_result))+"\n"

header_file=open("temp_header","w")
header_file.write(header_record)
header_file.close()

trailer_file=open("temp_trailer","w")
trailer_file.write(trailer_record)
trailer_file.close()

df_result.to_csv("temp_data", sep="|", header=False, index=False)

with open(outputfilename, 'wb') as wfd:
	for f in ['temp_header', 'temp_data', 'temp_trailer']:
		with open(f, 'rb') as fd:
			shutil.copyfileobj(fd, wfd)
print("Done generating output file")

