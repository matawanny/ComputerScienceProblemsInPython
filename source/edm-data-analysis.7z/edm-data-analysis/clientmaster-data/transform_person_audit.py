import sys
import pandas as pd
import numpy
import shutil
from common.envconfig import *
from common.database import PostgreSQL
from pandas import DataFrame


pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)

DB_SWITCH = "sv_init_5"
SV_PERSON = "salesvision_person_profile_2020-08-07"
OUTPUT = "person_audit.csv"


##############################################################################################3
target_person_header = "firm_id|office_id|person_id|name_last|name_first|name_middle|broker_team|crm_firm_id|crm_office_id|crm_person_id|event_code|crm_svc_req_id|person_status|home_office_flag|phone|email_address|crd|broker_rep_code|created_on|created_by|updated_on|updated_by"
orig_person_header="firm_id|office_id|person_id|name_last|name_first|name_middle|broker_team|crm_firm_id|crm_office_id|crm_person_id|home_office_flag|phone|email_address|crd|broker_rep_code|created_on|created_by|updated_on|updated_by|end_date"

# Read the Person audit file and transform to the right schema
svPerson = pd.read_csv(SV_PERSON, sep=",", names=orig_person_header.split("|"), header=None, engine="python", skiprows=2, skipfooter=1, dtype={"firm_id":str, "office_id":str, "person_id":str,"created_on":str,"updated_on":str},
                 keep_default_na=False)
print(f"done reading SV PERSON. rows={svPerson.shape[0]}")
svPerson.end_date.where(svPerson.end_date.isnull(), "keep", inplace=True)
svPerson.end_date.where(svPerson.end_date.notnull(), "delete", inplace=True)
print(f"rows in svPerson NON_END_DATED = {svPerson['end_date'].str.contains('keep').shape[0]}")
svPerson['event_code'] = 'X'
svPerson['crm_svc_req_id'] = ''
svPerson['person_status'] = ''

print("About to query database:")
query = """select 
    parent.salesvision_id as cm_parent_id, 
    person.salesvision_id as cm_person_id, 
    parent.persistence_id as cm_parent_persistence_id, 
    person.persistence_id as cm_person_persistence_id,
    parent.entity_type_id as cm_parent_entity_type_id
from stg_%s_entity person
join stg_%s_entity parent on parent.entity_id=person.parent_id
where
person.entity_type_id='101'
and
person.ended_at is null
and
person.salesvision_id is not null
""" % (DB_SWITCH, DB_SWITCH)
print("query = %s" % query)
cmPerson = pd.DataFrame(numpy.empty((0,5)))
#with PostgreSQL("prod", "RDS") as cursor:
#	cursor.execute(query)
#	cmPerson = DataFrame(cursor.fetchall())
cmPerson.columns=['cm_parent_id ', 'cm_person_id', 'cm_parent_persistence_id', 'cm_person_persistence_id', 'cm_parent_entity_type_id']
print("done querying database\n")


print(f"done reading CM PERSON rows={cmPerson.shape[0]}")
print(f"rows with NULL={cmPerson['cm_person_id'].isnull().shape[0]}")
sv_cm_outerJoin = pd.merge(left=svPerson, right=cmPerson, left_on="person_id", right_on="cm_person_id", how="outer", indicator=True)
joinGroups={}
for joinType, joinResult in sv_cm_outerJoin.groupby("_merge"):
        joinGroups[joinType]=joinResult

# Delete persons found only in CM and not SV
print("CM Only")
personsInCMOnly = joinGroups["right_only"]
personsInCMOnly["person_id"]=personsInCMOnly["cm_person_id"]
personsInCMOnly["person_id"]=personsInCMOnly["cm_person_id"]
personsInCMOnly["person_id"]=personsInCMOnly["cm_person_id"]

personsInCMOnly["event_code"] = "D"
print(f"rows personsInCMOnly = {personsInCMOnly.shape[0]}")

# Insert non-end-dated persons found in SV but not in CM
print("SV Only")
personsInSVOnly = joinGroups["left_only"]
print(f"rows personsInSVOnly = {personsInSVOnly.shape[0]}")
personsInSVOnly = personsInSVOnly[personsInSVOnly["end_date"].str.contains("keep")]    # remove SV end-dated persons
personsInSVOnly['event_code'] = 'I'
print(f"rows in personInSVOnly NON_END_DATED = {personsInSVOnly.shape[0]}")

# Delete SV end-dated persons found in SV and CM, updated the rest
print("BOTH")
personsInCMAndSV = joinGroups["both"]
print(f"rows personsInCMAndSV = {personsInCMAndSV.shape[0]}")
joinGroups={}
for joinType, joinResult in personsInCMAndSV.groupby("end_date"):
        joinGroups[joinType]=joinResult
personsInCMAndSV = None
if "delete" in joinGroups.keys():
        deletePersons = joinGroups["delete"]
        deletePersons['event_code'] = 'D'
        personsInCMAndSV = deletePersons
        print(f"rows in BOTH Delete = {personsInCMAndSV.shape[0]}")
if "keep" in joinGroups.keys():
        updatePersons = joinGroups["keep"]
        updatePersons['event_code'] = 'U'
        print(f"rows in BOTH Update = {updatePersons.shape[0]}")
        personsInCMAndSV = pd.concat([updatePersons, deletePersons], ignore_index=True) if personsInCMAndSV else updatePersons

personsResult = pd.concat([personsInCMAndSV, personsInSVOnly, personsInCMOnly], ignore_index=True)
personsResult = personsResult[target_person_header.split("|")]  # reorder columns to target file header

personsResult.loc[ :, 'crm_firm_id']=""
personsResult.loc[ :, 'crm_office_id']=""
personsResult.loc[ :, 'crm_person_id']=""

# generate output file
header_record = "H|2020-06-03 00:00:00|2020-06-04 10:44:43\n"
trailer_record = f"T|{personsResult.shape[0]}\n"

header_file=open("temp_header","w")
header_file.write(header_record)
header_file.close()

trailer_file=open("temp_trailer","w")
trailer_file.write(trailer_record)
trailer_file.close()

personsResult.to_csv("temp_data", sep="|", header=False, index=False)
with open(OUTPUT, 'wb') as wfd:
        for f in ['temp_header', 'temp_data', 'temp_trailer']:
                with open(f, 'rb') as fd:
                        shutil.copyfileobj(fd, wfd)

