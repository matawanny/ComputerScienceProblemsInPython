import pandas as pd
import sys
import numpy as np
import hashlib

def get_md5(row):
    return hashlib.md5(str(row['firm_id']).encode('utf-8')).hexdigest()

def get_status(row):
    if not str(row['ended_at']).strip():
        return 'ACTIVE'
    else:
        return 'NOT ACTIVE'

def get_require_pid_ack(row):
    if not str(row['crm_firm_id']).strip() and row['status']=='ACTIVE':
        return 'TRUE'
    else:
        return 'FALSE'

def get_salesvision_id(row):
    return row['firm_id']


SETTINGS = { "Firm" : {
        "sv_header":"firm_id|firm_name|address_line_1|address_line_2|address_city|address_state|address_zip|address_country|crm_firm_id|firm_type|parent_firm|created_on|created_by|updated_on|updated_by|ended_at",
        "sv_primary_key":"firm_id",
        "sf_header":"entity_id|persistence_id|entity_type_id|salesvision_id|entity_name|street_address_1|street_address_2|city|state|postal_code|country|created_at|updated_at|salesforce_id|crd|ect_channel_id|ect_entity_id|ect_team_id",
        "sf_primary_key":"salesvision_id",
        "compare_cols": [ ("crm_firm_id","persistence_id"), ("firm_name","entity_name"), ("address_line_1", "street_address_1"), ("address_line_2","street_address_2"), ("address_city", "city"),
                  ("address_state", "state"), ("address_zip", "postal_code"), ("address_country", "country"),("created_on","created_at")]
    },
    "Office": {
        "sv_header":"firm_id|office_id|address_line_1|address_line_2|address_line_3|address_city|address_state|address_zip|address_country|crm_firm_id|crm_office_id|home_office_flag|created_on|created_by|updated_on|updated_by|ended_at",
        "sv_primary_key":"office_id",
        "sf_header":"parent_entity_id|parent_persistence_id|parent_entity_type_id|parent_salesvision_id|entity_id|persistence_id|entity_type_id|salesvision_id|entity_name|street_address_1|street_address_2|city|state|postal_code|country|created_at|updated_at|salesforce_id|crd|ect_channel_id|ect_entity_id|ect_team_id",
        "sf_primary_key":"salesvision_id",
        "compare_cols": [("crm_firm_id","parent_persistence_id"),("crm_office_id","persistence_id"),("firm_id","parent_salesvision_id"), ("address_line_1", "street_address_1"), ("address_line_2","street_address_2"),  ("address_city", "city"),
                  ("address_state", "state"), ("address_zip", "postal_code"), ("address_country", "country"),("created_on","created_at")]
    },
    "Person": {
        "sv_header":"firm_id|office_id|person_id|name_last|name_first|name_middle|broker_team|crm_firm_id|crm_office_id|crm_person_id|home_office_flag|phone|email_address|crd|broker_rep_code|created_on|created_by|updated_on|updated_by|ended_at",
        "sv_primary_key":"person_id",
        "sf_header":"firm_persistence_id|firm_entity_type_id|firm_salesvision_id|firm_entity_id|office_persistence_id|office_entity_type_id|office_salesvision_id|office_entity_id|entity_id|persistence_id|entity_type_id|salesvision_id|\
entity_name|street_address_1|street_address_2|city|state|postal_code|country|created_at|updated_at|salesforce_id|crd_sf|ect_channel_id|ect_entity_id|ect_team_id|country_code|phone_number|email_address_sf",
        "sf_primary_key":"salesvision_id",
        "compare_cols": [("firm_id","firm_salesvision_id"),  ("office_id","office_salesvision_id"),
                         #("crm_firm_id","firm_persistence_id"), ("crm_office_id","office_persistence_id"), ("crm_person_id","persistence_id"),
                         ("name_last","name_last_sf"), ("name_middle", "name_middle_sf"), ("name_first", "name_first_sf"), ("broker_team", "broker_team"), ("home_office_flag","home_office_flag"), ("phone","phone"),
                         ("email_address","email_address_sf"),("crd","crd"), ("broker_rep_code","broker_rep_code")]
    }
}
sv_header = SETTINGS[type]["sv_header"]
sv_pk = SETTINGS[type]["sv_primary_key"]
sf_header = SETTINGS[type]["sf_header"]
sf_pk = SETTINGS[type]["sf_primary_key"]
compare_cols = SETTINGS[type]["compare_cols"]

type='Firm'
SV = f"C:\\data3\\CLTMSTRAUDLQE_{type}_File_2020-09-04_0000000000016.CSV"

svData = pd.read_csv(SV, sep=",", names=sv_header.split("|"), header=None, engine="python", skiprows=2,
                     dtype={"firm_id":str, "crm_firm_id":str, "created_on":str,"updated_on":str},
                     skipinitialspace = True, index_col=None, keep_default_na=False, escapechar='\\', error_bad_lines=False)
svData['salesvision_id']=svData.apply(lambda x: get_salesvision_id(x), axis=1)
svData['ideal_pid']=svData.apply(lambda x: get_md5(x), axis=1)
svData["status"]=svData.apply(lambda x: get_status(x), axis=1)
svData["require_pid_ack"]=svData.apply(lambda x: get_require_pid_ack(x), axis=1)
svData1=svData[['salesvision_id','status','ideal_pid','require_pid_ack']]

SV1 = "C:\\data3\\firm_result.CSV"
svData1.to_csv(SV1, sep=",", header=True, index=False)


