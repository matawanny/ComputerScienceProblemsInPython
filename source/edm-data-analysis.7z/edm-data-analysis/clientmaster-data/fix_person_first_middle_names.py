import sys
import pandas as pd
import numpy
import shutil
from common.envconfig import *
from common.database import PostgreSQL
from pandas import DataFrame




DB_SWITCH = "sv_init_3"
OUTPUTFILE = "first_middle.csv"

print("Running with parameters:")
print("\tDB_SWITCH = %s" % DB_SWITCH)
print("\tOUTPUTFILE= %s" % OUTPUTFILE)

pd.set_option('display.max_rows', 5)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)

target_header = "case|SV_name|SF_name|CM_update_date|SF_update_date|SV_l|SV_f|SV_m|SF_l|SF_f|SF_m|CM_l|CM_f|CM_m|CM_pid|SF_pid|CM_sv_id|SV_sv_id|SF_sv_id|CM_sf_id|SF_sf_id"
target_cols = target_header.split("|")

query="""
select 
	'' as case,

	sv.ideal_name as "SV_name",
	SF.entity_name as "SF_name",

	cm.updated_at as "CM_update_date",
	sf.updated_at as "SF_update_date", 

	split_part(sv.ideal_name, '|', 1) as "SV_l",
	split_part(sv.ideal_name, '|', 2) as "SV_f",
	split_part(sv.ideal_name, '|', 3) as "SV_m",

	split_part(sf.entity_name, '|', 1) as "SF_l",
	split_part(sf.entity_name, '|', 2) as "SF_f",
	split_part(sf.entity_name, '|', 3) as "SF_m",

	split_part(cm.entity_name, '|', 1) as "CM_l",
	split_part(cm.entity_name, '|', 2) as "CM_f",
	split_part(cm.entity_name, '|', 3) as "CM_m",
	

        upper(split_part(sv.ideal_name, '|', 1)) as "comp_SV_l",
        upper(split_part(sv.ideal_name, '|', 2)) as "comp_SV_f",
        upper(split_part(sv.ideal_name, '|', 3)) as "comp_SV_m",

        upper(split_part(sf.entity_name, '|', 1)) as "comp_SF_l",
        upper(split_part(sf.entity_name, '|', 2)) as "comp_SF_f",
        upper(split_part(sf.entity_name, '|', 3)) as "comp_SF_m",

        upper(split_part(cm.entity_name, '|', 1)) as "comp_CM_l",
        upper(split_part(cm.entity_name, '|', 2)) as "comp_CM_f",
        upper(split_part(cm.entity_name, '|', 3)) as "comp_CM_m",


	cm.persistence_id as "CM_pid",
	sf.persistence_id as "SF_pid", 

	cm.salesvision_id as "CM_sv_id",
	sv.person_id as "SV_sv_id", 
	sf.salesvision_id as "SF_sv_id", 

	cm.salesforce_id as "CM_sf_id", 
	sf.salesforce_id as "SF_sf_id"
from
stg_%s_entity cm
join sf_entity_entity sf on sf.persistence_id=cm.persistence_id and sf.entity_type_id=cm.entity_type_id
join ch_fix_name sv on sv.person_id::text=cm.salesvision_id
where
cm.entity_type_id like '10%%' and cm.ended_at is null and cm.salesvision_id is not null
order by 1, 2
""" % DB_SWITCH

#print("query = %s" % query)


p_df = None
with PostgreSQL("prod", "RDS") as cursor:
	cursor.execute(query)
	p_df = DataFrame(cursor.fetchall())

print(f"done reading db rows={p_df.shape[0]}")
print()

cols = [i[0] for i in cursor.description]
p_df.columns=cols


#Define new boolean fields depending on 'null' combinations

#Normalize NA/NONE to NULL
p_df.loc[ (p_df['comp_SV_f'].eq('NA')) | (p_df['comp_SV_f'].eq('NONE')), 'comp_SV_f']='NULL'
p_df.loc[ (p_df['comp_SF_f'].eq('NA')) | (p_df['comp_SF_f'].eq('NONE')), 'comp_SF_f']='NULL'
p_df.loc[ (p_df['comp_SV_m'].eq('NA')) | (p_df['comp_SV_m'].eq('NONE')), 'comp_SV_m']='NULL'
p_df.loc[ (p_df['comp_SF_m'].eq('NA')) | (p_df['comp_SF_m'].eq('NONE')), 'comp_SF_m']='NULL'

p_df.loc[:, 'SV_f_null'] = (p_df['comp_SV_f'].eq('NULL'))
p_df.loc[:, 'SF_f_null'] = (p_df['comp_SF_f'].eq('NULL'))
p_df.loc[:, 'SV_m_null'] = (p_df['comp_SV_m'].eq('NULL'))
p_df.loc[:, 'SF_m_null'] = (p_df['comp_SF_m'].eq('NULL'))

p_df.loc[:, 'SF_SV_names_null']=( p_df['SV_f_null'] | p_df['SF_f_null'] | p_df['SV_m_null'] | p_df['SF_m_null'] )
p_df.loc[:, 'only_SV_f_null']=(  p_df['SV_f_null'] & ~p_df['SF_f_null'] & ~p_df['SV_m_null'] & ~p_df['SF_m_null'] )
p_df.loc[:, 'only_SF_f_null']=( ~p_df['SV_f_null'] &  p_df['SF_f_null'] & ~p_df['SV_m_null'] & ~p_df['SF_m_null'] )
p_df.loc[:, 'only_SV_m_null']=( ~p_df['SV_f_null'] & ~p_df['SF_f_null'] &  p_df['SV_m_null'] & ~p_df['SF_m_null'] )
p_df.loc[:, 'only_SF_m_null']=( ~p_df['SV_f_null'] & ~p_df['SF_f_null'] & ~p_df['SV_m_null'] &  p_df['SF_m_null'] )



#All cases here

#Case 00: SF_f=SV_f and SF_m=SV_m
p_df.loc[ (p_df['comp_SF_f']==p_df['comp_SV_f']) & (p_df['comp_SF_m']==p_df['comp_SV_m']) & p_df['case'].eq(''), 'case' ] = '00'


#Case 01: SF first=L,middle=Greg and SV first=X,middle=Greg : first!=, middle==
p_df.loc[ ~(p_df['SF_SV_names_null']) & (p_df['comp_SV_f']!=p_df['comp_SF_f']) & (p_df['comp_SV_m']==p_df['comp_SF_m']) & p_df['case'].eq(''), 'case' ] = '01'

#Case 02: SF First=L,middle=Greg and SV first=L,middle=George : first==, middle!=
p_df.loc[ ~(p_df['SF_SV_names_null']) & (p_df['comp_SV_f']==p_df['comp_SF_f']) & (p_df['comp_SV_m']!=p_df['comp_SF_m']) & p_df['case'].eq('') , 'case' ] = '02'

#Case 03: SF first=L, middle=Greg and SV first=Greg,middle=L 
p_df.loc[ ~(p_df['SF_SV_names_null']) & (p_df['comp_SV_f']!=p_df['comp_SF_m']) & (p_df['comp_SV_m']==p_df['comp_SF_f']) & p_df['case'].eq('') , 'case' ] = '03'

#Case 04: SF first=L, middle=Greg and SV first=Greg,middle=X
p_df.loc[ ~(p_df['SF_SV_names_null']) & (p_df['comp_SV_f']==p_df['comp_SF_m']) & (p_df['comp_SV_m']!=p_df['comp_SF_f']) & p_df['case'].eq('') , 'case' ] = '04'

#Case 05: SF first=L, middle=Greg and SV first=George,middle=X
p_df.loc[ ~(p_df['SF_SV_names_null']) & (p_df['comp_SV_f']!=p_df['comp_SF_m']) & (p_df['comp_SV_m']!=p_df['comp_SF_f']) & (p_df['comp_SV_f']!=p_df['comp_SF_f']) & (p_df['comp_SV_m']!=p_df['comp_SF_m']) & p_df['case'].eq('') , 'case' ] = '05'

#Case 06: SF first=X, middle=Greg and SV first=Greg, middle=X : criss-crossed
p_df.loc[ ~(p_df['SF_SV_names_null']) & (p_df['comp_SV_f']==p_df['comp_SF_m']) & (p_df['comp_SV_m']==p_df['comp_SF_f']) & p_df['case'].eq('') , 'case' ] = '06'

#Case 07: SF first=null, middle=Greg and SV first=Greg, middle=X : criss-crossed and SF_f=null
p_df.loc[ p_df['only_SF_f_null'] & (p_df['comp_SV_f']==p_df['comp_SF_m']) & p_df['case'].eq('')  , 'case' ] = '07'

#Case 08: SF first=X, middle=null and SV first=Greg, middle=X : criss-crossed and SF_m=null
p_df.loc[ p_df['only_SF_m_null'] & (p_df['comp_SV_m']==p_df['comp_SF_f']) & p_df['case'].eq('') , 'case' ] = '08'

#Case 09: SF f=Greg,m=null and SV f=Greg,m=X
p_df.loc[ p_df['only_SF_m_null'] & (p_df['comp_SV_f']==p_df['comp_SF_f']) & p_df['case'].eq('') , 'case' ] = '09'

#Case 10: SF f=null,m=X and SV f=Greg,m=X
p_df.loc[ p_df['only_SF_f_null'] & (p_df['comp_SV_m']==p_df['comp_SF_m']) & p_df['case'].eq('') , 'case' ] = '10'

#Case 11: SF f=Greg,m=X and SV f=Greg,m=null
p_df.loc[ p_df['only_SV_m_null'] & (p_df['comp_SV_f']==p_df['comp_SF_f']) & p_df['case'].eq('') , 'case' ] = '11'

#Case 12: SF f=Greg,m=X and SV f=null,m=X
p_df.loc[ p_df['only_SV_f_null'] & (p_df['comp_SV_m']==p_df['comp_SF_m']) & p_df['case'].eq('') , 'case' ] = '12'

#Case 13: SF f=null,m=Greg and SV f=Greg,m=null
p_df.loc[ p_df['SF_f_null'] & ~p_df['SF_m_null'] & ~p_df['SV_f_null'] & p_df['SV_m_null'] & (p_df['comp_SV_f']==p_df['comp_SF_m']) & p_df['case'].eq('') , 'case' ] = '13'

#Case 99: Everything else
p_df.loc[ p_df['case'].eq('') , 'case' ] = '99'


print("OLD COLUMNS:")
print("p_df =\n%s" % p_df)
print()

p_df = p_df[target_cols]
print("NEW COLUMNS:")
print("p_df =\n%s" % p_df)
print()

p_df.to_csv(OUTPUTFILE, sep="~", index=False)

counts_df = p_df.groupby(['case']).size().reset_index(name='row_count')
print("Row counts:")
pd.set_option('display.max_rows', None)
print(counts_df)
print()

