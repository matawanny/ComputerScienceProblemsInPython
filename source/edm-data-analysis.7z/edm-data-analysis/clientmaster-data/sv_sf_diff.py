import pandas as pd
import numpy as np
import hashlib

def generate_md5(*args):
    if args[0] is None:
        return None
    entity_id = '_'.join(args)
    return hashlib.md5(entity_id.encode()).hexdigest()


pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)

type = "Person"
SV = f"CLTMSTRAUDLQE_{type}_File_2020-08-07_0000000000012.CSV"
SF = f"sf_{type}.csv"
changePID = True

SETTINGS = { "Firm" : {
        "sv_header":"firm_id|firm_name|address_line_1|address_line_2|address_city|address_state|address_zip|address_country|crm_firm_id|firm_type|parent_firm|created_on|created_by|updated_on|updated_by|ended_at",
        "sv_primary_key":"firm_id",
        "sf_header":"entity_id|persistence_id|entity_type_id|salesvision_id|entity_name|street_address_1|street_address_2|city|state|postal_code|country|created_at|updated_at|salesforce_id|crd|ect_channel_id|ect_entity_id|ect_team_id",
        "sf_primary_key":"salesvision_id",
        "compare_cols": [ ("crm_firm_id","persistence_id"), ("firm_name","entity_name"), ("address_line_1", "street_address_1"), ("address_line_2","street_address_2"), ("address_city", "city"),
                  ("address_state", "state"), ("address_zip", "postal_code"), ("address_country", "country"),("created_on","created_at")]
    },
    "Office": {
        "sv_header":"firm_id|office_id|address_line_1|address_line_2|address_line_3|address_city|address_state|address_zip|address_country|crm_firm_id|crm_office_id|home_office_flag|created_on|created_by|updated_on|updated_by|ended_at",
        "sv_primary_key":"office_id",
        "sf_header":"parent_entity_id|parent_persistence_id|parent_entity_type_id|parent_salesvision_id|entity_id|persistence_id|entity_type_id|salesvision_id|entity_name|street_address_1|street_address_2|city|state|postal_code|country|created_at|updated_at|salesforce_id|crd|ect_channel_id|ect_entity_id|ect_team_id",
        "sf_primary_key":"salesvision_id",
        "compare_cols": [("crm_firm_id","parent_persistence_id"),("crm_office_id","persistence_id"),("firm_id","parent_salesvision_id"), ("address_line_1", "street_address_1"), ("address_line_2","street_address_2"),  ("address_city", "city"),
                  ("address_state", "state"), ("address_zip", "postal_code"), ("address_country", "country"),("created_on","created_at")]
    },
    "Person": {
        "sv_header":"firm_id|office_id|person_id|name_last|name_first|name_middle|broker_team|crm_firm_id|crm_office_id|crm_person_id|home_office_flag|phone|email_address|crd|broker_rep_code|created_on|created_by|updated_on|updated_by|ended_at",
        "sv_primary_key":"person_id",
        "sf_header":"firm_persistence_id|firm_entity_type_id|firm_salesvision_id|firm_entity_id|office_persistence_id|office_entity_type_id|office_salesvision_id|office_entity_id|entity_id|persistence_id|entity_type_id|salesvision_id|\
entity_name|street_address_1|street_address_2|city|state|postal_code|country|created_at|updated_at|salesforce_id|crd_sf|ect_channel_id|ect_entity_id|ect_team_id|country_code|phone_number|email_address_sf",
        "sf_primary_key":"salesvision_id",
        "compare_cols": [("firm_id","firm_salesvision_id"),  ("office_id","office_salesvision_id"),
                         #("crm_firm_id","firm_persistence_id"), ("crm_office_id","office_persistence_id"), ("crm_person_id","persistence_id"),
                         ("name_last","name_last_sf"), ("name_middle", "name_middle_sf"), ("name_first", "name_first_sf"), ("broker_team", "broker_team"), ("home_office_flag","home_office_flag"), ("phone","phone"),
                         ("email_address","email_address_sf"),("crd","crd"), ("broker_rep_code","broker_rep_code")]
    }
}
sv_header = SETTINGS[type]["sv_header"]
sv_pk = SETTINGS[type]["sv_primary_key"]
sf_header = SETTINGS[type]["sf_header"]
sf_pk = SETTINGS[type]["sf_primary_key"]
compare_cols = SETTINGS[type]["compare_cols"]

# Read the Person audit file and transform to the right schema
svData = pd.read_csv(SV, sep=",", names=sv_header.split("|"), header=None, engine="python", skiprows=2,
                     skipinitialspace=True, index_col=None, keep_default_na=False, escapechar='\\', error_bad_lines=False)
#personAudit["office_id"] = personAudit["office_id"].str.encode('utf-8')
print(f"done reading SalesVision {type}. rows={svData.shape[0]}")
svData=svData.loc[svData["ended_at"]== ""]    # filter out end-dated records
svData=svData.replace('N/A', '')
svData=svData.replace('UNKNOWN', '')

if type == "Firm":
    svData['crm_firm_id'] = svData.apply(lambda x: generate_md5(x['firm_id', 'firm']), axis=1)
elif type == 'Office':
    svData['crm_firm_id'] = svData.apply(lambda x: generate_md5(x['firm_id', 'firm']), axis=1)
    svData['crm_office_id'] = svData.apply(lambda x: generate_md5(x['office_id'], 'office'), axis=1)
else:
    svData['crm_firm_id'] = svData.apply(lambda x: generate_md5(x['firm_id'], 'firm'), axis=1)
    svData['crm_office_id'] = svData.apply(lambda x: generate_md5(x['office_id'], 'office'), axis=1)
    svData['crm_person_id'] = svData.apply(lambda x: generate_md5(x['person_id', 'person']), axis=1)

#print(personAudit['office_id'].dtypes)
#svPerson.astype({c: int for c in ["firm_id","office_id","person_id","created_on","updated_on"]})
#personAudit = personAudit[personAudit.ended_at.isnull()]  # filter out end-dated records
#col = personAudit["person_id"]
#col = personAudit.iloc[0:10,0]
#print(col.iloc[0:10])
#print(f"rows in svPerson NON_END_DATED = {svPerson['end_date'].str.contains('keep').shape[0]}")

sfData = pd.read_csv(SF, sep="|", names=sf_header.split("|"), header=None, engine="python", skiprows=1, skipfooter=0, dtype="string", skipinitialspace = True, index_col=None, keep_default_na=False)
sfData=sfData.replace('None', '')
sfData=sfData.replace('edm_exempt', '')
#sfData.fillna('', inplace=True)

if type in ("Office","Firm"):
    svData.loc[svData['address_state'].str.startswith('US-'), 'address_state'] = svData.loc[
        svData['address_state'].str.contains('-'), 'address_state'].str[-2:]
    #svData.loc[svData['address_state'].str.startswith('CA-'), 'address_state'] = svData.loc[
        #svData['address_state'].str.startswith('CA-'), 'address_state'].str.replace("CA-","")
else:
    sfData[['name_last_sf', 'name_first_sf', 'name_middle_sf']] = sfData['entity_name'].str.split("|",expand=True)
    sfData.drop(['entity_name'], axis=1)
    SETTINGS["Person"]["sf_header"] = "firm_persistence_id|firm_entity_type_id|firm_salesvision_id|firm_entity_id|office_persistence_id|office_entity_type_id|office_salesvision_id|office_entity_id|entity_id|persistence_id|entity_type_id|salesvision_id|\
    name_last_sf|name_first_sf|name_middle_sf|street_address_1|street_address_2|city|state|postal_code|country|created_at|updated_at|salesforce_id|crd_sf|ect_channel_id|ect_entity_id|ect_team_id|country_code|phone_number|email_address_sf",

#personAcknowledge["office_id"] = personAcknowledge["office_id"].str.encode('utf-8')
#col = personAcknowledge["person_id"]
#print(col.iloc[0:10])
print(f"done reading Salesforce {type}. rows={sfData.shape[0]}")
#print(personAcknowledge['office_id'].dtypes)

sv_sf_outerJoin = pd.merge(left=svData, right=sfData, left_on=sv_pk, right_on=sf_pk, how="outer", indicator=True)
#print(sv_cm_outerJoin.iloc[0:10])
joinGroups={}
for joinType, joinResult in sv_sf_outerJoin.groupby("_merge"):
        joinGroups[joinType]=joinResult

sfOnly = joinGroups["right_only"]
svOnly = joinGroups["left_only"]
print("BOTH")
svANDsf = joinGroups["both"]
svANDsf = svANDsf.drop(columns=["_merge"])

#print(f"{personsAcknowledged.iloc[0:2]}")
print(f"rows svANDsf = {svANDsf.shape[0]}")
resultHeader = [h for h in sv_header.split("|")] + [i for i in sf_header.split("|")]
resultHeader.remove(sf_pk)

result = pd.DataFrame(columns = resultHeader)    # create empty dataframe with the right schema
#print(f"resultHeader {resultHeader}")
result.insert(0, "fields_changed", "", allow_duplicates=False)
stats = {}
for svCol, sfCol in compare_cols:
    diffRows = svANDsf.loc[svANDsf[svCol].str.lower() != svANDsf[sfCol].str.lower()]
    if diffRows.shape[0]:
        #print(f"diffRows: {diffRows}")
        diffRows.insert(0, "fields_changed", sfCol, allow_duplicates=False)
        #print(f"diffRows {diffRows.iloc[0:1]}")
        result = pd.concat([result, diffRows], ignore_index=True)
        stats[f"SV {svCol} vs. SF {sfCol}"]=diffRows.shape[0]
    else:
        pass
#result.groupby('person_id').agg({"fields_changed":lambda x: x.tolist()})

# generate output file
result.to_csv(f"{type}_diff_both", sep="|", header=True, index=False)  # both
sfOnly = sfOnly[sf_header.split("|")]
sfOnly.columns = sf_header.split("|")
sfOnly.to_csv(f"{type}_sf_only", sep="|", header=True, index=False)
svOnly = svOnly[sv_header.split("|")]
svOnly.columns = sv_header.split("|")
svOnly.to_csv(f"{type}_sv_only", sep="|", header=True, index=False)

print("STATISTICS")
print(f"{type}s ONLY in SalesVision : {svOnly.shape[0]}")
print(f"{type}s ONLY in Salesforce : {sfOnly.shape[0]}")
print(f"{type}s in both : {svANDsf.shape[0]}")
for colPair in stats.keys():
    print(f"   {colPair} : {stats[colPair]}")
