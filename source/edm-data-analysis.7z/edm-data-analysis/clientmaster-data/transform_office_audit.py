import sys
import numpy
import pandas as pd
import shutil
from common.envconfig import *
from common.database import PostgreSQL

from pandas import DataFrame

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)


DB_SWITCH="sv_init_5"
filename="salesvision_office_profile_2020-08-07"
outputfilename="office_output"

firm_header = "firm_id|firm_name|address_line_1|address_line_2|address_city|address_state|address_zip|address_country|crm_firm_id|event_code|crm_svc_req_id|firm_status|firm_type|parent_firm|created_on|created_by|updated_on|updated_by|FIR_END_DATE18"
orig_firm_header = "firm_id|firm_name|address_line_1|address_line_2|address_city|address_state|address_zip|address_country|crm_firm_id|firm_type|parent_firm|created_on|created_by|updated_on|updated_by|FIR_END_DATE18"

office_header = "firm_id|office_id|address_line_1|address_line_2|address_line_3|address_city|address_state|address_zip|address_country|crm_firm_id|crm_office_id|event_code|crm_svc_req_id|office_status|home_office_flag|created_on|created_by|updated_on|updated_by"
orig_office_header = "firm_id|office_id|address_line_1|address_line_2|address_line_3|address_city|address_state|address_zip|address_country|crm_firm_id|crm_office_id|home_office_flag|created_on|created_by|updated_on|updated_by|OFL_END_DATE15"



print("Running with the following parameters:")
print("\tDB_SWITCH = %s" %DB_SWITCH)
print("\tCM OFFICE Audit File = %s" %filename)
print ("\tOutput Filename = %s" % outputfilename) 
print("\n")

target_header=office_header
orig_header=orig_office_header
status_field_name="office_status"

#get the right header field lists
fh = office_header.split("|")
orig_fh = orig_office_header.split("|")

print("Opening Office audit file", filename)
df_result = pd.read_csv(filename, sep=",", names=orig_fh, header=None, engine="python", skiprows=2, skipfooter=1, keep_default_na=False,dtype={"office_id":str})
print("done reading office file\n")

#add blank columns: event_code, crm_svc_req_id, and (firm_status, office_status, or person_status)
df_result['event_code']='X'
df_result['crm_svc_req_id']=''
df_result[status_field_name]=''

cm_firm_id_dict = {}

print("About to query database:")
query = """select office.salesvision_id as cm_office_id, 
	office.salesvision_id as cm_firm_id, 
	office.persistence_id as office_persistence_id
from stg_%s_entity office 
left join stg_%s_entity firm on firm.entity_id=office.parent_id
where 
office.salesvision_id is not null 
and 
office.ended_at is null 
and 
office.entity_type_id='201'
""" % (DB_SWITCH, DB_SWITCH)

print("query=%s" % query)

cm_office_file = pd.DataFrame(numpy.empty((0,3)))
#with PostgreSQL("prod", "RDS") as cursor:
#	cursor.execute(query)
#	cm_office_file  = DataFrame(cursor.fetchall())

cm_office_file.columns=['cm_office_id','cm_firm_id','office_persistence_id']


print("cm_office_file count=%d and type=%s" % ( len(cm_office_file), type(cm_office_file) ))
print("\n")

print("generating dictionary")
for ind in cm_office_file.index:
	ofc_id = cm_office_file.loc[ind,'cm_office_id']
	firm_id = cm_office_file.loc[ind,'cm_firm_id']
	cm_firm_id_dict[ofc_id]=firm_id
print("length of cm_firm_id_dict=%d" % len(cm_firm_id_dict) )
print("\n")

print("Processing dataframes")
def office_id_exists_in_cm(k):
	return ( k in cm_firm_id_dict )
def get_cm_firm_id(k):
	if k in cm_firm_id_dict:
		return str(cm_firm_id_dict[k])
	else:
		return None

df_result['cm_firm_id']= df_result['office_id'].map( get_cm_firm_id )	#sets a new column with cm firm_id, or None
df_result['sv_office_id_exists_in_cm']= df_result['office_id'].map( office_id_exists_in_cm )	#sets a new df column saying if office_id exists in cm
df_result['sv_office_is_active'] = df_result['OFL_END_DATE15'].map(len)==0	#sets a new df column saying if office_id is end-dated

df_result.loc[ (df_result['sv_office_is_active']) & (df_result['sv_office_id_exists_in_cm']),'event_code' ]='U'
df_result.loc[ (df_result['sv_office_is_active']) & ~(df_result['sv_office_id_exists_in_cm']), 'event_code' ] = 'I'
df_result.loc[~(df_result['sv_office_is_active']) & (df_result['sv_office_id_exists_in_cm']), 'event_code' ] = 'D'

mask = (df_result['event_code']=='U') & ~(df_result['cm_firm_id'] == (df_result['firm_id'].map(str)))
df_result.loc[mask, 'updated_on'] = '20200623'

df_result.drop(df_result[df_result.event_code=='X'].index, inplace=True)

df_result = df_result[fh]


print("Setting firm and office client master id's to null")
df_result.loc[ :, 'crm_firm_id']=""
df_result.loc[ :, 'crm_office_id']=""
print("Done setting firm and office client master id's to null")
print()



print("Done processing dataframes")
print("\n")


# generate output file

print("Generating output file %s" % outputfilename)
header_record = "H|2020-06-03 00:00:00|2020-06-04 10:44:43\n"
trailer_record = "T|"+str(len(df_result))+"\n"

header_file=open("temp_header","w")
header_file.write(header_record)
header_file.close()

trailer_file=open("temp_trailer","w")
trailer_file.write(trailer_record)
trailer_file.close()

df_result.to_csv("temp_data", sep="|", header=False, index=False)

with open(outputfilename, 'wb') as wfd:
	for f in ['temp_header', 'temp_data', 'temp_trailer']:
		with open(f, 'rb') as fd:
			shutil.copyfileobj(fd, wfd)
print("Done generating output file")

print("Exiting program")

